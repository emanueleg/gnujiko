<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-07-2014
 #PACKAGE: gproducts
 #DESCRIPTION: Archive functions for GProducts archives
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

function dynarcfunction_gproducts_oninheritarchive($args, $sessid, $shellid, $archiveInfo)
{

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 dynarcfunction_gproducts_updateItemCounter($sessid, $shellid, $archiveInfo, 0, $itemInfo['cat_id']);
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 if($catInfo['parent_id'])
  dynarcfunction_gproducts_updateCatCounter($sessid, $shellid, $archiveInfo, 0, $catInfo['parent_id']);
 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 if($itemInfo['old_cat_id'] != $itemInfo['cat_id'])
  dynarcfunction_gproducts_updateItemCounter($sessid, $shellid, $archiveInfo, $itemInfo['old_cat_id'], $itemInfo['cat_id']);

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 if($catInfo['old_parent_id'] != $catInfo['parent_id'])
 {
  dynarcfunction_gproducts_fixCounters($sessid, $shellid, $archiveInfo, $catInfo['old_parent_id']);
  dynarcfunction_gproducts_fixCounters($sessid, $shellid, $archiveInfo, $catInfo['parent_id']);
 }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 dynarcfunction_gproducts_fixCounters($sessid, $shellid, $archiveInfo, $catInfo['parent_id']);
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 dynarcfunction_gproducts_updateItemCounter($sessid, $shellid, $archiveInfo, $itemInfo['cat_id'], 0);
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 if($newItemInfo['old_cat_id'] != $newItemInfo['cat_id'])
  dynarcfunction_gproducts_updateItemCounter($sessid, $shellid, $archiveInfo, $newItemInfo['old_cat_id'], $newItemInfo['cat_id']);
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 if($newCatInfo['old_parent_id'] != $newCatInfo['parent_id'])
 {
  dynarcfunction_gproducts_fixCounters($sessid, $shellid, $archiveInfo, $newCatInfo['old_parent_id']);
  dynarcfunction_gproducts_fixCounters($sessid, $shellid, $archiveInfo, $newCatInfo['parent_id']);
 }

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_oncopyitem($sessid, $shellid, $archiveInfo, $cloneInfo, $srcInfo)
{
 //dynarcfunction_gproducts_updateItemCounter($sessid, $shellid, $archiveInfo, 0, $cloneInfo['cat_id']);
 /* Qui non serve l'updateItemCounter perchè viene automaticamente gia lanciata dalla funzione oncreateitem */
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_oncopycategory($sessid, $shellid, $archiveInfo, $cloneInfo, $srcInfo)
{
 //dynarcfunction_gproducts_fixCounters($sessid, $shellid, $archiveInfo, $srcInfo['parent_id']);
 /* Qui non serve l'updateCatCounter perchè viene automaticamente gia lanciata dalla funzione oncreatecategory */
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 dynarcfunction_gproducts_fixCounters($sessid, $shellid, $archiveInfo, $catInfo['parent_id']);
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 dynarcfunction_gproducts_updateItemCounter($sessid, $shellid, $archiveInfo, 0, $itemInfo['cat_id']);
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_updateItemCounter($sessid, $shellid, $archiveInfo, $oldCatId, $newCatId)
{
 if($oldCatId)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT id,parent_id,items_count,totitems_count,hierarchy FROM dynarc_".$archiveInfo['prefix']."_categories WHERE id='".$oldCatId."'");
  if($db->Read())
  {
   $oldHierarchy = $db->record['hierarchy'];
   $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_categories SET items_count='".($db->record['items_count']-1)."',totitems_count='"
	.($db->record['totitems_count']-1)."' WHERE id='".$oldCatId."'");
   $x = explode(",",$oldHierarchy);
   for($c=0; $c < count($x); $c++)
   {
	if(!$x[$c]) continue;
	if($x[$c] == $oldCatId) continue;
	$db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_categories SET totitems_count=totitems_count-1 WHERE id='".$x[$c]."'");
   }
  }
  $db->Close();
 }

 if($newCatId)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT id,parent_id,items_count,totitems_count,hierarchy FROM dynarc_".$archiveInfo['prefix']."_categories WHERE id='".$newCatId."'");
  if($db->Read())
  {
   $newHierarchy = $db->record['hierarchy'];
   $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_categories SET items_count='".($db->record['items_count']+1)."',totitems_count='"
	.($db->record['totitems_count']+1)."' WHERE id='".$newCatId."'");
   $x = explode(",",$newHierarchy);
   for($c=0; $c < count($x); $c++)
   {
	if(!$x[$c]) continue;
	if($x[$c] == $newCatId) continue;
	$db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_categories SET totitems_count=totitems_count+1 WHERE id='".$x[$c]."'");
   }
  }
  $db->Close();
 }
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_updateCatCounter($sessid, $shellid, $archiveInfo, $oldCatId, $newCatId)
{
 if($oldCatId)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_categories SET subcat_count=subcat_count-1 WHERE id='".$oldCatId."'");
  $db->Close();
 }
 if($newCatId)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_categories SET subcat_count=subcat_count+1 WHERE id='".$newCatId."'");
  $db->Close();
 }
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_gproducts_fixCounters($sessid, $shellid, $archiveInfo, $catId, $norecursive=false)
{
 if(!$catId) return;
 $subcatCount = 0;
 $itemsCount = 0;
 $totitemsCount = 0;

 // get cat info
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT parent_id,hierarchy FROM dynarc_".$archiveInfo['prefix']."_categories WHERE id='".$catId."'");
 $db->Read();
 $catInfo = array("id"=>$catId, "parent_id"=>$db->record['parent_id'], "hierarchy"=>$db->record['hierarchy']);

 // get subcat count and totitems count
 $db->RunQuery("SELECT totitems_count FROM dynarc_".$archiveInfo['prefix']."_categories WHERE parent_id='".$catId."' AND trash='0'");
 while($db->Read())
 {
  $subcatCount++;
  $totitemsCount+= $db->record['totitems_count'];
 }

 // get items count
 $db->RunQuery("SELECT COUNT(*) FROM dynarc_".$archiveInfo['prefix']."_items WHERE cat_id='".$catId."' AND trash='0'");
 $db->Read();
 $itemsCount = $db->record[0];
 $totitemsCount+= $itemsCount;

 // update cat counters
 $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_categories SET subcat_count='".$subcatCount."',items_count='"
	.$itemsCount."',totitems_count='".$totitemsCount."' WHERE id='".$catId."'");

 $db->Close();

 if(!$norecursive)
 {
  /* UPDATE COUNTER AT THE REST OF BRANCH */
  $x = explode(",",$catInfo['hierarchy']);
  $list = array();
  for($c=0; $c < count($x); $c++)
  {
   if($x[$c] && is_numeric($x[$c]))
    $list[] = $x[$c];
  }
  $catList = array_reverse($list);
  for($c=0; $c < count($catList); $c++)
   dynarcfunction_gproducts_fixCounters($sessid, $shellid, $archiveInfo, $catList[$c], true);
 }
 
}
//-------------------------------------------------------------------------------------------------------------------//



