<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: gproducts
 #DESCRIPTION: Excel parser for GProducts.
 #VERSION: 2.1beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.
 #TODO:
 
*/

function gnujikoexcelparser_gproducts_info()
{
 $info = array('name' => "Prodotti");
 $keys = array(
	/* BASIC INFO */
	"name"=>"Nome articolo",
	"desc"=>"Descrizione",
	"code"=>"Codice",
	"barcode"=>"Codice a barre",
	"units"=>"Unita di misura",
	"baseprice"=>"Prezzo di base",
	"vat"=>"Aliquota IVA",
	);

 $ret = GShell("pricelists list");
 $list = $ret['outarr'];
 for($c=0; $c < count($list); $c++)
  $keys["pricelist_".$list[$c]['id']] = $list[$c]['name'];

 $keydict = array(
	/* BASIC INFO */
	"name"=> array("nome","titolo","articolo"),
	"desc"=> array("descrizione","desc."),
	"code"=> array("codice","cod."),
	"barcode"=> array("barcode","codice a barre","cod. a barre"),
	"units"=> array("um","u.m.","unità di mis","unita di mis","unita_mis"),
	"baseprice"=> array("prezzo","pr. vendita","pr vendita"),
	"vat"=> array("iva","aliquota iva"),
	);

 for($c=0; $c < count($list); $c++)
  $keydict["pricelist_".$list[$c]['id']] = array(0=>strtolower($list[$c]['name']));

 return array('info'=>$info, 'keys'=>$keys, 'keydict'=>$keydict);
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoexcelparser_gproducts_import($_DATA, $sessid, $shellid, $archivePrefix="gproducts", $catId=0, $catTag="", $id=0)
{
 $ret = GShell("pricelists list",$sessid,$shellid);
 $pllist = $ret['outarr'];
 $mtime = date('Y-m-d H:i:s');

 $interface = array("name"=>"progressbar","steps"=>count($_DATA['items']));
 gshPreOutput($shellid,"Import from Excel to Products", "ESTIMATION", "", "PASSTHRU", $interface);

 $db2 = new AlpaDatabase();
 for($c=0; $c < count($_DATA['items']); $c++)
 {
  $itm = $_DATA['items'][$c];

  // verifica se l'articolo esiste gia //
  $checkQry = "SELECT id FROM dynarc_".$archivePrefix."_items WHERE ";
  if($itm['code'])
   $checkQry.= "code_str='".$itm['code']."'";
  else
  {
   $name = $db2->Purify($itm['name']);
   $checkQry.= "name='".$name."' OR name LIKE '".$name."%'";
  }

  $db2->RunQuery($checkQry." AND trash='0'");
  if($db2->Read())
  {
   gshPreOutput($shellid,"Update: ".$itm['name'].($itm['code'] ? "<i>cod.".$itm['code']."</i>" : ""),"PROGRESS", $itm);
   $qry = "dynarc edit-item -ap `".($archivePrefix ? $archivePrefix : "gproducts")."` -id '".$db2->record['id']."' -name `".$itm['name']."` -code-str `"
	.$itm['code']."` -mtime '".$mtime."'";
  }
  else
  {
   gshPreOutput($shellid,"Import: ".$itm['name'].($itm['code'] ? "<i>cod.".$itm['code']."</i>" : ""),"PROGRESS", $itm);
   $qry = "dynarc new-item -ap `".($archivePrefix ? $archivePrefix : "gproducts")."`"
	.($catId ? " -cat '".$catId."'" : ($catTag ? " -ct `".$catTag."`" : ""))." -name `".$itm['name']."` -mtime '".$mtime."'";
  }

  $set = "";
  $extset = "";
  if($itm['desc']) $qry.= " -desc `".$itm['desc']."`";
  if($itm['code']) $qry.= " -code-str `".$itm['code']."`";
  if($itm['baseprice']) $set.= ",baseprice='".(str_replace(",",".",$itm['baseprice']))."'";  
  if($itm['vat']) $set.= ",vat='".$itm['vat']."'";

  /* DETECT PRICELISTS */
  $pricelists = "";
  for($i=0; $i < count($pllist); $i++)
  {
   if($itm["pricelist_".$pllist[$i]['id']])
   {
	if((stripos($itm["pricelist_".$pllist[$i]['id']], "s") !== false) || (stripos($itm["pricelist_".$pllist[$i]['id']], "x") !== false))
	 $pricelists.= ",".$pllist[$i]['id'];
   }
  }
  if($pricelists)
   $set.= ",pricelists='".ltrim($pricelists,",")."'";

  if($itm['barcode']) $extset.= ",barcode='".$itm['barcode']."'";
  if($itm['units']) $extset.= ",units='".$itm['units']."'";

  if($extset)
   $extset = "gproducts.".ltrim($extset,",");

  $ret = GShell($qry.($set ? " -set `".ltrim($set,",")."`" : "").($extset ? " -extset `".ltrim($extset,",")."`" : ""),$sessid,$shellid);
  if($ret['error'])
   return $ret;

 }
 $db2->Close();

 return array('message'=>"done!");
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoexcelparser_gproducts_fastimport($_KEYS, $_DATA, $sessid, $shellid, $_AP="", $catId=0, $catTag="", $id=0, $sessInfo)
{
 if(!$_AP) $_AP = "gproducts";

 $ret = GShell("pricelists list",$sessid,$shellid);
 $_PRICELISTS = $ret['outarr'];

 /* get archive info */
 $ret = GShell("dynarc archive-info -prefix '".$_AP."'",$sessid,$shellid);
 if($ret['error'])
  return $ret;
 $archiveInfo = $ret['outarr'];

 if($catTag || $catId)
 {
  // get cat info
  $ret = GShell("dynarc cat-info -ap '".$_AP."'".($catId ? " -id '".$catId."'" : " -tag '".$catTag."'"),$sessid,$shellid);
  if(!$ret['error'])
  {
   $catId = $ret['outarr']['id'];
   $catInfo = $ret['outarr'];
  }
 }

 /* PROGRESS BAR */
 $interface = array("name"=>"progressbar","steps"=>count($_DATA['items']));
 gshPreOutput($shellid,"Import from Excel to Products", "ESTIMATION", "", "PASSTHRU", $interface);

 // default fields
 $fields = array('uid','gid','_mod','cat_id','name','description','ordering','ctime','mtime','hierarchy','code_str','units',
'baseprice','vat','pricelists','barcode');
 $pricelists = "";
 for($c=0; $c < count($_PRICELISTS); $c++)
 {
  $fields[] = "pricelist_".$_PRICELISTS[$c]['id']."_baseprice";
  $fields[] = "pricelist_".$_PRICELISTS[$c]['id']."_mrate";
  $fields[] = "pricelist_".$_PRICELISTS[$c]['id']."_vat";
  $pricelists.= ",".$_PRICELISTS[$c]['id'];
 }
 $pricelists = ltrim($pricelists,",");

 $now = time();
 $ctime = date('Y-m-d H:i:s',$now);
 $mtime = $ctime;
 $uid = $sessInfo['uid'];
 $gid = $sessInfo['gid'];
 $mod = $archiveInfo['def_item_perms'] ? $archiveInfo['def_item_perms'] : 640;
 $hierarchy = $catId ? $catInfo['hierarchy'].$catInfo['id'] : ",";

 $_VENDOR = array();

 /* IMPORT ITEMS */
 $fieldsString = implode(",",$fields);
 $ordering = 0;
 for($c=0; $c < count($_DATA['items']); $c++)
 {
  $itm = $_DATA['items'][$c];
  $ordering++;
  $isUpdated=false;

  // verifica se l'articolo esiste gia //
  $db = new AlpaDatabase();
  $checkQry = "SELECT id FROM dynarc_".$_AP."_items WHERE ";
  if($itm['code'])
   $checkQry.= "code_str='".$itm['code']."'";
  else
  {
   $name = $db->Purify($itm['name']);
   $checkQry.= "name='".$name."' OR name LIKE '".$name."%'";
  }

  $db->RunQuery($checkQry." AND trash='0'");
  if($db->Read())
  {
   $_ID = $db->record['id'];
   gshPreOutput($shellid,"Update: ".$itm['name'].($itm['code'] ? "<i>cod.".$itm['code']."</i>" : ""),"PROGRESS", $itm);
   $qry = "UPDATE dynarc_".$_AP."_items SET code_str='".$itm['code']."',name='"
	.$db->Purify($itm['name'] ? $itm['name'] : $itm['desc'])."',description='".$db->Purify($itm['desc'])."',mtime='".$mtime."',units='"
	.$itm['units']."',baseprice='".$itm['baseprice']."',vat='".$itm['vat']."',pricelists='".$pricelists."',barcode='".$itm['barcode']."'";
   // pricelists
   for($i=0; $i < count($_PRICELISTS); $i++)
    $qry.= ",pricelist_".$_PRICELISTS[$i]['id']."_baseprice='".$itm['baseprice']."',pricelist_".$_PRICELISTS[$i]['id']."_mrate='"
	.$_PRICELISTS[$i]['markuprate']."',pricelist_".$_PRICELISTS[$i]['id']."_vat='".$itm['vat']."'";
   $qry.= " WHERE id='".$_ID."'";

   $db2 = new AlpaDatabase();
   $db2->RunQuery($qry);
   if($db2->Error)
    return array("message"=>"MySQL Error: ".$db2->Error, "error"=>"MYSQL_ERROR");
   $db2->Close();
   $isUpdated=true;
  }
  else
  {
   gshPreOutput($shellid,"Import: ".$itm['name'].($itm['code'] ? "<i>cod.".$itm['code']."</i>" : ""),"PROGRESS", $itm);
   $qry = "INSERT INTO dynarc_".$_AP."_items (".$fieldsString.") VALUES('".$uid."','".$gid."','".$mod."','".$catId."','"
	.$db->Purify($itm['name'] ? $itm['name'] : $itm['desc'])."','".$db->Purify($itm['desc'])."','".$ordering."','".$ctime."','".$mtime."','"
	.$hierarchy."','".$itm['code']."','".$itm['units']."','".$itm['baseprice']."','".$itm['vat']."','".$pricelists."','".$itm['barcode']."'";
   // pricelists
   for($i=0; $i < count($_PRICELISTS); $i++)
    $qry.= ",'".$itm['baseprice']."','".$_PRICELISTS[$i]['markuprate']."','".$itm['vat']."'";
   $qry.= ")";

   $db2 = new AlpaDatabase();
   $db2->RunQuery($qry);
   if($db2->Error)
    return array("message"=>"MySQL Error: ".$db2->Error, "error"=>"MYSQL_ERROR");
   $_ID = $db2->GetInsertId();
   $db2->Close();
  }
  $db->Close();
 }

 if($catId)
 {
  // aggiorna i totali articoli e categorie
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT COUNT(*) FROM dynarc_".$_AP."_items WHERE trash='0' AND cat_id='".$catId."'");
  $db->Read();
  $totItems = $db->record[0];
  $db->RunQuery("SELECT COUNT(*) FROM dynarc_".$_AP."_categories WHERE trash='0' AND parent_id='".$catId."'");
  $db->Read();
  $totCats = $db->record[0];
  $db->RunQuery("UPDATE dynarc_".$_AP."_categories SET subcat_count='".$totCats."',items_count='".$totItems."',totitems_count='".$totItems."' WHERE id='".$catId."'");
  $db->Close();
 }

 return array('message'=>"done!");
}
//-------------------------------------------------------------------------------------------------------------------//

