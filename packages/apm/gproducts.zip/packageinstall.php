<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `gproducts` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='FinalProducts/'");
if($db->Read())
 $db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Prod. finiti...";
 $ret = GShell("system register-app -name `Prod. finiti` -desc `Catalogo prodotti finiti.` -url 'FinalProducts/' -icon 'FinalProducts/icon.png' -group gproducts -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new archive */
$_SHELL_OUT.= "Create new archive Prodotti finiti...";
$ret = GShell("dynarc new-archive -name `Prodotti finiti` -prefix 'gproducts' -group 'gproducts' -type gproducts -perms '660' --def-cat-perms '660' --def-item-perms '660' --functions-file `etc/dynarc/archive_funcs/__gproducts/index.php` -launcher `gframe -f gproducts/edit.item -params id=%d`",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension 'coding' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension custompricing...";
$ret = GShell("dynarc install-extension 'custompricing' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension gproducts...";
$ret = GShell("dynarc install-extension 'gproducts' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension idoc...";
$ret = GShell("dynarc install-extension 'idoc' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension pricing...";
$ret = GShell("dynarc install-extension 'pricing' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension storeinfo...";
$ret = GShell("dynarc install-extension 'storeinfo' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension thumbnails...";
$ret = GShell("dynarc install-extension 'thumbnails' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension components...";
$ret = GShell("dynarc install-extension 'components' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension materials...";
$ret = GShell("dynarc install-extension 'materials' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension labors...";
$ret = GShell("dynarc install-extension 'labors' -ap 'gproducts'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];