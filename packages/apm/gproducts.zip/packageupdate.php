<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* 26-09-2015 : aggiunto hide_in_store */
$db = new AlpaDatabase();
$db2 = new AlpaDatabase();
$db->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE archive_type='gproducts'");
while($db->Read())
{
 $db2->RunQuery("ALTER TABLE `dynarc_".$db->record['tb_prefix']."_items` ADD `hide_in_store` TINYINT(1) NOT NULL, ADD INDEX (`hide_in_store`)");
}
$db2->Close();
$db->Close();