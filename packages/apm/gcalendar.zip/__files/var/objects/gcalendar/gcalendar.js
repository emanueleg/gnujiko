/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 16-04-2014
 #PACKAGE: gcalendar
 #DESCRIPTION: Standard calendar object
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

function GCalendar(objId)
{
 this.Id = objId ? objId : "gcalendar";
 this.O = document.getElementById(this.Id);
 if(!this.O)
  return alert("GCalendar error: Object "+objId+" does not exists.");
 this.SelectedDate = new Date(); // today
 this.sdTD = null; // selected date TD
 this.init();

 /* EVENTS */
 this.OnChange = function(datestr){};
}

GCalendar.prototype.init = function()
{
 var oThis = this;

 this.prevBtn = document.getElementById(this.Id+"-prevbtn");
 this.nextBtn = document.getElementById(this.Id+"-nextbtn");
 this.handle = document.getElementById(this.Id+"-handle");
 this.grid = document.getElementById(this.Id+"-grid");

 this.prevBtn.onclick = function(){oThis.PrevMonth();}
 this.nextBtn.onclick = function(){oThis.NextMonth();}

 for(var r=0; r < this.grid.rows.length; r++)
 {
  for(var c=0; c < 7; c++)
  {
   var td = this.grid.rows[r].cells[c];
   td.onclick = function(){oThis.SetDate(this.getAttribute('date'), this);}
   if(td.getAttribute('date') == this.SelectedDate.printf('Y-m-d'))
   {
	td.oldClassName = (td.className != "selected") ? td.className : "";
	td.className = "selected";
	this.sdTD = td;
   }
  }
 }

}

GCalendar.prototype.PrevMonth = function()
{
 var date = new Date();
 date.setFromISO(this.handle.getAttribute('date'));
 date.PrevMonth();
 this.update(date);
}

GCalendar.prototype.NextMonth = function()
{
 var date = new Date();
 date.setFromISO(this.handle.getAttribute('date'));
 date.NextMonth();
 this.update(date);
}

GCalendar.prototype.SetDate = function(datestr, TD)
{
 if(this.sdTD)
  this.sdTD.className = this.sdTD.oldClassName;
 this.SelectedDate.setFromISO(datestr);
 if(TD)
 {
  TD.oldClassName = TD.className;
  TD.className = "selected";
  this.sdTD = TD;
 }
 if(this.OnChange)
  this.OnChange(datestr);
}

GCalendar.prototype.update = function(date)
{
 var oThis = this;
 var tmpdate = new Date();
 var sh = new GShell();
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 oThis.handle.innerHTML = date.printf('F')+" "+date.printf('Y');
	 oThis.handle.setAttribute('date',date.printf('Y-m-01'));

	 var tb = oThis.grid;
	 for(var r=0; r < a.length; r++)
	 {
	  var week = a[r];
	  for(var c=0; c < 7; c++)
	  {
	   var td = tb.rows[r].cells[c];
	   td.setAttribute("date",week['dates'][c]);
	   tmpdate.setFromISO(week['dates'][c]);
	   if(week['dates'][c] == oThis.SelectedDate.printf('Y-m-d'))
	   {
		if(tmpdate.printf('m') != date.printf('m'))
		 td.oldClassName = "out";
		else
		 td.oldClassName = "";
		td.className = "selected";
		oThis.sdTD = td;
	   }
	   else if(tmpdate.printf('m') != date.printf('m'))
		td.oldClassName = td.className = "out";
	   else
		td.oldClassName = td.className = "";
	   td.innerHTML = week['days'][c];
	  }
	 }
	}
 sh.sendCommand("calendar print -month `"+date.printf('m')+"` -year `"+date.printf('Y')+"`");
}

