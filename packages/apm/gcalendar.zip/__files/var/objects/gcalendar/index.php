<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 16-04-2014
 #PACKAGE: gcalendar
 #DESCRIPTION: Standard calendar object
 #VERSION: 2.0beta
 #CHANGELOG:
 #DEPENDS:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;

define("VALID-GNUJIKO",1);

include_once($_BASE_PATH."include/gshell.php");
include_once($_BASE_PATH."include/js/gshell.php");
include_once($_BASE_PATH."include/i18n.php");
LoadLanguage("calendar");

?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL; ?>var/objects/gcalendar/gcalendar.css" type="text/css" />
<script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>var/objects/gcalendar/gcalendar.js" type="text/javascript"></script>
<?php

class GCalendar
{
 var $Id;

 function GCalendar($id="gcalendar")
 {
  $this->Id = $id;
 }

 function Paint()
 {
  global $_BASE_PATH, $_ABSOLUTE_URL;
  $from = time();
  ?>
  <div class="gcalendar-container" id="<?php echo $this->Id; ?>">
  <div class="gcalendar-header">
   <table width="100%" height='28' cellspacing="0" cellpadding="0" border="0">
    <tr>
	 <td align='right' valign='middle' width='34'><img src="<?php echo $_ABSOLUTE_URL; ?>var/objects/gcalendar/img/prevbtn.png" class="prevbtn" id="<?php echo $this->Id; ?>-prevbtn"/></td>
	 <td align='center' valign='middle' class='gcalendar-handle' date="<?php echo date('Y-m-01',$from); ?>" id="<?php echo $this->Id; ?>-handle"><?php echo i18n("MONTH-".date('n',$from))." ".date('Y',$from); ?></td>
	 <td align='left' valign='middle' width='34'><img src="<?php echo $_ABSOLUTE_URL; ?>var/objects/gcalendar/img/nextbtn.png" class="nextbtn" id="<?php echo $this->Id; ?>-nextbtn"/></td>
    </tr>
   </table>
   <table width="100%" height='6' cellspacing='0' cellpadding='0' border='0' class="gcalendar-days">
    <tr><td>lun</td><td>mar</td><td>mer</td><td>gio</td><td>ven</td><td>sab</td><td>dom</td></tr>
   </table>
  </div>

  <table width="100%" cellspacing="0" cellpadding="0" border="0" class="gcalendar-grid" id="<?php echo $this->Id; ?>-grid">
  <?php

  $ret = GShell("calendar print -month ".date('n',$from),$_REQUEST['sessid'],$_REQUEST['shellid']);
  for($r=0; $r < count($ret['outarr']); $r++)
  {
   $week = $ret['outarr'][$r];
   echo "<tr>";
   for($c=0; $c < 7; $c++)
   {
    echo "<td";
    if($week['dates'][$c] == date('Y-m-d')) // today
     echo " class='selected'";
    else if(date('n',strtotime($week['dates'][$c])) != date('n',$from))
     echo " class='out'";
    echo " date='".$week['dates'][$c]."'>".$week['days'][$c]."</td>";
   }
   echo "</tr>";
  }
  ?>
  </table>
  
  </div>
  <?php
 }

}

?>
