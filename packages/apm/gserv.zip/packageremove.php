<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Remove archive services */
GShell("dynarc delete-archive -r -prefix gserv",$_SESSION_ID,$_SHELL_ID);

/* Un-register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Services/'");
if($db->Read())
GShell("system unregister-app -id ".$db->record['id'],$_SESSION_ID,$_SHELL_ID);
$db->Close();