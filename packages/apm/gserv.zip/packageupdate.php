<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

if(version_compare($_INSTALLED_VER,"2.26beta","<" ))
{
 /* 11-02-2013 : Two fields has been inserted into extension gserv. */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT archive_id FROM dynarc_archive_extensions WHERE extension_name='gserv'");
 while($db->Read())
 {
  $db2 = new AlpaDatabase();
  $db2->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE id='".$db->record['archive_id']."'");
  $db2->Read();
  $db2->RunQuery("ALTER TABLE `dynarc_".$db2->record['tb_prefix']."_items ADD `service_type` VARCHAR( 32 ) NOT NULL"); // old updated query 29-01-2013
  $db2->RunQuery("ALTER TABLE `dynarc_".$db2->record['tb_prefix']."_items ADD `qty_sold` FLOAT NOT NULL, ADD `units` VARCHAR( 16 ) NOT NULL");
  $db2->Close();
 }
 $db->Close();
}

if(version_compare($_INSTALLED_VER,"2.27beta","<" ))
{
 /* 04-02-2013 : Install extension Custom Pricing */
 $_SHELL_OUT.= "Install extension custompricing...";
 $ret = GShell("dynarc install-extension custompricing -ap gserv",$_SESSION_ID,$_SHELL_ID);
 $_SHELL_OUT.= $ret['message'];
}