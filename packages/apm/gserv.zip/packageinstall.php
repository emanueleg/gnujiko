<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `gserv` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Services/'");
if($db->Read())
$db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Servizi...";
 $ret = GShell("system register-app -name `Servizi` -desc `Catalogo servizi personalizzabile.` -url 'Services/' -icon 'Services/icon.png' -group gserv -perms 640",$_SESSION_ID, $_SHELL_ID);
 $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new archive */
$_SHELL_OUT.= "Create new archive Catalogo Servizi...";
$ret = GShell("dynarc new-archive -name `Catalogo Servizi` -prefix gserv -group `gserv` -type gserv --default-cat-perms 664 --default-item-perms 664 --functions-file etc/dynarc/archive_funcs/__gserv/index.php --hidden",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension gserv...";
$ret = GShell("dynarc install-extension gserv -ap gserv",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension coding -ap gserv",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension pricing...";
$ret = GShell("dynarc install-extension pricing -ap gserv",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension custompricing...";
$ret = GShell("dynarc install-extension custompricing -ap gserv",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension thumbnails...";
$ret = GShell("dynarc install-extension thumbnails -ap gserv",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension vendorprices...";
$ret = GShell("dynarc install-extension vendorprices -ap gserv",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];