<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* 12-04-2013 : Aggiunto le 3 colonne degli sconti. */
$db = new AlpaDatabase();
$db2 = new AlpaDatabase();
$db3 = new AlpaDatabase();

$db->RunQuery("SELECT archive_id FROM dynarc_archive_extensions WHERE extension_name='custompricing'");
while($db->Read())
{
 $db2->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE id='".$db->record['archive_id']."'");
 $db2->Read();
 $db3->RunQuery("ALTER TABLE `dynarc_".$db2->record['tb_prefix']."_custompricing` ADD `discount2` FLOAT NOT NULL , ADD `discount3` FLOAT NOT NULL");
 $db3->RunQuery("ALTER TABLE `dynarc_".$db2->record['tb_prefix']."_custompricing` CHANGE `baseprice` `baseprice` DECIMAL(10,4) NOT NULL");
}
$db3->Close();
$db2->Close();
$db->Close();