<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2016 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 24-10-2016
#PACKAGE: dynarc-oslist-extension
#DESCRIPTION: 
#VERSION: 2.1beta
#CHANGELOG: 24-10-2016 : MySQLi integration.
#TODO: 
*/

global $_BASE_PATH;

function dynarcextension_oslist_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_".$archiveInfo['prefix']."_oslist` (
	`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
	`item_id` INT(11) NOT NULL ,
	`name` VARCHAR(32) NOT NULL ,
	`user1` VARCHAR(32) NOT NULL ,
	`user2` VARCHAR(32) NOT NULL ,
	`user3` VARCHAR(32) NOT NULL ,
	`rootuser` VARCHAR(32) NOT NULL ,
	`passwd1` VARCHAR(32) NOT NULL ,
	`passwd2` VARCHAR(32) NOT NULL ,
	`passwd3` VARCHAR(32) NOT NULL ,
	`rootpasswd` VARCHAR(32) NOT NULL ,
	INDEX (`item_id`)
 )");
 $db->Close();
 return array("message"=>"OS List extension has been installed into archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DROP TABLE `dynarc_".$archiveInfo['prefix']."_oslist`");
 $db->Close();

 return array("message"=>"OS List extension has been removed from archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_catset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_catunset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_catget($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_oslist_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'name' : {$osName=$args[$c+1]; $c++;} break;
   case 'user' : case 'user1' : case 'usr1' : {$user1=$args[$c+1]; $c++;} break;
   case 'user2' : case 'usr2' : {$user2=$args[$c+1]; $c++;} break;
   case 'user3' : case 'usr3' : {$user3=$args[$c+1]; $c++;} break;
   case 'root' : case 'rootuser' : {$rootUser=$args[$c+1]; $c++;} break;
   case 'passwd' : case 'password' : case 'passwd1' : case 'password1' : {$passwd1=$args[$c+1]; $c++;} break;
   case 'passwd2' : case 'password2' : {$passwd2=$args[$c+1]; $c++;} break;
   case 'passwd3' : case 'password3' : {$passwd3=$args[$c+1]; $c++;} break;
   case 'rootpwd' : case 'rootpasswd' : case 'rootpassword' : {$rootPasswd=$args[$c+1]; $c++;} break;
  }

 $db = new AlpaDatabase();
 if($id)
 {
  $q = "";
  if($osName)				$q.= ",name='".$db->Purify($osName)."'";
  if(isset($user1))			$q.= ",user1='".$db->Purify($user1)."'";
  if(isset($user2))			$q.= ",user2='".$db->Purify($user2)."'";
  if(isset($user3))			$q.= ",user3='".$db->Purify($user3)."'";
  if(isset($rootUser))		$q.= ",rootuser='".$db->Purify($rootUser)."'";
  if(isset($passwd1))		$q.= ",passwd1='".$db->Purify($passwd1)."'";
  if(isset($passwd2))		$q.= ",passwd2='".$db->Purify($passwd2)."'";
  if(isset($passwd3))		$q.= ",passwd3='".$db->Purify($passwd3)."'";
  if(isset($rootPasswd))	$q.= ",rootpasswd='".$db->Purify($rootPasswd)."'";
  if($q)
  {
   $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_oslist SET ".ltrim($q,",")." WHERE id='".$id."'");
   if($db->Error) return array('message'=>'MySQL Error:'.$db->Error, 'error'=>'MYSQL_ERROR');
  }
 }
 else
 {
  $q = "INSERT INTO dynarc_".$archiveInfo['prefix']."_oslist (item_id,name,user1,user2,user3,rootuser,passwd1,passwd2,passwd3,rootpasswd) ";
  $q.= "VALUES('".$itemInfo['id']."','".$db->Purify($osName)."','".$db->Purify($user1)."','".$db->Purify($user2)."','"
	.$db->Purify($user3)."','".$db->Purify($rootUser)."','".$db->Purify($passwd1)."','".$db->Purify($passwd2)."','"
	.$db->Purify($passwd3)."','".$db->Purify($rootPasswd)."')";
  $db->RunQuery($q);
  if($db->Error) return array('message'=>'MySQL Error:'.$db->Error, 'error'=>'MYSQL_ERROR');
  $id = $db->GetInsertId();
  $itemInfo['last_os'] = array('id'=>$id, 'name'=>$osName, 'user1'=>$user1, 'user2'=>$user2, 'user3'=>$user3, 
	'rootuser'=>$rootUser, 'passwd1'=>$passwd1, 'passwd2'=>$passwd2, 'passwd3'=>$passwd3, 'rootpasswd'=>$rootPasswd);
 }
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_oslist_catunset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'all' : $all=true; break;
  }

 $db = new AlpaDatabase();
 if($id)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_oslist WHERE id='".$id."'");
 else if($all)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_oslist WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_oslist_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 $all = false;
 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'name' : $osName=true; break;
   case 'users' : $users=true; break;
   case 'passwords' : $passwords=true; break;
  }

 $itemInfo['oslist'] = array();
 if(!count($args)) $all=true;
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT id,name,user1,user2,user3,rootuser,passwd1,passwd2,passwd3,rootpasswd FROM dynarc_"
	.$archiveInfo['prefix']."_oslist WHERE item_id='".$itemInfo['id']."' ORDER BY id ASC");
 while($db->Read())
 {
  $a = array('id'=>$db->record['id']);
  if($osName || $all)			$a['name'] = $db->record['name'];
  if($users || $all)
  {
   $a['user1'] = $db->record['user1'];
   $a['user2'] = $db->record['user2'];
   $a['user3'] = $db->record['user3'];
   $a['rootuser'] = $db->record['rootuser'];
  }
  if($passwords || $all)
  {
   $a['passwd1'] = $db->record['passwd1'];
   $a['passwd2'] = $db->record['passwd2'];
   $a['passwd3'] = $db->record['passwd3'];
   $a['rootpasswd'] = $db->record['rootpasswd'];
  }
  $itemInfo['oslist'][] = $a;
 }
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 $xml = "<oslist />";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 if(!$node)
  return ;

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_oslist_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
