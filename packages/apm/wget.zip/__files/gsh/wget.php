<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 28-10-2016
 #PACKAGE: wget
 #DESCRIPTION: Download from the web.
 #VERSION: 2.1beta
 #CHANGELOG: 28-10-2016 : Bug fix on line 87. ereg deprecated replaced with preg_match.
 #TODO: Fixare bug alla riga 116 in caso di contenuti html o testuali.
 
*/

function shell_wget($args, $sessid, $shellid=0)
{
 global $_BASE_PATH, $_FTP_SERVER, $_FTP_USERNAME, $_FTP_PASSWORD, $_FTP_PATH, $_USERS_HOMES;
 $out = "";
 $outArr = array();

 if(count($args) == 0)
  return wget_invalidArguments();

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-url' : {$URL=$args[$c+1]; $c++;} break;
   case '-o' : case '-dest' : {$dest=$args[$c+1]; $c++;} break;
   default : {if(!$URL) $URL=$args[$c]; else if(!$dest) $dest=$args[$c];} break;
  }

 if(!$URL)
  return array("message"=>"You must specify the URL.", "error"=>"INVALID_URL");
 if(!$dest)
  return array("message"=>"You must specify the destination file.", "error"=>"INVALID_DEST_FILE");

 $sessInfo = sessionInfo($sessid);
 if($sessInfo['uname'] == "root")
  $homedir = "";
 else if($sessInfo['uid'])
 {
  /* Check if user is able for move files and folders */
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT * FROM gnujiko_user_privileges WHERE uid='".$sessInfo['uid']."'");
  $db->Read();
  if(!$db->record['mkdir_enable'])
   return array("message"=>"Unable to copy files/directories: Your account has not privileges to copy files or folders!","error"=>"MKDIR_DISABLED");
  $db->Close();

  $db = new AlpaDatabase();
  $db->RunQuery("SELECT homedir FROM gnujiko_users WHERE id='".$sessInfo['uid']."'");
  $db->Read();
  $homedir = $_USERS_HOMES.$db->record['homedir']."/";
  $db->Close();
 }
 else
  return array("message"=>"Unable to copy files or directory: you don't have a valid account!","error"=>"INVALID_USER");

 include_once($_BASE_PATH."include/filesfunc.php");
 $destination = $homedir.$dest;
 
 $url_stuff = parse_url($URL);
 $port = isset($url_stuff['port']) ? $url_stuff['port'] : 80;

 $fp = fsockopen($url_stuff['host'], $port);

 $query  = 'GET ' . $url_stuff['path']."?".$url_stuff['query'] . " HTTP/1.0\n";
 $query .= 'Host: ' . $url_stuff['host'];
 $query .= "\n\n";

 fwrite($fp, $query);

 $fileSize = 0;
 $needPreOutput = false;
 $nextStep = 0;

 while ($tmp = fread($fp, 1024))
 {
  $buffer .= $tmp;
  $buffLen = strlen($buffer);
  if(!$fileSize)
  { 
   // check for errors //
   if(preg_match("/404/",$buffer))
	return array("message"=>"File not found!","error"=>"FILE_NOT_FOUND");

   // try to detect file size //
   if(preg_match('/Content-Length: (\d+)/', $buffer, $matches))
   {
	$fileSize = (int)$matches[1];
	if($fileSize > 71680)
	 $needPreOutput = true;
	$perc = floor((100/$fileSize)*$buffLen);
	gshPreOutput($shellid, "Downloading: ".$perc."%", "DOWNLOADING", $url_stuff['host'], "SINGLE_LINE", array('size'=>$fileSize,'current'=>$buffLen,'percentage'=>$perc));
	$nextStep+= 71680;
   }
  }
  if($needPreOutput && (strlen($buffer) >= $nextStep))
  {
   $perc = floor((100/$fileSize)*$buffLen);
   gshPreOutput($shellid, "Downloading: ".$perc."%", "DOWNLOADING", $url_stuff['host'], "SINGLE_LINE", array('size'=>$fileSize,'current'=>$buffLen,'percentage'=>$perc));
   $nextStep+= 71680;
  }
 }

 preg_match('/Content-Length: ([0-9]+)/', $buffer, $parts);
 $buffer = substr($buffer, - $parts[1]);

 // verify if destination folder exists and is writable //
 if(strpos(basename($dest), ".") === false)
  $destDir = rtrim($dest,"/")."/";
 else
  $destDir = substr($dest, 0, -strlen(basename($dest)));
 if(!is_dir($_BASE_PATH.$homedir.$destDir))
 {
  $ret = GShell("mkdir `".$destDir."`",$sessid,$shellid);
  if($ret['error'])
   return $ret;
 }

 if($_FTP_USERNAME)
 {
  // TRY WITH FTP //
  if(!@gftpwrite($destination,$buffer))
   return array("message"=>"Unable to download file into ".$destination.". Please check permissions!","error"=>"PERMISSION_DENIED");
 }
 else
 {
  // COPY IN NORMAL MODE //
  $dest = @fopen($_BASE_PATH.$destination,"wb");
  if(@fwrite($dest,$buffer)===false)
   return array("message"=>"Unable to download file into ".$destination.". Please check permissions!","error"=>"PERMISSION_DENIED");
  @fclose($dest);
 }
 $out.= "File has been downloaded into ".$destination."\n";
 $outArr['filename'] = $destination;
 return array("message"=>$out, "outarr"=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function wget_invalidArguments()
{
 return array("message"=>"Invalid arguments.", "error"=>"INVALID_ARGUMENTS");
}
//-------------------------------------------------------------------------------------------------------------------//

