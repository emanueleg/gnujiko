<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new category */
$_SHELL_OUT.= "Create new category POS...";
$ret = GShell("dynarc new-cat -ap printmodels -name `POS` -tag POS -group `commdocs-receipts`",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) 
{ 
 $_SHELL_ERR = $ret['error']; 
 $_SHELL_OUT = $ret['message']; 
} 
else 
 $_SHELL_OUT.= $ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create new category Scontrini...";
$ret = GShell("dynarc new-cat -ap printmodels -name `Scontrini` -tag POS-RECEIPTS -pt POS -group `commdocs-receipts`",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) 
{ 
 $_SHELL_ERR = $ret['error']; 
 $_SHELL_OUT = $ret['message']; 
} 
else 
 $_SHELL_OUT.= $ret['message'];

/* Import print models */
GShell("dynarc import -f tmp/demo-scontrino-80mm.xml -ap `printmodels` -ct POS-RECEIPTS",$_SESSION_ID,$_SHELL_ID);