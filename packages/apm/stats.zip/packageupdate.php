<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;	 

if(version_compare($_INSTALLED_VER, "2.2beta", "<"))
 GShell("stats enable -service orders",$_SESSION_ID, $_SHELL_ID);