<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `gnujiko_stats_services` (`service` varchar(64) NOT NULL, `enabled` tinyint(1) NOT NULL, PRIMARY KEY (`service`))");
$db->Close();

/* Abilita i primi due servizi */
GShell("stats enable -service sales",$_SESSION_ID, $_SHELL_ID);
GShell("stats enable -service purchases",$_SESSION_ID, $_SHELL_ID);	 
GShell("stats enable -service orders",$_SESSION_ID, $_SHELL_ID);