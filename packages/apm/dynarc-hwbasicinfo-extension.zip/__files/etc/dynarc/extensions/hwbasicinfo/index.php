<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2014 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 28-11-2014
#PACKAGE: dynarc-hwbasicinfo-extension
#DESCRIPTION: 
#VERSION: 2.0beta
#CHANGELOG: 
#TODO: Fare funzioni di importazione ed esportazione.
*/

global $_BASE_PATH;

function dynarcextension_hwbasicinfo_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` ADD `subject_id` INT(11) NOT NULL ,
	ADD `subject_name` VARCHAR(64) NOT NULL ,
	ADD `brand_id` INT(11) NOT NULL ,
	ADD `brand_name` VARCHAR(32) NOT NULL ,
	ADD `product_number` VARCHAR(32) NOT NULL ,
	ADD `serial_number` VARCHAR(32) NOT NULL ,
	ADD `purchase_date` DATE NOT NULL ,
	ADD `years_guarantee` TINYINT(1) NOT NULL ,
	ADD INDEX (`subject_id`,`brand_id`,`product_number`,`serial_number`)");
 $db->Close();

 return array("message"=>"Hardware Basic Info extension has been installed into archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` DROP `subject_id`,
  DROP `subject_name`, DROP `brand_id`, DROP `brand_name`, DROP `product_number`, DROP `serial_number`,
  DROP `purchase_date`, DROP `years_guarantee`");
 $db->Close();

 return array("message"=>"Hardware Basic Info extension has been removed from archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_catset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_catunset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_catget($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_hwbasicinfo_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'subjid' : case 'subjectid' : {$subjectId=$args[$c+1]; $c++;} break;
   case 'subjname' : case 'subjectname' : {$subjectName=$args[$c+1]; $c++;} break;
   case 'brandap' : {$brandAP=$args[$c+1]; $c++;} break; /* Brands archive prefix */
   case 'brandid' : {$brandId=$args[$c+1]; $c++;} break;
   case 'brand' : case 'brandname' : {$brandName=$args[$c+1]; $c++;} break;
   case 'prodnum' : case 'productnumber' : {$productNumber=$args[$c+1]; $c++;} break;
   case 'sn' : case 'serialnumber' : {$serialNumber=$args[$c+1]; $c++;} break;
   case 'purchdate' : case 'purchasedate' : {$purchaseDate=$args[$c+1]; $c++;} break;
   case 'yearsgr' : case 'yearsguarantee' : {$yearsGuarantee=$args[$c+1]; $c++;} break;
  }

 if($brandAP && $brandName && !$brandId)
 {
  $ret = GShell("dynarc new-item -ap '".$brandAP."' -name `".$brandName."`",$sessid,$shellid);
  if(!$ret['error']) $brandId=$ret['outarr']['id'];
 }

 $db = new AlpaDatabase();
 $q = "";
 if(isset($subjectId))			{ $q.= ",subject_id='".$subjectId."'";					$itemInfo['subject_id'] = $subjectId; }
 if(isset($subjectName))		{ $q.= ",subject_name='".$db->Purify($subjectName)."'";	$itemInfo['subject_name'] = $subjectName; }
 if(isset($brandId))			{ $q.= ",brand_id='".$brandId."'";						$itemInfo['brand_id'] = $brandId; }
 if(isset($brandName))			{ $q.= ",brand_name='".$db->Purify($brandName)."'";		$itemInfo['brand_name'] = $brandName; }
 if(isset($productNumber))		{ $q.= ",product_number='".$productNumber."'";			$itemInfo['product_number'] = $productNumber; }
 if(isset($serialNumber))		{ $q.= ",serial_number='".$serialNumber."'";			$itemInfo['serial_number'] = $serialNumber; }
 if(isset($purchaseDate))		
 { 
  $q.= ",purchase_date='".($purchaseDate ? date('Y-m-d',strtotime($purchaseDate)) : '')."'";
  $itemInfo['purchase_date'] = $purchaseDate ? date('Y-m-d',strtotime($purchaseDate)) : '';
 }
 if(isset($yearsGuarantee))		{ $q.= ",years_guarantee='".$yearsGuarantee."'"; 		$itemInfo['years_guarantee'] = $yearsGuarantee; }

 if($q) $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET ".ltrim($q,",")." WHERE id='".$itemInfo['id']."'");
 $db->Close();


 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_hwbasicinfo_catunset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_hwbasicinfo_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 $all = false;
 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'subjid' : case 'subjectid' : 		$subjectId=true; break;
   case 'subjname' : case 'subjectname' : 	$subjectName=true; break;
   case 'brandid' : 						$brandId=true; break;
   case 'brand' : case 'brandname' : 		$brandName=true; break;
   case 'prodnum' : case 'productnumber' :  $productNumber=true; break;
   case 'sn' : case 'serialnumber' : 		$serialNumber=true; break;
   case 'purchdate' : case 'purchasedate' : $purchaseDate=true; break;
   case 'yearsgr' : case 'yearsguarantee' : $yearsGuarantee=true; break;
  }

 if(!count($args)) $all=true;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT subject_id,subject_name,brand_id,brand_name,product_number,serial_number,purchase_date,years_guarantee FROM dynarc_"
	.$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 if($subjectId || $all)			$itemInfo['subject_id'] = $db->record['subject_id'];
 if($subjectName || $all)		$itemInfo['subject_name'] = $db->record['subject_name'];
 if($brandId || $all)			$itemInfo['brand_id'] = $db->record['brand_id'];
 if($brandName || $all)			$itemInfo['brand_name'] = $db->record['brand_name'];
 if($productNumber || $all)		$itemInfo['product_number'] = $db->record['product_number'];
 if($serialNumber || $all)		$itemInfo['serial_number'] = $db->record['serial_number'];
 if($purchaseDate || $all)		$itemInfo['purchase_date'] = ($db->record['purchase_date'] && ($db->record['purchase_date'] != "0000-00-00") && ($db->record['purchase_date'] != "1970-01-01")) ? $db->record['purchase_date'] : "";
 if($yearsGuarantee || $all)	$itemInfo['years_guarantee'] = $db->record['years_guarantee'];

 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 $xml = "<hwbasicinfo />";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 if(!$node)
  return ;

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_hwbasicinfo_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
