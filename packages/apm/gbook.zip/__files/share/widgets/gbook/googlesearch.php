<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 07-08-2014
 #PACKAGE: gbook
 #DESCRIPTION: Google Book Search
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 #DEPENDS: glight-template
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES, $_COMMERCIALDOCS_CONFIG;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate("widget");
$template->includeCSS("share/widgets/gbook/googlesearch.css");

$template->Begin("Cerca un libro");
$template->Header();
//-------------------------------------------------------------------------------------------------------------------//
$_FILTERS = array(
	"title"=>"titolo",
	"isbn"=>"cod. ISBN", 
);

$_FILTER = $_REQUEST['filter'] ? $_REQUEST['filter'] : "title";
//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0,0,10);
?>
<span class='smalltext' style='float:left;vertical-align:top;height:30px;line-height:30px'>cerca per:</span>
<input type='text' class='dropdown' style='width:90px;float:left;margin-left:5px' readonly='true' connect='filterlist' id='filterselect' placeholder="seleziona un filtro" retval='title' value='titolo' />
<ul class='popupmenu' id='filterlist'>
<?php
 reset($_FILTERS);
 while(list($k,$v)=each($_FILTERS))
 {
  echo "<li value='".$k."'>".$v."</li>";
 }
?>
</ul>

<!-- INPUT SEARCH - DEFAULT FILTERS -->
<?php
echo "<input type='text' class='edit' id='search' style='width:340px;float:left;margin-left:5px;";
switch($_FILTER)
{
 case 'title' : echo "' placeholder='digita il titolo di un libro'"; break;
 case 'isbn' : echo "' placeholder='digita il codice ISBN'"; break;
 default : echo "display:none'"; break;
}
echo " value=\"".$_REQUEST['title']."\"/>";
?>
<input type='button' class='button-search' id='searchbtn' title="Cerca su Google Libri"/>
<?php
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",600);
//-------------------------------------------------------------------------------------------------------------------//
?>
<div class='booklist' style="height:380px;width:560px" id='booklist'>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->Footer("",true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
Template.OnInit = function(){
	document.getElementById('search').onchange = function(){runQuery();}
	this.initBtn(document.getElementById("searchbtn")).onclick = function(){runQuery();};
	this.initEd(document.getElementById('filterselect'), "dropdown").onselect = function(){
		 /* DEFAULT FILTERS */
		 switch(this.getAttribute('retval'))
		 {
		  case 'title' : {
			 var ed = document.getElementById("search");
			 ed.placeholder = "digita il titolo di un libro"; 
			 ed.value = "";
			} break;

		  case 'isbn' : {
			 var ed = document.getElementById("search");
			 ed.placeholder = "digita il codice ISBN";
			 ed.value = "";
			} break;

		 }
		};
	if(document.getElementById('search').value != "")
	 runQuery();
}

function runQuery()
{
 var filter = document.getElementById('filterselect').getValue();
 var ed = document.getElementById("search");
 var sh = new GShell();

 var booklist = document.getElementById("booklist");
 booklist.innerHTML = "<div class='googlesearchwait'>Attendi un attimo!<br/"+"><br/"+">Sto cercando le informazioni su Google Libri...<br/"+"><br/"+"><img src='"+ABSOLUTE_URL+"share/widgets/gbook/img/loadingbar.gif'/"+"></div>";

 sh.OnError = function(msg, code){
	 booklist.innerHTML = "<div class='googlesearcherror'>"+msg+"</div>";
	}

 sh.OnOutput = function(o,a){
	 if(!a || !a['count'] || !a['results'] || !a['results'].length)
	 {
	  booklist.innerHTML = "<div class='googlesearchnoresults'>Spiacente!<br/"+">nessun risultato trovato per '"+ed.value+"'</div>";
	  return;
	 }
 	 booklist.innerHTML = "";
	 for(var c=0; c < a['results'].length; c++)
	 {
	  var div = document.createElement('DIV');
	  div.className = "book";
	  div.data = a['results'][c];
	  var html = "<div class='book-thumbnail' onclick='selectBook(this.parentNode)'><img src='"+div.data['thumbnail']+"' style='width:64px'/"+"></div>";
	  html+= "<div class='book-title' onclick='selectBook(this.parentNode)'>"+div.data['title']+"</div>";
	  html+= "<div class='book-info' onclick='selectBook(this.parentNode)'>"+div.data['authors']+"<br/"+">"+(div.data['publisher'] ? div.data['publisher']+', ' : '')+div.data['publishdate']+"</div>";
	  html+= "<div class='book-links'><a href='"+div.data['previewlink']+"' target='blank'>Anteprima libro &raquo;</a><a href='"+div.data['infolink']+"' target='blank' style='margin-left:100px'>Altre informazioni &raquo;</a></div>";
	  div.innerHTML = html;
	  booklist.appendChild(div);
	 }
	}

 switch(filter)
 {
  case 'title' : sh.sendCommand("gbook google-search -title `"+ed.value+"`"); break;
  case 'isbn' : sh.sendCommand("gbook google-search -isbn `"+ed.value+"`"); break;
 }
}

function selectBook(div)
{
 gframe_close("Book @"+div.data['isbn']+" selected!",div.data);
}
</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

