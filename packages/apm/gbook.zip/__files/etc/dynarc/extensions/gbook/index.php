<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 26-09-2015
 #PACKAGE: gbook
 #DESCRIPTION: GBook basic info extension for Dynarc.
 #VERSION: 2.1beta
 #CHANGELOG: 26-09-2015 : Aggiunto campo nascondi dal magazzino.
 #TODO:
 
*/

global $_BASE_PATH;

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` ADD `publisher` VARCHAR(32) NOT NULL ,
ADD `publisher_id` INT(11) NOT NULL ,
ADD `authors` VARCHAR(32) NOT NULL ,
ADD `author_id` INT(11) NOT NULL ,
ADD `publish_date` DATE NOT NULL ,
ADD `isbn` VARCHAR(13) NOT NULL ,
ADD `barcode` VARCHAR(13) NOT NULL ,
ADD `pagecount` INT(4) NOT NULL ,
ADD `preview_link` VARCHAR(255) NOT NULL ,
ADD `info_link` VARCHAR(255) NOT NULL ,
ADD `language` VARCHAR(3) NOT NULL ,
ADD `qty_sold` FLOAT NOT NULL ,
ADD `units` VARCHAR(16) NOT NULL ,
ADD `item_location` VARCHAR(64) NOT NULL ,
ADD `hide_in_store` TINYINT(1) NOT NULL,
ADD INDEX (`publisher_id`,`author_id`,`isbn`,`barcode`,`hide_in_store`)");

 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_categories` ADD `subcat_count` INT( 4 ) NOT NULL ,
ADD `items_count` INT( 4 ) NOT NULL ,
ADD `totitems_count` INT( 4 ) NOT NULL");

 $db->Close();
 return array("message"=>"GBook extension has been installed into archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` DROP `publisher`, DROP `publisher_id`, DROP `authors`,
  DROP `author_id`, DROP `publish_date`, DROP `isbn`, DROP `barcode`, DROP `pagecount`, DROP `preview_link`, DROP `info_link`,
  DROP `language`, DROP `qty_sold`, DROP `units`, DROP `item_location`, DROP `hide_in_store`");
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_categories` DROP `subcat_count`,  DROP `items_count`,  DROP `totitems_count`");
 $db->Close();

 return array("message"=>"GBook extension has been removed from archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_catset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'subcatcount' : {$subcatCount=$args[$c+1]; $c++;} break;
   case 'itemscount' : {$itemsCount=$args[$c+1]; $c++;} break;
   case 'totitemscount' : {$totItemsCount=$args[$c+1]; $c++;} break;
  }

 $db = new AlpaDatabase();
 $q = "";
 if(isset($subcatCount))
  $q.= ",subcat_count='$subcatCount'";
 if(isset($itemsCount))
  $q.= ",items_count='$itemsCount'";
 if(isset($totItemsCount))
  $q.= ",totitems_count='$totItemsCount'";
 
 if($q)
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_categories SET ".ltrim($q,",")." WHERE id='".$catInfo['id']."'");
 $db->Close();

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 if($isCategory)
  return dynarcextension_gbook_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'barcode' : {$barcode=$args[$c+1]; $c++;} break;
   case 'location' : {$itemLocation=$args[$c+1]; $c++;} break;
   case 'sold' : case 'qty-sold' : case 'qtysold' : {$qtySold=$args[$c+1]; $c++;} break;
   case 'units' : case 'umis' : {$units=$args[$c+1]; $c++;} break;
   case 'publisher' : {$publisher=$args[$c+1]; $c++;} break;
   case 'publisherid' : {$publisherId=$args[$c+1]; $c++;} break;
   case 'author' : case 'authors' : {$authors=$args[$c+1]; $c++;} break;
   case 'authorid' : {$authorId=$args[$c+1]; $c++;} break;
   case 'publishdate' : {$publishDate=$args[$c+1]; $c++;} break;
   case 'isbn' : {$isbn=$args[$c+1]; $c++;} break;
   case 'pagecount' : {$pagecount=$args[$c+1]; $c++;} break;
   case 'previewlink' : {$previewLink=$args[$c+1]; $c++;} break;
   case 'infolink' : {$infoLink=$args[$c+1]; $c++;} break;
   case 'language' : case 'lang' : {$language=$args[$c+1]; $c++;} break;
   case 'hideinstore' : {$hideInStore=$args[$c+1]; $c++;} break;	/* nascondi dal magazzino */
  }

 if($publisher && !$publisherId)
 {
  // check if publisher exists
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT id FROM dynarc_publishers_items WHERE name='".$db->Purify($publisher)."' AND trash='0' LIMIT 1");
  if($db->Read())
   $publisherId = $db->record['id'];
  else
  {
   $ret = GShell("dynarc new-item -ap publishers -ct gbook -name `".$publisher."`",$sessid,$shellid);
   if(!$ret['error'])
	$publisherId = $ret['outarr']['id'];
  }
  $db->Close();
 }

 if($authors && !$authorId)
 {
  // check if author exists
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT id FROM dynarc_authors_items WHERE name='".$db->Purify($authors)."' AND trash='0' LIMIT 1");
  if($db->Read())
   $authorId = $db->record['id'];
  else
  {
   $ret = GShell("dynarc new-item -ap authors -ct gbook -name `".$authors."`",$sessid,$shellid);
   if(!$ret['error'])
	$authorId = $ret['outarr']['id'];
  }
  $db->Close();
 }

 $db = new AlpaDatabase();
 $q="";
 if(isset($publisher))		$q.= ",publisher='".$db->Purify($publisher)."'";
 if(isset($publisherId))	$q.= ",publisher_id='".$publisherId."'";
 if(isset($authors))		$q.= ",authors='".$db->Purify($authors)."'";
 if(isset($authorId))		$q.= ",author_id='".$authorId."'";
 if(isset($publishDate))	$q.= ",publish_date='".$publishDate."'";
 if(isset($isbn))			$q.= ",isbn='".$isbn."'";
 if(isset($barcode))		$q.= ",barcode='".$barcode."'";
 if(isset($pagecount))		$q.= ",pagecount='".$pagecount."'";
 if(isset($previewLink))	$q.= ",preview_link='".$previewLink."'";
 if(isset($infoLink))		$q.= ",info_link='".$infoLink."'";
 if(isset($language))		$q.= ",language='".$language."'";
 if(isset($itemLocation))	$q.= ",item_location='".$db->Purify($itemLocation)."'";
 if(isset($qtySold))		$q.= ",qty_sold='".$qtySold."'";
 if(isset($units))			$q.= ",units='".$units."'";
 if(isset($hideInStore))	$q.= ",hide_in_store='".$hideInStore."'";

 if($q)
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET ".ltrim($q,",")." WHERE id='".$itemInfo['id']."'");
 $db->Close();


 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_catget($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'subcatcount' : $subcatCount=true; break;
   case 'itemscount' : $itemsCount=true; break;
   case 'totitemscount' : $totItemsCount=true; break;
  }

 if(!count($args))
  $all=true;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT subcat_count,items_count,totitems_count FROM dynarc_".$archiveInfo['prefix']."_categories WHERE id='".$catInfo['id']."'");
 $db->Read();
 if($subcatCount || $all)
  $catInfo['subcatcount'] = $db->record['subcat_count'];
 if($itemsCount || $all)
  $catInfo['itemscount'] = $db->record['items_count'];
 if($totItemsCount || $all)
  $catInfo['totitemscount'] = $db->record['totitems_count'];
 $db->Close();

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 if($isCategory)
  return dynarcextension_gbook_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'barcode' : $barcode=true; break;
   case 'location' : $itemLocation=true; break;
   case 'sold' : case 'qty-sold' : case 'qtysold' : $qtySold=true; break;
   case 'units' : case 'umis' : $units=true; break;
   case 'publisher' : $publisher=true; break;
   case 'authors' : $authors=true; break;
   case 'publishdate' : $publishDate=true; break;
   case 'isbn' : $isbn=true; break;
   case 'pagecount' : $pagecount=true; break;
   case 'previewlink' : $previewLink=true; break;
   case 'infolink' : $infoLink=true; break;
   case 'language' : $language=true; break;
   case 'hideinstore' : $hideInStore=true; break;
  }

 if(!count($args))
  $all=true;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT publisher,publisher_id,authors,author_id,publish_date,isbn,barcode,pagecount,preview_link,info_link,language,item_location,qty_sold,units,hide_in_store FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 if($publisher || $all)
 {
  $itemInfo['publisher'] = $db->record['publisher'];
  $itemInfo['publisher_id'] = $db->record['publisher_id'];
 }
 if($authors || $all)
 {
  $itemInfo['authors'] = $db->record['authors'];
  $itemInfo['author_id'] = $db->record['author_id'];
 }
 if($publishDate || $all)		$itemInfo['publish_date'] = ($db->record['publish_date'] != "0000-00-00") ? $db->record['publish_date'] : "";
 if($isbn || $all)				$itemInfo['isbn'] = $db->record['isbn'];
 if($pagecount || $all)			$itemInfo['pagecount'] = $db->record['pagecount'];
 if($previewLink || $all)		$itemInfo['preview_link'] = $db->record['preview_link'];
 if($infoLink || $all)			$itemInfo['info_link'] = $db->record['info_link'];
 if($language || $all)			$itemInfo['language'] = $db->record['language'];
 if($barcode || $all)			$itemInfo['barcode'] = $db->record['barcode'];
 if($itemLocation || $all)		$itemInfo['item_location'] = $db->record['item_location'];
 if($qtySold || $all)			$itemInfo['sold'] = $db->record['qty_sold'];
 if($units || $all)				$itemInfo['units'] = $db->record['units'];
 if($hideInStore || $all)		$itemInfo['hide_in_store'] = $db->record['hide_in_store'];

 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 $db = new AlpaDatabase();
 $db2 = new AlpaDatabase();
 $db->RunQuery("SELECT publisher,publisher_id,authors,author_id,publish_date,isbn,barcode,pagecount,preview_link,info_link,language,item_location,qty_sold,units,hide_in_store FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$srcInfo['id']."'");
 $db->Read();
 $db2->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET publisher='".$db2->Purify($db->record['publisher'])."',publisher_id='"
	.$db->record['publisher_id']."',authors='".$db2->Purify($db->record['authors'])."',author_id='".$db->record['author_id']."',publish_date='"
	.$db->record['publish_date']."',isbn='".$db->record['isbn']."',barcode='".$db->record['barcode']."',pagecount='"
	.$db->record['pagecount']."',preview_link='".$db->record['preview_link']."',info_link='".$db->record['info_link']."',language='"
	.$db->record['language']."',item_location='".$db2->Purify($db->record['item_location'])."',units='".$db->record['units']."',hide_in_store='"
	.$db->record['hide_in_store']."' WHERE id='".$cloneInfo['id']."'");
 $db2->Close();
 $db->Close();

 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 if($isCategory)
  return;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT publisher,publisher_id,authors,author_id,publish_date,isbn,barcode,pagecount,preview_link,info_link,language,item_location,qty_sold,units,hide_in_store FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 $xml = "<gbook publisher='".$db->record['publisher']."' publisher_id='".$db->record['publisher_id']."' authors='"
	.$db->record['authors']."' author_id='".$db->record['author_id']."' publish_date='".$db->record['publish_date']."' isbn='"
	.$db->record['isbn']."' barcode='".$db->record['barcode']."' pagecount='".$db->record['pagecount']."' preview_link='"
	.$db->record['preview_link']."' info_link='".$db->record['info_link']."' language='".$db->record['language']."'	item_location='".$db->record['item_location']."' units='".$db->record['units']."' hideinstore='".$db->record['hide_in_store']."'/>";
 $db->Close();
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 if($isCategory)
  return;

 if(!$node)
  return;

 $q = "";
 $db = new AlpaDatabase();
 if($publisher = $node->getString('publisher'))			$q.= ",publisher='".$db->Purify($publisher)."'";
 if($publisherId = $node->getString('publisher_id'))	$q.= ",publisher_id='".$publisherId."'";
 if($authors = $node->getString('authors'))				$q.= ",authors='".$db->Purify($authors)."'";
 if($authorId = $node->getString('author_id'))			$q.= ",author_id='".$authorId."'";
 if($publishDate = $node->getString('publish_date'))	$q.= ",publish_date='".$publishDate."'";
 if($isbn = $node->getString('isbn'))					$q.= ",isbn='".$isbn."'";
 if($pagecount = $node->getString('pagecount'))			$q.= ",pagecount='".$pagecount."'";
 if($previewLink = $node->getString('preview_link'))	$q.= ",preview_link='".$previewLink."'";
 if($infoLink = $node->getString('info_link'))			$q.= ",info_link='".$infoLink."'";
 if($language = $node->getString('language'))			$q.= ",language='".$language."'";
 if($barcode = $node->getString('barcode'))				$q.= ",barcode='".$barcode."'";
 if($location = $node->getString('item_location'))		$q.= ",item_location='".$location."'";
 if($units = $node->getString('units'))					$q.= ",units='".$units."'";
 if($hideInStore = $node->getString('hideinstore'))		$q.= ",hide_in_store='".$hideInStore."'";
 
 $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET ".ltrim($q,",")." WHERE id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_syncexport($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_USERS_HOMES;
 $xml = "";
 $attachments = array();

 return array('xml'=>$xml,'attachments'=>$attachments);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gbook_syncimport($sessid, $shellid, $archiveInfo, $itemInfo, $xmlNode, $isCategory=false)
{
 global $_USER_PATH;
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

