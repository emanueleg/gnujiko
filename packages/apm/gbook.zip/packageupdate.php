<?php global $_BASE_PATH, $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Sistema il gruppo ed i permessi */
include_once($_BASE_PATH."include/userfunc.php");
$gid = _getGID("gbook");
$db = new AlpaDatabase();
$db->RunQuery("UPDATE gnujiko_applications SET gid='".$gid."',_mod='640' WHERE url='Books/'");
$db->Close();

/* 26-09-2015 : aggiunto hide_in_store */
$db = new AlpaDatabase();
$db2 = new AlpaDatabase();
$db->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE archive_type='gbook'");
while($db->Read())
{
 $db2->RunQuery("ALTER TABLE `dynarc_".$db->record['tb_prefix']."_items` ADD `hide_in_store` TINYINT(1) NOT NULL, ADD INDEX (`hide_in_store`)");
}
$db2->Close();
$db->Close();