<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `gbook` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Books/'");
if($db->Read())
 $db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Libri...";
 $ret = GShell("system register-app -name `Libri` -desc `Catalogo Libri personalizzabile` -url 'Books/' -icon 'Books/icon.png' -group gbook -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new archive */
$_SHELL_OUT.= "Create new archive Libri...";
$ret = GShell("dynarc new-archive -name `Libri` -prefix 'gbook' -type gbook -group 'gbook' -perms '664' --def-cat-perms '664' --def-item-perms '664' --functions-file `etc/dynarc/archive_funcs/__gbook/index.php` -launcher `gframe -f gbook/edit.item -params id=%d`",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Create new archive Editori...";
$ret = GShell("dynarc new-archive -name `Editori` -prefix 'publishers' -perms '664' --def-cat-perms '664' --def-item-perms '664'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Create new archive Autori...";
$ret = GShell("dynarc new-archive -name `Autori` -prefix 'authors' -perms '664' --def-cat-perms '664' --def-item-perms '664'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension 'coding' -ap 'gbook'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension custompricing...";
$ret = GShell("dynarc install-extension 'custompricing' -ap 'gbook'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension gbook...";
$ret = GShell("dynarc install-extension 'gbook' -ap 'gbook'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension pricing...";
$ret = GShell("dynarc install-extension 'pricing' -ap 'gbook'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension storeinfo...";
$ret = GShell("dynarc install-extension 'storeinfo' -ap 'gbook'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension thumbnails...";
$ret = GShell("dynarc install-extension 'thumbnails' -ap 'gbook'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension vendorprices...";
$ret = GShell("dynarc install-extension 'vendorprices' -ap 'gbook'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension idoc...";
$ret = GShell("dynarc install-extension 'idoc' -ap 'gbook'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create category Libri...";
$ret = GShell("dynarc new-cat -ap 'publishers' -name `Libri` -tag `gbook` -group 'gbook' -perms '664'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Create category Libri...";
$ret = GShell("dynarc new-cat -ap 'authors' -name `Libri` -tag `gbook` -group 'gbook' -perms '664'",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];