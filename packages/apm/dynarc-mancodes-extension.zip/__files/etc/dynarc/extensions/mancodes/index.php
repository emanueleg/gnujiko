<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2014 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 13-09-2014
#PACKAGE: dynarc-mancodes-extension
#DESCRIPTION: 
#VERSION: 2.0beta
#CHANGELOG: 
#TODO: 
*/

global $_BASE_PATH;

function dynarcextension_mancodes_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_".$archiveInfo['prefix']."_mancodes` (
 `code` VARCHAR(32) NOT NULL ,
 `item_id` INT(11) NOT NULL ,
 PRIMARY KEY (`code`) , INDEX (`item_id`) )");
 $db->Close();

 return array("message"=>"mancodes extension has been installed into archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DROP TABLE IF EXISTS `dynarc_".$archiveInfo['prefix']."_mancodes`");
 $db->Close();

 return array("message"=>"mancodes extension has been removed from archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_catset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_catunset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_catget($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_mancodes_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'mancodes' : case 'codes' : case 'list' : case 'codelist' : {$codelist=$args[$c+1]; $c++;} break;
   case 'code' : {$code=$args[$c+1]; $c++;} break;
  }

 if(isset($codelist))
 {
  // empty list
  $db = new AlpaDatabase();
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_mancodes WHERE item_id='".$itemInfo['id']."'");
  $db->Close();

  if($codelist)
  {
   // register codes
   $list = explode(",",$codelist);
   $db = new AlpaDatabase();
   for($c=0; $c < count($list); $c++)
   {
    $code = trim($list[$c]);
	if(!$code) continue;
	$db->RunQuery("INSERT INTO dynarc_".$archiveInfo['prefix']."_mancodes(code,item_id) VALUES('".$db->Purify($code)."','".$itemInfo['id']."')");
	if($db->Error)
	{
     $err = $db->Error;
     $db->RunQuery("SELECT item_id FROM dynarc_".$archiveInfo['prefix']."_mancodes WHERE code='".$db->Purify($code)."'");
     if($db->Read())
	  return array("message"=>"Code '".$code."' already assigned.", "error"=>"CODE_ALREADY_EXISTS");
     else
	  return array("message"=>"MySQL error: ".$err, "error"=>"MYSQL_ERROR");
	}
   }
   $db->Close();
  }
 }
 else if($code)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("INSERT INTO dynarc_".$archiveInfo['prefix']."_mancodes(code,item_id) VALUES('".$db->Purify($code)."','".$itemInfo['id']."')");
  if($db->Error)
  {
   $err = $db->Error;
   $db->RunQuery("SELECT item_id FROM dynarc_".$archiveInfo['prefix']."_mancodes WHERE code='".$db->Purify($code)."'");
   if($db->Read())
	return array("message"=>"Code '".$code."' already assigned.", "error"=>"CODE_ALREADY_EXISTS");
   else
	return array("message"=>"MySQL error: ".$err, "error"=>"MYSQL_ERROR");
  }
  $db->Close();
 }
 

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_mancodes_catunset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'code' : {$code=$args[$c+1]; $c++;} break;
   case 'all' : {$all=$args[$c+1]; $c++;} break;
  }

 if($code)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_mancodes WHERE code='".$db->Purify($code)."'");
  $db->Close();
 }
 else if($all)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_mancodes WHERE item_id='".$itemInfo['id']."'");
  $db->Close();
 }

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_mancodes_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 $limit = 100;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'limit' : {$limit=$args[$c+1]; $c++;} break;
  }

 $itemInfo['mancodes'] = array();

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT code FROM dynarc_".$archiveInfo['prefix']."_mancodes WHERE item_id='".$itemInfo['id']."' ORDER BY code ASC LIMIT ".$limit);
 while($db->Read())
 {
  $itemInfo['mancodes'][] = $db->record['code'];
 }
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 $codes = "";
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT code FROM dynarc_".$archiveInfo['prefix']."_mancodes WHERE item_id='".$itemInfo['id']."' ORDER BY code ASC");
 while($db->Read())
 {
  $codes.= ",".$db->record['code'];
 }
 $db->Close();
 if($codes) $codes = ltrim($codes,",");

 $xml = "<mancodes codes='".$codes."'/>";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 if(!$node)
  return;

 $tmp = $node->getString('codes');
 if(!$tmp) return true;
 $codes = explode(",",$tmp);

 $db = new AlpaDatabase();
 for($c=0; $c < count($codes); $c++)
 {
  $code = trim($codes[$c]);
  if(!$code) continue;
  $db->RunQuery("INSERT INTO dynarc_".$archiveInfo['prefix']."_mancodes(code,item_id) VALUES('".$db->Purify($code)."','".$itemInfo['id']."')");
 }
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_mancodes WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_mancodes_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("TRUNCATE TABLE `dynarc_".$archiveInfo['prefix']."_mancodes`");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
