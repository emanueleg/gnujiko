<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

/* 18-02-2014 : Store fix */
 $qry = "";
 $ret = GShell("store list",$sessid,$shellid);
 $list = $ret['outarr'];
 for($c=0; $c < count($list); $c++)
  $qry.= ", ADD `store_".$list[$c]['id']."_qty` FLOAT NOT NULL";
 $qry = ltrim($qry,",");

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE archive_type='gmart'");
 while($db->Read())
 {
  $db2 = new AlpaDatabase();
  $db2->RunQuery("ALTER TABLE `dynarc_".$db->record['tb_prefix']."_items`".$qry);
  $db2->Close();
 }
 $db->Close();

/* 20-02-2014 : Aggiunto scorta minima */
$db = new AlpaDatabase();
$db->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE archive_type='gmart'");
while($db->Read())
{
 $db2 = new AlpaDatabase();
 $db2->RunQuery("ALTER TABLE `dynarc_".$db->record['tb_prefix']."_items` ADD `minimum_stock` FLOAT NOT NULL");
 $db2->Close();
}
$db->Close();

/* 25-03-2016 : Bug fix tabelle stockenhcat e stockenhitm */
if(version_compare($_INSTALLED_VER, "2.9beta", "<"))
{
 $ret = GShell("dynarc extension-info storeinfo", $_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
 {
  $ret = GShell("store list",$_SESSION_ID, $_SHELL_ID);
  $list = $ret['outarr'];
  for($i=0; $i < count($ret['outarr']['archives']); $i++)
  {
   $ap = $ret['outarr']['archives'][$i]['ap'];
 
   // creo tabella stockenhcat //
   $db = new AlpaDatabase();
   $query = "CREATE TABLE IF NOT EXISTS `dynarc_".$ap."_stockenhcat` (`cat_id` INT(11) NOT NULL PRIMARY KEY";
   for($c=0; $c < count($list); $c++)
    $query.= ", `store_".$list[$c]['id']."_amount` DECIMAL(10,5) NOT NULL, `store_".$list[$c]['id']."_vat` DECIMAL(10,5) NOT NULL, `store_".$list[$c]['id']."_total` DECIMAL(10,5) NOT NULL";
   $query.= ")";
   $db->RunQuery($query);
   $db->Close();

   // creo tabella stockenhitm //
   $db = new AlpaDatabase();
   $query = "CREATE TABLE IF NOT EXISTS `dynarc_".$ap."_stockenhitm` (`item_id` INT(11) NOT NULL PRIMARY KEY";
   for($c=0; $c < count($list); $c++)
    $query.= ", `store_".$list[$c]['id']."_qty` FLOAT NOT NULL, `store_".$list[$c]['id']."_amount` DECIMAL(10,5) NOT NULL, `store_".$list[$c]['id']."_vat` DECIMAL(10,5) NOT NULL, `store_".$list[$c]['id']."_total` DECIMAL(10,5) NOT NULL";
   $query.= ")";
   $db->RunQuery($query);
   $db->Close();
  }
 }
}