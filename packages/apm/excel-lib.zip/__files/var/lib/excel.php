<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 19-03-2013
 #PACKAGE: excel-lib
 #DESCRIPTION: Excel library
 #VERSION: 2.0-1.7.8
 #CHANGELOG: 
*/

require_once($_BASE_PATH."var/lib/excel/PHPExcel.php");
