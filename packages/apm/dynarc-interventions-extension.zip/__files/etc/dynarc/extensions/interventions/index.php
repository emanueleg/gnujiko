<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: dynarc-interventions-extension
 #DESCRIPTION: Estensione interventi per archivi Dynarc. 
 #VERSION: 2.1beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.
 #TODO: 
 
*/

global $_BASE_PATH;

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_".$archiveInfo['prefix']."_interventions` (
 `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
 `item_id` INT(11) NOT NULL ,
 `date` DATE NOT NULL ,
 `name` VARCHAR(255) NOT NULL ,
 `description` TEXT NOT NULL ,
 `operator_id` INT(11) NOT NULL ,
 `operator_name` VARCHAR(32) NOT NULL ,
 `tot_hours` VARCHAR(7) NOT NULL ,
 `tot_extra_hours` VARCHAR(7) NOT NULL ,
 `start_time_1` VARCHAR(5) NOT NULL ,
 `end_time_1` VARCHAR(5) NOT NULL ,
 `start_time_2` VARCHAR(5) NOT NULL ,
 `end_time_2` VARCHAR(5) NOT NULL ,
 `tot_amount` DECIMAL(10,4) NOT NULL ,
 `job_type` INT(11) NOT NULL ,
 INDEX (`item_id`,`operator_id`,`job_type`) 
)");
 $db->Close();

 return array("message"=>"Interventions extension has been installed into archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DROP TABLE IF EXISTS `dynarc_".$archiveInfo['prefix']."_interventions`");
 $db->Close();

 return array("message"=>"Interventions extension has been removed from archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* REMOVE ALL ITEM EVENTS */
 $db = new AlpaDatabase();
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_interventions WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_set($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 global $_BASE_PATH, $_ABSOLUTE_URL, $_COMPANY_PROFILE;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'date' : {$date=$args[$c+1]; $c++;} break;
   case 'name' : case 'title' : {$name=$args[$c+1]; $c++;} break;
   case 'desc' : case 'description' : {$description=$args[$c+1]; $c++;} break;
   case 'opid' : case 'operatorid' : {$operatorId=$args[$c+1]; $c++;} break;
   case 'opname' : case 'operatorname' : {$operatorName=$args[$c+1]; $c++;} break;
   case 'tothours' : {$totHours=$args[$c+1]; $c++;} break;
   case 'totextra' : case 'totextrahours' : case 'extrahours' : {$totExtraHours=$args[$c+1]; $c++;} break;
   case 'totamount' : {$totAmount=$args[$c+1]; $c++;} break;
   case 'starttime' : {$startTime1=$args[$c+1]; $c++;} break;
   case 'endtime' : {$endTime1=$args[$c+1]; $c++;} break;
   case 'starttime2' : {$startTime2=$args[$c+1]; $c++;} break;
   case 'endtime2' : {$endTime2=$args[$c+1]; $c++;} break;
   case 'jobtype' : {$jobTypeId=$args[$c+1]; $c++;} break;
  }

 $sessInfo = sessionInfo($sessid);

 if($id)
 {
  $db = new AlpaDatabase();
  $q = "";
  
  if($date)					$q.= ",date='".$date."'";
  if($name)					$q.= ",name='".$db->Purify($name)."'";
  if(isset($description))   $q.= ",description='".$db->Purify($description)."'";
  if(isset($operatorId))	$q.= ",operator_id='".$operatorId."'";
  if(isset($operatorName))  $q.= ",operator_name='".$db->Purify($operatorName)."'";
  if(isset($totHours))		$q.= ",tot_hours='".$totHours."'";
  if(isset($totExtraHours))	$q.= ",tot_extra_hours='".$totExtraHours."'";
  if(isset($totAmount))		$q.= ",tot_amount='".$totAmount."'";
  if(isset($startTime1))	$q.= ",start_time_1='".$startTime1."'";
  if(isset($endTime1))		$q.= ",end_time_1='".$endTime1."'";
  if(isset($startTime2))	$q.= ",start_time_2='".$startTime2."'";
  if(isset($endTime2))		$q.= ",end_time_2='".$endTime2."'";
  if(isset($jobTypeId))		$q.= ",job_type='".$jobTypeId."'";
   
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_interventions SET ".ltrim($q,',')." WHERE id='".$id."'");
  $db->Close();
 }
 else
 {
  $db = new AlpaDatabase();
  $db->RunQuery("INSERT INTO dynarc_".$archiveInfo['prefix']."_interventions(item_id,date,name,description,operator_id,operator_name,
tot_hours,tot_extra_hours,start_time_1,end_time_1,start_time_2,end_time_2,tot_amount,job_type) VALUE('".$itemInfo['id']."','".$date."','".$db->Purify($name)."','"
	.$db->Purify($description)."','".$operatorId."','".$db->Purify($operatorName)."','".$totHours."','".$totExtraHours."','"
	.$startTime1."','".$endTime1."','".$startTime2."','".$endTime2."','".$totAmount."','".$jobTypeId."')");
  $id = $db->GetInsertId();
  $db->Close();
 }

 $itemInfo['last_element'] = array('id'=>$id, 'item_id'=>$itemInfo['id'], 'date'=>$date, 'name'=>$name, 'desc'=>$description,
	'operator_id'=>$operatorId, 'operator_name'=>$operatorName, 'tot_hours'=>$totHours, 'tot_extra_hours'=>$totExtraHours,
	'start_time'=>$startTime1, 'end_time'=>$endTime1, 'start_time2'=>$startTime2, 'end_time2'=>$endTime2, 'tot_amount'=>$totAmount,
	'job_type'=>$jobTypeId);

  // get tot_minutes
  $minutes = 0;
  if($itemInfo['last_element']['tot_hours'])
  {
   $x = explode(":",$itemInfo['last_element']['tot_hours']);
   $minutes+= (($x[0]*60)+$x[1]);
  }
  if($itemInfo['last_element']['tot_extra_hours'])
  {
   $x = explode(":",$itemInfo['last_element']['tot_extra_hours']);
   $minutes+= (($x[0]*60)+$x[1]);
  }
  $itemInfo['last_element']['tot_minutes'] = $minutes;

  // get subtot hours
  $hh = 0;
  $mm = 0;
  $totHours = "0:00";
  if($minutes)
  {
   $hh = floor($minutes/60);
   $mm = $minutes-($hh*60);
   $totHours = $hh.":".($mm<10 ? "0".$mm : $mm);
  }
  $itemInfo['last_element']['subtot_hours'] = $totHours;


 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'all' : $all=true; break;
  }
 
 $db = new AlpaDatabase();
 if($id)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_interventions WHERE id='".$id."'");
 else if($all)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_interventions WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_get($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 global $_BASE_PATH, $_ABSOLUTE_URL, $_COMPANY_PROFILE;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$archiveInfo['prefix']."_interventions WHERE item_id='".$itemInfo['id']."' ORDER BY date ASC");
 while($db->Read())
 {
  $a = array('id'=>$db->record['id'], 'date'=>$db->record['date'], 'name'=>$db->record['name'], 'desc'=>$db->record['description'],
	'operator_id'=>$db->record['operator_id'], 'operator_name'=>$db->record['operator_name'], 'tot_hours'=>$db->record['tot_hours'],
	'tot_extra_hours'=>$db->record['tot_extra_hours'], 'start_time'=>$db->record['start_time_1'], 'end_time'=>$db->record['end_time_1'],
	'start_time2'=>$db->record['start_time_2'], 'end_time2'=>$db->record['end_time_2'], 'tot_amount'=>$db->record['tot_amount'],
	'job_type'=>$db->record['job_type']);

  // get tot_minutes
  $minutes = 0;
  if($a['tot_hours'])
  {
   $x = explode(":",$a['tot_hours']);
   $minutes+= (($x[0]*60)+$x[1]);
  }
  if($a['tot_extra_hours'])
  {
   $x = explode(":",$a['tot_extra_hours']);
   $minutes+= (($x[0]*60)+$x[1]);
  }
  $a['tot_minutes'] = $minutes;

  // get subtot hours
  $hh = 0;
  $mm = 0;
  $totHours = "0:00";
  if($minutes)
  {
   $hh = floor($minutes/60);
   $mm = $minutes-($hh*60);
   $totHours = $hh.":".($mm<10 ? "0".$mm : $mm);
  }
  $a['subtot_hours'] = $totHours;
  

  $itemInfo['interventions'][] = $a;
 }
 $db->Close();
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_export($sessid, $shellid, $archiveInfo, $itemInfo)
{
 $xml = "";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_import($sessid, $shellid, $archiveInfo, $itemInfo, $node)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_syncexport($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_USERS_HOMES;
 $xml = "";
 $attachments = array();

 return array('xml'=>$xml,'attachments'=>$attachments);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_interventions_syncimport($sessid, $shellid, $archiveInfo, $itemInfo, $xmlNode, $isCategory=false)
{
 global $_USER_PATH;
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

