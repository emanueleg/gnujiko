<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 04-10-2014
 #PACKAGE: dynarc-interventions-extension
 #DESCRIPTION: Registrazione intervento
 #VERSION: 2.1beta
 #CHANGELOG: 04-10-2014 : Rinominato operatore con tecnico.
 #DEPENDS:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate("widget");
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeObject("fckeditor");
$template->includeInternalObject("contactsearch");

$template->Begin("Nuovo intervento");
//-------------------------------------------------------------------------------------------------------------------//

$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : $_REQUEST['refap'];
$_ID = $_REQUEST['id'] ? $_REQUEST['id'] : $_REQUEST['refid'];

//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-header bg-blue"><h3>Nuovo intervento</h3></div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",700);


//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-body" style="width:684px;height:400px">
<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td><label>Titolo</label><br/>
	 <input type="text" class="edit" id="title" style="width:410px" value=""/>
	</td>
	<td width='120'><label>Data</label><br/>
	 <input type='text' class='calendar' id='date' placeholder='gg/mm/aaaa' value="<?php echo date('d/m/Y'); ?>"/>
	</td>
	<td width='60' align='right'><label style='font-size:10px'>ora inizio</label><br/>
	 <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='starttime'/></td>
	<td width='20' align='center'><b>-</b></td>
	<td width='60'><label style='font-size:10px'>ora fine</label><br/>
	 <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='endtime'/></td>
</tr>
</table>

<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform" style="margin-top:10px">
<tr><td><label>Tipo di lavoro</label><br/>
	 <input type='text' class='search' style='width:220px' id='jobtype' ap="jobtype"/>
	 <img src="<?php echo $_ABSOLUTE_URL; ?>share/widgets/intervention/img/add.png" onclick="NewJobType()" style="cursor:pointer"/>
	</td>
	<td width='270'><label>Tecnico</label><br/>
	 <input type='text' class='search' style='width:250px' id='operator' ct='employees'/></td>
	<td width='60' align='right'><label style='font-size:10px'>ora inizio 2</label><br/>
	 <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='starttime2'/></td>
	<td width='20' align='center'><b>-</b></td>
	<td width='60'><label style='font-size:10px'>ora fine 2</label><br/>
	 <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='endtime2'/></td>
</tr>
</table>

<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr class='separator'><td colspan="3"><hr style="width:670px"/></td></tr>
<tr><td width='280'>Tot. ore ordinarie: <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='tothours'/></td>
	<td>Tot. ore straord.: <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='totextrahours'/></td>
	<td align='right'>Tot. importi: &euro; <input type='text' class='edit' style='width:70px;text-align:right' value='0,00' id='totamount'/></tr>

<tr class='separator'><td colspan="3"><hr style="width:670px"/></td></tr>

<tr><td colspan='3'><label>Dettagli</label><br/>
	 <textarea class="textarea" id="description" style="width:676px;height:200px"></textarea>
    </td></tr>
</table>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$footer = "<input type='button' class='button-blue' value='Salva' style='float:left' onclick='SubmitAction()'/>";
$footer.= "<input type='button' class='button-gray' value='Annulla' style='float:right' onclick='abort()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";

function abort()
{
 if(!confirm("Sei sicuro di voler annullare l'operazione?"))
  return false;
 Template.Exit();
}

Template.OnInit = function(){
	 this.initEd(document.getElementById("description"), "fckeditor", "Basic");
	 this.initEd(document.getElementById("date"), "date");
	 this.initEd(document.getElementById("operator"), "contact");
	 this.initEd(document.getElementById("starttime"), "timelength").OnChange = function(){calculateHours();}
	 this.initEd(document.getElementById("endtime"), "timelength").OnChange = function(){calculateHours();}
	 this.initEd(document.getElementById("starttime2"), "timelength").OnChange = function(){calculateHours();}
	 this.initEd(document.getElementById("endtime2"), "timelength").OnChange = function(){calculateHours();}
	 this.initEd(document.getElementById("tothours"), "timelength").OnChange = function(){
		 var h = parse_timelength(this.value);
		 var r = parse_timelength(document.getElementById('endtime').value) - parse_timelength(document.getElementById('starttime').value);
		 r+= parse_timelength(document.getElementById('endtime2').value) - parse_timelength(document.getElementById('starttime2').value);
		 if(r <= 0) return;
		 if(h > r)
		 {
		  if(confirm("Il totale ore ordinarie che stai inserendo a mano supera il totale calcolato dai campi 'ora inizio' e 'ora fine'. Desideri continuare (quindi mi tocca resettarti i campi ora inizio e fine, perchè non hanno senso), oppure... è meglio fare una pausa caffè?"))
		  {
		   document.getElementById('starttime').value = "";		   document.getElementById('endtime').value = "";
		   document.getElementById('starttime2').value = "";	   document.getElementById('endtime2').value = "";
		   document.getElementById("totextrahours").value = "";
		  }
		  return;
		 }
		 document.getElementById("totextrahours").value = timelength_to_str(r-h);
		}
	 this.initEd(document.getElementById("totextrahours"), "timelength").OnChange = function(){
		 var xh = parse_timelength(this.value);
		 var h = parse_timelength(document.getElementById("tothours").value);
		 var r = parse_timelength(document.getElementById('endtime').value) - parse_timelength(document.getElementById('starttime').value);
		 r+= parse_timelength(document.getElementById('endtime2').value) - parse_timelength(document.getElementById('starttime2').value);
		 if(!r) return;
		 if(xh > r)
		 {
		  if(confirm("Il totale ore straordinare che stai inserendo a mano supera il totale calcolato dai campi 'ora inizio' e 'ora fine'. Desideri continuare (quindi mi tocca resettarti i campi ora inizio e fine perchè non hanno senso), oppure... è meglio fare una pausa caffè?"))
		  {
		   document.getElementById('starttime').value = "";		   document.getElementById('endtime').value = "";
		   document.getElementById('starttime2').value = "";	   document.getElementById('endtime2').value = "";
		   document.getElementById("tothours").value = "";
		  }
		  return;
		 }
		 document.getElementById("tothours").value = timelength_to_str(r-xh);
		}
	 this.initEd(document.getElementById("totamount"), "currency");	 
	 this.initEd(document.getElementById("jobtype"), "itemfind");
}

function SubmitAction()
{
 var title = document.getElementById("title").value;
 var date = document.getElementById('date').isodate;
 var operatorId = document.getElementById('operator').getId();
 var operatorName = document.getElementById('operator').value;
 var startTime = document.getElementById('starttime').value;
 var endTime = document.getElementById('endtime').value;
 var startTime2 = document.getElementById('starttime2').value;
 var endTime2 = document.getElementById('endtime2').value;
 var description = document.getElementById("description").getValue();
 var totHours = document.getElementById("tothours").value;
 var totExtraHours = document.getElementById("totextrahours").value;
 var totAmount = document.getElementById("totamount").value;
 var jobTypeId = document.getElementById("jobtype").getId();

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){gframe_close(o,a);}

 var cmd = "dynarc edit-item -ap '<?php echo $_AP; ?>' -id `<?php echo $_ID; ?>` -extset `interventions.date='"+date+"',name='''"+title.E_QUOT()+"''',desc='''"+description+"''',opid='"+operatorId+"',opname='''"+operatorName.E_QUOT()+"''',tothours='"+totHours+"',totextrahours='"+totExtraHours+"',totamount='"+totAmount+"',starttime='"+startTime+"',endtime='"+endTime+"',starttime2='"+startTime2+"',endtime2='"+endTime2+"',jobtype='"+jobTypeId+"'`";
 sh.sendCommand(cmd);
}

function NewJobType()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.sendCommand("gframe -f jobtype/new");
}

function calculateHours()
{
 document.getElementById("totextrahours").value = "";
 var r = parse_timelength(document.getElementById('endtime').value) - parse_timelength(document.getElementById('starttime').value);
 r+= parse_timelength(document.getElementById('endtime2').value) - parse_timelength(document.getElementById('starttime2').value);
 document.getElementById("tothours").value = (r > 0) ? timelength_to_str(r) : "0:00";
}

</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

