<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 04-10-2014
 #PACKAGE: dynarc-interventions-extension
 #DESCRIPTION: Modifica intervento
 #VERSION: 2.1beta
 #CHANGELOG: 04-10-2014 : Rinominato operatore con tecnico.
 #DEPENDS:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate("widget");
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeObject("fckeditor");
$template->includeInternalObject("contactsearch");

$template->Begin("Dettagli intervento");
//-------------------------------------------------------------------------------------------------------------------//

$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : $_REQUEST['refap'];
$_REFID = $_REQUEST['refid'];
$_ID = $_REQUEST['id'];

//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-header bg-blue"><h3>Dettagli intervento</h3></div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",700);

$db = new AlpaDatabase();
$db->RunQuery("SELECT date,name,description,operator_id,operator_name,tot_hours,tot_extra_hours,start_time_1,end_time_1,start_time_2,end_time_2,tot_amount,job_type FROM dynarc_".$_AP."_interventions WHERE id='".$_ID."'");
$db->Read();
$itemInfo = $db->record;

if($itemInfo['job_type'])
{
 // get job type name //
 $db->RunQuery("SELECT name FROM dynarc_jobtype_items WHERE id='".$itemInfo['job_type']."'");
 $db->Read();
 $itemInfo['job_type_name'] = $db->record['name'];
}

$db->Close();

//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-body" style="width:684px;height:400px">
<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td><label>Titolo</label><br/>
	 <input type="text" class="edit" id="title" style="width:410px" value="<?php echo $itemInfo['name']; ?>"/>
	</td>
	<td width='120'><label>Data</label><br/>
	 <input type='text' class='calendar' id='date' placeholder='gg/mm/aaaa' value="<?php echo date('d/m/Y',strtotime($itemInfo['date'])); ?>"/>
	</td>
	<td width='60' align='right'><label style='font-size:10px'>ora inizio</label><br/>
	 <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='starttime' value="<?php echo $itemInfo['start_time_1']; ?>"/></td>
	<td width='20' align='center'><b>-</b></td>
	<td width='60'><label style='font-size:10px'>ora fine</label><br/>
	 <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='endtime' value="<?php echo $itemInfo['end_time_1']; ?>"/></td>
</tr>
</table>

<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform" style="margin-top:10px">
<tr><td><label>Tipo di lavoro</label><br/>
	 <input type='text' class='search' style='width:220px' id='jobtype' ap='jobtype' refid="<?php echo $itemInfo['job_type']; ?>" value="<?php echo $itemInfo['job_type_name']; ?>"/>
	 <img src="<?php echo $_ABSOLUTE_URL; ?>share/widgets/intervention/img/add.png" onclick="NewJobType()" style="cursor:pointer"/>
	</td>
	<td width='270'><label>Tecnico</label><br/>
	 <input type='text' class='search' style='width:250px' id='operator' value="<?php echo $itemInfo['operator_name']; ?>" refid="<?php echo $itemInfo['operator_id']; ?>" ct='employees'/></td>
	<td width='60' align='right'><label style='font-size:10px'>ora inizio 2</label><br/>
	 <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='starttime2' value="<?php echo $itemInfo['start_time_2']; ?>"/></td>
	<td width='20' align='center'><b>-</b></td>
	<td width='60'><label style='font-size:10px'>ora fine 2</label><br/>
	 <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='endtime2' value="<?php echo $itemInfo['end_time_2']; ?>"/></td>
</tr>
</table>

<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr class='separator'><td colspan="3"><hr style="width:670px"/></td></tr>
<tr><td width='280'>Tot. ore ordinarie: <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='tothours' value="<?php echo $itemInfo['tot_hours']; ?>"/></td>
	<td>Tot. ore straord.: <input type='text' class='edit' style='width:60px' placeholder='hh:mm' id='totextrahours' value="<?php echo $itemInfo['tot_extra_hours']; ?>"/></td>
	<td align='right'>Tot. importi: &euro; <input type='text' class='edit' style='width:70px;text-align:right' value="<?php echo number_format($itemInfo['tot_amount'],2,',','.'); ?>" id='totamount'/></tr>

<tr class='separator'><td colspan="3"><hr style="width:670px"/></td></tr>

<tr><td colspan='3'><label>Dettagli</label><br/>
	 <textarea class="textarea" id="description" style="width:676px;height:200px"><?php echo $itemInfo['description']; ?></textarea>
    </td></tr>
</table>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$footer = "<input type='button' class='button-blue' value='Salva' style='float:left' onclick='SubmitAction()'/>";
$footer.= "<input type='button' class='button-gray' value='Chiudi' style='float:left;margin-left:10px' onclick='abort()'/>";
$footer.= "<input type='button' class='button-red' value='Elimina' style='float:right' onclick='DeleteIntervention()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";
var REFID = "<?php echo $_REFID; ?>";
var ID = "<?php echo $_ID; ?>";


function abort(){Template.Exit();}

Template.OnInit = function(){
	 this.initEd(document.getElementById("description"), "fckeditor", "Basic");
	 this.initEd(document.getElementById("date"), "date");
	 this.initEd(document.getElementById("operator"), "contact");
	 this.initEd(document.getElementById("starttime"), "timelength").OnChange = function(){calculateHours();}
	 this.initEd(document.getElementById("endtime"), "timelength").OnChange = function(){calculateHours();}
	 this.initEd(document.getElementById("starttime2"), "timelength").OnChange = function(){calculateHours();}
	 this.initEd(document.getElementById("endtime2"), "timelength").OnChange = function(){calculateHours();}
	 this.initEd(document.getElementById("tothours"), "timelength").OnChange = function(){
		 var h = parse_timelength(this.value);
		 var r = parse_timelength(document.getElementById('endtime').value) - parse_timelength(document.getElementById('starttime').value);
		 r+= parse_timelength(document.getElementById('endtime2').value) - parse_timelength(document.getElementById('starttime2').value);
		 if(r <= 0) return;
		 if(h > r)
		 {
		  if(confirm("Il totale ore ordinarie che stai inserendo a mano supera il totale calcolato dai campi 'ora inizio' e 'ora fine'. Desideri continuare (quindi mi tocca resettarti i campi ora inizio e fine, perchè non hanno senso), oppure... è meglio fare una pausa caffè?"))
		  {
		   document.getElementById('starttime').value = "";		   document.getElementById('endtime').value = "";
		   document.getElementById('starttime2').value = "";	   document.getElementById('endtime2').value = "";
		   document.getElementById("totextrahours").value = "";
		  }
		  return;
		 }
		 document.getElementById("totextrahours").value = timelength_to_str(r-h);
		}
	 this.initEd(document.getElementById("totextrahours"), "timelength").OnChange = function(){
		 var xh = parse_timelength(this.value);
		 var h = parse_timelength(document.getElementById("tothours").value);
		 var r = parse_timelength(document.getElementById('endtime').value) - parse_timelength(document.getElementById('starttime').value);
		 r+= parse_timelength(document.getElementById('endtime2').value) - parse_timelength(document.getElementById('starttime2').value);
		 if(!r) return;
		 if(xh > r)
		 {
		  if(confirm("Il totale ore straordinare che stai inserendo a mano supera il totale calcolato dai campi 'ora inizio' e 'ora fine'. Desideri continuare (quindi mi tocca resettarti i campi ora inizio e fine perchè non hanno senso), oppure... è meglio fare una pausa caffè?"))
		  {
		   document.getElementById('starttime').value = "";		   document.getElementById('endtime').value = "";
		   document.getElementById('starttime2').value = "";	   document.getElementById('endtime2').value = "";
		   document.getElementById("tothours").value = "";
		  }
		  return;
		 }
		 document.getElementById("tothours").value = timelength_to_str(r-xh);
		}
	 this.initEd(document.getElementById("totamount"), "currency");
	 this.initEd(document.getElementById("jobtype"), "itemfind");
}

function DeleteIntervention()
{
 if(!confirm("Sei sicuro di voler eliminare questo intervento?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 a['removed'] = true;
	 gframe_close(o,a);
	}
 sh.sendCommand("dynarc edit-item -ap '"+AP+"' -id '"+REFID+"' -extunset `interventions.id="+ID+"`");
}

function SubmitAction()
{
 var title = document.getElementById("title").value;
 var date = document.getElementById('date').isodate;
 var operatorId = document.getElementById('operator').getId();
 var operatorName = document.getElementById('operator').value;
 var startTime = document.getElementById('starttime').value;
 var endTime = document.getElementById('endtime').value;
 var startTime2 = document.getElementById('starttime2').value;
 var endTime2 = document.getElementById('endtime2').value;
 var description = document.getElementById("description").getValue();
 var totHours = document.getElementById("tothours").value;
 var totExtraHours = document.getElementById("totextrahours").value;
 var totAmount = document.getElementById("totamount").value;
 var jobTypeId = document.getElementById("jobtype").getId();

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){gframe_close(o,a);}

 var cmd = "dynarc edit-item -ap '"+AP+"' -id `"+REFID+"` -extset `interventions.id="+ID+",date='"+date+"',name='''"+title.E_QUOT()+"''',desc='''"+description+"''',opid='"+operatorId+"',opname='''"+operatorName.E_QUOT()+"''',tothours='"+totHours+"',totextrahours='"+totExtraHours+"',totamount='"+totAmount+"',starttime='"+startTime+"',endtime='"+endTime+"',starttime2='"+startTime2+"',endtime2='"+endTime2+"',jobtype='"+jobTypeId+"'`";
 sh.sendCommand(cmd);
}

function NewJobType()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.sendCommand("gframe -f jobtype/new");
}

function calculateHours()
{
 document.getElementById("totextrahours").value = "";
 var r = parse_timelength(document.getElementById('endtime').value) - parse_timelength(document.getElementById('starttime').value);
 r+= parse_timelength(document.getElementById('endtime2').value) - parse_timelength(document.getElementById('starttime2').value);
 document.getElementById("tothours").value = (r > 0) ? timelength_to_str(r) : "0:00";
}
</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

