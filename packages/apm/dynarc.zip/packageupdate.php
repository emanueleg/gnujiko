<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

/* 16-11-2012 */
// Update tables
if(version_compare($_INSTALLED_VER,"2.56beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_archives` ADD `sync_enabled` TINYINT( 1 ) NOT NULL , ADD INDEX ( `sync_enabled` )");
 $db->Close();

 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarcsync_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `device_type` varchar(64) NOT NULL,
  `url` varchar(255) NOT NULL,
  `login` varchar(40) NOT NULL,
  `password` varchar(32) NOT NULL,
  `last_sync_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
 )");
 $db->Close();
}	 

if(version_compare($_INSTALLED_VER,"2.65beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_archives` ADD `shgrps` VARCHAR(255) NOT NULL, ADD `shusrs` VARCHAR(255) NOT NULL");
 $db->Close();
}