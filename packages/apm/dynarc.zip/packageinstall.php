<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Creating tables */
$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_archives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `_mod` varchar(3) NOT NULL,
  `archive_type` varchar(32) NOT NULL,
  `name` varchar(80) NOT NULL,
  `description` varchar(255) NOT NULL,
  `tb_prefix` varchar(64) NOT NULL,
  `fun_file` varchar(255) NOT NULL,
  `default_cat_perms` varchar(3) NOT NULL,
  `default_item_perms` varchar(3) NOT NULL,
  `default_cat_published` tinyint(1) NOT NULL,
  `default_item_published` tinyint(1) NOT NULL,
  `trash` tinyint(1) NOT NULL,
  `launcher` varchar(255) NOT NULL,
  `tb_inherit` varchar(64) NOT NULL,
  `hidden` tinyint(1) NOT NULL,
  `thumb_img` varchar(255) NOT NULL,
  `thumb_mode` tinyint(1) NOT NULL,
  `params` varchar(255) NOT NULL,
  `sync_enabled` tinyint(1) NOT NULL,
  `shgrps` VARCHAR(255) NOT NULL,
  `shusrs` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`gid`,`_mod`,`name`,`tb_prefix`,`trash`,`sync_enabled`),
  KEY `hidden` (`hidden`)
)");

$db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_archive_extensions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `archive_id` int(11) NOT NULL,
  `extension_name` varchar(64) NOT NULL,
  `params` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `archive_id` (`archive_id`)
)");

$db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarcsync_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `device_type` varchar(64) NOT NULL,
  `url` varchar(255) NOT NULL,
  `login` varchar(40) NOT NULL,
  `password` varchar(32) NOT NULL,
  `last_sync_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
)");

$db->Close();

$_SHELL_OUT.= "Creating dynarc tables... done!";