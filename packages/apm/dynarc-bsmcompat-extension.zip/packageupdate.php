<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$ret = GShell("dynarc item-info -ap idoc -alias bsmcompat",$_SESSION_ID,$_SHELL_ID);
if(!$ret['error'])
 GShell("dynarc delete-item -ap idoc -id '".$ret['outarr']['id']."' -r",$_SESSION_ID,$_SHELL_ID);

GShell("dynarc import -f 'tmp/idoc-bsmcompat.xml' -ap 'idoc' -ct 'gmart-generic'",$_SESSION_ID,$_SHELL_ID);