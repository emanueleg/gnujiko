<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: dynarc-bsmcompat-extension
 #DESCRIPTION: Brand-Serie-Model excel parser 
 #VERSION: 2.1beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.
 #TODO:
 
*/

function gnujikoexcelparser_bsmcompat_info()
{
 $info = array('name' => "Rubrica");
 $keys = array(
	"brand"=>"Marca",
	"serie"=>"Serie",
	"model"=>"Modello"
	);

 $keydict = array(
	/* BASIC INFO */
	"brand"=> array("marca"),
	"serie"=> array("serie"),
	"model"=> array("modello")
	);

 return array('info'=>$info, 'keys'=>$keys, 'keydict'=>$keydict);
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoexcelparser_bsmcompat_import($_DATA, $sessid, $shellid, $archivePrefix="", $catId=0, $catTag="", $id=0)
{
 $sessInfo = sessionInfo($sessid);
 $interface = array("name"=>"progressbar","steps"=>count($_DATA['items']));
 gshPreOutput($shellid,"Import from Excel", "ESTIMATION", "", "PASSTHRU", $interface);

 $_BRANDS = array();
 // get archive id //
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT id FROM dynarc_archives WHERE tb_prefix='".$archivePrefix."' AND trash='0' LIMIT 1");
 $db->Read();
 $archiveId = $db->record['id'];
 $db->Close();

 //$db = new AlpaDatabase();
 //$db2 = new AlpaDatabase();
 for($c=0; $c < count($_DATA['items']); $c++)
 {
  $itm = $_DATA['items'][$c];

  if(!$itm['brand'] || !$itm['serie'] || !$itm['model'])
  {
   // se manca la marca, la serie o il modello, passa avanti.
   continue;
  }

  gshPreOutput($shellid,"Import: ".$itm['model'],"PROGRESS", $itm);

  if(!$_BRANDS[$itm['brand']])
  {
   $ret = gnujikoexcelparser_bsmcompat_getBrandCatId($archivePrefix,$sessInfo,$itm['brand']);
   if($ret['error']) return $ret;
   $_BRANDS[$itm['brand']] = array("id"=>$ret['id'], "serie"=>array());
  }
  if(!$_BRANDS[$itm['brand']]['serie'][$itm['serie']])
  {
   $ret = gnujikoexcelparser_bsmcompat_getSerieCatId($archivePrefix,$sessInfo,$_BRANDS[$itm['brand']]['id'],$itm['brand'],$itm['serie']);
   if($ret['error']) return $ret;
   $_BRANDS[$itm['brand']]['serie'][$itm['serie']] = array("id"=>$ret['id']);
  }
  
  $brand = $db->Purify($itm['brand']);
  $serie = $db->Purify($itm['serie']);
  $model = $db->Purify($itm['model']);

  $brandCatId = $_BRANDS[$itm['brand']]['id'];
  $serieCatId = $_BRANDS[$itm['brand']]['serie'][$itm['serie']]['id'];

  $now = date('Y-m-d H:i:s');
  $hierarchy = ",".$brandCatId.",".$serieCatId.","; 

  // verifica se questo modello è gia stato registrato nella tabella dynarc_XXX_bsm_items
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT id FROM dynarc_".$archivePrefix."_bsm_items WHERE name='".$model."' AND cat_id='".$serieCatId."' AND trash='0' LIMIT 1");
  if(!$db->Read())
  {
   $db->RunQuery("INSERT INTO dynarc_".$archivePrefix."_bsm_items (uid,gid,_mod,cat_id,lnk_id,lnkarc_id,name,ctime,hierarchy) VALUES('"
	.$sessInfo['uid']."','".$sessInfo['gid']."','666','".$serieCatId."','".$id."','".($id ? $archiveId : 0)."','".$model."','".$now."','"
	.$hierarchy."')");
   if($db->Error) return array("message"=>"MySQL Error: ".$db->Error."\nLast qry:\n".$db->lastQuery, "error"=>"MYSQL_ERROR");
  }
  $db->Close();

  if($id)
  {
   // verifica prima se esiste già il record nella tabella dynarc_XXX_bsmcompat
   $db = new AlpaDatabase();
   $db->RunQuery("SELECT id FROM dynarc_".$archivePrefix."_bsmcompat WHERE item_id='".$id."' AND brand_name='".$brand."' AND serie='"
	.$serie."' AND model='".$model."' LIMIT 1");
   if(!$db->Read())
   {
    $db->RunQuery("INSERT INTO dynarc_".$archivePrefix."_bsmcompat (item_id,brand_name,serie,model) VALUES('".$id."','".$brand."','"
	.$serie."','".$model."')");
    if($db->Error) return array("message"=>"MySQL Error: ".$db->Error."\nLast qry:\n".$db->lastQuery, "error"=>"MYSQL_ERROR");
   }
   $db->Close();
  }

 }
 //$db2->Close();
 //$db->Close();

 return array('message'=>"done!");
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoexcelparser_bsmcompat_getBrandCatId($_AP,$sessInfo,$brand)
{
 $now = date('Y-m-d H:i:s');
 $db = new AlpaDatabase();
 $brandP = $db->Purify($brand);
 $db->RunQuery("SELECT id FROM dynarc_".$_AP."_bsm_categories WHERE name='".$brandP."' AND parent_id='0' AND trash='0' LIMIT 1");
 if(!$db->Read())
 {
  $db->RunQuery("INSERT INTO dynarc_".$_AP."_bsm_categories (uid,gid,_mod,tag,name,ctime) VALUES('".$sessInfo['uid']."','"
	.$sessInfo['gid']."','666','".$db->Purify(str_replace("&amp;","",$brand))."','".$brandP."','".$now."')");
  if($db->Error) return array("message"=>"MySQL Error: ".$db->Error."\nLast qry:\n".$db->lastQuery, "error"=>"MYSQL_ERROR");
  $retId = $db->GetInsertId();
 }
 else
  $retId = $db->record['id'];
 $db->Close();
 return array("id"=>$retId);
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoexcelparser_bsmcompat_getSerieCatId($_AP,$sessInfo,$brandCatId,$brand,$serie)
{
 $now = date('Y-m-d H:i:s');
 $db = new AlpaDatabase();
 $brandP = $db->Purify($brand);
 $serieP = $db->Purify($serie);
 $db->RunQuery("SELECT id FROM dynarc_".$_AP."_bsm_categories WHERE name='".$serieP."' AND parent_id='".$brandCatId."' AND trash='0' LIMIT 1");
 if(!$db->Read())
 {
  $db->RunQuery("INSERT INTO dynarc_".$_AP."_bsm_categories (uid,gid,_mod,parent_id,tag,name,ctime,hierarchy) VALUES('".$sessInfo['uid']."','"
	.$sessInfo['gid']."','666','".$brandCatId."','".$db->Purify(str_replace("&amp;","",$brand.'-'.$serie))."','".$serieP."','".$now."',',".$brandCatId.",')");
  if($db->Error) return array("message"=>"MySQL Error: ".$db->Error."\nLast qry:\n".$db->lastQuery, "error"=>"MYSQL_ERROR");
  $retId = $db->GetInsertId();
 }
 else
  $retId = $db->record['id'];
 $db->Close();
 return array("id"=>$retId);
}
//-------------------------------------------------------------------------------------------------------------------//

