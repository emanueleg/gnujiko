<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: dynarc-bsmcompat-extension
 #DESCRIPTION: Brand-Serie-Model compatibility extension for Dynarc archives.
 #VERSION: 2.1beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.
 #TODO:
 
*/

global $_BASE_PATH;

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_".$archiveInfo['prefix']."_bsmcompat` (
`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`item_id` INT(11) NOT NULL ,
`brand_id` INT(11) NOT NULL ,
`brand_name` VARCHAR(32) NOT NULL ,
`serie` VARCHAR(32) NOT NULL ,
`model` VARCHAR(32) NOT NULL ,
INDEX (`item_id`,`brand_id`,`serie`)
)");
 $db->Close();

 $ret = GShell("dynarc new-archive -name `Marche, serie e modelli` -prefix ".$archiveInfo['prefix']."_bsm -perms 666 --def-cat-perms 666 --def-item-perms 666", $sessid, $shellid);

 return array("message"=>"BSMCompat extension has been installed into archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DROP TABLE IF EXISTS `dynarc_".$archiveInfo['prefix']."_bsmcompat`");
 $db->Close();

 $ret = GShell("dynarc delete-archive -prefix '".$archiveInfo['prefix']."' -r",$sessid,$shellid);

 return array("message"=>"BSMCompat extension has been removed from archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* REMOVE ALL ITEM EVENTS */
 $db = new AlpaDatabase();
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_bsmcompat WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_set($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 global $_BASE_PATH, $_ABSOLUTE_URL;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'brand' : case 'brandname' : {$brandName=$args[$c+1]; $c++;} break;
   case 'brandid' : {$brandId=$args[$c+1]; $c++;} break;
   case 'serie' : {$serie=$args[$c+1]; $c++;} break;
   case 'model' : {$model=$args[$c+1]; $c++;} break;
  }

 $sessInfo = sessionInfo($sessid);

 if($id)
 {
  $db = new AlpaDatabase();
  $q = "";
  
  if(isset($brandName))
   $q.= ",brand_name='".$db->Purify($brandName)."'";
  if(isset($brandId))
   $q.= ",brand_id='".$brandId."'";
  if(isset($serie))
   $q.= ",serie='".$db->Purify($serie)."'";
  if(isset($model))
   $q.= ",model='".$db->Purify($model)."'";

  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_bsmcompat SET ".ltrim($q,',')." WHERE id='".$id."'");
  $db->Close();
 }
 else
 {
  $db = new AlpaDatabase();
  $db->RunQuery("INSERT INTO dynarc_".$archiveInfo['prefix']."_bsmcompat(item_id,brand_id,brand_name,serie,model) VALUES('"
	.$itemInfo['id']."','".$brandId."','".$db->Purify($brandName)."','".$db->Purify($serie)."','".$db->Purify($model)."')");
  $id = $db->GetInsertId();
  $db->Close();
 }

 if(isset($brandName))
 {
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT id FROM dynarc_".$archiveInfo['prefix']."_bsm_categories WHERE tag='".$db->Purify(str_replace("&amp;","",$brandName))."' AND parent_id='0' LIMIT 1");
  if(!$db->Read())
  {
   // create new brand category //
   $ret = GShell("dynarc new-cat -ap '".$archiveInfo['prefix']."_bsm' -name `".$brandName."` -tag `".str_replace("&amp;","",$brandName)."`",$sessid,$shellid);
   if($ret['error'])
	return $ret;
  }
  $db->Close();

  if(isset($serie))
  {
   $db = new AlpaDatabase();
   $db->RunQuery("SELECT id FROM dynarc_".$archiveInfo['prefix']."_bsm_categories WHERE tag='".$db->Purify(str_replace("&amp;","",$brandName)."-".$serie)."' AND parent_id!='0' LIMIT 1");
   if(!$db->Read())
   {
    // create new serie category //
    $ret = GShell("dynarc new-cat -ap '".$archiveInfo['prefix']."_bsm' -name `".$serie."` -tag `".str_replace("&amp;","",$brandName)."-".$serie."` -pt `".str_replace("&amp;","",$brandName)."`",$sessid,$shellid);
    if($ret['error'])
	 return $ret;
	$serieCatId = $ret['outarr']['id'];
   }
   else
    $serieCatId = $db->record['id'];
   $db->Close();
  }

  if(isset($serie) && isset($model))
  {
   $db = new AlpaDatabase();
   $db->RunQuery("SELECT id FROM dynarc_".$archiveInfo['prefix']."_bsm_items WHERE name='".$db->Purify($model)."' AND trash='0' LIMIT 1");
   if(!$db->Read())
   {
	// create new model item //
    $ret = GShell("dynarc new-item -ap '".$archiveInfo['prefix']."_bsm' -name `".$model."` -cat `".$serieCatId."` -linkap '".$archiveInfo['prefix']."' -linkid '".$itemInfo['id']."'",$sessid,$shellid);
	if($ret['error'])
	 return $ret;
   }
   $db->Close();
  }

 }

 $itemInfo['last_element'] = array('id'=>$id, 'item_id'=>$itemInfo['id'], 'brand_id'=>$brandId, 'brand_name'=>$brandName, 
	'serie'=>$serie, 'model'=>$model);

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'all' : $all=true; break;
  }
 
 $db = new AlpaDatabase();
 if($id)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_bsmcompat WHERE id='$id'");
 else if($all)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_bsmcompat WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_get($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$archiveInfo['prefix']."_bsmcompat WHERE item_id='".$itemInfo['id']."' ORDER BY brand_name,serie,model");
 while($db->Read())
 {
  $a = array('id'=>$db->record['id'], 'brand_id'=>$db->record['brand_id'], 'brand_name'=>$db->record['brand_name'], 'serie'=>$db->record['serie'],
	'model'=>$db->record['model']);
  $itemInfo['bsmcompat'][] = $a;
 }
 $db->Close();
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_getList($params, $sessid, $shellid, $extraParams=null)
{
 $out = "";
 $outArr = array();

 /* ARRAYZE PARAMS */
 $tmp = explode("&",$params);
 $params = array();
 for($c=0; $c < count($tmp); $c++)
 {
  $x = explode("=",$tmp[$c]);
  $params[$x[0]] = $x[1];
 }
 /* EOF - ARRAYZE PARAMS */

 if(!$params['ap']) return array("message"=>"You must specify the archive prefix. (with: -ap ARCHIVE_PREFIX)","error"=>"INVALID_ARCHIVE");
 if(!$params['id']) return array("message"=>"You must specify the item id. (with: -id ITEM_ID)","error"=>"INVALID_ITEM"); 

 $_AP = $params['ap'];
 $_ID = $params['id'];
 $_LIMIT = $params['limit'] ? $params['limit'] : 100;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT COUNT(*) FROM dynarc_".$_AP."_bsmcompat WHERE item_id='".$_ID."'");
 $db->Read();
 $outArr['count'] = $db->record[0];
 $outArr['items'] = array();
 $db->RunQuery("SELECT * FROM dynarc_".$_AP."_bsmcompat WHERE item_id='".$_ID."' ORDER BY brand_name,serie,model LIMIT ".$_LIMIT);
 while($db->Read())
 {
  $a = array('id'=>$db->record['id'], 'brand_id'=>$db->record['brand_id'], 'brand_name'=>$db->record['brand_name'], 'serie'=>$db->record['serie'],
	'model'=>$db->record['model']);
  $outArr['items'][] = $a;
 }
 $db->Close();

 $out.= $outArr['count']." items found.";
 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("TRUNCATE TABLE `dynarc_".$archiveInfo['prefix']."_bsmcompat`");
 $db->Close();
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 if($isCategory)
  return;

 $xml = "<bsmcompat>";
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$archiveInfo['prefix']."_bsmcompat WHERE item_id='".$itemInfo['id']."' ORDER BY id ASC");
 while($db->Read())
 {
  $xml.= '<item brand_id="'.$db->record['brand_id'].'" brand_name="'.sanitize($db->record['brand_name']).'" serie="'
	.sanitize($db->record['serie']).'" model="'.sanitize($db->record['model']).'"/>';
 }
 $xml.= "</bsmcompat>";
 $db->Close();


 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 if($isCategory)
  return;

 $list = $node->GetElementsByTagName("bsmcompat");
 for($c=0; $c < count($list); $c++)
 {
  $node = $list[$c];
  $brandId = $node->getString('brand_id');
  $brandName = $node->getString('brand_name');
  $serie = $node->getString('serie');
  $model = $node->getString('model');

  $db = new AlpaDatabase();
  $db->RunQuery("INSERT INTO dynarc_".$archiveInfo['prefix']."_bsmcompat(item_id,brand_id,brand_name,serie,model) VALUES('"
	.$itemInfo['id']."','".$brandId."','".$db->Purify($brandName)."','".$db->Purify($serie)."','".$db->Purify($model)."')");
  $db->Close();
 }

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_syncexport($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_USERS_HOMES;
 $xml = "";
 $attachments = array();

 return array('xml'=>$xml,'attachments'=>$attachments);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_bsmcompat_syncimport($sessid, $shellid, $archiveInfo, $itemInfo, $xmlNode, $isCategory=false)
{
 global $_USER_PATH;
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

