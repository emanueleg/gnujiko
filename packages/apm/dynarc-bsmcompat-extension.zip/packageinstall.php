<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$ret = GShell("dynarc cat-info -ap idoc -tag 'TECHNICAL-DATA-SHEET'", $_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 GShell("dynarc new-cat -ap idoc -tag 'TECHNICAL-DATA-SHEET' -name `Schede tecniche` -code 'TDS-' -perms 666",$_SESSION_ID, $_SHELL_ID);

$ret = GShell("dynarc cat-info -ap idoc -tag 'GMART'", $_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 GShell("dynarc new-cat -ap idoc -tag 'GMART' -pt 'TECHNICAL-DATA-SHEET' -name 'Articoli / Prodotti' -code 'TDS-GMART-' -perms 666",$_SESSION_ID, $_SHELL_ID);

$ret = GShell("dynarc cat-info -ap idoc -tag 'gmart-generic'", $_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 GShell("dynarc new-cat -ap idoc -tag 'gmart-generic' -pt 'GMART' -name 'Generici' -code 'TDS-GMART-1' -perms 666",$_SESSION_ID, $_SHELL_ID);

GShell("dynarc import -f 'tmp/idoc-bsmcompat.xml' -ap 'idoc' -ct 'gmart-generic'",$_SESSION_ID,$_SHELL_ID);