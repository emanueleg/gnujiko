<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2012 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 09-07-2012
 #PACKAGE: htmlgutility
 #DESCRIPTION: Make a screen shot on a object
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/
global $_BASE_PATH, $_ABSOLUTE_URL;
include_once($_BASE_PATH."var/objects/html2canvas/index.php");
?>
<script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>var/objects/htmlgutility/screenshot.js" type="text/javascript"></script>


