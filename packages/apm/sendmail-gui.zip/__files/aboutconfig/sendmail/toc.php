<?php

global $_APPLICATION_CONFIG;

$_APPLICATION_CONFIG['mainmenu'][] = array("title"=>"SendMail", "url"=>"sendmail/index.php");
