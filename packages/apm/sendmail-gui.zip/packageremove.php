<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

GShell("dynarc delete-cat -ap aboutconfig_htmlparms -tag sendmail",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc delete-archive -ap 'sendmail_predmsg' -r",$_SESSION_ID, $_SHELL_ID);