<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$ret = GShell("dynarc cat-info -ap aboutconfig_htmlparms -tag sendmail",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 GShell("dynarc new-cat -ap aboutconfig_htmlparms -tag sendmail -name 'Send Mail'",$_SESSION_ID, $_SHELL_ID);
}
 
GShell("groupadd sendmail --first-user", $_SESSION_ID, $_SHELL_ID);
$ret = GShell("dynarc new-archive -name 'SendMail Predef. Messages' -prefix sendmail_predmsg -group sendmail -perms 660 --def-cat-perms 660 --def-item-perms 660",$_SESSION_ID, $_SHELL_ID);
if($ret['error']) { $_SHELL_OUT = $ret['message']; $_SHELL_ERR = $ret['error']; return; }
  
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_sendmail_predmsg_items` ADD `last_time_used` DATETIME NOT NULL");
if($db->Error) { $_SHELL_OUT.= "MySQL Error: ".$db->Error; $_SHELL_ERR = "MYSQL_ERROR"; return; }
$db->Close();