<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* TODO: queste 2 query sono da rimuovere la prossima volta che si compila */

/* Rimuovo il vecchio indice perchè era univoco */
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_gmart_partnumbers` DROP INDEX partnumber");
$db->Close();

/* Reinserisco l'indice */
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_gmart_partnumbers` ADD INDEX (`partnumber`)");
$db->Close();
