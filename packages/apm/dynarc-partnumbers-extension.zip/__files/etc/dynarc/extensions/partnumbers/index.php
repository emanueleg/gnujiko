<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 05-07-2014
 #PACKAGE: dynarc-partnumbers-extension
 #DESCRIPTION: Part numbers extension for Dynarc archives.
 #VERSION: 2.2beta
 #CHANGELOG: 05-07-2014 : Rimosso blocco su part-number non univoci.
 #TODO: 
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;

function dynarcextension_partnumbers_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_".$archiveInfo['prefix']."_partnumbers` (
 `item_id` INT(11) NOT NULL ,
 `partnumber` VARCHAR(32) NOT NULL ,
 INDEX (`item_id`,`partnumber`)");
 $db->Close();
 return array("message"=>"PartNumbers extension has been installed into archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DROP TABLE IF EXISTS `dynarc_".$archiveInfo['prefix']."_partnumbers`");
 $db->Close();

 return array("message"=>"PartNumbers extension has been removed from archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_set($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'partnumber' : case 'number' : case 'code' : {$partnumber=$args[$c+1]; $c++;} break;
  }

 if(!$partnumber)
  return array("message"=>"Invalid part-number", "error"=>"INVALID_PARTNUMBER");

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT item_id FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE partnumber='".$partnumber."' AND item_id='".$itemInfo['id']."'");
 if($db->Read())
  return array("message"=>"Part-number '".$partnumber."' already exists.", "error"=>"PARTNUMBER_ALREADY_EXISTS");
 $db->RunQuery("INSERT INTO dynarc_".$archiveInfo['prefix']."_partnumbers (item_id,partnumber) VALUES('"
	.$itemInfo['id']."','".$db->Purify($partnumber)."')");
 if($db->Error)
  return array("message"=>"MySQL Error: ".$db->Error, "error"=>"MYSQL_ERROR");
 $db->Close();

 return $itemInfo; 
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'partnumber' : case 'number' : case 'code' : {$partnumber=$args[$c+1]; $c++;} break;
   case 'all' : $all=true; break;
  }
 
 $db = new AlpaDatabase();
 if($partnumber)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE partnumber='".$partnumber."' AND item_id='".$itemInfo['id']."'");
 else
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_get($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $itemInfo['partnumbers'] = array();
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE item_id='".$itemInfo['id']."' ORDER BY partnumber ASC");
 while($db->Read())
 {
  $a = array('partnumber'=>$db->record['partnumber']);
  $itemInfo['partnumbers'][] = $a;
 }
 $db->Close();
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 if($isCategory)
  return;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT COUNT(*) FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE item_id='".$itemInfo['id']."'");
 $db->Read();
 if(!$db->record[0])
 {
  $db->Close();
  return true;
 }
 $db->Close();

 $xml = "<partnumbers>\n";

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT partnumber FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE item_id='".$itemInfo['id']."' ORDER BY partnumber ASC");
 while($db->Read())
 {
  $xml.= '<item partnumber="'.sanitize($db->record['partnumber']).'"/>\n';
 }
 $db->Close();
 $xml.= "</partnumbers>\n";

 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_import($sessid, $shellid, $archiveInfo, $itemInfo, $extNode, $isCategory=false)
{
 if($isCategory)
  return true;

 $list = $extNode->GetElementsByTagName('item');
 $fields = array('partnumber');
 for($c=0; $c < count($list); $c++)
 {
  $n = $list[$c];
  $extQ = "";
  for($i=0; $i < count($fields); $i++)
   $extQ.= ",".$fields[$i]."=\"".$n->getString($fields[$i])."\"";
  GShell("dynarc edit-item -ap `".$archiveInfo['prefix']."` -id `".$itemInfo['id']."` -extset `partnumbers.".ltrim($extQ,",")."`",$sessid, $shellid);
 }
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE item_id='".$itemInfo['id']."'");
 $db->Close();
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{

 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_find($args, $sessid, $shellid, $archiveInfo)
{
 $orderBy = "partnumber ASC";
 $out = "";
 $outArr = array("results"=>array());

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-partnumber' : case '-code' : case '-number' : {$partnumber=$args[$c+1]; $c++;} break;
   case '-limit' : {$limit=$args[$c+1]; $c++;} break;
   case '--order-by' : {$orderBy=$args[$c+1]; $c++;} break;
   case '--distinct' : $distinct=true; break;
   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 $db = new AlpaDatabase();
 $search = $db->Purify($partnumber);
 if($distinct)
  $qry = "SELECT DISTINCT partnumber FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE (";
 else
  $qry = "SELECT item_id,partnumber FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE (";
 $qry.= "partnumber='".$search."' OR partnumber LIKE '".$search."%' OR partnumber LIKE '%".$search."%' OR partnumber LIKE '%".$search."')";
 $qry.= " ORDER BY ".$orderBy.($limit ? " LIMIT ".$limit : "");

 $db->RunQuery($qry);
 while($db->Read())
 {
  $a = array("item_id"=>$db->record['item_id'], "partnumber"=>$db->record['partnumber']);
  $outArr['results'][] = $a;
 }
 $db->Close();

 if($verbose)
 {
  for($c=0; $c < count($outArr['results']); $c++)
   $out.= $outArr['results'][$c]['partnumber']." (#".$outArr['results'][$c]['item_id'].")\n";
 }

 if(!count($outArr['results']))
  $out.= "no results match for '".$search."'";
 else
  $out.= "\nfound ".count($outArr['results'])." results for '".$search."'";

 return array("message"=>$out, "outarr"=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("TRUNCATE TABLE `dynarc_".$archiveInfo['prefix']."_partnumbers`");
 $db->Close();
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_syncexport($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_USERS_HOMES;
 $xml = "";
 $attachments = array();

 if($isCategory)
  return;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT COUNT(*) FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE item_id='".$itemInfo['id']."'");
 $db->Read();
 if(!$db->record[0])
 {
  $db->Close();
  return true;
 }
 $db->Close();

 $xml = "<partnumbers>\n";

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT partnumber FROM dynarc_".$archiveInfo['prefix']."_partnumbers WHERE item_id='".$itemInfo['id']."' ORDER BY partnumber ASC");
 while($db->Read())
 {
  $xml.= '<item partnumber="'.sanitize($db->record['partnumber']).'"/>\n';
 }
 $db->Close();
 $xml.= "</partnumbers>\n";

 return array('xml'=>$xml,'attachments'=>$attachments);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_partnumbers_syncimport($sessid, $shellid, $archiveInfo, $itemInfo, $extNode, $isCategory=false)
{
 global $_USERS_HOMES;

 if($isCategory)
  return true;

 $list = $extNode->GetElementsByTagName('item');
 $fields = array('partnumber');
 for($c=0; $c < count($list); $c++)
 {
  $n = $list[$c];
  $extQ = "";
  for($i=0; $i < count($fields); $i++)
   $extQ.= ",".$fields[$i]."=\"".$n->getString($fields[$i])."\"";
  GShell("dynarc edit-item -ap `".$archiveInfo['prefix']."` -id `".$itemInfo['id']."` -extset `partnumbers.".ltrim($extQ,",")."`",$sessid, $shellid);
 }
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

