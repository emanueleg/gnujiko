<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_commercialdocs_mmr` ADD `doc_date` DATE NOT NULL , ADD INDEX (`doc_date`)");
$db->Close();


$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_commercialdocs_mmr` ADD `doc_type` VARCHAR( 32 ) NOT NULL ,
ADD `doc_num` INT( 11 ) NOT NULL ,
ADD `doc_num_ext` VARCHAR( 8 ) NOT NULL ,
ADD `doc_name` VARCHAR( 64 ) NOT NULL ,
ADD `doc_tag` VARCHAR( 32 ) NOT NULL ,
ADD `doc_bank` INT( 11 ) NOT NULL ,
ADD `payment_type` VARCHAR( 8 ) NOT NULL ,
ADD `payment_mode` INT( 11 ) NOT NULL ,
ADD INDEX (`doc_type`,`payment_type`)");
$db->Close();


/* 14-02-2014 : Float fix */
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_commercialdocs_mmr` CHANGE `incomes` `incomes` DECIMAL(10,4) NOT NULL , CHANGE `expenses` `expenses` DECIMAL(10,4) NOT NULL");
$db->Close();



?>