<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `commercialdocs` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='GCommercialDocs/'");
if($db->Read())
$db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Documenti...";
 $ret = GShell("system register-app -name `Documenti` -desc `Gestore di documenti commerciali quali: Fatture, DDT, Ordini, Preventivi, ecc..` -url 'GCommercialDocs/' -icon 'GCommercialDocs/icon.png' -group commercialdocs -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new group */
GShell("groupadd `commdocs-preemptives` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new group */
GShell("groupadd `commdocs-orders` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new group */
GShell("groupadd `commdocs-ddt` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new group */
GShell("groupadd `commdocs-invoices` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new group */
GShell("groupadd `commdocs-vendororders` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new group */
GShell("groupadd `commdocs-purchaseinvoices` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new group */
GShell("groupadd `commdocs-creditsnote` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new group */
GShell("groupadd `commdocs-debitsnote` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new group */
GShell("groupadd `commdocs-ddtin` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new archive */
$_SHELL_OUT.= "Create new archive Documenti Commerciali...";
$ret = GShell("dynarc new-archive -name `Documenti Commerciali` -prefix commercialdocs -group `commercialdocs` --default-cat-perms 660 --default-item-perms 660 --functions-file etc/dynarc/archive_funcs/__commercialdocs/index.php -launcher `url:GCommercialDocs/docinfo.php?id=%d`",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];
GShell("dynarc enable-sharing-system -ap commercialdocs", $_SESSION_ID, $_SHELL_ID);

/* Installing extension */
$_SHELL_OUT.= "Install extension commercialdocs...";
$ret = GShell("dynarc install-extension coding -ap commercialdocs",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc install-extension cdinfo -ap commercialdocs",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc install-extension cdelements -ap commercialdocs",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc install-extension mmr -ap commercialdocs",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc install-extension labels -ap commercialdocs",$_SESSION_ID,$_SHELL_ID);


/* Create default category */
$_SHELL_OUT.= "Create default categories...";
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Preventivi` -tag PREEMPTIVES -group `commdocs-preemptives` --publish",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Ordini` -tag ORDERS -group `commdocs-orders` --publish",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap commercialdocs -name `D.D.T.` -tag DDT -group `commdocs-ddt` --publish",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap commercialdocs -name 'DDT Fornitore' -tag DDTIN -group 'commdocs-ddtin' --publish",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Fatture` -tag INVOICES -group `commdocs-invoices` --publish",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Ordini Fornitore` -tag VENDORORDERS -group `commdocs-vendororders` --publish",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Fatture di acquisto` -tag PURCHASEINVOICES -group `commdocs-purchaseinvoices` --publish",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Note di Accredito` -tag CREDITSNOTE -group `commdocs-creditsnote` --publish",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Note di Debito` -tag DEBITSNOTE -group `commdocs-debitsnote` --publish",$_SESSION_ID,$_SHELL_ID);

/* Create print models categories */
$ret = GShell("dynarc cat-info -ap `printmodels` -tag commercialdocs",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Documenti commerciali` -tag `commercialdocs` -group commercialdocs",$_SESSION_ID, $_SHELL_ID);

// PREEMPTIVES //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag PREEMPTIVES",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Preventivi` -tag `PREEMPTIVES` -pt commercialdocs -group commdocs-preemptives",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-preemptive.xml -ap `printmodels` -ct PREEMPTIVES",$_SESSION_ID,$_SHELL_ID);
}

// ORDERS //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag ORDERS",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Ordini` -tag `ORDERS` -pt commercialdocs -group commdocs-orders",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-order.xml -ap `printmodels` -ct ORDERS",$_SESSION_ID,$_SHELL_ID);
}

// DDT //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag DDT",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `D.D.T.` -tag `DDT` -pt commercialdocs -group commdocs-ddt",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-ddt.xml -ap `printmodels` -ct DDT",$_SESSION_ID,$_SHELL_ID);
}

// DDT FORNITORE//
$ret = GShell("dynarc cat-info -ap `printmodels` -tag DDTIN",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap 'printmodels' -name 'D.D.T. Fornitore' -tag 'DDTIN' -pt commercialdocs -group commdocs-ddtin",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-ddtin.xml -ap `printmodels` -ct DDTIN",$_SESSION_ID,$_SHELL_ID);
}

// INVOICES //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag INVOICES",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Fatture` -tag `INVOICES` -pt commercialdocs -group commdocs-invoices",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
 {
  GShell("dynarc import -f tmp/demo-invoice.xml -ap `printmodels` -ct INVOICES",$_SESSION_ID,$_SHELL_ID);
  GShell("dynarc import -f tmp/demo-fatt-c-rivinps-e-ritacc.xml -ap `printmodels` -ct INVOICES",$_SESSION_ID,$_SHELL_ID);
 }
}

// VENDORORDERS //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag VENDORORDERS",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Ordini fornitore` -tag `VENDORORDERS` -pt commercialdocs -group commdocs-vendororders",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-vendororder.xml -ap `printmodels` -ct VENDORORDERS",$_SESSION_ID,$_SHELL_ID);
}

// PURCHASEINVOICES //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag PURCHASEINVOICES",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Fatture di acquisto` -tag `PURCHASEINVOICES` -pt commercialdocs -group commdocs-purchaseinvoices",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-purchaseinvoice.xml -ap `printmodels` -ct PURCHASEINVOICES",$_SESSION_ID,$_SHELL_ID);
}

// CREDITSNOTE //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag CREDITSNOTE",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Note di accredito` -tag `CREDITSNOTE` -pt commercialdocs -group commdocs-creditsnote",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-creditsnote.xml -ap `printmodels` -ct CREDITSNOTE",$_SESSION_ID,$_SHELL_ID);
}

// DEBITSNOTE //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag DEBITSNOTE",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Note di debito` -tag `DEBITSNOTE` -pt commercialdocs -group commdocs-debitsnote",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-debitsnote.xml -ap `printmodels` -ct DEBITSNOTE",$_SESSION_ID,$_SHELL_ID);
}

// DOCUMENT LIST //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag COMMDOCS-LIST",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Liste di documenti` -tag `COMMDOCS-LIST` -pt commercialdocs -group commercialdocs",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-liste-documenti.xml -ap `printmodels` -ct COMMDOCS-LIST",$_SESSION_ID,$_SHELL_ID);
}

// creazione archivio causali documenti //
$ret = GShell("dynarc archive-info -prefix gcdcausal",$_SESSION_ID,$_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-archive -name 'Causali Documenti' -prefix gcdcausal -group commercialdocs -perms 664 --def-cat-perms 664 --def-item-perms 664",$_SESSION_ID,$_SHELL_ID);
 if(!$ret['error']) // importa le causali
  GShell("dynarc import -f tmp/causali-documenti.xml -ap 'gcdcausal'",$_SESSION_ID,$_SHELL_ID);
}


/* 04-05-2013 - PREDEFINED MESSAGES */
$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_commercialdocs_predefmsg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
)");
$db->Close();

/* Create configuration file */
if(!file_exists($_BASE_PATH."etc/commercialdocs/config.php"))
 GShell("mv etc/commercialdocs/config-dist.php etc/commercialdocs/config.php",$_SESSION_ID,$_SHELL_ID);