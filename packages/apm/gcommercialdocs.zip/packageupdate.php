<?php global $_BASE_PATH, $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

if(version_compare($_INSTALLED_VER, "2.180beta", "<"))
{
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` CHANGE `discount` `discount_1` DECIMAL(10,4) NOT NULL");
$db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `reference_id` INT( 11 ) NOT NULL");
$db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `validity_date` DATE NOT NULL, 
 ADD `charter_datefrom` DATE NOT NULL, 
 ADD `charter_dateto` DATE NOT NULL");
$db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `tot_rit_acc` DECIMAL(10,4) NOT NULL, 
 ADD `tot_ccp` DECIMAL(10,4) NOT NULL, 
 ADD `tot_rinps` DECIMAL(10,4) NOT NULL, 
 ADD `tot_enasarco` DECIMAL(10,4) NOT NULL, 
 ADD `tot_netpay` DECIMAL(10,4) NOT NULL");
$db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `ext_docref` VARCHAR(64) NOT NULL, 
 ADD `discount_2` DECIMAL(10,4) NOT NULL, 
 ADD `unconditional_discount` DECIMAL(10,4) NOT NULL, 
 ADD `rebate` DECIMAL(10,4) NOT NULL, 
 ADD `tot_goods` DECIMAL(10,4) NOT NULL, 
 ADD `discounted_goods` DECIMAL(10,4) NOT NULL, 
 ADD `tot_expenses` DECIMAL(10,4) NOT NULL, 
 ADD `exp_1_name` VARCHAR(64) NOT NULL, 
 ADD `exp_1_vatid` INT(11) NOT NULL, 
 ADD `exp_1_amount` DECIMAL(10,4) NOT NULL, 
 ADD `exp_2_name` VARCHAR(64) NOT NULL, 
 ADD `exp_2_vatid` INT(11) NOT NULL, 
 ADD `exp_2_amount` DECIMAL(10,4) NOT NULL,  
 ADD `exp_3_name` VARCHAR(64) NOT NULL,  
 ADD `exp_3_vatid` INT(11) NOT NULL,  
 ADD `exp_3_amount` DECIMAL(10,4) NOT NULL,  
 ADD `tot_discount` DECIMAL(10,4) NOT NULL,  
 ADD `vat_1_id` INT(11) NOT NULL,  
 ADD `vat_1_taxable` DECIMAL(10,4) NOT NULL,  
 ADD `vat_1_tax` DECIMAL(10,4) NOT NULL,  
 ADD `vat_2_id` INT(11) NOT NULL,  
 ADD `vat_2_taxable` DECIMAL(10,4) NOT NULL,  
 ADD `vat_2_tax` DECIMAL(10,4) NOT NULL,  
 ADD `vat_3_id` INT(11) NOT NULL,  
 ADD `vat_3_taxable` DECIMAL(10,4) NOT NULL,  
 ADD `vat_3_tax` DECIMAL(10,4) NOT NULL");
$db->Close();
}

/* ??-??-2013 : Rimesso il lotto */
if(version_compare($_INSTALLED_VER, "2.181beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_elements` ADD `lot` VARCHAR(64) NOT NULL , ADD INDEX (`lot`)");
 $db->Close();
}

/* 18-10-2013 : Aggiunto i bolli */
if(version_compare($_INSTALLED_VER, "2.182beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `stamp` DECIMAL(10,4) NOT NULL");
 $db->Close();
}

/* 23-10-2013 : Aggiunto division e ship_subject_id*/
if(version_compare($_INSTALLED_VER, "2.183beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `division` VARCHAR(32) NOT NULL , ADD `ship_subject_id` INT(11) NOT NULL, ADD INDEX (`division`), ADD INDEX (`ship_subject_id`)");
 $db->Close();


 /* Create configuration file */
 if(!file_exists($_BASE_PATH."etc/commercialdocs/config.php"))
  GShell("mv etc/commercialdocs/config-dist.php etc/commercialdocs/config.php",$_SESSION_ID,$_SHELL_ID);
}

/* 14-11-2013 : Aggiunto spese trasporto e spese imballaggio */
if(version_compare($_INSTALLED_VER, "2.184beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `cartage` DECIMAL(10,4) NOT NULL , ADD `packing_charges` DECIMAL(10,4) NOT NULL");
 $db->Close();
}

/* 29-11-2013 : Aggiunto due campi per ordini ricorsivi */
if(version_compare($_INSTALLED_VER, "2.185beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `renewal_date` DATE NOT NULL , ADD `ren_doc_id` INT NOT NULL , ADD INDEX (`ren_doc_id`)");
 $db->Close();
}

/* 12-12-2013 : Aggiunto agent_id */
if(version_compare($_INSTALLED_VER, "2.186beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `agent_id` INT(11) NOT NULL , ADD `agent_commiss` DECIMAL(10,4) NOT NULL, ADD INDEX (`agent_id`)");
 $db->Close();
}

/* 24-12-2013 : Aggiunto spese di incasso */
if(version_compare($_INSTALLED_VER, "2.187beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `collection_charges` DECIMAL(10,4) NOT NULL");
 $db->Close();
}

/* 31-01-2014 : Aggiunto riba_id su mmr */
if(version_compare($_INSTALLED_VER, "2.188beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_mmr` ADD `riba_id` INT(11) NOT NULL , ADD INDEX (`riba_id`)");
 $db->Close();
}

/* 14-02-2014 : Float fix */
if(version_compare($_INSTALLED_VER, "2.189beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` CHANGE `amount` `amount` DECIMAL(10,4) NOT NULL, 
CHANGE `vat` `vat` DECIMAL(10,4) NOT NULL, 
CHANGE `total` `total` DECIMAL(10,4) NOT NULL, 
CHANGE `unconditional_discount` `unconditional_discount` DECIMAL(10,4) NOT NULL, 
CHANGE `tot_rit_acc` `tot_rit_acc` DECIMAL(10,4) NOT NULL, 
CHANGE `tot_ccp` `tot_ccp` DECIMAL(10,4) NOT NULL, 
CHANGE `tot_rinps` `tot_rinps` DECIMAL(10,4) NOT NULL, 
CHANGE `tot_enasarco` `tot_enasarco` DECIMAL(10,4) NOT NULL, 
CHANGE `tot_netpay` `tot_netpay` DECIMAL(10,4) NOT NULL, 
CHANGE `discount_1` `discount_1` DECIMAL(10,4) NOT NULL, 
CHANGE `discount_2` `discount_2` DECIMAL(10,4) NOT NULL, 
CHANGE `rebate` `rebate` DECIMAL(10,4) NOT NULL, 
CHANGE `tot_goods` `tot_goods` DECIMAL(10,4) NOT NULL, 
CHANGE `discounted_goods` `discounted_goods` DECIMAL(10,4) NOT NULL, 
CHANGE `tot_expenses` `tot_expenses` DECIMAL(10,4) NOT NULL, 
CHANGE `exp_1_amount` `exp_1_amount` DECIMAL(10,4) NOT NULL, 
CHANGE `exp_2_amount` `exp_2_amount` DECIMAL(10,4) NOT NULL, 
CHANGE `exp_3_amount` `exp_3_amount` DECIMAL(10,4) NOT NULL ,
CHANGE `tot_discount` `tot_discount` DECIMAL(10,4) NOT NULL ,
CHANGE `vat_1_taxable` `vat_1_taxable` DECIMAL(10,4) NOT NULL ,
CHANGE `vat_1_tax` `vat_1_tax` DECIMAL(10,4) NOT NULL ,
CHANGE `vat_2_taxable` `vat_2_taxable` DECIMAL(10,4) NOT NULL ,
CHANGE `vat_2_tax` `vat_2_tax` DECIMAL(10,4) NOT NULL ,
CHANGE `vat_3_taxable` `vat_3_taxable` DECIMAL(10,4) NOT NULL ,
CHANGE `vat_3_tax` `vat_3_tax` DECIMAL(10,4) NOT NULL ,
CHANGE `stamp` `stamp` DECIMAL(10,4) NOT NULL");
 $db->Close();
}

/* 03-04-2014 : Aggiunto tot. pagato e restante da pagare */
if(version_compare($_INSTALLED_VER, "2.190beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `tot_paid` DECIMAL(10,4) NOT NULL, ADD `rest_to_pay` DECIMAL(10,4) NOT NULL");
 $db->Close();
}

/* 21-05-2014 : Aggiunto banca appoggio aziendale */
if(version_compare($_INSTALLED_VER, "2.191beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `ourbank_support` INT(11) NOT NULL");
 $db->Close();
}

/* 25-05-2014 : Aggiunto docref_ap e docref_id per Riferimento documento interno */
if(version_compare($_INSTALLED_VER, "2.192beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `docref_ap` VARCHAR(32) NOT NULL, ADD `docref_id` INT(11) NOT NULL, ADD INDEX (`docref_ap`, `docref_id`)");
 $db->Close();

 // aggiunto prezzo base listino, ricarico, sconto listino e vencode
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_elements` ADD `vencode` VARCHAR(64) NOT NULL, ADD `plbaseprice` DECIMAL(10,4) NOT NULL, ADD `plmrate` FLOAT NOT NULL, ADD `pldiscperc` FLOAT NOT NULL");
 $db->Close();


 // aggiunto extra status 
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `status_extra` TINYINT NOT NULL, ADD INDEX (`status_extra`)");
 $db->Close();

 // creazione archivio causali documenti //
 $ret = GShell("dynarc archive-info -prefix gcdcausal",$_SESSION_ID,$_SHELL_ID);
 if($ret['error'])
 {
  $ret = GShell("dynarc new-archive -name 'Causali Documenti' -prefix gcdcausal -group commercialdocs -perms 664 --def-cat-perms 664 --def-item-perms 664",$_SESSION_ID,$_SHELL_ID);
  if(!$ret['error']) // importa le causali
   GShell("dynarc import -f tmp/causali-documenti.xml -ap 'gcdcausal'",$_SESSION_ID,$_SHELL_ID);
 }

 // creo gruppo commdocs-ddtin per DDT fornitore
 GShell("groupadd `commdocs-ddtin` --first-user",$_SESSION_ID,$_SHELL_ID);
 $ret = GShell("dynarc cat-info -ap commercialdocs -tag DDTIN",$_SESSION_ID,$_SHELL_ID);
 if($ret['error'])
 {
  // creo cartella DDT Fornitore
  $ret = GShell("dynarc new-cat -ap commercialdocs -name 'DDT Fornitore' -tag DDTIN -group 'commdocs-ddtin'",$_SESSION_ID,$_SHELL_ID);
  if(!$ret['error'])
  {
   // creo la cartella nei modelli di stampa per i DDT Fornitore
   $ret = GShell("dynarc new-cat -ap 'printmodels' -name 'D.D.T. Fornitore' -tag 'DDTIN' -pt commercialdocs -group commdocs-ddtin -perms 660",$_SESSION_ID,$_SHELL_ID);
   if(!$ret['error']) // importo il modello demo di DDT Fornitore.
    GShell("dynarc import -f tmp/demo-ddtin.xml -ap 'printmodels' -ct DDTIN",$_SESSION_ID,$_SHELL_ID);
  }
 }
}

// 02-06-2014 - Aggiunto brand_id //
if(version_compare($_INSTALLED_VER, "2.193beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_elements` ADD `brand_id` INT(11) NOT NULL");
 $db->Close();
}

// 12-07-2014 - Aggiunto docrefap e docrefid //
if(version_compare($_INSTALLED_VER, "2.194beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_elements` ADD `doc_ref_ap` VARCHAR(64) NOT NULL , ADD `doc_ref_id` INT(11) NOT NULL , ADD INDEX (`doc_ref_ap`,`doc_ref_id`)");
 $db->Close();

 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `rivalsa_inps` FLOAT NOT NULL, ADD `contr_cassa_prev` FLOAT NOT NULL, ADD `contr_cassa_prev_vatid` INT(11) NOT NULL , 
ADD `rit_enasarco` FLOAT NOT NULL , ADD `rit_enasarco_percimp` FLOAT NOT NULL , ADD `rit_acconto` FLOAT NOT NULL , ADD `rit_acconto_percimp` FLOAT NOT NULL , ADD `rit_acconto_rivinpsinc` TINYINT(1) NOT NULL");
 $db->Close();

 /* Sistema il gruppo ed i permessi */
 include_once($_BASE_PATH."include/userfunc.php");
 $gid = _getGID("commercialdocs");
 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE gnujiko_applications SET gid='".$gid."',_mod='640' WHERE url='GCommercialDocs/'");
 $db->Close();
}

/* 03-09-2014 : Aggiunto i servizi */
if(version_compare($_INSTALLED_VER, "2.195beta", "<"))
{
 $ret = GShell("dynarc cat-info -ap scheduledtasks -tag COMMERCIALDOCS",$_SESSION_ID,$_SHELL_ID);
 if($ret['error'])
 {
  GShell("dynarc new-cat -ap scheduledtasks -name `Documenti commerciali` -tag COMMERCIALDOCS",$_SESSION_ID,$_SHELL_ID);
  GShell("scheduledtasks add -type COMMERCIALDOCS -name `Fatture di vendita scadute` -status 0 -imode 1 -alias commercialdocs.overdueinvoices -desc `Invia un'email all'indirizzo specificato per ogni fattura di vendita scaduta` -exefile etc/scheduledtasks/exec/commercialdocs.php -exename commercialdocs -exeaction overdueInvoices",$_SESSION_ID,$_SHELL_ID);
  GShell("scheduledtasks add -type COMMERCIALDOCS -name `Solleciti di pagamento` -status 0 -imode 1 -alias commercialdocs.paymentreminders -desc `Invia un'email di sollecito di pagamento al cliente.` -exefile etc/scheduledtasks/exec/commercialdocs.php -exename commercialdocs -exeaction paymentReminders",$_SESSION_ID,$_SHELL_ID);
  GShell("scheduledtasks add -type COMMERCIALDOCS -name `Fatture di acquisto scadute` -status 0 -imode 1 -alias commercialdocs.overduepurchaseinvoices -desc `Invia un'email all'indirizzo specificato per ogni fattura di acquisto scaduta` -exefile etc/scheduledtasks/exec/commercialdocs.php -exename commercialdocs -exeaction overduePurchaseInvoices",$_SESSION_ID,$_SHELL_ID);
  GShell("dynarc new-cat -ap aboutconfig_htmlparms -name `Documenti commerciali` -tag gcommercialdocs -group gcommercialdocs --if-not-exists",$_SESSION_ID,$_SHELL_ID);

  // modelli demo
  $overdueInvoicesECID = 0;
  $emailContent = '<p>Lista fatture di vendita scadute:</p><table cellspacing="1" cellpadding="1" border="1"><tbody><tr><td><strong>DATA SCADENZA</strong></td><td><strong>CLIENTE</strong></td><td><strong>IMPORTO RATA</strong></td><td><strong>DOCUMENTO</strong></td><td><strong>IMPONIBILE</strong></td><td><strong>IVA</strong></td><td><strong>TOTALE</strong></td></tr><tr><td> {EXPIRY_DATE}</td><td>{SUBJECT_NAME}</td><td style="text-align: right;">{RATE_AMOUNT}</td><td>{DOC_LINK}</td><td style="text-align: right;">{DOC_AMOUNT}</td><td style="text-align: right;">{DOC_VAT}</td><td style="text-align: right;">{DOC_TOTAL}</td></tr><tr><td> </td><td> </td><td> </td><td> </td><td> </td><td> </td><td> </td></tr></tbody></table><p>Totale scaduto: <strong>{TOT_AMOUNT} €</strong></p>';

  $ret = GShell("dynarc new-item -ap aboutconfig_htmlparms -ct gcommercialdocs -name `Testo email fatture di vendita scadute` -desc `".$emailContent."`",$_SESSION_ID,$_SHELL_ID);
  if(!$ret['error'])
   $overdueInvoicesECID = $ret['outarr']['id'];

  $overduePurchaseInvoicesECID = 0;
  $emailContent = '<p>Lista fatture di acquisto scadute:</p><table cellspacing="1" cellpadding="1" border="1"><tbody><tr><td><strong>DATA SCADENZA</strong></td><td><strong>FORNITORE</strong></td><td><strong>IMPORTO RATA</strong></td><td><strong>DOCUMENTO</strong></td><td><strong>IMPONIBILE</strong></td><td><strong>IVA</strong></td><td><strong>TOTALE</strong></td></tr><tr><td> {EXPIRY_DATE}</td><td>{SUBJECT_NAME}</td><td style="text-align: right;">{RATE_AMOUNT}</td><td>{DOC_LINK}</td><td style="text-align: right;">{DOC_AMOUNT}</td><td style="text-align: right;">{DOC_VAT}</td><td style="text-align: right;">{DOC_TOTAL}</td></tr><tr><td> </td><td> </td><td> </td><td> </td><td> </td><td> </td><td> </td></tr></tbody></table><p>Totale scaduto: <strong>{TOT_AMOUNT} €</strong></p>';

  $ret = GShell("dynarc new-item -ap aboutconfig_htmlparms -ct gcommercialdocs -name `Testo email fatture di acquisto scadute` -desc `".$emailContent."`",$_SESSION_ID,$_SHELL_ID);
  if(!$ret['error'])
   $overduePurchaseInvoicesECID = $ret['outarr']['id'];

  $xmlConfig = "<overdueinvoices recp='' sender='' subject='' pdfattach='0' emailcontentap='aboutconfig_htmlparms' emailcontentid='".$overdueInvoicesECID."'/>";
  $xmlConfig.= "<overduepurchaseinvoices recp='' sender='' subject='' pdfattach='0' emailcontentap='aboutconfig_htmlparms' emailcontentid='".$overduePurchaseInvoicesECID."'/>";

  $ret = GShell("aboutconfig set-config -app gcommercialdocs -sec alerts -xml-config `".$xmlConfig."`",$_SESSION_ID,$_SHELL_ID);
 }
}

/* 16-09-2014 : Aggiunto vendor_price */
if(version_compare($_INSTALLED_VER, "2.196beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_elements` ADD `vendor_price` DECIMAL(10,4) NOT NULL, ADD `sale_price` DECIMAL(10,4) NOT NULL");
 $db->Close();
}

/* 02-10-2014 : Aggiunto vendor_id */
if(version_compare($_INSTALLED_VER, "2.197beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_elements` ADD `vendor_id` INT(11) NOT NULL");
 $db->Close();
}

/* 24-10-2014 : Ridimensionato ship_zip a 8 caratteri */
if(version_compare($_INSTALLED_VER, "2.198beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` CHANGE `ship_zip` `ship_zip` VARCHAR(8) NOT NULL");
 $db->Close();
}

/* 18-11-2014 : Aggiunto campi variant_coltint e variant_sizmis */
if(version_compare($_INSTALLED_VER, "2.199beta", "<"))
{
 $ret = GShell("dynarc extension-info cdelements",$_SESSION_ID,$_SHELL_ID);
 if(!$ret['error'] && count($ret['outarr']['archives']))
 {
  for($c=0; $c < count($ret['outarr']['archives']); $c++)
  {
   $ap = $ret['outarr']['archives'][$c]['ap'];
   $db = new AlpaDatabase();
   $db->RunQuery("ALTER TABLE `dynarc_".$ap."_elements` ADD `variant_coltint` VARCHAR(64) NOT NULL, ADD `variant_sizmis` VARCHAR(64) NOT NULL");
   $db->Close();
  }
 }
}

/* 17-12-2014 : Aggiunto campi rit_acconto e xml_data */
if(version_compare($_INSTALLED_VER, "2.200beta", "<"))
{
 $ret = GShell("dynarc extension-info cdelements",$_SESSION_ID,$_SHELL_ID);
 if(!$ret['error'] && count($ret['outarr']['archives']))
 {
  for($c=0; $c < count($ret['outarr']['archives']); $c++)
  {
   $ap = $ret['outarr']['archives'][$c]['ap'];
   $db = new AlpaDatabase();
   $db->RunQuery("ALTER TABLE `dynarc_".$ap."_elements` ADD `rit_acc_apply` TINYINT(1) NOT NULL, ADD `xml_data` TEXT NOT NULL");
   $db->Close();
  }
 }
}

/* 19-01-2015 : Install. estensione etichette. Nuova grafica. */
if(version_compare($_INSTALLED_VER, "2.201beta", "<"))
{
 $ret = GShell("dynarc install-extension labels -ap commercialdocs",$_SESSION_ID,$_SHELL_ID);
}

/* 20-01-2015 : Aggiunto campi cartage_vatid e packing_charges_vatid */
if(version_compare($_INSTALLED_VER, "2.202beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `cartage_vatid` INT(11) NOT NULL, ADD `packing_charges_vatid` INT(11) NOT NULL");
 $db->Close();
}

/* 26-01-2015 : Aggiunto campo location */
if(version_compare($_INSTALLED_VER, "2.203beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `location` VARCHAR(255) NOT NULL");
 $db->Close();
}

/* 04-02-2015 : Aggiunto campi metric */
if(version_compare($_INSTALLED_VER, "2.204beta", "<"))
{
 $ret = GShell("dynarc extension-info cdelements",$_SESSION_ID,$_SHELL_ID);
 if(!$ret['error'] && count($ret['outarr']['archives']))
 {
  for($c=0; $c < count($ret['outarr']['archives']); $c++)
  {
   $ap = $ret['outarr']['archives'][$c]['ap'];
   $db = new AlpaDatabase();
   $db->RunQuery("ALTER TABLE `dynarc_".$ap."_elements` ADD `metric_length` FLOAT NOT NULL, ADD `metric_width` FLOAT NOT NULL, ADD `metric_hw` FLOAT NOT NULL, ADD `metric_eqp` FLOAT NOT NULL");
   $db->Close();
  }
 }
}

/* 18-02-2015 : Aggiunto campo data consegna */
if(version_compare($_INSTALLED_VER, "2.205beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `delivery_date` DATE NOT NULL");
 $db->Close();
}

/* 03-03-2015 : Bug fix decimali */
if(version_compare($_INSTALLED_VER, "2.206beta", "<"))
{
 $ret = GShell("dynarc extension-info cdelements",$_SESSION_ID,$_SHELL_ID);
 if(!$ret['error'] && count($ret['outarr']['archives']))
 {
  for($c=0; $c < count($ret['outarr']['archives']); $c++)
  {
   $ap = $ret['outarr']['archives'][$c]['ap'];
   $db = new AlpaDatabase();
   $db->RunQuery("ALTER TABLE `dynarc_".$ap."_elements` CHANGE `price` `price` DECIMAL(10,4) NOT NULL, CHANGE `discount_inc` `discount_inc` DECIMAL(10,4) NOT NULL, CHANGE `price_adjust` `price_adjust` DECIMAL(10,4) NOT NULL");
   $db->Close();
  }
 }
}

/* 05-03-2015 : Aggiunto campi fatt PA */
if(version_compare($_INSTALLED_VER, "2.207beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `fatt_pa_id` INT(11) NOT NULL");
 $db->Close();
}

/* 12-03-2015 : Aggiunto altri campi fatt */
if(version_compare($_INSTALLED_VER, "2.208beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `pa_doctype` VARCHAR(32) NOT NULL, 
	ADD `pa_docnum` VARCHAR(20) NOT NULL, 
	ADD `pa_cig` VARCHAR(15) NOT NULL, 
	ADD `pa_cup` VARCHAR(15) NOT NULL");
 $db->Close();
}

/* 25-01-2016 : Rev. 2.209beta */
if(version_compare($_INSTALLED_VER, "2.209beta", "<"))
{
 /* imposta come pubbliche tutte le cartelle dei documenti commerciali perchè ora è possibile
 mostrarle e nasconderle da aboutconfig. */
 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE dynarc_commercialdocs_categories SET published='1' WHERE 1");
 $db->Close();
}

/* 04-02-2016 : Rev. 2.216beta */
if(version_compare($_INSTALLED_VER, "2.216beta", "<"))
{
 /* Aggiunto campi qty_sent e qty_downloaded su cdelements anche degli altri archivi */
 $ret = GShell("dynarc extension-info cdelements",$_SESSION_ID,$_SHELL_ID);
 if(!$ret['error'] && count($ret['outarr']['archives']))
 {
  for($c=0; $c < count($ret['outarr']['archives']); $c++)
  {
   $ap = $ret['outarr']['archives'][$c]['ap'];
   $db = new AlpaDatabase();
   $db->RunQuery("ALTER TABLE `dynarc_".$ap."_elements` ADD `qty_sent` FLOAT UNSIGNED NOT NULL, ADD `qty_downloaded` FLOAT UNSIGNED NOT NULL");
   $db->Close();
  }
 }
}

/* 12-02-2016 : Rev. 2.218beta */
if(version_compare($_INSTALLED_VER, "2.218beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `tracking_number` VARCHAR(32) NOT NULL, ADD INDEX (`tracking_number`)");
 $db->Close();
}

/* 07-03-2016 : Rev. 2.224beta */
if(version_compare($_INSTALLED_VER, "2.224beta", "<"))
{
 /* Aggiunto campi row_ref_docap, row_ref_docid, row_ref_id su cdelements */
 $ret = GShell("dynarc extension-info cdelements",$_SESSION_ID,$_SHELL_ID);
 if($ret['error']) { $_SHELL_OUT.= $ret['message']; $_SHELL_ERR=$ret['error']; return; }
 if(!$ret['error'] && count($ret['outarr']['archives']))
 {
  for($c=0; $c < count($ret['outarr']['archives']); $c++)
  {
   $ap = $ret['outarr']['archives'][$c]['ap'];
   $db = new AlpaDatabase();
   $_SHELL_OUT.= "Insert new fields into archive dynarc_".$ap."_elements ...";
   $db->RunQuery("ALTER TABLE `dynarc_".$ap."_elements` ADD `row_ref_docap` VARCHAR(32) NOT NULL, ADD `row_ref_docid` INT(11) NOT NULL, ADD `row_ref_id` INT(11) NOT NULL");
   if($db->Error) $_SHELL_OUT.= "failed!\nMySQL Error:".$db->Error;
   else $_SHELL_OUT.= "done!\n";
   $db->Close();
  }
 }
  
 /* Aggiunto campi partial_proc ed entirely_proc */
 $db = new AlpaDatabase();
 $_SHELL_OUT.= "Insert new fields into archive dynarc_commercialdocs_items...";
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `partial_proc` TINYINT(1) NOT NULL, ADD `entirely_proc` TINYINT(1) NOT NULL");
 if($db->Error) $_SHELL_OUT.= "failed!\nMySQL Error:".$db->Error;
 else $_SHELL_OUT.= "done!\n";
 $db->Close();
}

/* 02-05-2016 : Rev. 2.234beta */
if(version_compare($_INSTALLED_VER, "2.234beta", "<"))
{
 /* Aggiunto campo vat_nd */
 $db = new AlpaDatabase();
 $_SHELL_OUT.= "Insert new field into archive dynarc_commercialdocs_items...";
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `vat_nd` DECIMAL(10,5) NOT NULL");
 if($db->Error) $_SHELL_OUT.= "failed!\nMySQL Error:".$db->Error;
 else $_SHELL_OUT.= "done!\n";
 $db->Close();
}

/* 24-05-2016 : Rev. 2.235beta */
if(version_compare($_INSTALLED_VER, "2.235beta", "<"))
{
 /* Aggiunto campo ccp_apply su cdelements */
 $ret = GShell("dynarc extension-info cdelements",$_SESSION_ID,$_SHELL_ID);
 if($ret['error']) { $_SHELL_OUT.= $ret['message']; $_SHELL_ERR=$ret['error']; return; }
 if(!$ret['error'] && count($ret['outarr']['archives']))
 {
  for($c=0; $c < count($ret['outarr']['archives']); $c++)
  {
   $ap = $ret['outarr']['archives'][$c]['ap'];
   $db = new AlpaDatabase();
   $_SHELL_OUT.= "Insert new fields into archive dynarc_".$ap."_elements ...";
   $db->RunQuery("ALTER TABLE `dynarc_".$ap."_elements` ADD `ccp_apply` TINYINT(1) NOT NULL");
   if($db->Error) $_SHELL_OUT.= "failed!\nMySQL Error:".$db->Error;
   else $_SHELL_OUT.= "done!\n";
   $db->Close();
  }
 }
}	 

/* 05-05-2017 : Rev. 2.261beta */
if(version_compare($_INSTALLED_VER, "2.261beta", "<"))
{
 $db = new AlpaDatabase();
 $_SHELL_OUT.= "Insert new field agent_invoice into table dynarc_commercialdocs_items...";
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `agent_invoice` INT(11) NOT NULL");
 if($db->Error) {$_SHELL_OUT.= "failed!\nMySQL Error: ".$db->Error; $_SHELL_ERR = "MYSQL_ERROR"; }
 else $_SHELL_OUT.= "done!\n";
 $db->Close();
}	 

/* 20-05-2017 : Enabled sharing system. */
if(version_compare($_INSTALLED_VER,"2.263beta","<"))
{
 GShell("dynarc enable-sharing-system -ap commercialdocs", $_SESSION_ID, $_SHELL_ID);
}	

/* 28-05-2017 : Doc type field added. */
if(version_compare($_INSTALLED_VER,"2.265beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `root_ct` VARCHAR(48) NOT NULL, ADD INDEX (`root_ct`)");
 $db->Close();
  
 GShell("commercialdocs fix-doctype", $_SESSION_ID, $_SHELL_ID);
}	 

/* 08-04-2018 : Aggiunto campo esigibilita IVA */
if(version_compare($_INSTALLED_VER,"2.269beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_commercialdocs_items` ADD `vat_chargeability` VARCHAR(1) NOT NULL");
 $db->Close();
}