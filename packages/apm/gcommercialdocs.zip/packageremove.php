<?php

/* Remove archive commercialdocs */
GShell("dynarc delete-archive -r -prefix commercialdocs",$_SESSION_ID,$_SHELL_ID);

$db = new AlpaDatabase();
$db->RunQuery("DROP TABLE `dynarc_commercialdocs_predefmsg`");
$db->Close();

/* Un-register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='GCommercialDocs/'");
if($db->Read())
GShell("system unregister-app -id ".$db->record['id'],$_SESSION_ID,$_SHELL_ID);
$db->Close();