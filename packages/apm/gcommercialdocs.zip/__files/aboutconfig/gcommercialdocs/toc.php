<?php

global $_APPLICATION_CONFIG;

$_APPLICATION_CONFIG['mainmenu'][] = array("title"=>"Documenti Commerciali", "url"=>"gcommercialdocs/index.php");
