<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Remove archive */
$_SHELL_OUT.= "Remove archive Fatture Elettroniche...";
$ret = GShell("dynarc delete-archive -prefix 'fatturepa' -r",$_SESSION_ID,$_SHELL_ID);