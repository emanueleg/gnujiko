<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 13-03-2015
 #PACKAGE: fatturepa
 #DESCRIPTION: Fattura PA parser
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

function gnujikocontentparser_fatturapa_info($sessid, $shellid)
{
 $info = array('name' => "Fattura PA");
 $keys = array(
	 "PROG" => "Codice progressivo invio", 
	 "DOCREF" => "Ns. fatt. di riferimento",
	 "DOCDATE" => "Ns. fatt. di rif. - data", 
	 "DOCNUM" => "Ns. fatt. di rif. - numero", 
	 "TOTAL" => "Importo totale documento",
	 "CUSTOMER" => "Cliente/Amministrazione",
	 "CIG" => "Codice Identificativo Gara",
	 "CUP" => "Codice Univoco Progetto",
	 "DOCID" => "ID Documento"
	);
 return array('info'=>$info, 'keys'=>$keys);
}

function gnujikocontentparser_fatturapa_parse($_CONTENTS, $_PARAMS, $sessid, $shellid)
{
 global $_BASE_PATH, $_ABSOLUTE_URL;

 $contents = $_CONTENTS;

 /* GET DOC INFO */
 $ret = GShell("dynarc item-info -ap `".($_PARAMS['ap'] ? $_PARAMS['ap'] : "fatturepa")."` -id `".$_PARAMS['id']."` -extget `fatturapa.docinfo`",$sessid,$shellid);
 if(!$ret['error'])
  $docInfo = $ret['outarr'];

 $keys = array("{PROG}", "{DOCREF}", "{DOCDATE}" , "{DOCNUM}", "{TOTAL}", "{CUSTOMER}", "{CIG}" , "{CUP}" , "{DOCID}");

 $vals = array(
	 $docInfo['code_str'],
	 $docInfo['doc_name'],
	 date('d/m/Y',$docInfo['docinfo']['ctime']),
	 $docInfo['docinfo']['code_num'],
	 number_format($docInfo['netpay'],2,',','.'),
	 $docInfo['subject_name'],
	 $docInfo['docinfo']['pa_cig'],
	 $docInfo['docinfo']['pa_cup'],
	 $docInfo['docinfo']['pa_docnum']
	);

 for($c=0; $c < count($keys); $c++)
 {
  $key = $keys[$c];
  $val = $vals[$c];

  while($p = stripos($contents,$key,$p))
  {
   $chunk = strtoupper(substr($contents,$p-4,4));
   if(($chunk == "ID='") || ($chunk == 'ID="'))
   {// is inside on html tag //
    $endTag = stripos($contents,">",$p+strlen($key));
    $contents = substr($contents,0,$endTag+1).$val.substr($contents,$endTag+1);
    $p = $endTag+strlen($val);
   }
   else
   {
    $contents = substr($contents,0,$p).$val.substr($contents,$p+strlen($key));
    $p+= strlen($val);
   }
  }
 }

 $_CONTENTS = $contents;

 return $contents;
}

