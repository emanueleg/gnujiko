<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 05-03-2015
 #PACKAGE: fatturepa
 #DESCRIPTION: Archive functions for Fatture Elettroniche
 #VERSION: 2.1beta
 #CHANGELOG: 
 
*/

function dynarcfunction_fatturepa_oninheritarchive($args, $sessid, $shellid, $archiveInfo)
{

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* Get last document and adjust document number */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT code_num FROM dynarc_".$archiveInfo['prefix']."_items WHERE id!='"
	.$itemInfo['id']."' AND trash=0 AND ctime>='".date('Y',$itemInfo['ctime'])."-01-01' AND ctime<'".date('Y',strtotime("+1 Year",$itemInfo['ctime']))."-01-01' ORDER BY code_num DESC LIMIT 1");
 if($db->Read())
  $itemInfo['code_num'] = $db->record['code_num']+1;
 else
  $itemInfo['code_num'] = 1; 
 $db->Close();

 if($prefix)
  $itemInfo['code_ext'] = $prefix;

 $title = "Fatt. Elettr.";
 $title.= " n&deg;".$itemInfo['code_num'].($itemInfo['code_ext'] ? "/".$itemInfo['code_ext'] : "")." del ".date('d/m/Y',$itemInfo['ctime']);

 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET code_num='".$itemInfo['code_num']."',code_ext='"
	.$itemInfo['code_ext']."',name='".$db->Purify($title)."',ctime='".date('Y-m-d',$itemInfo['ctime'])."' WHERE id='"
	.$itemInfo['id']."'");
 $db->Close();

 $itemInfo['name'] = $title;
 
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $title = "Fatt. Elettr.";
 $title.= " n&deg;".$itemInfo['code_num'].($itemInfo['code_ext'] ? "/".$itemInfo['code_ext'] : "")." del ".date('d/m/Y',$itemInfo['ctime']);

 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET name='".$db->Purify($title)."',ctime='".date('Y-m-d',$itemInfo['ctime'])
	."' WHERE id='".$itemInfo['id']."'");
 $db->Close();

 $itemInfo['name'] = $title;

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_onmoveitem($sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_onmovecategory($sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_oncopyitem($sessid, $shellid, $archiveInfo, $cloneInfo, $srcInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_oncopycategory($sessid, $shellid, $archiveInfo, $cloneInfo, $srcInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_fatturepa_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

