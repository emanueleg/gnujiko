<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2015 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 05-03-2015
#PACKAGE: fatturepa
#DESCRIPTION: 
#VERSION: 2.0beta
#CHANGELOG: 
#TODO: 
*/

global $_BASE_PATH;

function dynarcextension_fatturapa_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE  `dynarc_".$archiveInfo['prefix']."_items` ADD `invoice_id` INT(11) NOT NULL ,
	ADD `subject_id` INT(11) NOT NULL ,
	ADD `subject_name` VARCHAR(80) NOT NULL ,
	ADD `xml_file_name` VARCHAR(64) NOT NULL ,
	ADD `send_datetime` DATETIME NOT NULL ,
	ADD `status` TINYINT(1) NOT NULL ,
	ADD INDEX (`subject_id`,`status`)");
 $db->Close();

 return array("message"=>"FatturaPA extension has been installed into archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` DROP `invoice_id`, DROP `subject_id`,
	DROP `subject_name`, DROP `xml_file_name`, DROP `send_datetime`, DROP `status`");
 $db->Close();

 return array("message"=>"FatturaPA extension has been removed from archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_catset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_catunset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_catget($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_fatturapa_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'invoiceid' : {$invoiceID=$args[$c+1]; $c++;} break;
   case 'subjectid' : case 'subjid' : {$subjectId=$args[$c+1]; $c++;} break;
   case 'subjectname' : case 'subjname' : {$subjectName=$args[$c+1]; $c++;} break;
   case 'xmlfilename' : case 'filename' : {$xmlFileName=$args[$c+1]; $c++;} break;
   case 'sendtime' : case 'senddate' : case 'senddatetime' : {$sendDateTime=$args[$c+1]; $c++;} break;
   case 'status' : {$status=$args[$c+1]; $c++;} break;
  }

 $db = new AlpaDatabase();
 $q = "";

 if(isset($invoiceID))				$q.= ",invoice_id='".$invoiceID."'";
 if(isset($subjectId))				$q.= ",subject_id='".$subjectId."'";
 if(isset($subjectName))			$q.= ",subject_name='".$db->Purify($subjectName)."'";
 if(isset($xmlFileName))			$q.= ",xml_file_name='".$xmlFileName."'";
 if(isset($sendDateTime))			$q.= ",send_datetime='".$sendDateTime."'";
 if(isset($status))					$q.= ",status='".$status."'";

 if($q) 
 {
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET ".ltrim($q,",")." WHERE id='".$itemInfo['id']."'");
  if($db->Error) return array('message'=>"MySQL Error: ".$db->Error, 'error'=>'MYSQL_ERROR');
 }
 $db->Close();

 if(isset($invoiceID))
 {
  // aggiorna il campo fatt_pa_id su commercialdocs_items
  $db = new AlpaDatabase();
  $db->RunQuery("UPDATE dynarc_commercialdocs_items SET fatt_pa_id='".$itemInfo['id']."' WHERE id='".$invoiceID."'");
  $db->Close();
 }

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_fatturapa_catunset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_fatturapa_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'docinfo' : $getDocInfo=true; break;
  }

 $_FIELDS = "invoice_id,subject_id,subject_name,xml_file_name,send_datetime,status";
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT ".$_FIELDS." FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();

 $itemInfo['invoice_id'] = $db->record['invoice_id'];
 $itemInfo['subject_id'] = $db->record['subject_id'];
 $itemInfo['subject_name'] = $db->record['subject_name'];
 $itemInfo['xml_file_name'] = $db->record['xml_file_name'];
 $itemInfo['send_datetime'] = ($db->record['send_datetime'] != "0000-00-00 00:00:00") ? $db->record['send_datetime'] : "";
 $itemInfo['status'] = $db->record['status'];

 if($getDocInfo && $itemInfo['invoice_id'])
 {
  $ret = GShell("dynarc item-info -ap commercialdocs -id '".$itemInfo['invoice_id']."' -extget `cdinfo`",$sessid,$shellid);
  if(!$ret['error'])
  {
   $itemInfo['docinfo'] = $ret['outarr'];

   $itemInfo['doc_name'] = $ret['outarr']['name'];
   $itemInfo['subject_code'] = $ret['outarr']['subject_code'];
   $itemInfo['amount'] = $ret['outarr']['amount'];
   $itemInfo['vat'] = $ret['outarr']['vat'];
   $itemInfo['total'] = $ret['outarr']['total'];
   $itemInfo['netpay'] = $ret['outarr']['tot_netpay'];
  }
 }

 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 $xml = "<fatturapa />";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 if(!$node)
  return ;

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* Resetta fatt_pa_id sulla fattura */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT invoice_id FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 $db->RunQuery("UPDATE dynarc_commercialdocs_items SET fatt_pa_id='0' WHERE id='".$db->record['invoice_id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* Ripristina fatt_pa_id sulla fattura */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT invoice_id FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 $db->RunQuery("UPDATE dynarc_commercialdocs_items SET fatt_pa_id='".$itemInfo['id']."' WHERE id='".$db->record['invoice_id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* Resetta fatt_pa_id sulla fattura */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT invoice_id FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 $db->RunQuery("UPDATE dynarc_commercialdocs_items SET fatt_pa_id='0' WHERE id='".$db->record['invoice_id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_fatturapa_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 /* Resetta fatt_pa_id su tutte le fatture */

 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE dynarc_commercialdocs_items SET fatt_pa_id='0' WHERE 1");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
