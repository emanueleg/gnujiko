<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2019 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 09-11-2019
 #PACKAGE: fatturepa
 #DESCRIPTION: PA xml protocol ver.1.2
 #VERSION: 2.10beta
 #CHANGELOG: 09-11-2019 : Aggiornata sezione partita IVA
             28-11-2018 : Integrato con fatture elettroniche obbligatorie dal 2019
			 08-04-2018 : Aggiunto campo esigibilita IVA.
			 14-01-2017 : Bug fix condizioni di pagamento.
			 08-01-2017 : Aggiornato al protocollo 1.2
			 25-02-2016 : Bug fix numero sequenziale file fattura elettronica.
			 13-01-2016 : Bug fix IBAN.
			 08-04-2015 : Bug fix caratteri speciali.
			 04-04-2015 : bug fix vari e check su campi obbligatori.
 #TODO:
 
*/

function commercialdocs_paxml_generatefile($args, $sessid, $shellid)
{
 global $_BASE_PATH, $_DEFAULT_FILE_PERMS, $_USERS_HOMES, $_COMPANY_PROFILE, $fatturePAarchiveInfo;

 include_once($_BASE_PATH."var/lib/xmllib.php");
 include_once($_BASE_PATH."include/company-profile.php");

 $_DECIMALS = $_COMPANY_PROFILE['accounting']['decimals_pricing'];
 $_COD_AZ = "A";	/* PS: è previsto il multi-azienda anche se non ancora gestito */
 /* A= prima azienda, B=seconda, C=terza, ... , Z=ventiseiesima, 0=ventisettesima, ... , 9=trentaseiesima */
 /* PS: Con questo sistema di codifica sarà possibile avere un max di 36 aziende. */

 $_XMLFILE_DIR = "share/fatturepa/"; /* Directory di destinazione del file XML generato. */ 
 $_TRANS_FORMAT = "FPA12";			// Formato trasmissione: FPA12 = P.A. , FPR12 = Privato o Azienda.

 $out = "";
 $outArr = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$id=$args[$c+1]; $c++;} break;
   case '-filename' : {$fileName=$args[$c+1]; $c++;} break;
  }

 $_TRANS_METHOD = array("A MEZZO MITTENTE", "A MEZZO DESTINATARIO", "A MEZZO VETTORE");

 /* GET LIST OF VAT RATES */
 $ret = GShell("dynarc item-list -ap vatrates -get `percentage,vat_type`", $sessid, $shellid);
 $_VAT_LIST = $ret['outarr']['items'];
 $_VAT_BY_ID = array();
 for($c=0; $c < count($_VAT_LIST); $c++)
  $_VAT_BY_ID[$_VAT_LIST[$c]['id']] = $_VAT_LIST[$c];

 $ret = GShell("dynarc item-info -ap commercialdocs -id `".$id."` -extget `cdinfo,cdelements`",$sessid, $shellid);
 if($ret['error'])
  return array('message'=>"Failed! ".$ret['message'], $ret['error']);

 $docInfo = $ret['outarr'];
 $docNumPlusYear = $docInfo['code_num'].($docInfo['code_ext'] ? "/".$docInfo['code_ext'] : "")."-".date('Y',$docInfo['ctime']);

 /* GET CAT TAG */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT tag,parent_id FROM dynarc_commercialdocs_categories WHERE id='".$docInfo['cat_id']."'");
 if($db->Read())
 {
  if($db->record['parent_id'])
  {
   $db->RunQuery("SELECT tag FROM dynarc_commercialdocs_categories WHERE id='".$db->record['parent_id']."'");
   $db->Read();
   $_CAT_TAG = $db->record['tag']; 
  }
  else
   $_CAT_TAG = $db->record['tag'];
 }
 $db->Close();

 /* GET PAYMENT MODE */
 $_PA_PAYMODE = "MP01";
 if($docInfo['paymentmode'])
 {
  $ret = GShell("paymentmodes info -id '".$docInfo['paymentmode']."'",$sessid,$shellid);
  if(!$ret['error'])
  {
   $pmInfo = $ret['outarr'];
   $_PA_PAYMODE = $pmInfo['pa_mode'];
  }
 }

 $_DOC_TYPE = "";
 switch($_CAT_TAG)
 {
  case 'INVOICES' : 	$_DOC_TYPE = ($_COMPANY_PROFILE['accounting']['invoice_type'] == "PARCEL") ? "TD06" : "TD01"; break;
  case 'CREDITSNOTE' :  $_DOC_TYPE = "TD04"; break;
  case 'DEBITSNOTE' :   $_DOC_TYPE = "TD05"; break;
 }

 /* Get subject info */
 $ret = GShell("dynarc item-info -ap `rubrica` -id `".$docInfo['subject_id']."` -extget `rubricainfo,contacts`",$sessid,$shellid);
 if(!$ret['error'])
 {
  $subjectInfo = $ret['outarr'];
  if($subjectInfo['iscompany'] != 2) $_TRANS_FORMAT = "FPR12";
 }

 if($docInfo['ship_subject_id'])
 {
  /* Get ship subject info */
  $ret = GShell("dynarc item-info -ap `rubrica` -id `".$docInfo['ship_subject_id']."`",$sessid,$shellid);
  if(!$ret['error'])
   $shipSubjectInfo = $ret['outarr']; 
 }
 else
  $shipSubjectInfo = $subjectInfo;

 /* SCADENZE */
 $expiry = array();
 $db = new AlpaDatabase();
 //$db->RunQuery("SELECT * FROM dynarc_commercialdocs_mmr WHERE item_id='".$docInfo['id']."' AND payment_date='0000-00-00' ORDER BY expire_date ASC");
 $db->RunQuery("SELECT * FROM dynarc_commercialdocs_mmr WHERE item_id='".$docInfo['id']."' ORDER BY expire_date ASC");
 while($db->Read())
 {
  $expiry[] = array('date'=>$db->record['expire_date'], 'amount'=>$db->record['incomes']);
 }
 $db->Close();

 $_COND_PAGAM = "TP02";
 if(count($expiry) > 1)
  $_COND_PAGAM = "TP01";

 $now = time();

 /* --- SOME VALUES ------------------------------------------------------------------------------------------------ */
 $IdPaese = $_COMPANY_PROFILE['addresses']['registered_office']['country'] ? strtoupper($_COMPANY_PROFILE['addresses']['registered_office']['country']) : "IT";
 $IdCodice = $_COMPANY_PROFILE['taxcode'] ? $_COMPANY_PROFILE['taxcode'] : $_COMPANY_PROFILE['vatnumber'];

 $paIdPaese = $subjectInfo['contacts'][0]['countrycode'] ? $subjectInfo['contacts'][0]['countrycode'] : "IT";
 $paIdCodice = $subjectInfo['taxcode'] ? $subjectInfo['taxcode'] : $subjectInfo['vatnumber'];
 $paIdVatNum = $subjectInfo['vatnumber'];
 $paIdVatPre = $subjectInfo['vatnumber_pre'] ? $subjectInfo['vatnumber_pre'] : ($subjectInfo['contacts'][0]['countrycode'] ? $subjectInfo['contacts'][0]['countrycode'] : "IT");
 $paCode = strtoupper($subjectInfo['pacode']); // SI TRATTA DEL COD. IPA  e non del cod. PA.
 if(!$paCode && ($_TRANS_FORMAT == "FPR12")) $paCode = "0000000";


 $fattPAinfo = null;
 $_UPDATE_NEXT_SEQ_NUM = true;

 /* --- REGISTRA O PRELEVA INFO FATT ELETTRONICA ------------------------------------------------------------------- */
 if($docInfo['fatt_pa_id'])
 {
  // Preleva informazioni sulla fattura elettronica
  $ret = GShell("dynarc item-info -ap fatturepa -id '".$docInfo['fatt_pa_id']."' -extget `fatturapa`",$sessid,$shellid);
  if($ret['error']) return array('message'=>'Unable to get info from fattura PA. '.$ret['message'], 'error'=>$ret['error']);

  $fattPAinfo = $ret['outarr'];
  $fileName = $fattPAinfo['xml_file_name'];
  if(!$fileName)
  {
   $nextSeqNum = commercialdocs_paxml_getNextSequenceNumber();
   $_PUF = str_pad($nextSeqNum,5,'0', STR_PAD_LEFT); /* Progressivo univoco invio (max 5 caratteri alfanum.) da cambiare quando implementeremo il multi-azienda */
   $fileName = $IdPaese.$IdCodice."_".$_PUF.".xml";
  }
  else
   $_UPDATE_NEXT_SEQ_NUM = false;
 }

 if(!$fattPAinfo || ($fattPAinfo['status'] > 0))
 {
  // Registra o ri-genera fattura elettronica
  $nextSeqNum = commercialdocs_paxml_getNextSequenceNumber();
  $_UPDATE_NEXT_SEQ_NUM = true;
  if(!$fattPAinfo)
  {
   // Registra nuova fattura elettronica
   $ret = GShell("dynarc new-item -ap fatturepa -extset `fatturapa.invoiceid='".$docInfo['id']."',subjid='".$docInfo['subject_id']."',subjname='''"
	.$docInfo['subject_name']."'''`",$sessid,$shellid);
   if($ret['error']) return array('message'=>'Unable to register fattura PA. '.$ret['message'], 'error'=>$ret['error']);

   $fattPAinfo = $ret['outarr'];
  }
  $_PUF = str_pad($nextSeqNum,5,'0', STR_PAD_LEFT); /* Progressivo univoco invio (max 5 caratteri alfanum.) da cambiare quando implementeremo il multi-azienda */
  $fileName = $IdPaese.$IdCodice."_".$_PUF.".xml";
 }

 $_PROGR_INVIO = date('Y',$docInfo['ctime']).$_COD_AZ.str_pad($fattPAinfo['code_num'],5,'0', STR_PAD_LEFT);


 /* --- GENERATE XML FILE ------------------------------------------------------------------------------------------ */
 // header
 $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
 //$xml.= "<p:FatturaElettronica versione=\"1.1\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:p=\"http://www.fatturapa.gov.it/sdi/fatturapa/v1.1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n";

 $xml.= "<p:FatturaElettronica versione=\"".$_TRANS_FORMAT."\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:p=\"http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2 fatturaordinaria_v1.2.xsd \">";

 /* HEADER */
 $xml.= "  <FatturaElettronicaHeader>\n";

 /* DATI TRASMISSIONE */
 $xml.= "    <DatiTrasmissione>\n";
 $xml.= "      <IdTrasmittente>\n";
 $xml.= "        <IdPaese>".$IdPaese."</IdPaese>\n";

 // verifica IdCodice
 if(!$IdCodice) return array('message'=>"Errore: Manca la tua Partita IVA o Codice Fiscale!, devi impostarla in configurazione -> profilo aziendale",'error'=>"INVALID_ID_CODICE");

 $xml.= "        <IdCodice>".$IdCodice."</IdCodice>\n";
 $xml.= "      </IdTrasmittente>\n";

 // verifica ProgressivoInvio
 if(strlen($_PROGR_INVIO) > 10)
  return array('message'=>"Errore: Il cod. progressivo invio '".$_PROGR_INVIO."' supera i 10 caratteri", 'error'=>"INVALID_PROGRESSIVO_INVIO");

 $xml.= "      <ProgressivoInvio>".$_PROGR_INVIO."</ProgressivoInvio>\n";
 $xml.= "      <FormatoTrasmissione>".$_TRANS_FORMAT."</FormatoTrasmissione>\n";

 // verifica cod. IPA
 if(!$paCode) return array('message'=>"Errore: Il cod. IPA del destinatario non è stato impostato. Verificare in anagrafica cliente.", 'error'=>"INVALID_IPA_CODE");
 $paCodeLen = ($_TRANS_FORMAT == "FPA12") ? 6 : 7;
 if(strlen($paCode) != $paCodeLen) return array('message'=>"Errore: Il cod. IPA del destinatario deve essere di ".$paCodeLen." caratteri. Verificare in anagrafica cliente.", 'error'=>"INVALID_IPA_CODE");

 $xml.= "      <CodiceDestinatario>".$paCode."</CodiceDestinatario>\n";
 $xml.= "      <ContattiTrasmittente/>\n";
 $xml.= "    </DatiTrasmissione>\n";

 /* CEDENTE PRESTATORE */
 $xml.= "    <CedentePrestatore>\n";
 $xml.= "      <DatiAnagrafici>\n";
 $xml.= "        <IdFiscaleIVA>\n";

 // verifica IdPaese
 if(!$IdPaese)
  return array('message'=>"Errore: Il cod. paese della tua azienda non è stato impostato. (es: IT,ES,...). Verifica in configurazione -> profilo aziendale.", 'error'=>"INVALID_ID_PAESE");
 if(strlen($IdPaese) != 2)
  return array('message'=>"Errore: Il cod. paese della tua azienda deve essere esattamente di 2 caratteri. (es: IT,ES,...). Verifica in configurazione -> profilo aziendale.", 'error'=>"INVALID_ID_PAESE");

 $xml.= "          <IdPaese>".$IdPaese."</IdPaese>\n";

 // verifica IdCodice
 $IdCodice2 = $_COMPANY_PROFILE['vatnumber'] ? $_COMPANY_PROFILE['vatnumber'] : $_COMPANY_PROFILE['taxcode'];
 if(!$IdCodice2) 
  return array('message'=>"Errore: Manca la tua Partita IVA o Codice Fiscale!, devi impostarla in configurazione -> profilo aziendale",'error'=>"INVALID_ID_CODICE"); 

 $xml.= "          <IdCodice>".$IdCodice2."</IdCodice>\n";
 $xml.= "        </IdFiscaleIVA>\n";
 $xml.= "        <Anagrafica>\n";

 // verifica denominazione
 if(!$_COMPANY_PROFILE['name'])
  return array('message'=>"Errore: Manca la denominazione della tua azienda. Verifica in configurazione -> profilo aziendale.", 'error'=>"INVALID_DENOMINAZIONE");
 if(strlen($_COMPANY_PROFILE['name']) > 80)
  return array('message'=>"Errore: La denominazione della tua azienda supera gli 80 caratteri. Verifica in configurazione -> profilo aziendale.", 'error'=>"INVALID_DENOMINAZIONE");

 $xml.= "          <Denominazione>".xml_purify($_COMPANY_PROFILE['name'])."</Denominazione>\n";
 $xml.= "        </Anagrafica>\n";

 // verifica regime fiscale
 $regimeFiscale = $_COMPANY_PROFILE['accounting']['tax_regime'] ? $_COMPANY_PROFILE['accounting']['tax_regime'] : 'RF01';
 if(!$regimeFiscale)
  return array('message'=>"Errore: Il regime fiscale della tua azienda non è stato impostato. Verifica in configurazione -> profilo aziendale -> contabilità.", 'error'=>"INVALID_REGIME_FISCALE");

 $xml.= "        <RegimeFiscale>".$regimeFiscale."</RegimeFiscale>\n";
 $xml.= "      </DatiAnagrafici>\n";
 $xml.= "      <Sede>\n";

 // verifica indirizzo
 if(!$_COMPANY_PROFILE['addresses']['registered_office']['address'])
  return array('message'=>"Errore: L'indirizzo della tua azienda non è stato impostato. Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_INDIRIZZO");
 if(strlen($_COMPANY_PROFILE['addresses']['registered_office']['address']) > 60)
  return array('message'=>"Errore: L'indirizzo della tua azienda supera i 60 caratteri. Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_INDIRIZZO");

 $xml.= "        <Indirizzo>".xml_purify($_COMPANY_PROFILE['addresses']['registered_office']['address'])."</Indirizzo>\n";

 // verifica CAP
 if(!$_COMPANY_PROFILE['addresses']['registered_office']['zip'])
  return array('message'=>"Errore: Il C.A.P. della tua azienda non è stato impostato. Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_CAP");
 if(strlen($_COMPANY_PROFILE['addresses']['registered_office']['zip']) != 5)
  return array('message'=>"Errore: Il C.A.P. della tua azienda deve essere esattamente di 5 caratteri. Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_CAP");

 $xml.= "        <CAP>".$_COMPANY_PROFILE['addresses']['registered_office']['zip']."</CAP>\n";

 // verifica Comune
 if(!$_COMPANY_PROFILE['addresses']['registered_office']['city'])
  return array('message'=>"Errore: La città della tua azienda non è stata impostata. Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_COMUNE");
 if(strlen($_COMPANY_PROFILE['addresses']['registered_office']['city']) > 60)
  return array('message'=>"Errore: Il nome della città della tua azienda supera i 60 caratteri. Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_COMUNE");

 $xml.= "        <Comune>".xml_purify($_COMPANY_PROFILE['addresses']['registered_office']['city'])."</Comune>\n";

 // verifica Provincia
 if(!$_COMPANY_PROFILE['addresses']['registered_office']['prov'])
  return array('message'=>"Errore: La provincia della tua azienda non è stata impostata. Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_PROVINCIA");
 if(strlen($_COMPANY_PROFILE['addresses']['registered_office']['prov']) != 2)
  return array('message'=>"Errore: La provincia della tua azienda deve essere esattamente di 2 caratteri. Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_PROVINCIA");

 $xml.= "        <Provincia>".strtoupper($_COMPANY_PROFILE['addresses']['registered_office']['prov'])."</Provincia>\n";

 // verifica Nazione
 $Nazione = $_COMPANY_PROFILE['addresses']['registered_office']['country'] ? strtoupper($_COMPANY_PROFILE['addresses']['registered_office']['country']) : 'IT';
 if(!$Nazione)
  return array('message'=>"Errore: Il cod. paese della tua azienda non è stato impostato (es: IT, ES, ...). Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_NAZIONE");
 if(strlen($Nazione) != 2)
  return array('message'=>"Errore: Il cod. paese della tua azienda deve essere esattamente di 2 caratteri (es: IT, ES, ...). Verifica su configurazione -> profilo aziendale.", 'error'=>"INVALID_NAZIONE");

 $xml.= "        <Nazione>".$Nazione."</Nazione>\n";
 $xml.= "      </Sede>\n";
 $xml.= "    </CedentePrestatore>\n";

 /* CESSIONARIO COMMITTENTE */
 $xml.= "    <CessionarioCommittente>\n";
 $xml.= "      <DatiAnagrafici>\n";

 // verifica Partita IVA
 if($paIdVatNum)
 {
  $xml.= "       <IdFiscaleIVA>\n";
  $xml.= "        <IdPaese>".$paIdVatPre."</IdPaese>\n";
  $xml.= "        <IdCodice>".$paIdVatNum."</IdCodice>\n";
  $xml.= "       </IdFiscaleIVA>\n";
 }

 // verifica CodiceFiscale
 if(!$paIdCodice)
  return array('message'=>"Errore: manca il Cod. Fiscale o la Partita Iva del cessionario/committente. Verificare l'anagrafica del cliente.", 'error'=>"INVALID_CODICEFISCALE");
 if((strlen($paIdCodice) < 11) || (strlen($paIdCodice) > 16))
  return array('message'=>"Errore: Il cod.fiscale o la p.iva del cessionario/committente non è valida. Deve essere di lunghezza tra gli 11 ed i 16 caratteri. Verificare l'anagrafica del cliente.", 'error'=>"INVALID_CODICEFISCALE");

 $xml.= "        <CodiceFiscale>".$paIdCodice."</CodiceFiscale>\n";

 $xml.= "        <Anagrafica>\n";

 // verifica Denominazione
 if(!$subjectInfo['name'])
  return array('message'=>"Manca la denominazione del cessionario/committente. Verificare in anagrafica cliente.", 'error'=>"INVALID_DENOMINAZIONE");
 if(strlen($subjectInfo['name']) > 80)
  return array('message'=>"La denominazione del cessionario/committente supera gli 80 caratteri. Verificare in anagrafica cliente.", 'error'=>"INVALID_DENOMINAZIONE");

 $xml.= "          <Denominazione>".xml_purify($subjectInfo['name'])."</Denominazione>\n";
 $xml.= "        </Anagrafica>\n";
 $xml.= "      </DatiAnagrafici>\n";
 $xml.= "      <Sede>\n";

 // verifica indirizzo
 if(!$subjectInfo['contacts'][0]['address'])
  return array('message'=>"Manca l'indirizzo della sede del cessionario/committente. Verificare in anagrafica cliente.", 'error'=>"INVALID_INDIRIZZO");
 if(strlen($subjectInfo['contacts'][0]['address']) > 60)
  return array('message'=>"L'indirizzo della sede del cessionario/committente supera i 60 caratteri. Verificare in anagrafica cliente.", 'error'=>"INVALID_INDIRIZZO");

 $xml.= "        <Indirizzo>".xml_purify($subjectInfo['contacts'][0]['address'])."</Indirizzo>\n";

 // verifica CAP
 if(!$subjectInfo['contacts'][0]['zipcode'])
  return array('message'=>"Manca il C.A.P. della sede del cessionario/committente. Verificare in anagrafica cliente.", 'error'=>"INVALID_CAP");
 if(strlen($subjectInfo['contacts'][0]['zipcode']) != 5)
  return array('message'=>"Il C.A.P. della sede del cessionario/committente deve essere esattamente di 5 caratteri. Verificare in anagrafica cliente.", 'error'=>"INVALID_CAP");

 $xml.= "        <CAP>".$subjectInfo['contacts'][0]['zipcode']."</CAP>\n";

 // verifica Comune
 if(!$subjectInfo['contacts'][0]['city'])
  return array('message'=>"Manca la città della sede del cessionario/committente. Verificare in anagrafica cliente.", 'error'=>"INVALID_COMUNE");
 if(strlen($subjectInfo['contacts'][0]['city']) > 60)
  return array('message'=>"La città della sede del cessionario/committente supera i 60 caratteri. Verificare in anagrafica cliente.", 'error'=>"INVALID_COMUNE");

 $xml.= "        <Comune>".xml_purify($subjectInfo['contacts'][0]['city'])."</Comune>\n";

 // verifica Provincia
 if(!$subjectInfo['contacts'][0]['province'])
  return array('message'=>"Manca la provincia della sede del cessionario/committente. Verificare in anagrafica cliente.", 'error'=>"INVALID_PROVINCIA");
 if(strlen($subjectInfo['contacts'][0]['province']) != 2)
  return array('message'=>"La provincia della sede del cessionario/committente deve essere esattamente di 2 caratteri. Verificare in anagrafica cliente.", 'error'=>"INVALID_PROVINCIA");

 $xml.= "        <Provincia>".strtoupper($subjectInfo['contacts'][0]['province'])."</Provincia>\n";

 // verifica Nazione
 if(!$paIdPaese)
  return array('message'=>"Manca il cod. della Nazione della sede del cessionario/committente. Verificare in anagrafica cliente.", 'error'=>"INVALID_NAZIONE");
 if(strlen($paIdPaese) != 2)
  return array('message'=>"Il cod. della Nazione della sede del cessionario/committente deve essere esattamente di 2 caratteri. Verificare in anagrafica cliente.", 'error'=>"INVALID_NAZIONE");

 $xml.= "        <Nazione>".strtoupper($paIdPaese)."</Nazione>\n";
 $xml.= "      </Sede>\n";
 $xml.= "    </CessionarioCommittente>\n";

 $xml.= "  </FatturaElettronicaHeader>\n";
 /* EOF - HEADER */


 /* BODY */
 $xml.= "  <FatturaElettronicaBody>\n";
 $xml.= "    <DatiGenerali>\n";
 $xml.= "      <DatiGeneraliDocumento>\n";
 $xml.= "        <TipoDocumento>".$_DOC_TYPE."</TipoDocumento>\n";
 $xml.= "        <Divisa>EUR</Divisa>\n";
 $xml.= "        <Data>".date('Y-m-d',$docInfo['ctime'])."</Data>\n";
 $xml.= "        <Numero>".$docNumPlusYear."</Numero>\n";
 $xml.= "        <ImportoTotaleDocumento>".sprintf('%.2f',$docInfo['tot_netpay'])."</ImportoTotaleDocumento>\n";
 $xml.= "      </DatiGeneraliDocumento>\n";

 if($docInfo['pa_docnum'])
 {
  $xml.= "      <DatiOrdineAcquisto>\n";
  $xml.= "        <IdDocumento>".$docInfo['pa_docnum']."</IdDocumento>\n";
  if($docInfo['pa_cup']) $xml.= "        <CodiceCUP>".$docInfo['pa_cup']."</CodiceCUP>\n";
  if($docInfo['pa_cig']) $xml.= "	     <CodiceCIG>".$docInfo['pa_cig']."</CodiceCIG>\n";
  $xml.= "      </DatiOrdineAcquisto>\n";
 }

 /*$xml.= "      <DatiContratto>";
 $xml.= "	<RiferimentoNumeroLinea>1</RiferimentoNumeroLinea>";
 $xml.= "	<IdDocumento>123</IdDocumento>";
 $xml.= "	<Data>2012-09-01</Data>";
 $xml.= "	<NumItem>5</NumItem>";
 $xml.= "	<CodiceCUP>123abc</CodiceCUP>";
 $xml.= "	<CodiceCIG>456def</CodiceCIG>";
 $xml.= "      </DatiContratto>";
 $xml.= "      <DatiConvenzione>";
 $xml.= "	<RiferimentoNumeroLinea>1</RiferimentoNumeroLinea>";
 $xml.= "	<IdDocumento>123</IdDocumento>";
 $xml.= "	<NumItem>5</NumItem>";
 $xml.= "	<CodiceCUP>123abc</CodiceCUP>";
 $xml.= "	<CodiceCIG>456def</CodiceCIG>";
 $xml.= "      </DatiConvenzione>";
 $xml.= "      <DatiRicezione>";
 $xml.= "	<RiferimentoNumeroLinea>1</RiferimentoNumeroLinea>";
 $xml.= "	<IdDocumento>123</IdDocumento>";
 $xml.= "	<NumItem>5</NumItem>";
 $xml.= "	<CodiceCUP>123abc</CodiceCUP>";
 $xml.= "	<CodiceCIG>456def</CodiceCIG>";
 $xml.= "      </DatiRicezione>";*/

 $DatiTrasportoXML = "";

 if($docInfo['trans_method'])
  $DatiTrasportoXML.= "		  <MezzoTrasporto>".$_TRANS_METHOD[$docInfo['trans_method']]."</MezzoTrasporto>\n";

 if($docInfo['trans_num'])
  $DatiTrasportoXML.= "		  <NumeroColli>".$docInfo['trans_num']."</NumeroColli>\n";

 if($docInfo['trans_aspect'])
  $DatiTrasportoXML.= "		  <Descrizione>".xml_purify($docInfo['trans_aspect'])."</Descrizione>\n";

 if($docInfo['trans_weight'])
 {
  $DatiTrasportoXML.= "		  <UnitaMisuraPeso>kg</UnitaMisuraPeso>\n";
  $DatiTrasportoXML.= "		  <PesoLordo>".sprintf('%.2f',$docInfo['trans_weight'])."</PesoLordo>\n";
 }

 if($docInfo['trans_datetime'])
 {
  $DatiTrasportoXML.= "		  <DataInizioTrasporto>".date('Y-m-d',$docInfo['trans_datetime'])."</DataInizioTrasporto>\n";
  $DatiTrasportoXML.= "		  <DataOraConsegna>".date('Y-m-d',$docInfo['trans_datetime'])."T".date('H:i:s',$docInfo['trans_datetime'])."</DataOraConsegna>\n";
 }
 

 if($DatiTrasportoXML)
 {
  $xml.= "      <DatiTrasporto>\n";
  $xml.= $DatiTrasportoXML;
  $xml.= "      </DatiTrasporto>\n";
 }

 $xml.= "    </DatiGenerali>\n";

 $xml.= "    <DatiBeniServizi>\n";

 $_IDX = 1;
 for($c=0; $c < count($docInfo['elements']); $c++)
 {
  $el = $docInfo['elements'][$c];
  if(($el['type'] == "note") || ($el['type'] == "message"))
   continue;

  $qty = $el['qty'] * ($el['extraqty'] ? $el['extraqty'] : 1);

  $discount = $el['discount_inc'] ? $el['discount_inc'] : 0;
  $discount2 = 0;
  $discount3 = 0;

  if($el['discount_perc'])				$discount = $el['price'] ? ($el['price']/100)*$el['discount_perc'] : 0;
  if($el['discount2'] && $el['price'])	$discount2 = (($el['price']-$discount)/100) * $el['discount2'];
  if($el['discount2'] && $el['discount3'] && $el['price'])	
   $discount3 = ((($el['price']-$discount)-$discount2)/100) * $el['discount3'];

  $amount = round(((($el['price']-$discount)-$discount2)-$discount3) * $qty, 5);


  $xml.= "      <DettaglioLinee>\n";
  $xml.= "        <NumeroLinea>".$_IDX."</NumeroLinea>\n";
  $xml.= "        <Descrizione>".xml_purify($el['name'])."</Descrizione>\n";
  $xml.= "        <Quantita>".sprintf('%.2f',$qty)."</Quantita>\n";
  
  if($el['units'])
   $xml.= "        <UnitaMisura>".$el['units']."</UnitaMisura>\n";

  $xml.= "        <PrezzoUnitario>".sprintf('%.5f',$el['price'])."</PrezzoUnitario>\n";

  if($el['discount_perc'])
  {
   $discT = $discount * $qty;

   $xml.= "         <ScontoMaggiorazione>\n";
   $xml.= "          <Tipo>SC</Tipo>\n";
   $xml.= "          <Percentuale>".sprintf('%.2f',$el['discount_perc'])."</Percentuale>\n";
   $xml.= "          <Importo>".sprintf('%.5f',$discT)."</Importo>\n";
   $xml.= "         </ScontoMaggiorazione>\n";
  }
  /* TODO: da fare sconto2 e sconto3 */

  $xml.= "        <PrezzoTotale>".sprintf('%.5f',$amount)."</PrezzoTotale>\n";
  $xml.= "        <AliquotaIVA>".sprintf('%.2f',$el['vatrate'])."</AliquotaIVA>\n";
  switch($el['vattype'])
  {
   case 'EXCLUDING' : 		$xml.= "        <Natura>N1</Natura>\n"; break;
   case 'NOT_SUBJECT' : 	$xml.= "        <Natura>N2</Natura>\n"; break;
   case 'NOT_TAXABLE' : 	$xml.= "        <Natura>N3</Natura>\n"; break;
   case 'FREE' : 			$xml.= "        <Natura>N4</Natura>\n"; break;
   case 'NOT_DEDUCTIBLE' : 	$xml.= "        <Natura>N5</Natura>\n"; break;
   case 'REVERSE_CHARGE' : 	$xml.= "        <Natura>N6</Natura>\n"; break;
   case 'PURCH_INEUR' : 	$xml.= "        <Natura>N7</Natura>\n"; break;
  }
  $xml.= "      </DettaglioLinee>\n";

  $_IDX++;
 }

 for($c=1; $c < 4; $c++)
 {
  $vatId = $docInfo['vat_'.$c.'_id'];
  if(!$vatId) continue;
  $vatName = $_VAT_BY_ID[$vatId]['name'];
  $vatRate = $_VAT_BY_ID[$vatId]['percentage'];
  $vatType = $_VAT_BY_ID[$vatId]['vat_type'];
  $taxable = $docInfo['vat_'.$c.'_taxable'];
  $tax = $docInfo['vat_'.$c.'_tax'];
  $vatChargeability = $docInfo['vat_chargeability'];

  $xml.= "      <DatiRiepilogo>\n";
  $xml.= "        <AliquotaIVA>".sprintf('%.2f',$vatRate)."</AliquotaIVA>\n";
  if(!$vatRate)
  {
   switch($vatType)
   {
    case 'EXCLUDING' : 			$xml.= "        <Natura>N1</Natura>\n"; break;
    case 'NOT_SUBJECT' : 		$xml.= "        <Natura>N2</Natura>\n"; break;
    case 'NOT_TAXABLE' : 		$xml.= "        <Natura>N3</Natura>\n"; break;
    case 'FREE' : 				$xml.= "        <Natura>N4</Natura>\n"; break;
    case 'NOT_DEDUCTIBLE' : 	$xml.= "        <Natura>N5</Natura>\n"; break;
    case 'REVERSE_CHARGE' : 	$xml.= "        <Natura>N6</Natura>\n"; break;
    case 'PURCH_INEUR' : 		$xml.= "        <Natura>N7</Natura>\n"; break;
   }
  }

  $xml.= "        <ImponibileImporto>".sprintf('%.2f',round($taxable,2))."</ImponibileImporto>\n";
  $xml.= "        <Imposta>".sprintf('%.2f',round($tax,2))."</Imposta>\n";

  if(($el['vattype'] == "SPLIT_PAYMENT") && ($taxable>0))
   $xml.= "        <EsigibilitaIVA>S</EsigibilitaIVA>\n";
  else if($vatChargeability && ($vatType != 'REVERSE_CHARGE') && ($taxable>0)) 
   $xml.= "        <EsigibilitaIVA>".$vatChargeability."</EsigibilitaIVA>\n";

  $xml.= "        <RiferimentoNormativo>".$vatName."</RiferimentoNormativo>\n";
  $xml.= "      </DatiRiepilogo>\n";
 }

 $xml.= "    </DatiBeniServizi>\n";

 $xml.= "    <DatiPagamento>\n";
 $xml.= "      <CondizioniPagamento>".$_COND_PAGAM."</CondizioniPagamento>\n";


 $_BANK = $docInfo['ourbanksupport_id'] ? $_COMPANY_PROFILE['banks'][$docInfo['ourbanksupport_id']] : $_COMPANY_PROFILE['banks'][0];

 for($c=0; $c < count($expiry); $c++)
 {
  $xml.= "      <DettaglioPagamento>\n";

  if($_BANK['holder'])
   $xml.= "        <Beneficiario>".xml_purify($_BANK['holder'])."</Beneficiario>\n";
  $xml.= "        <ModalitaPagamento>".$_PA_PAYMODE."</ModalitaPagamento>\n";
  $xml.= "        <DataScadenzaPagamento>".$expiry[$c]['date']."</DataScadenzaPagamento>\n";
  $xml.= "        <ImportoPagamento>".sprintf('%.2f',$expiry[$c]['amount'])."</ImportoPagamento>\n";

  if($_BANK['iban'])
   $xml.= "        <IBAN>".$_BANK['iban']."</IBAN>\n";
  else if($_BANK['abi'] && $_BANK['cab'])
  {
   $xml.= "        <ABI>".$_BANK['abi']."</ABI>\n";
   $xml.= "        <CAB>".$_BANK['cab']."</CAB>\n";
  }
  //if($_BANK['bicswift'])	$xml.= "        <BIC>".$_BANK['bicswift']."</BIC>\n";

  $xml.= "      </DettaglioPagamento>\n";
 }

 $xml.= "    </DatiPagamento>\n";

 $xml.= "  </FatturaElettronicaBody>\n";
 /* EOF - BODY */
 $xml.= "</p:FatturaElettronica>\n";


 /* --- WRITE TO FILE ---------------------------------------------------------------------------------------------- */
 $fullFileName = $_XMLFILE_DIR.$fileName;

 $f = @fopen($_BASE_PATH.$fullFileName,"w");
 if(!$f)
  return array('message'=>"Unable to create file $fullFileName","error"=>"UNKNOWN_ERROR");
 @fwrite($f,$xml);
 @fclose($f);
 @chmod($_BASE_PATH.$fullFileName,$_DEFAULT_FILE_PERMS);

 $out.= "File ".$fullFileName." has been generated!";

 $outArr = $fattPAinfo;
 $outArr['xml_file_name'] = $fileName;
 $outArr['xml_file_basedir'] = $_XMLFILE_DIR;
 $outArr['xml_fullname'] = $fullFileName;

 /* --- AGGIORNAMENTO DATI FATTURA ELETTRONICA --------------------------------------------------------------------- */
 GShell("dynarc edit-item -ap fatturepa -id '".$fattPAinfo['id']."' -code-str `".$_PROGR_INVIO."` -extset `fatturapa.filename='".$fileName."',subjid='"
	.$docInfo['subject_id']."',subjname='''".$docInfo['subject_name']."''',status='0'`",$sessid,$shellid);

 if($_UPDATE_NEXT_SEQ_NUM)
  commercialdocs_paxml_updateNextSequenceNumber($nextSeqNum+1);
 
 return array("message"=>$out, "outarr"=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function commercialdocs_paxml_getNextSequenceNumber()
{
 global $fatturePAarchiveInfo;

 // get next sequence number
 $nextSeqNum = 1;
 $fatturePAarchiveInfo = array();
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT id,params FROM dynarc_archives WHERE tb_prefix='fatturepa' AND trash='0'");
 if($db->Read())
 {
  $fatturePAarchiveInfo = array('id'=>$db->record['id'], 'params'=>array());
  if($db->record['params'])
  {
   $x = explode("&",$db->record['params']);
   for($c=0; $c < count($x); $c++)
   {
    if(!$x[$c]) continue;
    $xx = explode("=",$x[$c]);
    $fatturePAarchiveInfo['params'][$xx[0]] = $xx[1];
   }
  }
  if($fatturePAarchiveInfo['params']['nextseqnum'])
   $nextSeqNum = $fatturePAarchiveInfo['params']['nextseqnum'];
  else
  {
   $db2 = new AlpaDatabase();
   $db2->RunQuery("SELECT MAX(ordering) AS ordering FROM dynarc_fatturepa_items");
   if($db2->Read())
	$nextSeqNum = $db2->record['ordering']+1;
   $db2->Close();
  }
 }
 $db->Close();
 return $nextSeqNum;
}
//-------------------------------------------------------------------------------------------------------------------//
function commercialdocs_paxml_updateNextSequenceNumber($nextSeqNum)
{
 global $fatturePAarchiveInfo;

 $fatturePAarchiveInfo['params']['nextseqnum'] = $nextSeqNum;
 
 $params = "";
 reset($fatturePAarchiveInfo['params']);
 while(list($k,$v) = each($fatturePAarchiveInfo['params']))
 {
  $params.= "&".$k."=".$v;
 }

 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE dynarc_archives SET params='".ltrim($params,"&")."' WHERE id='".$fatturePAarchiveInfo['id']."'");
 $db->Close();
}
//-------------------------------------------------------------------------------------------------------------------//

