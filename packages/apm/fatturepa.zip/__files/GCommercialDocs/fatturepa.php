<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 06-03-2015
 #PACKAGE: fatturepa
 #DESCRIPTION: Riepilogo fatture PA
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO: 
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS, $_DECIMALS, $_COMPANY_PROFILE, $_COMMERCIALDOCS_CONFIG;

$_BASE_PATH = "../";
$_RESTRICTED_ACCESS = "commercialdocs";
$_AP = "commercialdocs";
$_DECIMALS = 2;

include($_BASE_PATH."var/templates/glight/index.php");

include_once($_BASE_PATH."include/company-profile.php");
include_once($_BASE_PATH."etc/commercialdocs/config.php");
$_BANKS = $_COMPANY_PROFILE['banks'];
$_DECIMALS = $_COMPANY_PROFILE['accounting']['decimals_pricing'];
$_TOTALS = array(
 'amount' => 0,
 'vat' => 0,
 'total' => 0,
 'ritacc' => 0,
 'ccp' => 0,
 'rinps' => 0,
 'enasarco' => 0,
 'netpay' => 0,
 'rebate' => 0,
 'stamp' => 0,
 'expenses' => 0,
 'discount' => 0,
 'cartage' => 0,
 'packingcharges' => 0,
 'collectioncharges' => 0,
 'agentcommiss' => 0,
);

$_STATUS = array(
 0 => "Da inviare",
 1 => "Inviata",
 2 => "Notifica scarto",
 3 => "Mancata consegna",
 4 => "Ricevuta consegna",
 5 => "Decorrenza termini",
 6 => "Notifica esito",
 7 => "Notifica esito EC02",
 8 => "Senza esiti oltre RC",
);

$template = new GLightTemplate();
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeInternalObject("serp");
$template->includeInternalObject("contactsearch");
$template->includeInternalObject("labels");
$template->includeObject("printmanager");
$template->includeCSS('doclist.css');

loadLanguage("calendar");

//-------------------------------------------------------------------------------------------------------------------//
$_CAT_INFO = array();
$_ROOT_CAT = array();
$_CAT_TAG = "";
$_ROOT_CT = "";
$_EXTRA_MENU_ITEMS = array();
$_SUBJTYPE_NAME = "Amministrazione";
$_REQUEST['hideleftsection'] = true;
$_TITLE_BAR = "Riepilogo fatture elettroniche";

$template->Begin($_TITLE_BAR);
//-------------------------------------------------------------------------------------------------------------------//
$dt = strtotime(date('Y-m')."-01");
if(!$_REQUEST['dtfilt'])
 $_REQUEST['dtfilt'] = 'thismonth';

switch($_REQUEST['dtfilt'])
{
 case 'thismonth' : {$_REQUEST['from'] = date('Y-m-d',$dt); $_REQUEST['to'] = date('Y-m-t',$dt); } break;
 case 'lastmonth' : {$_REQUEST['from'] = date('Y-m-d',strtotime("-1 month",$dt)); $_REQUEST['to'] = date('Y-m-t',strtotime("-1 month",$dt)); } break;
 case 'lastquarter' : {$_REQUEST['from'] = date('Y-m-d',strtotime("-3 month",$dt)); $_REQUEST['to'] = date('Y-m-d',strtotime("-1 day",$dt)); } break;
 case 'lastyear' : {$_REQUEST['from'] = date('Y-m-d',strtotime("-1 year",$dt)); $_REQUEST['to'] = date('Y',strtotime("-1 year",$dt))."-12-31"; } break;
 case 'thisyear' : {$_REQUEST['from'] = date('Y',$dt)."-01-01"; $_REQUEST['to'] = date('Y',$dt)."-12-31"; } break;
}

$dateFrom = $_REQUEST['from'] ? $_REQUEST['from'] : date('Y')."-01-01";
$dateTo = $_REQUEST['to'] ? $_REQUEST['to'] : date('Y-m-d');

$_DEF_RPP = 25;

$_COLUMNS = array(
 0 => array('title'=>'Nr',				'field'=>'code_num',		'width'=>50,		'sortable'=>true,	'visibled'=>true),
 1 => array('title'=>'Prog. invio',		'field'=>'code_str',		'width'=>50,		'sortable'=>true,	'visibled'=>false),
 2 => array('title'=>'Nome file XML',	'field'=>'xml_file_name',	'width'=>250,		'sortable'=>true,	'visibled'=>false),
 3 => array('title'=>'Documento',		'field'=>'doc_name',		'width'=>250,		'sortable'=>false,	'visibled'=>true),
 4 => array('title'=>'Cod. Cli',		'field'=>'subject_code',	'width'=>50,		'sortable'=>false,	'visibled'=>false),
 5 => array('title'=>$_SUBJTYPE_NAME,	'field'=>'subject_name',	'sortable'=>true,	'visibled'=>true),
 6 => array('title'=>'Data emiss.',		'field'=>'ctime',			'width'=>100,		'sortable'=>true,	'visibled'=>true, 	'format'=>'date'),
 7 => array('title'=>'Stato',			'field'=>'status',			'width'=>100,		'sortable'=>true,	'visibled'=>true),
 8 => array('title'=>'Note', 			'field'=>'description', 	'width'=>250,		'sortable'=>false,	'visibled'=>false),
 9 => array('title'=>'Imponibile',		'field'=>'amount',			'width'=>70,		'sortable'=>true,	'visibled'=>false,	'format'=>'currency'),
 10 => array('title'=>'I.V.A.',			'field'=>'vat',				'width'=>60,		'sortable'=>true,	'visibled'=>false,	'format'=>'currency'),
 11 => array('title'=>'Totale',			'field'=>'total',			'width'=>70,		'sortable'=>true,	'visibled'=>false,	'format'=>'currency'),
 12 => array('title'=>'Netto a pagare', 'field'=>'netpay', 			'width'=>70,		'sortable'=>true,	'visibled'=>true, 	'format'=>'currency'),

);

$_FOOTER_COLUMNS = array(
 0 => array('title'=>'IMPONIBILE',		'field'=>'amount',			'width'=>80,		'visibled'=>false),
 1 => array('title'=>'I.V.A.',			'field'=>'vat',				'width'=>80,		'visibled'=>false),
 2 => array('title'=>'TOTALE',			'field'=>'total',			'width'=>80,		'visibled'=>false),
 3 => array('title'=>'NETTO A PAGARE',	'field'=>'netpay',			'width'=>100,		'visibled'=>true),
);

/* GET COLUMN SETTINGS */
$ret = GShell("aboutconfig get -app gcommercialdocs -sec fatturepadocumentlist");
if(!$ret['error'])
{
 $settings = $ret['outarr']['config'];
 if(is_array($settings[$_ROOT_CT]))
 {
  $visibledColumns = explode(",",$settings[$_ROOT_CT]['visibledcolumns']);
  for($c=0; $c < count($_COLUMNS); $c++)
  {
   $col = $_COLUMNS[$c];
   if(in_array($col['field'], $visibledColumns))
	$_COLUMNS[$c]['visibled'] = true;
   else
	$_COLUMNS[$c]['visibled'] = false;
  }
  for($c=0; $c < count($_FOOTER_COLUMNS); $c++)
  {
   $col = $_FOOTER_COLUMNS[$c];
   if(in_array($col['field'], $visibledColumns))
	$_FOOTER_COLUMNS[$c]['visibled'] = true;
   else
	$_FOOTER_COLUMNS[$c]['visibled'] = false;
  }
  if($settings[$_ROOT_CT]['rpp'])
   $_DEF_RPP = $settings[$_ROOT_CT]['rpp'];
 }
}

/* GET CONFIG */
$ret = GShell("aboutconfig get-config -app gcommercialdocs -sec interface");
if(!$ret['error'])
 $config = $ret['outarr']['config'];


$centerContents = "<input type='text' class='edit' style='width:290px;float:left' placeholder='Ricerca per ".strtolower($_SUBJTYPE_NAME)."' id='search' value=\"".htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\" modal='extended' fields='code_str,name' contactfields='phone,phone2,cell,email' disablerightbtn='true'/>";
$centerContents.= "<input type='button' class='button-search' id='searchbtn'/>";

$_DATE_FILTERS = array('thisyear'=>'Quest&lsquo;anno', 'thismonth'=>'Questo mese', 'lastmonth'=>'Mese scorso', 'lastquarter'=>'Ultimo trimestre', 'lastyear'=>'Anno scorso');

$centerContents.= "<input type='edit' class='dropdown' id='dtfilt' connect='dtfiltlist' readonly='true' style='width:150px;margin-left:30px' value='".$_DATE_FILTERS[$_REQUEST['dtfilt']]."' retval='".$_REQUEST['dtfilt']."' placeholder='filtra per data'/>";
$centerContents.= "<ul class='popupmenu' id='dtfiltlist'>";
reset($_DATE_FILTERS);
while(list($k,$v)=each($_DATE_FILTERS)){ $centerContents.= "<li value='".$k."'>".$v."</li>"; }
$centerContents.= "</ul>";

$centerContents.= "<input type='text' class='calendar' value='".($dateFrom ? date('d/m/Y',strtotime($dateFrom)) : '')."' id='datefrom' style='margin-left:10px'/><span class='smalltext'> al </span><input type='text' class='calendar' value='".($dateTo ? date('d/m/Y',strtotime($dateTo)) : '')."' id='dateto'/>";


$template->Header("search", $centerContents, "BTN_EXIT", 800);
//-------------------------------------------------------------------------------------------------------------------//
$_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "id";
$_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "DESC";
$_RPP = $_REQUEST['rpp'] ? $_REQUEST['rpp'] : $_DEF_RPP;
$_PG = $_REQUEST['pg'] ? $_REQUEST['pg'] : 1;

$_SERP = new SERP();
$_SERP->setOrderBy($_ORDER_BY);
$_SERP->setOrderMethod($_ORDER_METHOD);
$_SERP->setResultsPerPage($_RPP);
$_SERP->setCurrentPage($_PG);

$cmd = "dynarc item-list -ap fatturepa";
$where = "";

if($_REQUEST['subjectid'])		$where.= " AND subject_id='".$_REQUEST['subjectid']."'";
if($dateFrom)					$where.= " AND ctime>='".$dateFrom."'";
if($dateTo)						$where.= " AND ctime<'".$dateTo." 23:59:59'";

if($where)						$cmd.= " -where <![CDATA[".ltrim($where,' AND ')."]]>";

$cmd.= " -extget 'fatturapa.docinfo'";

$_CMD = $cmd;
$ret = $_SERP->SendCommand($cmd);
$_DOCUMENT_LIST = $ret['items'];

//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0);
?>
 <input type='button' class='button-blue' value="&laquo; torna alla lista" onclick="comeBack()"/>
 </td>
 <td>
	<input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='mainmenubutton'/>
	<ul class='popupmenu' id='mainmenu'>
	 <li onclick="ExportToExcel(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Esporta su file Excel</li>
	 <!-- <li onclick="Print(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/printer.gif"/>Stampa</li> -->
	 <li class='separator'>&nbsp;</li>
	 <li onclick="DeleteSelected()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/delete.gif"/>Elimina selezionate</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="comeBack()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/import2.png"/>Torna alla lista</li>
	</ul>

	<input type='button' class="button-gray menu" value="Visualizza" connect="viewmenu" id="viewmenubutton"/>
	<ul class='popupmenu' id='viewmenu' style='width:320px'>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $checked = $col['visibled'] ? true : false;
	 echo "<li style='width:150px;float:left'><input type='checkbox'".($checked ? " checked='true'" : "")." onchange=\"showColumn('".$col['field']."',this)\"/>".$col['title']."</li>";
	}
	if($_REQUEST['show'] != "trash")
	{
	 ?>
	 <li class='separator' style='clear:both'>&nbsp;</li>
	 <li onclick="saveGlobalSettings()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save.gif"/>Salva configurazione</li>
	 <?php
	}
	?>
	</ul>

 </td>
 <td>
  &nbsp;
 </td>
 <td width='130'>
	<span class='smalltext'>Mostra</span>
	<input type='text' class='dropdown' id='rpp' value="<?php echo $_RPP; ?> righe" retval="<?php echo $_RPP; ?>" readonly='true' connect='rpplist' style='width:80px'/>
	<ul class='popupmenu' id='rpplist'>
	 <li value='10'>10 righe</li>
	 <li value='25'>25 righe</li>
	 <li value='50'>50 righe</li>
	 <li value='100'>100 righe</li>
	 <li value='250'>250 righe</li>
	 <li value='500'>500 righe</li>
	</ul>
 </td>
 <td width='223' align='right'>
	<?php $_SERP->DrawSerpButtons(true);
 
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("fullspace");
//-------------------------------------------------------------------------------------------------------------------//
?>
<table width="100%" height="80%" cellspacing="0" cellpadding="0" border="0" id="template-outer-mask">
 <tr><td class="bg-lightgray" style="width:270px;<?php if($_REQUEST['hideleftsection']) echo 'display:none'; ?>" valign="top" id="template-left-section">
	<div class='advanced-search-title'>DOCUMENTI COMMERCIALI
	 <img src="<?php echo $_ABSOLUTE_URL.$template->config['basepath']; ?>img/hidearrow.png" style="float:right;margin-top:12px;cursor:pointer" title="Nascondi barra laterale" onclick="HideLeftSection()"/>
	</div>
	<?php
	/* SHOW MAIN MENU */
	$ret = GShell("dynarc cat-list -ap commercialdocs");
	$list = $ret['outarr'];
	echo "<ul class='glight-main-menu'>";
	for($c=0; $c < count($list); $c++)
	{
	 $catInfo = $list[$c];
	 $ct = strtolower($catInfo['tag']);
	 switch($ct)
	 {
	  case 'preemptives' : $icon = "icons/doc-blue.png"; break;
	  case 'orders' : $icon = "icons/doc-orange.png"; break;
	  case 'ddt' : $icon = "icons/doc-violet.png"; break;
	  case 'invoices' : $icon = "icons/doc-green.png"; break;
	  case 'vendororders' : $icon = "icons/doc-red.png"; break;
	  case 'purchaseinvoices' : case 'paymentnotice' : $icon = "icons/doc-yellow.png"; break;
	  case 'intervreports' : $icon = "icons/doc-maroon.png"; break;
	  case 'creditsnote' : $icon = "icons/doc-sky.png"; break;
	  case 'debitsnote' : $icon = "icons/doc-red.png"; break;
	
	  default : $icon = "icons/doc-gray.png"; break;
	 }

	 $url = $template->config['basepath'];
	 $active = false;
	 $url.= "index.php?ct=".$ct;
	 echo "<a href='".$_ABSOLUTE_URL.$url."'><li class='item".($active ? " selected" : "")."'>";
	 echo "<img src='".$_ABSOLUTE_URL.$template->config['basepath'].$icon."'/>";
	 echo "<span class='item-title-singleline'>".$catInfo['name']."</span>";
	 echo "</li></a>";
	}
	echo "</ul>";
	?>
	</td>
	<td style="width:8px" valign="top"><div class="vertical-gray-separator" id="template-left-bar" <?php if($_REQUEST['hideleftsection']) echo "style='cursor:pointer' onclick='ShowLeftSection()' title='Mostra barra laterale'"; ?>></div></td>
	<td class="page-contents" valign="top">
	 <div class="page-contents-body">
	  <!-- START OF PAGE ------------------------------------------------------------------------->
	  <div class="titlebar blue-bar"><span class="titlebar orange-bar"><?php echo $_TITLE_BAR; ?></span></div>

<div id='documentlist-container' style="height:100%;overflow:auto">
<table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='documentlist' noprinthidden='true'>
<tr><th width='16'><input type='checkbox'/></th>
	<th width='22'>&nbsp;</th>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $style = $col['fieldstyle'];
	 $visibled = $col['visibled'] ? true : false;
     if(($col['format'] == "currency") && !$style)
      $style = "text-align:right;";
     if(!$visibled) 
	   $style = "display:none;".$style;
	 echo "<th".($style ? " style='".$style."'" : "");
	 if($col['width'])			echo " width='".$col['width']."'";
	 if($col['field'])			echo " field='".$col['field']."'";
	 if($col['format'])			echo " format='".$col['format']."'";
	 if($col['sortable'])		echo " sortable='true'";
	 echo ">".$col['title']."</th>";
	}
	?>
	<th width='22'>&nbsp;</th>
</tr>
<?php
$row = 0;
$mod = new GMOD();
$lastdate = "";
for($z=0; $z < count($_DOCUMENT_LIST); $z++)
{
 $item = $_DOCUMENT_LIST[$z];
 $docInfo = $item['docinfo'];

 $hint = $docInfo['subject_code']." - ".$docInfo['subject_name'];

 echo "<tr class='row".$row."' id='".$item['id']."' title=\"".$hint."\"><td><input type='checkbox'/></td>";
 echo "<td align='center'><img src='".$_ABSOLUTE_URL."share/icons/16x16/pencil.gif' style='cursor:pointer' onclick='showFatturaPA(".$item['id'].")'/></td>";
 for($i=0; $i < count($_COLUMNS); $i++)
 {
  $col = $_COLUMNS[$i];
  $visibled = $col['visibled'] ? true : false;
  $style = $col['style'];
  if(($col['format'] == "currency") && !$style)
   $style = "text-align:right;";
  if(!$visibled) 
	$style = "display:none;".$style;
  echo "<td".($style ? " style='".$style."'" : "").">";
  switch($col['field'])
  {
   case 'code_num' : echo "<a href='#' onclick='showFatturaPA(".$item['id'].")'>".$item['code_num']."</a>"; break;
   case 'code_str' : echo "<a href='#' onclick='showFatturaPA(".$item['id'].")'>".$item['code_str']."</a>"; break;
   case 'xml_file_name' : echo "<a href='".$_ABSOLUTE_URL."getfile.php?file=".$item['xml_file_name']."&basedir=share/fatturepa/'>"
	.$item['xml_file_name']."</a>"; break;

   case 'doc_name' : echo "<a href='".$_ABSOLUTE_URL."GCommercialDocs/docinfo.php?id=".$item['invoice_id']."' target='GCD-"
	.$item['invoice_id']."'>".$item['doc_name']."</a>"; break;

   case 'ctime' : echo date('d/m/Y',$item['ctime']); break;
   case 'status' : echo $_STATUS[$item['status']]; break;
   case 'description' : echo $item['desc'] ? $item['desc'] : "&nbsp;"; break;

   case 'subject_code' : echo $item['subject_code'] ? $item['subject_code'] : "&nbsp;"; break;
   case 'subject_name' : echo $item['subject_name'] ? $item['subject_name'] : "&nbsp;"; break;

   case 'amount' : echo number_format($item['amount'],$_DECIMALS,',','.'); break;
   case 'vat' : echo number_format($item['vat'],$_DECIMALS,',','.'); break;
   case 'total' : echo number_format($item['total'],$_DECIMALS,',','.'); break;
   case 'netpay' : echo number_format($item['netpay'],$_DECIMALS,',','.'); break;

  }
  echo "</td>";
 }
 echo "<td><img src='".$_ABSOLUTE_URL."share/icons/16x16/email.gif' title='Invia x email' style='cursor:pointer' onclick=\"sendEmail("
	.$item['id'].",'".$item['subject_id']."','share/fatturepa/".$item['xml_file_name']."')\"/></td>";
 echo "</tr>";
 $row = $row ? 0 : 1;

 $_TOTALS['amount']+= 		$docInfo['amount'];
 $_TOTALS['vat']+= 			$docInfo['vat'];
 $_TOTALS['total']+= 		$docInfo['total'];
 $_TOTALS['ritacc']+=		$docInfo['tot_rit_acc'];
 $_TOTALS['ccp']+=			$docInfo['tot_ccp'];
 $_TOTALS['rinps']+=		$docInfo['tot_rinps'];
 $_TOTALS['enasarco']+=		$docInfo['tot_enasarco'];
 $_TOTALS['netpay']+=		$docInfo['tot_netpay'];
 $_TOTALS['rebate']+=		$docInfo['rebate'];
 $_TOTALS['stamp']+=		$docInfo['stamp'];
 $_TOTALS['expenses']+=		$docInfo['tot_expenses'];
 $_TOTALS['discount']+=		$docInfo['tot_discount'];
 $_TOTALS['cartage']+=		$docInfo['cartage'];
 $_TOTALS['packingcharges']+=	$docInfo['packing_charges'];
 $_TOTALS['collectioncharges']+=  $docInfo['collection_charges'];
 $_TOTALS['agentcommiss']+=	$docInfo['agent_commiss'];
}
?>
</table>
<div id='nuvcontainer' style="position:absolute;left:0px;top:0px;width:200px;display:block;visibility:hidden;"></div>
</div>
<!-- TOTALI -->
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="footer-totals" style="margin-top:20px;<?php if($_REQUEST['show'] == 'trash') echo 'display:none'; ?>">
<tr><th rowspan='2' class='blue'>&nbsp;</th>
	<?php
	for($c=0; $c < count($_FOOTER_COLUMNS); $c++)
	{
	 $col = $_FOOTER_COLUMNS[$c];
	 $style = "";
	 if(!$col['visibled'])
	  $style = "display:none";
	 $class = "";
	 switch($col['field'])
	 {
	  case 'total' : case 'netpay' : $class='green'; break;
	  default : $class = "blue"; break;
	 }
	 echo "<th class='".$class."' width='".$col['width']."' id='footer-".$col['field']."-title'".($style ? " style='".$style."'" : "").">".$col['title']."</th>";
	}
	?></tr>
<tr><?php
	for($c=0; $c < count($_FOOTER_COLUMNS); $c++)
	{
	 $col = $_FOOTER_COLUMNS[$c];
	 $style = "";
	 if(!$col['visibled'])
	  $style = "display:none";
	 echo "<td id='footer-".$col['field']."-value'".($style ? " style='".$style."' " : " ");
	 switch($col['field'])
	 {
	  case 'amount' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['amount'],$_DECIMALS,',','.')."</td>"; break;
	  case 'vat' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['vat'],$_DECIMALS,',','.')."</td>"; break;
	  case 'total' : echo "class='green' align='right'><em>&euro;</em>".number_format($_TOTALS['total'],$_DECIMALS,',','.')."</td>"; break;
	  case 'ritacconto' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['ritacc'],$_DECIMALS,',','.')."</td>"; break;
	  case 'cassaprev' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['ccp'],$_DECIMALS,',','.')."</td>"; break;
	  case 'rivalsainps' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['rinps'],$_DECIMALS,',','.')."</td>"; break;
	  case 'enasarco' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['enasarco'],$_DECIMALS,',','.')."</td>"; break;
	  case 'netpay' : echo "class='green' align='right'><em>&euro;</em>".number_format($_TOTALS['netpay'],$_DECIMALS,',','.')."</td>"; break;
	  case 'rebate' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['rebate'],$_DECIMALS,',','.')."</td>"; break;
	  case 'stamp' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['stamp'],$_DECIMALS,',','.')."</td>"; break;
	  case 'expenses' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['expenses'],$_DECIMALS,',','.')."</td>"; break;
	  case 'discount' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['discount'],$_DECIMALS,',','.')."</td>"; break;
	  case 'cartage' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['cartage'],$_DECIMALS,',','.')."</td>"; break;
	  case 'packingcharges' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['packingcharges'],$_DECIMALS,',','.')."</td>"; break;
	  case 'collectioncharges' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['collectioncharges'],$_DECIMALS,',','.')."</td>"; break;
	  case 'agentcommiss' : echo "class='blue' align='right'><em>&euro;</em>".number_format($_TOTALS['agentcommiss'],$_DECIMALS,',','.')."</td>"; break;
	 }
	}
	?></tr>
</table>


	  <!-- END OF PAGE --------------------------------------------------------------------------->
	 </div>
	</td>
 </tr>
</table>

<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
/*-------------------------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------------------------*/
?>
<script>

var AP = "<?php echo $_AP; ?>";
var ON_PRINTING = false;
var ON_EXPORT = false;
var SUBJTYPE_NAME = "<?php echo $_SUBJTYPE_NAME; ?>";

var EMAIL_SUBJECT = "<?php echo $config['fatturepa']['emailsubject']; ?>";
var EMAIL_MSGAP = "<?php echo $config['fatturepa']['messageap']; ?>";
var EMAIL_MSGID = "<?php echo $config['fatturepa']['messageid']; ?>";

function comeBack()
{
 document.location.href = ABSOLUTE_URL+"<?php echo $template->config['basepath']; ?>index.php?ct=invoices";
}

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL;
	return false;
}

Template.OnInit = function(){
 /* AUTORESIZE */
 var sH = this.getScreenHeight();
 var tb = document.getElementById("template-outer-mask");
 if(tb.offsetHeight < (sH-115))
  tb.style.height = (sH-115)+"px";
 //if(document.getElementById('documentlist-container').offsetHeight < (sH-240))
  document.getElementById('documentlist-container').style.height = (sH-240)+"px";
 /* EOF - AUTORESIZE */

	this.initEd(document.getElementById('rpp'), "dropdown").onchange = function(){
		 Template.SERP.RPP = this.getValue();
		 Template.SERP.reload(0);
		}


	this.initEd(document.getElementById("search"), "contactextended").OnSearch = function(){
			 Template.SERP.setVar("refap","");
			 Template.SERP.setVar("refid",0);
			 if(this.value && this.data)
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",this.data['id']);
			 }
			 else
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",0);
			 }
			 Template.SERP.reload(0);
			};
	this.initBtn(document.getElementById("searchbtn")).onclick = function(){document.getElementById("search").OnSearch();}

	this.initBtn(document.getElementById('mainmenubutton'), 'popupmenu');
	this.initBtn(document.getElementById('viewmenubutton'), 'popupmenu');

	/*this.initEd(document.getElementById('show'), "dropdown").onchange = function(){
		 if(this.getValue() == "")
		  Template.SERP.unsetVar("status");
		 else
		  Template.SERP.setVar("status",this.getValue());
		 Template.SERP.reload(0);
		};*/


	this.initEd(document.getElementById("datefrom"), "date").OnDateChange = function(date){
		 Template.SERP.setVar("from",document.getElementById("datefrom").isodate);
		 Template.SERP.setVar("dtfilt","custom");
		};
	this.initEd(document.getElementById("dateto"), "date").OnDateChange = function(date){
		 Template.SERP.setVar("from",document.getElementById("datefrom").isodate);
		 Template.SERP.setVar("to",date);
		 Template.SERP.setVar("dtfilt","custom");
		 Template.SERP.reload();
		};

	this.initEd(document.getElementById('dtfilt'), 'dropdown').onchange = function(){
		 Template.SERP.setVar('dtfilt',this.getValue());
		 Template.SERP.reload();
		};

	this.SERP = new SERP("<?php echo $_SERP->OrderBy; ?>", "<?php echo $_SERP->OrderMethod; ?>", "<?php echo $_SERP->RPP; ?>", "<?php echo $_SERP->PG; ?>");
	var tb = this.initSortableTable(document.getElementById("documentlist"), this.SERP.OrderBy, this.SERP.OrderMethod);
	tb.OnSort = function(field, method){
		 //Template.SERP.OrderBy = field;
	     //Template.SERP.OrderMethod = method;
		 Template.SERP.reload(0);
		}
	tb.OnSelect = function(list){}

}


function showColumn(field,cb)
{
 var tb = document.getElementById("documentlist");
 if(cb.checked == true)
  tb.showColumn(field);
 else
  tb.hideColumn(field);

 switch(field)
 {
  case 'amount' : case 'vat' : case 'total' : case 'netpay' : case 'rebate' : case 'expenses' : case 'cartage' : case 'packingcharges' : case 'collectioncharges' : case 'agentcommiss' : case 'resttopay' : case 'enasarco' : case 'stamp' : case 'ritacconto' : case 'cassaprev' : case 'rivalsainps' : case 'totpaid' : showFooterColumn(field,cb.checked); break;
 }
}

function showFooterColumn(field, bool)
{
 document.getElementById("footer-"+field+"-title").style.display = bool ? "" : "none";
 document.getElementById("footer-"+field+"-value").style.display = bool ? "" : "none";
}

function ExportToExcel(btn)
{
 document.getElementById('mainmenubutton').popupmenu.hide();
 var cmd = "<?php echo $_CMD; ?>";
 cmd = cmd.replace("<![CDATA[",'"');
 cmd = cmd.replace("]]>",'"');

 var keys = "code_num,xml_file_name,doc_name,subject_code,subject_name,ctime,desc,amount,vat,total,netpay";

 var titles = "NR|NOME FILE XML|DOCUMENTO|COD. CLI|"+SUBJTYPE_NAME.toUpperCase()+"|DATA EMISSIONE|NOTE|IMPONIBILE|IVA|TOTALE|NETTO A PAGARE";

 var formats = "string|string|string|string|string|date|string|currency|currency|currency|currency";

 cmd+= " || tableize *.items";
 cmd+= " -k '"+keys+"'";
 cmd+= " -n '"+titles+"'";
 cmd+= " -f '"+formats+"'";
 cmd+= " --include-totals";


 var sh = new GShell();
 sh.showProcessMessage("Esportazione in Excel", "Attendere prego, è in corso l'esportazione del riepilogo su file Excel.");
 sh.OnError = function(err){this.processMessage.error(err);}
 sh.OnOutput = function(o,a){
	 this.hideProcessMessage();
	 if(!a) return;
	 var fileName = a['filename'];
	 document.location.href = ABSOLUTE_URL+"getfile.php?file="+fileName;
	}

 var finalCommand = "gframe -f excel/export -params `file=riepilogo_fatture_pa` -command `"+cmd+"`";

 sh.sendCommand(finalCommand);
}

function setFilter(filter)
{
 Template.SERP.setVar("filter",filter);
 Template.SERP.reload();
}


function saveGlobalSettings()
{
 var xml = "<"+ROOT_CT;
 var visibledColumns = "";
 var rpp = document.getElementById('rpp').getValue();

 var tb = document.getElementById("documentlist");
 for(var c=0; c < tb.fields.length; c++)
 {
  var th = tb.fields[c];
  if(th.style.display != "none")
   visibledColumns+= ","+th.getAttribute('field');
 }
 if(visibledColumns)
  xml+= " visibledcolumns='"+visibledColumns.substr(1)+"'";

 xml+= " rpp='"+rpp+"'";
 xml+= "/"+">";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){alert("Configurazione salvata");}
 sh.sendSudoCommand("aboutconfig set-config-val -app gcommercialdocs -sec fatturepadocumentlist -xml `"+xml+"`");
}

function HideLeftSection()
{
 document.getElementById("template-left-section").style.display = "none";
 var tlb = document.getElementById('template-left-bar');
 tlb.style.cursor = "pointer";
 tlb.title = "Mostra barra laterale";
 tlb.onclick = function(){ShowLeftSection();}
 Template.SERP.setVar("hideleftsection",'true');
}

function ShowLeftSection()
{
 document.getElementById("template-left-section").style.display = "";
 var tlb = document.getElementById('template-left-bar');
 tlb.style.cursor = "default";
 tlb.title = "";
 tlb.onclick = null;
 Template.SERP.unsetVar("hideleftsection");
}

function showFatturaPA(id)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){if(a) document.location.reload();}
 sh.sendCommand("gframe -f commercialdocs/fatturapa -params `id="+id+"`");
}

function sendEmail(id, subjId, xmlFileName)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 var sh2 = new GShell();
	 sh2.OnError = function(err){alert(err);}
	 sh2.OnOutput = function(){document.location.reload();}
	 sh2.sendCommand("dynarc edit-item -ap fatturepa -id '"+id+"' -extset `fatturapa.status='1'`");
	}
 sh.sendCommand("gframe -f sendmail -params `subjid="+subjId+"&attachment="+xmlFileName+"&msgap="+EMAIL_MSGAP+"&msgid="+EMAIL_MSGID+"&parser=fatturapa&id="+id+"&parsesubject=true` -t `"+EMAIL_SUBJECT+"`");
}

function DeleteSelected()
{
 var list = document.getElementById("documentlist").getSelectedRows();
 if(!list.length) return alert("Nessun documento selezionato");
 if(!confirm("Sei sicuro di voler eliminare le fatture elettroniche selezionate?")) return;

 var q = "";
 for(var c=0; c < list.length; c++)
  q+= " -id "+list[c].id;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){document.location.reload();}
 sh.sendCommand("dynarc delete-item -ap fatturepa -r"+q);
}
</script>
<?php
$template->End();

