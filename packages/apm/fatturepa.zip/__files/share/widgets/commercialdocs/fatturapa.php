<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2018 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 28-11-2018
#PACKAGE: fatturepa
#DESCRIPTION: 
#VERSION: 2.1beta
#CHANGELOG: 28-11-2018 : Aggiunto bottone test
#TODO: 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;
$_BASE_PATH = '../../../';

include($_BASE_PATH.'var/templates/glight/index.php');

$template = new GLightTemplate('widget');
$template->includeObject('gcal');
$template->includeObject('editsearch');

$_AP = "fatturepa";

if($_REQUEST['id'])
{
 $ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_REQUEST['id']."' -extget `fatturapa.docinfo`",$_REQUEST['sessid'], $_REQUEST['shellid']);
 if(!$ret['error'])
  $fattInfo = $ret['outarr'];
}

$template->Begin('Riepilogo fattura elettronica');
?>
<div class='glight-widget-header bg-blue'><h3>Riepilogo fattura elettronica</h3></div>
<?php
$template->Body('widget',480);

$_STATUS = array(
 0 => "Da inviare",
 1 => "Inviata",
 2 => "Notifica scarto",
 3 => "Mancata consegna",
 4 => "Ricevuta consegna",
 5 => "Decorrenza termini",
 6 => "Notifica esito",
 7 => "Notifica esito EC02",
 8 => "Senza esiti oltre RC",
);

/* GET CONFIG */
$ret = GShell("aboutconfig get-config -app gcommercialdocs -sec interface");
if(!$ret['error'])
 $config = $ret['outarr']['config'];


//-------------------------------------------------------------------------------------------------------------------//
?>
<div class='glight-widget-body' style='width:464px;height:360px'>
<table width='456' cellspacing='0' cellpadding='0' border='0' class='standardform'>
<tr><td width='300'><label>Cliente</label><br/>
		<input type='text' class='contact' id='subject' style='width:270px' refid="<?php echo $fattInfo['subject_id']; ?>" value="<?php echo $fattInfo['subject_name']; ?>"/></td>
    <td><label>Data emissione</label><br/>
		<input type='text' class='calendar' id='ctime' value="<?php echo date('d/m/Y',$fattInfo['ctime']); ?>"/></td>
</tr>

<tr class='separator'><td colspan='2'>&nbsp;</td></tr>

<tr><td><label>Documento</label><br/>
		 <?php
		 if($fattInfo['invoice_id'])
		  echo "<a href='".$_ABSOLUTE_URL."GCommercialDocs/docinfo.php?id=".$fattInfo['invoice_id']."' target='GCD-".$fattInfo['id']."'>"
			.$fattInfo['doc_name']."</a>";
		 ?>
		</td>
    <td><label>Status</label><br/>
		<input type='text' class='dropdown' id='status' connect='statuslist' style='width:150px' value="<?php echo $_STATUS[$fattInfo['status']]; ?>" retval="<?php echo $fattInfo['status']; ?>"/>
		<ul class='popupmenu' id='statuslist'>
		 <?php
		 reset($_STATUS);
		 while(list($k,$v) = each($_STATUS))
		  echo "<li value='".$k."'>".$v."</li>";
		 ?>
		</ul>		
	</td>
</tr>

<tr class='separator'><td colspan='2'>&nbsp;</td></tr>

<tr><td><label>File XML</label><br/>
	 <a href="<?php echo $_ABSOLUTE_URL; ?>getfile.php?file=<?php echo $fattInfo['xml_file_name']; ?>&basedir=share/fatturepa/" id='xmlfilename'><?php echo $fattInfo['xml_file_name']; ?></a>
	</td>
	<td><label>&nbsp;</label><br/>
	 <input type='button' class='button-blue' value="Scarica" onclick="downloadXMLFile('<?php echo $fattInfo['xml_file_name']; ?>')"/>
	 <input type='button' class='button-blue' value="Invia" onclick="SendMail('share/fatturepa/<?php echo $fattInfo['xml_file_name']; ?>')"/>
	</td></tr>

<tr class='separator'><td colspan='2'>&nbsp;</td></tr>

<tr><td colspan='2'><label>Descrizione</label><br/>
	<textarea class='textarea' style='width:100%;height:100px' id='description'><?php echo $fattInfo['desc']; ?></textarea>
	</td></tr>

<tr class='separator'><td colspan='2'>&nbsp;</td></tr>

<tr><td><span class="tinytext gray">Scarica il file XML ed esegui il test della fattura elettronica utilizzando lo strumento a disposizione dell&lsquo; Agenzia delle Entrate</span></td>
	<td align='center'><input type='button' class='button-blue' value="Esegui test" onclick="MakeTest('share/fatturepa/<?php echo $fattInfo['xml_file_name']; ?>')"/></td>
</tr>

</table>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$footer = "<input type='button' class='button-blue' value='Salva' style='float:left' onclick='SubmitAction()'/>";
$footer.= "<input type='button' class='button-gray' value='Chiudi' style='float:left;margin-left:10px' onclick='abort()'/>";
$footer.= "<input type='button' class='button-red' value='Elimina' style='float:right' onclick='DeleteAction()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";
var ID = "<?php echo $fattInfo['id']; ?>";
var SUBJID = "<?php echo $fattInfo['subject_id']; ?>";

var EMAIL_SUBJECT = "<?php echo $config['fatturepa']['emailsubject']; ?>";
var EMAIL_MSGAP = "<?php echo $config['fatturepa']['messageap']; ?>";
var EMAIL_MSGID = "<?php echo $config['fatturepa']['messageid']; ?>";

function abort(){Template.Exit();}

Template.OnInit = function(){

 this.initEd(document.getElementById('ctime'), "date");
 this.initEd(document.getElementById('status'), "dropdown");
 this.initEd(document.getElementById('subject'), "contact");
}

function downloadXMLFile(fileName)
{
 document.location.href = ABSOLUTE_URL+"getfile.php?file="+fileName+"&basedir=share/fatturepa/";
}

function SubmitAction()
{
 var status = document.getElementById('status').getValue();
 var ctime = document.getElementById('ctime').isodate;
 var description = document.getElementById('description').value;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){gframe_close(o,a);}
 sh.sendCommand("dynarc edit-item -ap '"+AP+"' -id '"+ID+"' -ctime `"+ctime+"` -desc `"+description+"` -extset `fatturapa.status='"+status+"'`");
}

function DeleteAction()
{
 if(!confirm("Sei sicuro di voler eliminare questa fattura elettronica?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){gframe_close(o,a);}
 sh.sendCommand("dynarc delete-item -ap '"+AP+"' -id '"+ID+"' -r");
}

function SendMail(filename)
{
 if(!filename)
  var filename = "share/fatturepa/"+document.getElementById('xmlfilename').innerHTML;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(a || o) 
	 {
	  document.getElementById('status').setValue("Inviata","1");
	  SubmitAction();
	 }
	}

 sh.sendCommand("gframe -f sendmail -params `subjid="+SUBJID+"&attachment="+filename+"&msgap="+EMAIL_MSGAP+"&msgid="+EMAIL_MSGID+"&parser=fatturapa&id="+ID+"&parsesubject=true` -t `"+EMAIL_SUBJECT+"`");
}

function MakeTest(filename)
{
 window.open("https://sdi.fatturapa.gov.it/SdI2FatturaPAWeb/AccediAlServizioAction.do?pagina=controlla_fattura", "_blank");
}
</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//
?>
