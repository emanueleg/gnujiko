<?php

header('Location:../../../');
