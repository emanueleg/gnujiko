<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new archive */
$_SHELL_OUT.= "Create new archive Fatture Elettroniche...";
$ret = GShell("dynarc new-archive -name `Fatture Elettroniche` -prefix 'fatturepa' -group 'commercialdocs' -perms '660' --def-cat-perms '660' --def-item-perms '660' --functions-file etc/dynarc/archive_funcs/__fatturepa/index.php",$_SESSION_ID,$_SHELL_ID);


/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension 'coding' -ap 'fatturepa'",$_SESSION_ID,$_SHELL_ID);

$_SHELL_OUT.= "Install extension fatturapa...";
$ret = GShell("dynarc install-extension 'fatturapa' -ap 'fatturepa'",$_SESSION_ID,$_SHELL_ID);