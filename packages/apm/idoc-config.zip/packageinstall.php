<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `idoc` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new archive */
$_SHELL_OUT.= "Create new archive Gnujiko Interactive Documents...";
$ret = GShell("dynarc new-archive -name `Gnujiko Interactive Documents` -prefix idoc -group `idoc` -type document --default-cat-perms 664 --default-item-perms 664 --hidden --functions-file etc/dynarc/archive_funcs/__idoc/index.php",$_SESSION_ID,$_SHELL_ID);
		
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_idoc_items` ADD `idocs` VARCHAR(255) NOT NULL, ADD `thumbdata` LONGTEXT NOT NULL, ADD `params` VARCHAR(255) NOT NULL");
$db->Close();


/* Installing extensions */
$_SHELL_OUT.= "Install extension javascript and css...";
GShell("dynarc install-extension idoc -ap idoc",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc install-extension javascript -ap idoc",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc install-extension css -ap idoc",$_SESSION_ID,$_SHELL_ID);

/* Insert into config menu */
GShell("system cfg-add-element -name `IDoc - Editor` -sec apps -perms 444 -icon /share/widgets/config/icons/idoc.png -file /share/widgets/config/apps/idoc.php",$_SESSION_ID, $_SHELL_ID);

