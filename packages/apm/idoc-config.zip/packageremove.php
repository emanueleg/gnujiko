<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Remove IDocs archive */
GShell("dynarc delete-archive -prefix idoc -r",$_SESSION_ID, $_SHELL_ID);

/* Remove from config menu */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_config_menu WHERE cfg_file='/share/widgets/config/apps/idoc.php'");
if($db->Read())
 GShell("system cfg-delete-element -id `".$db->record['id']."`",$_SESSION_ID, $_SHELL_ID);
$db->Close();
