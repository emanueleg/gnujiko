<?php

/* BUG FIX, installa l'estensione principale (idoc) sull'archivio idoc. */
GShell("dynarc install-extension idoc -ap idoc",$_SESSION_ID,$_SHELL_ID);
