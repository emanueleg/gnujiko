<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `rubrica` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Rubrica/'");
if($db->Read())
$db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Rubrica...";
 $ret = GShell("system register-app -name `Rubrica` -desc `Anagrafica clienti,fornitori,ecc...` -url 'Rubrica/' -icon 'Rubrica/icon.png' -group rubrica -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; }
 else $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new archive */
$_SHELL_OUT.= "Create new archive Rubrica...";
$ret = GShell("dynarc new-archive -name `Rubrica` -prefix rubrica -group `rubrica` -type document -launcher `gframe -f rubrica.edit -params 'id=%d'` --default-cat-perms 660 --default-item-perms 660",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];

GShell("dynarc enable-sharing-system -ap rubrica", $_SESSION_ID, $_SHELL_ID);

/* Installing extension */
$_SHELL_OUT.= "Install extension rubricainfo...";
$ret = GShell("dynarc install-extension rubricainfo -ap rubrica",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else $_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension contacts...";
$ret = GShell("dynarc install-extension contacts -ap rubrica",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else $_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension banks...";
$ret = GShell("dynarc install-extension banks -ap rubrica",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else $_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension references...";
$ret = GShell("dynarc install-extension references -ap rubrica",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else $_SHELL_OUT.= $ret['message'];

GShell("dynarc install-extension labels -ap rubrica",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc install-extension predefdiscount -ap rubrica",$_SESSION_ID,$_SHELL_ID);

/* Create new category */
$_SHELL_OUT.= "Create new category Clienti...";
$ret = GShell("dynarc new-cat -ap rubrica -name `Clienti` -tag customers -group `rubrica` -code C -perms 660 --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else $_SHELL_OUT.= $ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create new category Fornitori...";
$ret = GShell("dynarc new-cat -ap rubrica -name `Fornitori` -tag vendors -group `rubrica` -code V -perms 660 --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else $_SHELL_OUT.= $ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create new category Vettori...";
$ret = GShell("dynarc new-cat -ap rubrica -name `Vettori` -tag shippers -group `rubrica` -code T -perms 660 --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else  $_SHELL_OUT.= $ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create new category Riferimenti...";
$ret = GShell("dynarc new-cat -ap rubrica -name `Riferimenti` -tag referrers -group `rubrica` -code R -perms 660 --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else $_SHELL_OUT.= $ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create new category Agenti...";
$ret = GShell("dynarc new-cat -ap rubrica -name `Agenti` -tag agents -group `rubrica` -code A -perms 660 --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else $_SHELL_OUT.= $ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create new category Collaboratori...";
$ret = GShell("dynarc new-cat -ap rubrica -name `Collaboratori` -tag collaborators -group `rubrica` -code X -perms 660 --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } 
else $_SHELL_OUT.= $ret['message'];

/* PRINT MODELS */
GShell("dynarc new-cat -ap printmodels -name 'Rubrica' -tag rubrica -group rubrica --if-not-exists -perms 664",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc new-cat -ap printmodels -name 'Schede' -tag contactinfo -pt rubrica -group rubrica --if-not-exists -perms 664",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc import -f tmp/demo-contactinfo.xml -ap printmodels -ct contactinfo",$_SESSION_ID,$_SHELL_ID);