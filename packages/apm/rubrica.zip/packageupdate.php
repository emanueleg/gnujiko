<?php global $_BASE_PATH, $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

/* 31-01-2013 */
if(version_compare($_INSTALLED_VER,"2.34beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `distance` FLOAT NOT NULL");
 $db->Close();
}

/* 08-05-2013 : REFERENCES */
if(version_compare($_INSTALLED_VER,"2.35beta","<"))
{
 GShell("dynarc install-extension references -ap rubrica",$_SESSION_ID,$_SHELL_ID);
}

/* 09-09-2013 : Fidelity card */
if(version_compare($_INSTALLED_VER,"2.36beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `fidelitycard` VARCHAR(32) NOT NULL , ADD INDEX (`fidelitycard`)");
 $db->Close();
}

/* 05-11-2013 : Extra notes */
if(version_compare($_INSTALLED_VER,"2.37beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `extranotes` TEXT NOT NULL");
 $db->Close();
}

/* 13-12-2013 : Agent and login integration */
if(version_compare($_INSTALLED_VER,"2.38beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `agent_id` INT(11) NOT NULL , 
 ADD `user_id` INT(11) NOT NULL , 
 ADD `login` VARCHAR(32) NOT NULL , 
 ADD `password` VARCHAR(32) NOT NULL, 
 ADD INDEX (`agent_id`)");
 $db->Close();
}

/* 03-05-2014 : Nuova grafica */
if(version_compare($_INSTALLED_VER,"2.39beta","<"))
{
 GShell("dynarc install-extension labels -ap rubrica",$_SESSION_ID,$_SHELL_ID);
}

/* 26-05-2014 : Aggiunto banca d'appoggio */
if(version_compare($_INSTALLED_VER,"2.40beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `ourbanksupport_id` INT(11) NOT NULL");
 $db->Close();
}

/* 03-07-2014 : Aggiunto causali predefinite documenti, e codice su contatti. */
if(version_compare($_INSTALLED_VER,"2.41beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `gcdcausals` VARCHAR(255) NOT NULL");
 $db->Close();

 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_contacts` ADD `code` VARCHAR(32) NOT NULL");
 $db->Close();

 /* Sistema il gruppo ed i permessi */
 include_once($_BASE_PATH."include/userfunc.php");
 $gid = _getGID("rubrica");
 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE gnujiko_applications SET gid='".$gid."',_mod='640' WHERE url='Rubrica/'");
 $db->Close();
}

/* 29-09-2014 : Aggiunto punti fidelity card. */
if(version_compare($_INSTALLED_VER,"2.42beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `fidelitycard_points` FLOAT NOT NULL");
 $db->Close();
}

/* 15-10-2014 : Aggiunta email predefinita */
if(version_compare($_INSTALLED_VER,"2.43beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `default_email` VARCHAR(255) NOT NULL");
 $db->Close();
}

/* 24-10-2014 : Ridimensionato campi CAP a 8 caratteri e IBAN a 31 */
if(version_compare($_INSTALLED_VER,"2.44beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_contacts` CHANGE `zipcode` `zipcode` VARCHAR(8) NOT NULL");
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_banks` CHANGE `iban` `iban` VARCHAR(31) NOT NULL");
 $db->Close();

 /* PRINT MODELS */
 GShell("dynarc new-cat -ap printmodels -name 'Rubrica' -tag rubrica -group rubrica --if-not-exists -perms 664",$_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc cat-info -ap printmodels -tag contactinfo",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  GShell("dynarc new-cat -ap printmodels -name 'Schede' -tag contactinfo -pt rubrica -group rubrica --if-not-exists -perms 664",$_SESSION_ID, $_SHELL_ID);
  GShell("dynarc import -f tmp/demo-contactinfo.xml -ap printmodels -ct contactinfo",$_SESSION_ID,$_SHELL_ID);
 }
}

/* 19-01-2015 : Aggiunto bic/swift */
if(version_compare($_INSTALLED_VER,"2.45beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_banks` ADD `bic_swift` VARCHAR(11) NOT NULL");
 $db->Close();
}

/* 14-03-2015 : Aggiunto campo pa_code */
if(version_compare($_INSTALLED_VER,"2.46beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `pa_code` VARCHAR(6) NOT NULL");
 $db->Close();
}

/* 19-03-2015 : Aggiunto campo assist_avail_hours */
if(version_compare($_INSTALLED_VER,"2.47beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `assist_avail_hours` FLOAT NOT NULL");
 $db->Close();
}	 

/* 30-04-2016 : Aggiunto campo aliquota iva predefinita */
if(version_compare($_INSTALLED_VER,"2.49beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `vat_id` INT(11) NOT NULL");
 $db->Close();
}	 

/* 30-04-2016 : Aggiunta estensione predefdiscount */
if(version_compare($_INSTALLED_VER,"2.53beta","<"))
{
 GShell("dynarc install-extension predefdiscount -ap rubrica",$_SESSION_ID,$_SHELL_ID);
}	

/* 20-05-2017 : Enabled sharing system. */
if(version_compare($_INSTALLED_VER,"2.55beta","<"))
{
 GShell("dynarc enable-sharing-system -ap rubrica", $_SESSION_ID, $_SHELL_ID);
}	 

/* 08-07-2017 : Aggiunto campi note,floor e boxnum */
if(version_compare($_INSTALLED_VER,"2.57beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_contacts` ADD `note` VARCHAR(255) NOT NULL, ADD `boxnum` VARCHAR(32) NOT NULL, ADD `floor` VARCHAR(64) NOT NULL");
 $db->Close();
}	 

if(version_compare($_INSTALLED_VER,"2.60beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_items` CHANGE `pa_code` `pa_code` VARCHAR(7) NOT NULL");
 $db->Close();
}

// 09/11/2019 - Rev. 2.61beta
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_rubrica_items` ADD `vatnumber_pre` VARCHAR(3) NOT NULL AFTER `vatnumber`");
$db->Close();