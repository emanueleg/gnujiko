<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `packs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(32) NOT NULL,
  `ref_at` varchar(32) NOT NULL,
  `ref_ap` varchar(32) NOT NULL,
  `ref_cat` int(11) NOT NULL,
  `ref_id` int(11) NOT NULL,
  `ref_code` varchar(32) NOT NULL,
  `ref_name` varchar(64) NOT NULL,
  `id_code` varchar(32) NOT NULL,
  `pack_code` varchar(32) NOT NULL,
  `code` varchar(32) NOT NULL,
  `qty` int(4) NOT NULL,
  `available` int(4) NOT NULL,
  `load_datetime` datetime NOT NULL,
  `lot` varchar(32) NOT NULL,
  `doc_ref_ap` varchar(32) NOT NULL,
  `doc_ref_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `barcode` (`barcode`,`ref_at`,`ref_ap`,`ref_cat`,`ref_id`,`code`,`lot`,`vendor_id`)
)");

$db->RunQuery("CREATE TABLE IF NOT EXISTS `pack_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pack_id` int(11) NOT NULL,
  `ref_ap` varchar(32) NOT NULL,
  `ref_id` int(11) NOT NULL,
  `ref_name` varchar(64) NOT NULL,
  `barcode` varchar(32) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `download_datetime` datetime NOT NULL,
  `doc_ref_ap` varchar(32) NOT NULL,
  `doc_ref_id` int(11) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pack_id` (`pack_id`,`ref_ap`,`ref_id`,`barcode`,`status`)
)");

$db->Close();