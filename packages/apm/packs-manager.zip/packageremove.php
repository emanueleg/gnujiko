<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("DROP TABLE `packs`");
$db->RunQuery("DROP TABLE `pack_items`");
$db->Close();