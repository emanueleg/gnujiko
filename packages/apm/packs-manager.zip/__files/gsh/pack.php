<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: packs-manager
 #DESCRIPTION: Official Gnujiko Packs Manager.
 #VERSION: 2.1beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;
include_once($_BASE_PATH."include/userfunc.php");

function shell_pack($args, $sessid, $shellid=null)
{
 switch($args[0])
 {
  case 'new' : case 'add' : return pack_new($args, $sessid, $shellid); break;
  case 'edit' : return pack_edit($args, $sessid, $shellid); break;
  case 'delete' : return pack_delete($args, $sessid, $shellid); break;
  case 'info' : return pack_info($args, $sessid, $shellid); break;
  case 'list' : return pack_list($args, $sessid, $shellid); break;

  case 'add-item' : return pack_newItem($args, $sessid, $shellid); break;
  case 'edit-item' : return pack_editItem($args, $sessid, $shellid); break;
  case 'delete-item' : return pack_deleteItem($args, $sessid, $shellid); break;
  case 'item-info' : return pack_itemInfo($args, $sessid, $shellid); break;
  case 'item-list' : return pack_itemList($args, $sessid, $shellid); break;

  case 'generate-codes' : return pack_generateCodes($args, $sessid, $shellid); break;
  case 'fast-upload' : return pack_fastUpload($args, $sessid, $shellid); break;
  case 'download' : return pack_download($args, $sessid, $shellid); break;

  case 'search' : return pack_search($args, $sessid, $shellid); break;

  default : return pack_invalidArguments(); break;
 }

}
//-------------------------------------------------------------------------------------------------------------------//
function pack_invalidArguments()
{
 return array('message'=>"Invalid arguments",'error'=>"INVALID_ARGUMENTS");
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_new($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 $loadDateTime = date('Y-m-d H:i:s');

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-barcode' : {$barcode=$args[$c+1]; $c++;} break;
   case '-refap' : {$refAP=$args[$c+1]; $c++;} break;
   case '-refid' : {$refID=$args[$c+1]; $c++;} break;
   case '-refcode' : {$refCode=$args[$c+1]; $c++;} break;
   case '-refname' : {$refName=$args[$c+1]; $c++;} break;
   case '-idcode' : {$idCode=$args[$c+1]; $c++;} break;
   case '-pkgcode' : case '-packcode' : {$packCode=$args[$c+1]; $c++;} break;
   case '-code' : {$code=$args[$c+1]; $c++;} break;
   case '-qty' : {$qty=$args[$c+1]; $c++;} break;
   case '-ctime' : case '--load-datetime' : case '-loadtime' : {$loadDateTime=$args[$c+1]; $c++;} break;
   case '-lot' : {$lot=$args[$c+1]; $c++;} break;
   case '-docrefap' : case '-docap' : {$docRefAP=$args[$c+1]; $c++;} break;
   case '-docrefid' : case '-docid' : {$docRefID=$args[$c+1]; $c++;} break;
   case '-vendorid' : {$vendorId=$args[$c+1]; $c++;} break;

   case '--auto-generate-codes' : $autoGenerateCodes=true; break;
  }

 //if(!$barcode)  return array("message"=>"Error: You must specify the barcode.", "error"=>"INVALID_BARCODE");
 if(!$refAP)	return array("message"=>"Error: You must specify the archive type.", "error"=>"INVALID_ARCHIVETYPE");
 if(!$refID)	return array("message"=>"Error: You must specify the item id.", "error"=>"INVALID_REFID");
 if(!$code)
 {
  $code = $idCode.$packCode;
  if(!$code)	return array("message"=>"Error: You must specify the pack code.", "error"=>"INVALID_PACK_CODE");
 }
 
 // get archive type
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT archive_type FROM dynarc_archives WHERE tb_prefix='".$refAP."' AND trash='0'");
 if(!$db->Read())
 {
  $db->Close();
  return array("message"=>"Error: unable to detect the archive type. Archive ".$refAP." does not exists.", "error"=>"INVALID_ARCHIVE_TYPE");
 }
 else
  $refAT = $db->record['archive_type'];
 $db->Close();

 // get item info
 $ret = GShell("dynarc item-info -ap '".$refAP."' -id '".$refID."'",$sessid,$shellid);
 if($ret['error']) return $ret;
 $itemInfo = $ret['outarr'];
 $refCatId = $itemInfo['cat_id'];

 if(!$refName)	$refName = $itemInfo['name'];
 if(!$refCode)	$refCode = $itemInfo['code_str'];
 $available = $qty;
 

 $db = new AlpaDatabase();
 $qry = "INSERT INTO packs(barcode,ref_at,ref_ap,ref_cat,ref_id,ref_code,ref_name,id_code,pack_code,code,qty,available,load_datetime,lot,doc_ref_ap,doc_ref_id,vendor_id) VALUES('"
	.$barcode."','".$refAT."','".$refAP."','".$refCatId."','".$refID."','".$db->Purify($refCode)."','".$db->Purify($refName)."','"
	.$idCode."','".$packCode."','".$code."','".$qty."','".$available."','".$loadDateTime."','".$lot."','".$docRefAP."','".$docRefID."','".$vendorId."')";

 $db->RunQuery($qry);
 if($db->Error)
  return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");
 $id = $db->GetInsertId();
 $db->Close();

 $outArr = array('id'=>$id, 'barcode'=>$barcode, 'refat'=>$refAT, 'refap'=>$refAP, 'refid'=>$refID, 'refcat'=>$refCatId, 'refcode'=>$refCode,
	'refname'=>$refName, 'idcode'=>$idCode, 'packcode'=>$packCode, 'code'=>$code, 'qty'=>$qty, 'loadtime'=>$loadDateTime, 'lot'=>$lot, 
	'docrefap'=>$docRefAP, 'docrefid'=>$docRefID, 'vendor_id'=>$vendorId, 'vendor_name'=>$vendorName);

 $out.= "Pack has been created. ID=".$outArr['id'];

 if($autoGenerateCodes)
 {
  // get schemas
  $schemas = array();
  $ret = GShell("barcode get-schemas",$sessid,$shellid);
  if(!$ret['error']) $schemas = $ret['outarr']['list'];

  $zerofill = 0;
  $startnum = 0;

  for($c=0; $c < count($schemas); $c++)
  {
   $schema = $schemas[$c];
   if(($schema['at'] == $refAT) || ($schema['ap'] == $refAP))
   {
	for($i=0; $i < count($schema['chunks']); $i++)
	{
	 if(strtoupper($schema['chunks'][$i]['ref']) == "ITEM_SEQCODE")
	 {
	  $zerofill = $schema['chunks'][$i]['len'];
	  $startnum = $schema['chunks'][$i]['startnum'];
	  break;
	 }
	}
	break;
   }
  }

  $ret = GShell("pack generate-codes -pack '".$outArr['id']."' -from '".$startnum."' -qty '".$outArr['qty']."' -digit '".$zerofill."'",$sessid,$shellid,$outArr);
  if($ret['error']) return $ret;
 }

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_edit($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$id=$args[$c+1]; $c++;} break;
   case '-barcode' : {$barcode=$args[$c+1]; $c++;} break;
   case '-refcode' : {$refCode=$args[$c+1]; $c++;} break;
   case '-refname' : {$refName=$args[$c+1]; $c++;} break;
   case '-idcode' : {$idCode=$args[$c+1]; $c++;} break;
   case '-pkgcode' : case '-packcode' : {$packCode=$args[$c+1]; $c++;} break;
   case '-code' : {$code=$args[$c+1]; $c++;} break;
   case '-ctime' : case '--load-datetime' : case '-loadtime' : {$loadDateTime=$args[$c+1]; $c++;} break;
   case '-lot' : {$lot=$args[$c+1]; $c++;} break;
   case '-docrefap' : case '-docap' : {$docRefAP=$args[$c+1]; $c++;} break;
   case '-docrefid' : case '-docid' : {$docRefID=$args[$c+1]; $c++;} break;
   case '-vendorid' : {$vendorId=$args[$c+1]; $c++;} break;
  }

 if(!$id)
  return array("message"=>"You must specify the pack id.", "error"=>"INVALID_PACK_ID");

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM packs WHERE id='".$id."'");
 if(!$db->Read())
 {
  $db->Close();
  return array("message"=>"Pack #".$id." does not exists.", "error"=>"PACK_DOES_NOT_EXISTS");
 }
 $packInfo = array('id'=>$db->record['id'], 'barcode'=>$db->record['barcode'], 
	'refat'=>$db->record['ref_at'], 'refap'=>$db->record['ref_ap'], 'refcat'=>$db->record['ref_cat'], 'refid'=>$db->record['ref_id'],
	'refcode'=>$db->record['ref_code'], 'refname'=>$db->record['ref_name'], 'idcode'=>$db->record['id_code'], 'packcode'=>$db->record['pack_code'], 
	'code'=>$db->record['code'], 'qty'=>$db->record['qty'], 'available'=>$db->record['available'], 'loadtime'=>$db->record['load_datetime'],
	'lot'=>$db->record['lot'], 'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'vendor_id'=>$db->record['vendor_id']);

 $q = "";
 if($barcode){			$q.= ",barcode='".$barcode."'";					$packInfo['barcode'] = $barcode; }
 if($refCode){			$q.= ",ref_code='".$db->Purify($refCode)."'";	$packInfo['refcode'] = $refCode; } 
 if($refName){			$q.= ",ref_name='".$db->Purify($refName)."'";	$packInfo['refname'] = $refName; } 
 if(isset($idCode)){	$q.= ",id_code='".$idCode."'";					$packInfo['idcode'] = $idCode; }
 if(isset($packCode)){	$q.= ",pack_code='".$packCode."'";				$packInfo['packcode'] = $packCode; }
 if($code){				$q.= ",code='".$code."'";						$packInfo['code'] = $code; }
 if($loadDateTime){		$q.= ",load_datetime='".$loadDateTime."'";		$packInfo['loadtime'] = $loadDateTime; }
 if(isset($lot)){		$q.= ",lot='".$lot."'";							$packInfo['lot'] = $lot; }
 if(isset($docRefAP)){	$q.= ",doc_ref_ap='".$docRefAP."'";				$packInfo['docap'] = $docRefAP; }
 if(isset($docRefID)){	$q.= ",doc_ref_id='".$docRefID."'";				$packInfo['docid'] = $docRefID; }
 if(isset($vendorId)){	$q.= ",vendor_id='".$vendorId."'";				$packInfo['vendor_id'] = $vendorId; }

 if($q)
 {
  $db->RunQuery("UPDATE packs SET ".ltrim($q,",")." WHERE id='".$id."'");
  if($db->Error)
   return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");
  $out.= "Pack #".$id." has been updated.";
 }

 $db->Close();

 $outArr = $packInfo;

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_delete($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$id=$args[$c+1]; $c++;} break;
  }

 if(!$id)
  return array("message"=>"You must specify the pack id", "error"=>"INVALID_PACK_ID");

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM packs WHERE id='".$id."'");
 if(!$db->Read())
 {
  $db->Close();
  return array("message"=>"Pack #".$id." does not exists.", "error"=>"PACK_DOES_NOT_EXISTS");
 }

 // delete pack
 $db->RunQuery("DELETE FROM packs WHERE id='".$id."'");
 if($db->Error) return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");

 // delete items
 $db->RunQuery("DELETE FROM pack_items WHERE pack_id='".$id."'");
 if($db->Error) return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");

 $db->Close();

 $out.= "Pack #".$id." has been removed.";
 $outArr = array("id"=>$id, "removed"=>true);

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_info($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);
 $limit = 100;

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$id=$args[$c+1]; $c++;} break;
   case '-verbose' : case '--verbose' : $verbose=true; break;
   case '--get-item-list' : case '--get-items' : $getItemList=true; break;
   case '-limit' : {$limit=$args[$c+1]; $c++;} break;
  }

 if(!$id)
  return array("message"=>"You must specify the pack id", "error"=>"INVALID_PACK_ID");

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM packs WHERE id='".$id."'");
 if(!$db->Read())
 {
  $db->Close();
  return array("message"=>"Pack #".$id." does not exists.", "error"=>"PACK_DOES_NOT_EXISTS");
 }

 $outArr = array('id'=>$db->record['id'], 'barcode'=>$db->record['barcode'], 
	'refat'=>$db->record['ref_at'], 'refap'=>$db->record['ref_ap'], 'refcat'=>$db->record['ref_cat'], 'refid'=>$db->record['ref_id'],
	'refcode'=>$db->record['ref_code'], 'refname'=>$db->record['ref_name'], 'idcode'=>$db->record['id_code'], 'packcode'=>$db->record['pack_code'], 
	'code'=>$db->record['code'], 'qty'=>$db->record['qty'], 'available'=>$db->record['available'], 'loadtime'=>$db->record['load_datetime'],
	'lot'=>$db->record['lot'], 'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'vendor_id'=>$db->record['vendor_id']);

 $db->Close();

 if($verbose)
 {
  $out.= "ID: ".$outArr['id']."\n";
  $out.= "Barcode: ".$outArr['barcode']."\n";
  $out.= "Code: ".$outArr['code']."\n";
  $out.= "Cod. art.: ".$outArr['refcode']."\n";
  $out.= "Description: ".$outArr['refname']."\n";
  $out.= "Id code: ".$outArr['idcode']."\n";
  $out.= "Pack code: ".$outArr['packcode']."\n";
  $out.= "Qty: ".$outArr['qty']."\n";
  $out.= "Available: ".$outArr['available']."\n";
  $out.= "Load date: ".$outArr['loadtime']."\n";
  $out.= "Lot: ".$outArr['lot']."\n";
 }

 if($getItemList)
 {
  $outArr['items'] = array();
  if($verbose)
   $out.= "\nList of pack items:\n";

  $db = new AlpaDatabase();
  $db->RunQuery("SELECT * FROM pack_items WHERE pack_id='".$outArr['id']."' ORDER BY barcode ASC LIMIT ".$limit);
  while($db->Read())
  {
   $a = array('id'=>$db->record['id'], 'pack_id'=>$db->record['pack_id'], 
	'refap'=>$db->record['ref_ap'], 'refid'=>$db->record['ref_id'], 'refname'=>$db->record['ref_name'],
	'barcode'=>$db->record['barcode'], 'status'=>$db->record['status'], 'downloadtime'=>$db->record['download_datetime'],
	'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'note'=>$db->record['note']);
   $outArr['items'][] = $a;
   if($verbose)
    $out.= "#".$a['id']." - ".$a['barcode'].(strtotime($a['downloadtime']) ? " download at ".date('d/m/Y H:i',strtotime($a['downloadtime'])) : "")."\n";
  }
  $db->Close();
 }

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_list($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array('count'=>0, 'items'=>array());

 $sessInfo = sessionInfo($sessid);
 $limit = 10;
 $orderBy = "load_datetime DESC, id DESC";

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-at' : {$refAT=$args[$c+1]; $c++;} break;
   case '-ap' : {$refAP=$args[$c+1]; $c++;} break;
   case '-cat' : {$refCatId=$args[$c+1]; $c++;} break;
   case '-id' : case '-refid' : {$refID=$args[$c+1]; $c++;} break;
   case '-loadtime' : case '-load-date-time' : {$loadDateTime=$args[$c+1]; $c++;} break;

   case '-order-by' : case '--order-by' : {$orderBy=$args[$c+1]; $c++;} break;
   case '-limit' : {$limit=$args[$c+1]; $c++;} break;
   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 $qry = "";
 if(isset($refAT))			$qry.= " AND ref_at='".$refAT."'";
 if(isset($refAP))			$qry.= " AND ref_ap='".$refAP."'";
 if(isset($refCatId))		$qry.= " AND ref_cat='".$refCatId."'";
 if(isset($refID))			$qry.= " AND ref_id='".$refID."'";
 if($loadDateTime)
 {
  $from = date('Y-m-d',strtotime($loadDateTime))." 00:00:00";
  $to = date('Y-m-d H:i:s',strtotime("+1 day",strtotime($from)));
  $qry.= " AND (load_datetime >= '".$from."' AND load_datetime < '".$to."')";
 }

 if(!$qry) $qry = "1";
 else $qry = ltrim($qry, " AND ");

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT COUNT(*) FROM packs WHERE ".$qry);
 $db->Read();
 $outArr['count'] = $db->record[0];

 $db->RunQuery("SELECT * FROM packs WHERE ".$qry." ORDER BY ".$orderBy." LIMIT ".$limit);
 while($db->Read())
 {
  $a = array('id'=>$db->record['id'], 'barcode'=>$db->record['barcode'], 
	'refat'=>$db->record['ref_at'], 'refap'=>$db->record['ref_ap'], 'refcat'=>$db->record['ref_cat'], 'refid'=>$db->record['ref_id'],
	'refcode'=>$db->record['ref_code'], 'refname'=>$db->record['ref_name'], 'idcode'=>$db->record['id_code'], 'packcode'=>$db->record['pack_code'], 
	'code'=>$db->record['code'], 'qty'=>$db->record['qty'], 'available'=>$db->record['available'], 'loadtime'=>$db->record['load_datetime'],
	'lot'=>$db->record['lot'], 'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'vendor_id'=>$db->record['vendor_id']);
  $outArr['items'][] = $a;
  if($verbose)
  {
   $out.= $a['loadtime']." #".$a['id']." - ".$a['refname']." [".$a['code']."] X ".$a['qty']."\n";
  }
 }
 $db->Close();
 $out.= $outArr['count']." results found.";

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//--- I T E M S -----------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
function pack_newItem($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);
 $status = 1;

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-pack' : case '-packid' : {$packId=$args[$c+1]; $c++;} break;
   case '-barcode' : {$barcode=$args[$c+1]; $c++;} break;
   case '-status' : {$status=$args[$c+1]; $c++;} break;
   case '-downloadtime' : case '-download-date-time' : {$downloadDateTime=$args[$c+1]; $c++;} break;
   case '-docap' : case '-docrefap' : {$docRefAP=$args[$c+1]; $c++;} break;
   case '-docid' : case '-docrefid' : {$docRefID=$args[$c+1]; $c++;} break;
   case '-note' : case '-notes' : {$note=$args[$c+1]; $c++;} break;

   case '--update-pack-qty' : $updatePackQty=true; break;
  }

 if(!$packId)
  return array("message"=>"You must specify the pack id.", "error"=>"INVALID_PACK_ID");

 // get pack info
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM packs WHERE id='".$packId."'");
 if(!$db->Read())
 {
  $db->Close();
  return array("message"=>"Pack #".$packId." does not exists.", "error"=>"PACK_DOES_NOT_EXISTS");
 }
 $packInfo = array('id'=>$db->record['id'], 'barcode'=>$db->record['barcode'], 
	'refat'=>$db->record['ref_at'], 'refap'=>$db->record['ref_ap'], 'refcat'=>$db->record['ref_cat'], 'refid'=>$db->record['ref_id'],
	'refname'=>$db->record['ref_name'], 'idcode'=>$db->record['id_code'], 'packcode'=>$db->record['pack_code'], 
	'code'=>$db->record['code'], 'qty'=>$db->record['qty'], 'available'=>$db->record['available'], 'loadtime'=>$db->record['load_datetime'],
	'lot'=>$db->record['lot'], 'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'vendor_id'=>$db->record['vendor_id']);
 $db->Close();

 // insert item
 $db = new AlpaDatabase();
 $db->RunQuery("INSERT INTO pack_items(pack_id,ref_ap,ref_id,ref_name,barcode,status,download_datetime,doc_ref_ap,doc_ref_id,note) VALUES('"
	.$packId."','".$packInfo['refap']."','".$packInfo['refid']."','".$db->Purify($packInfo['refname'])."','"
	.$barcode."','".$status."','".$downloadDateTime."','".$docRefAP."','".$docRefID."','".$db->Purify($note)."')");
 if($db->Error) return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");
 $id = $db->GetInsertId();
 $db->Close();

 $outArr = array('id'=>$id, 'pack_id'=>$packId, 'refap'=>$packInfo['refap'], 'refid'=>$packInfo['refid'], 'refname'=>$packInfo['refname'],
	'barcode'=>$barcode, 'status'=>$status, 'downloadtime'=>$downloadDateTime, 'docap'=>$docRefAP, 'docid'=>$docRefID, 'note'=>$note);

 $out.= "New item has been created into pack #".$packId;

 if($updatePackQty)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("UPDATE packs SET qty='".($packInfo['qty']+1)."',available='".($packInfo['available']+1)."' WHERE id='".$packId."'");
  $db->Close();
 }

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_editItem($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$id=$args[$c+1]; $c++;} break;
   case '-barcode' : {$barcode=$args[$c+1]; $c++;} break;
   case '-status' : {$status=$args[$c+1]; $c++;} break;
   case '-downloadtime' : case '-download-date-time' : {$dlDateTime=$args[$c+1]; $c++;} break;
   case '-docap' : case '-docrefap' : {$docRefAP=$args[$c+1]; $c++;} break;
   case '-docid' : case '-docrefid' : {$docRefID=$args[$c+1]; $c++;} break;
   case '-note' : case '-notes' : {$note=$args[$c+1]; $c++;} break;
  }

 if(!$id)
  return array("message"=>"You must specify the item id.", "error"=>"INVALID_ITEM_ID");

 // get item info
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM pack_items WHERE id='".$id."'");
 if(!$db->Read())
 {
  $db->Close();
  return array("message"=>"Item #".$id." does not exists.", "error"=>"ITEM_DOES_NOT_EXISTS");
 }
 $itemInfo = array('id'=>$db->record['id'], 'pack_id'=>$db->record['pack_id'], 
	'refap'=>$db->record['ref_ap'], 'refid'=>$db->record['ref_id'], 'refname'=>$db->record['ref_name'],
	'barcode'=>$db->record['barcode'], 'status'=>$db->record['status'], 'downloadtime'=>$db->record['download_datetime'],
	'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'note'=>$db->record['note']);
 $db->Close();

 $db = new AlpaDatabase();
 $q = "";
 if($barcode){				$q.= ",barcode='".$barcode."'"; 				$itemInfo['barcode'] = $barcode; }
 if(isset($status)){		$q.= ",status='".$status."'";					$itemInfo['status'] = $status; }
 if(isset($dlDateTime)){	$q.= ",download_datetime='".$dlDateTime."'";	$itemInfo['downloadtime'] = $dlDateTime; }
 if(isset($docRefAP)){		$q.= ",doc_ref_ap='".$docRefAP."'";				$itemInfo['docap'] = $docRefAP; }
 if(isset($docRefID)){		$q.= ",doc_ref_id='".$docRefID."'";				$itemInfo['docid'] = $docRefID; }
 if(isset($note)){			$q.= ",note='".$db->Purify($note)."'";			$itemInfo['note'] = $note; }

 if($q)
 {
  $db->RunQuery("UPDATE pack_items SET ".ltrim($q,",")." WHERE id='".$id."'");
  if($db->Error) return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");
  $out.= "Item #".$id." has been updated.";
 }

 $db->Close();

 $outArr = $itemInfo;

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_deleteItem($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$id=$args[$c+1]; $c++;} break;
  }

 if(!$id)
  return array("message"=>"You must specify the item id.", "error"=>"INVALID_ITEM_ID");

 // get item info
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM pack_items WHERE id='".$id."'");
 if(!$db->Read())
 {
  $db->Close();
  return array("message"=>"Item #".$id." does not exists.", "error"=>"ITEM_DOES_NOT_EXISTS");
 }
 else
  $packId = $db->record['pack_id'];
 $db->Close();

 // delete item
 $db = new AlpaDatabase();
 $db->RunQuery("DELETE FROM pack_items WHERE id='".$id."'");
 if($db->Error) return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");
 $out.= "Item #".$id." has been removed.\n";

 // update pack count
 $db->RunQuery("UPDATE packs SET qty=qty-1,available=available-1 WHERE id='".$packId."'");
 if($db->Error) return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");
 $out.= "Pack #".$packId." qty has been updated.\n";

 $db->Close();

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_itemInfo($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$id=$args[$c+1]; $c++;} break;
   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 if(!$id)
  return array("message"=>"You must specify the item id.", "error"=>"INVALID_ITEM_ID");

 // get item info
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM pack_items WHERE id='".$id."'");
 if(!$db->Read())
 {
  $db->Close();
  return array("message"=>"Item #".$id." does not exists.", "error"=>"ITEM_DOES_NOT_EXISTS");
 }
 $outArr = array('id'=>$db->record['id'], 'pack_id'=>$db->record['pack_id'], 
	'refap'=>$db->record['ref_ap'], 'refid'=>$db->record['ref_id'], 'refname'=>$db->record['ref_name'],
	'barcode'=>$db->record['barcode'], 'status'=>$db->record['status'], 'downloadtime'=>$db->record['download_datetime'],
	'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'note'=>$db->record['note']);
 $db->Close();

 if($verbose)
 {
  $out.= "ID: ".$outArr['id']."\n";
  $out.= "Pack ID: ".$outArr['pack_id']."\n";
  $out.= "Name: ".$outArr['refname']."\n";
  $out.= "Barcode: ".$outArr['barcode']."\n";
 }

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_itemList($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array('count'=>0, 'items'=>array());

 $sessInfo = sessionInfo($sessid);
 $limit = 100;
 $orderBy = "barcode ASC";

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-pack' : case '-packid' : {$packId=$args[$c+1]; $c++;} break;
   case '--order-by' : case '-orderby' : {$orderBy=$args[$c+1]; $c++;} break;
   case '-limit' : {$limit=$args[$c+1]; $c++;} break;

   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 if(!$packId)
  return array("message"=>"You must specify the pack id.", "error"=>"INVALID_PACK_ID");

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT COUNT(*) FROM pack_items WHERE pack_id='".$packId."'");
 $db->Read();
 $outArr['count'] = $db->record[0];

 $db->RunQuery("SELECT * FROM pack_items WHERE pack_id='".$packId."' ORDER BY ".$orderBy." LIMIT ".$limit);
 while($db->Read())
 {
  $a = array('id'=>$db->record['id'], 'pack_id'=>$db->record['pack_id'], 
	'refap'=>$db->record['ref_ap'], 'refid'=>$db->record['ref_id'], 'refname'=>$db->record['ref_name'],
	'barcode'=>$db->record['barcode'], 'status'=>$db->record['status'], 'downloadtime'=>$db->record['download_datetime'],
	'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'note'=>$db->record['note']);
  $outArr['items'][] = $a;
  if($verbose)
  {
   $out.= "#".$a['id']." - ".$a['refname']." [".$a['barcode']."]\n";
  }
 }
 $db->Close();
 $out.= $outArr['count']." items found.";

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
function pack_generateCodes($args, $sessid, $shellid, $extraVar=null)
{
 global $_BASE_PATH;

 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-pack' : case '-packid' : {$packId=$args[$c+1]; $c++;} break;
   case '-from' : case '-start' : {$from=$args[$c+1]; $c++;} break;
   case '-to' : case '-end' : {$to=$args[$c+1]; $c++;} break;
   case '-length' : case '-qty' : {$qty=$args[$c+1]; $c++;} break;
   case '-digit' : case '-zerofill' : {$zerofill=$args[$c+1]; $c++;} break;

   case '--verbose' : $verbose=true; break;
  }

 if(!$packId) return array("message"=>"You must specify the pack id.", "error"=>"INVALID_PACK_ID");
 if($extraVar)
  $packInfo = $extraVar;
 else 
 {// get pack info //
  $ret = GShell("pack info -id '".$packId."'",$sessid,$shellid);
  if($ret['error']) return $ret;
  $packInfo = $ret['outarr'];
 }

 if(!$to && $qty) $to = $from+$qty;
 else if($to) $to = $to+1; 
 if(!$to) return array("message"=>"Unable to generate code from pack #".$packId.". You have not specified the quantity of codes to be generated.", "error"=>"INVALID_QTY");

 $db = new AlpaDatabase();
 for($c=$from; $c < $to; $c++)
 {
  if($zerofill)
   $code = str_pad($c, $zerofill, '0', STR_PAD_LEFT);
  else
   $code = $c;

  $barcode = $packInfo['code'].$code;	/* TODO: da verificare */
  $status = 1;
  $db->RunQuery("INSERT INTO pack_items(pack_id,ref_ap,ref_id,ref_name,barcode,status) VALUES('"
	.$packId."','".$packInfo['refap']."','".$packInfo['refid']."','".$db->Purify($packInfo['refname'])."','"
	.$barcode."','".$status."')");
  if($db->Error) return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");
  $id = $db->GetInsertId();
 
  $outArr[] = array('id'=>$id, 'pack_id'=>$packId, 'refap'=>$packInfo['refap'], 'refid'=>$packInfo['refid'], 'refname'=>$packInfo['refname'],
	'barcode'=>$barcode, 'status'=>$status);

  if($verbose)
   $out.= "New item has been created into pack #".$packId;
 }
 $db->Close();

 $out.= count($outArr)." codes has been generated!";

 return array("message"=>$out, "outarr"=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_fastUpload($args, $sessid, $shellid)
{
 global $_BASE_PATH;

 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-xml' : {$xmlContent=$args[$c+1]; $c++;} break;
  }

 include_once($_BASE_PATH."var/lib/xmllib.php");
 $xml = new GXML();
 if(!$xml->LoadFromString("<xml>".$xmlContent."</xml>"))
  return array("message"=>"PACK FastUpload error: XML parse failed.", "error"=>"XML_PARSE_FAILED");
 $nodes = $xml->GetElementsByTagName('item');
 for($c=0; $c < count($nodes); $c++)
 {
  $node = $nodes[$c];
  $ap = $node->getString('ap');
  $id = $node->getString('id');
  $date = $node->getString('date');
  $barcode = $node->getString('barcode');
  $idCode = $node->getString('idcode');
  $pkgCode = $node->getString('pkgcode');
  $qty = $node->getInt('qty');
  $location = $node->getString('location');

  $ret = GShell("pack new -barcode '".$barcode."' -refap '".$ap."' -refid '".$id."' -idcode '".$idCode."' -pkgcode '"
	.$pkgCode."' -qty '".$qty."' -ctime '".$date."' --auto-generate-codes",$sessid,$shellid);
  if($ret['error']) return $ret;

  $outArr[] = $ret['outarr'];
 }

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_download($args, $sessid, $shellid)
{
 global $_BASE_PATH;

 $out = "";
 $outArr = array();
 $sessInfo = sessionInfo($sessid);
 $ctime = date('Y-m-d H:i:s');

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-pack' : case '-packid' : {$packId=$args[$c+1]; $c++;} break;
   case '-id' : case '-itemid' : {$id=$args[$c+1]; $c++;} break;
   case '-docap' : {$docAP=$args[$c+1]; $c++;} break;
   case '-docid' : {$docID=$args[$c+1]; $c++;} break;
   case '-ctime' : {$ctime=$args[$c+1]; $c++;} break;
  }

 if(!$id)
  return array("message"=>"You must specify the item ID", "error"=>"INVALID_ITEM_ID");

 if(!$packId)
 { // get pack id
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT pack_id FROM pack_items WHERE id='".$id."'");
  if(!$db->Read())
   return array("message"=>"Item #".$id." does not exists.", "error"=>"ITEM_DOES_NOT_EXISTS");
  $packId = $db->record['pack_id'];
  $db->Close();
 }

 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE pack_items SET status='0',download_datetime='".$ctime."',doc_ref_ap='".$docAP."',doc_ref_id='"
	.$docID."' WHERE id='".$id."'");
 if($db->Error) return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");
 $db->RunQuery("UPDATE packs SET available=available-1 WHERE id='".$packId."'");
 if($db->Error) return array("message"=>"MySQL error: ".$db->Error, "error"=>"MYSQL_ERROR");
 $db->Close();

 $out.= "done. Item #".$id." has been downloaded from the pack #".$packId;

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function pack_search($args, $sessid, $shellid)
{
 global $_BASE_PATH;

 $out = "";
 $outArr = array('result'=>null, 'similar'=>array());

 $sessInfo = sessionInfo($sessid);
 $barcodeQry = "";
 $pkgBarcodeQry = "";
 $orderBy = "id ASC";
 $limit = 25;

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-barcode' : {$barcodeQry=$args[$c+1]; $c++;} break;
   case '-pkgbarcode' : {$pkgBarcodeQry=$args[$c+1]; $c++;} break;

   case '--no-similar' : $noSimilar=true; break;
   case '--order-by' : case '-orderby' : {$orderBy=$args[$c+1]; $c++;} break;
   case '-limit' : {$limit=$args[$c+1]; $c++;} break;
   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 if(!$barcodeQry && !$pkgBarcodeQry)
  return array("message"=>"You must specify the barcode or pack-barcode.", "error"=>"INVALID_QUERY");

 /* MAKE QUERY */

 if($barcodeQry)
 {
  /* SEARCH FOR ITEM */
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT * FROM pack_items WHERE barcode='".$db->Purify($barcodeQry)."'");
  if($db->Read())
   $outArr['result'] = array('id'=>$db->record['id'], 'pack_id'=>$db->record['pack_id'], 
	'refap'=>$db->record['ref_ap'], 'refid'=>$db->record['ref_id'], 'refname'=>$db->record['ref_name'],
	'barcode'=>$db->record['barcode'], 'fullbarcode'=>$barcodeQry, 'status'=>$db->record['status'], 
	'downloadtime'=>$db->record['download_datetime'], 'docap'=>$db->record['doc_ref_ap'],
	'docid'=>$db->record['doc_ref_id']);
  else
  {
   $db->Close();
   $schemas = array();
   $ret = GShell("barcode get-schemas",$sessid,$shellid);
   if(!$ret['error']) $schemas = $ret['outarr']['list'];
   $db = new AlpaDatabase();
   for($c=0; $c < count($schemas); $c++)
   {
    $schema = $schemas[$c];
	if($schema['minlen'] && (strlen($barcodeQry) < $schema['minlen']))
	 continue;
	if($schema['maxlen'] && (strlen($barcodeQry) > $schema['maxlen']))
	 continue;
	if($schema['fixedlen'] && (strlen($barcodeQry) != $schema['fixedlen']))
	 continue;
    $query = ($schema['signlen'] < strlen($barcodeQry)) ? substr($barcodeQry,0,$schema['signlen']) : $barcodeQry;
	$db->RunQuery("SELECT * FROM pack_items WHERE barcode='".$db->Purify($query)."'");
    if($db->Read())
	{
     $outArr['result'] = array('id'=>$db->record['id'], 'pack_id'=>$db->record['pack_id'], 
		'refap'=>$db->record['ref_ap'], 'refid'=>$db->record['ref_id'], 'refname'=>$db->record['ref_name'],
		'barcode'=>$db->record['barcode'], 'fullbarcode'=>$barcodeQry, 'status'=>$db->record['status'], 
		'downloadtime'=>$db->record['download_datetime'], 'docap'=>$db->record['doc_ref_ap'],
		'docid'=>$db->record['doc_ref_id']);
	 break;
	}
   }
  }
  $db->Close();

  if(!$outArr['result'] && !$noSimilar)
  { // check similar
   $db = new AlpaDatabase();
   $db->RunQuery("SELECT * FROM pack_items WHERE barcode LIKE '".$db->Purify($barcodeQry)."%' ORDER BY ".$orderBy." LIMIT ".$limit);
   while($db->Read())
   {
	$outArr['similar'][] = array('id'=>$db->record['id'], 'pack_id'=>$db->record['pack_id'], 
	'refap'=>$db->record['ref_ap'], 'refid'=>$db->record['ref_id'], 'refname'=>$db->record['ref_name'],
	'barcode'=>$db->record['barcode'], 'status'=>$db->record['status'], 
	'downloadtime'=>$db->record['download_datetime'], 'docap'=>$db->record['doc_ref_ap'],
	'docid'=>$db->record['doc_ref_id']);
   }
   $db->Close();
  }

  if($verbose)
  {
   if(!$outArr['result'])
   {
	$out.= "No item found with barcode '".$barcodeQry."'\n";
    if(count($outArr['similar']))
	{
	 $out.= "List of similar:\n";
	 for($c=0; $c < count($outArr['similar']); $c++)
	 {
	  $a = $outArr['similar'][$c];
	  $out.= "#".$a['id']." - ".$a['barcode']." - ".$a['refname']."\n";
	 }
	}
   }
   else
   {
	$a = $outArr['result'];
	$out.= "#".$a['id']." - ".$a['barcode']." - ".$a['refname']."\n";
   }
  }
 }
 else if($pkgBarcodeQry)
 {
  /* SEARCH FOR PACK */
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT * FROM packs WHERE barcode='".$db->Purify($pkgBarcodeQry)."'");
  if($db->Read())
   $outArr['result'] = array('id'=>$db->record['id'], 'barcode'=>$db->record['barcode'], 
	'refat'=>$db->record['ref_at'], 'refap'=>$db->record['ref_ap'], 'refcat'=>$db->record['ref_cat'], 'refid'=>$db->record['ref_id'],
	'refcode'=>$db->record['ref_code'], 'refname'=>$db->record['ref_name'], 'idcode'=>$db->record['id_code'], 'packcode'=>$db->record['pack_code'], 
	'code'=>$db->record['code'], 'qty'=>$db->record['qty'], 'available'=>$db->record['available'], 'loadtime'=>$db->record['load_datetime'],
	'lot'=>$db->record['lot'], 'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'vendor_id'=>$db->record['vendor_id']);
  else if(!$noSimilar)
  { // check similar
   $db->RunQuery("SELECT * FROM packs WHERE barcode LIKE '".$db->Purify($pkgBarcodeQry)."%' ORDER BY ".$orderBy." LIMIT ".$limit);
   while($db->Read())
   {
	$outArr['similar'][] = array('id'=>$db->record['id'], 'barcode'=>$db->record['barcode'], 
	'refat'=>$db->record['ref_at'], 'refap'=>$db->record['ref_ap'], 'refcat'=>$db->record['ref_cat'], 'refid'=>$db->record['ref_id'],
	'refcode'=>$db->record['ref_code'], 'refname'=>$db->record['ref_name'], 'idcode'=>$db->record['id_code'], 'packcode'=>$db->record['pack_code'], 
	'code'=>$db->record['code'], 'qty'=>$db->record['qty'], 'available'=>$db->record['available'], 'loadtime'=>$db->record['load_datetime'],
	'lot'=>$db->record['lot'], 'docap'=>$db->record['doc_ref_ap'], 'docid'=>$db->record['doc_ref_id'], 'vendor_id'=>$db->record['vendor_id']);
   }
  }
  $db->Close();

  if($verbose)
  {
   if(!$outArr['result'])
   {
	$out.= "No pack found with barcode '".$pkgBarcodeQry."'\n";
    if(count($outArr['similar']))
	{
	 $out.= "List of similar:\n";
	 for($c=0; $c < count($outArr['similar']); $c++)
	 {
	  $a = $outArr['similar'][$c];
	  $out.= "#".$a['id']." - ".$a['barcode']." - ".$a['refname']."\n";
	 }
	}
   }
   else
   {
	$a = $outArr['result'];
	$out.= "#".$a['id']." - ".$a['barcode']." - ".$a['refname']."\n";
   }
  }
 }
 

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
?>


