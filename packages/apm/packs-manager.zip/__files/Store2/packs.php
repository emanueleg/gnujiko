<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 17-02-2015
 #PACKAGE: packs-manager
 #DESCRIPTION: Gestione pacchi.
 #VERSION: 2.1beta
 #CHANGELOG: 17-02-2015 : Aggiunto menu configurazione avanzata.
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS;

$_BASE_PATH = "../";
$_RESTRICTED_ACCESS = "gstore";

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate();
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeInternalObject("serp");
$template->includeInternalObject("productsearch");

$template->Begin("Gestione pacchi");

$centerContents = "<input type='text' class='edit' style='width:390px;float:left' placeholder='cerca un articolo' id='search' value=\""
	.htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\" ap='' at='' emptyonclick='true'/>";
$centerContents.= "<input type='button' class='button-search' id='searchbtn'/>";

$template->Header("search", $centerContents, "BTN_EXIT", 800);

$_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "load_datetime";
$_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "DESC";
$_RPP = $_REQUEST['rpp'] ? $_REQUEST['rpp'] : 10;
$_PG = $_REQUEST['pg'] ? $_REQUEST['pg'] : 1;

$_SERP = new SERP();
$_SERP->setOrderBy($_ORDER_BY);
$_SERP->setOrderMethod($_ORDER_METHOD);
$_SERP->setResultsPerPage($_RPP);
$_SERP->setCurrentPage($_PG);


$cmd = "pack list";

$_CMD = $cmd;
$ret = $_SERP->SendCommand($cmd);
$list = $ret['items'];

$ret = GShell("store list");
$storelist = $ret['outarr'];
if($_REQUEST['storeid'])
{
 for($c=0; $c < count($storelist); $c++)
 {
  if($storelist[$c]['id'] == $_REQUEST['storeid'])
  {
   $storeInfo = $storelist[$c];
   break;
  }
 }
}

$template->SubHeaderBegin(20);
?>
 <input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='menubutton' style="float:left"/>
 <img src="img/manual-load-btn.png" style="float:left;margin-left:15px;margin-top:1px;cursor:pointer" title="Carico pacchi manuale" onclick="ManualUpload()"/>
 <!--<img src="img/manual-download-btn.png" style="float:left;margin-left:5px;margin-top:1px;cursor:pointer" title="Scarico pacchi manuale" onclick="ManualDownload()"/>
 <img src="img/manual-move-btn.png" style="float:left;margin-left:5px;margin-top:1px;cursor:pointer" title="Movimenta pacchi" onclick="ManualTransfer()"/> -->
 <ul class='popupmenu' id='mainmenu'>
  <li onclick="ManualUpload()"><img src="img/upload.png" height="16"/>Carica pacchi magazzino</li>
  <!--<li onclick="ManualDownload()"><img src="img/download.png" height="16"/>Scarica pacchi dal magazzino</li>
  <li onclick="ManualTransfer()"><img src="img/transfer.png" height="16"/>Movimenta pacchi a magazzino</li>
  <li class='separator'>&nbsp;</li>
  <li onclick="EditStock()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/pencil.gif" height="16"/>Modifica giacenze articoli selezionati</li>
  <li class='separator'>&nbsp;</li>
  <li onclick="ExportToExcel(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Salva su Excel</li>
  <li onclick="Print(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/printer.gif"/>Stampa</li> -->
  <li class='separator'>&nbsp;</li>
  <li onclick="gotoAboutConfig()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/cog.gif"/>Configurazione avanzata</li>
 </ul>
 </td>
 <td width='200'>
  <input type='button' class="button-blue menuwhite" value="<?php echo $storeInfo ? $storeInfo['name'] : 'Tutti gli articoli'; ?>" connect='storeselmenu' id='storeselbutton'/>
		<ul class='popupmenu' id='storeselmenu'>
		<?php
		for($c=0; $c < count($storelist); $c++)
		 echo "<li onclick='selectStore(".$storelist[$c]['id'].",this)'><img src='img/storeicon.png'/>".$storelist[$c]['name']."</li>";
		if(count($storelist))
		 echo "<li class='separator'>&nbsp;</li>";
		echo "<li onclick='selectStore(0,this)'><img src='img/allstores.png'/>Tutti gli articoli</li>";
		?>
		</ul></td>
 <td width='400'>
	<!--<span class='smalltext'>Filtra per catalogo: </span>
	<input type='text' class='dropdown' id='catalog' value="<?php echo $archiveInfo ? $archiveInfo['name'] : ''; ?>" at="<?php echo $_AT; ?>" ap="<?php echo $archiveInfo ? $archiveInfo['prefix'] : ''; ?>" style="width:150px"/> -->
	&nbsp;&nbsp;
	<span class='smalltext'>Mostra</span>
	<input type='text' class='dropdown' id='rpp' value="<?php echo $_RPP; ?> righe" retval="<?php echo $_RPP; ?>" readonly='true' connect='rpplist' style='width:80px'/>
	<ul class='popupmenu' id='rpplist'>
	 <li value='10'>10 righe</li>
	 <li value='25'>25 righe</li>
	 <li value='50'>50 righe</li>
	 <li value='100'>100 righe</li>
	 <li value='250'>250 righe</li>
	 <li value='500'>500 righe</li>
	</ul>
 </td>
 <td>
	<?php $_SERP->DrawSerpButtons(true);
 
//---------------------------------------------//
$template->SubHeaderEnd();

$template->Body("default", 800);
?>
<table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='productlist'>
<tr><th width='16'><input type='checkbox'/></th>
	<th width='70' sortable='true' field='loadtime'>Data carico</th>
	<th width='70' sortable='true' field='refcode'>Cod. art.</th>
	<th sortable='true' field='refname'>Descrizione articolo</th>
	<th width='80' sortable='true' field='packcode' style='text-align:center'>Cod. pacco</th>
	<th width='70' sortable='true' field='qty' style='text-align:center'>Qt&agrave;</th>
	<th width='70' sortable='true' field='available' style='text-align:center'>Disp.</th>
</tr>
<?php
for($c=0; $c < count($list); $c++)
{
 $item = $list[$c];
 echo "<tr id='".$item['id']."'><td><input type='checkbox'/></td>";
 echo "<td><span class='link blue' onclick='showPackInfo(".$item['id'].")'>".date('d/m/Y',strtotime($item['loadtime']))."</span></td>";
 echo "<td><span class='link blue' onclick='showPackInfo(".$item['id'].")'>".$item['refcode']."</span></td>";
 echo "<td><span class='link blue' onclick='showPackInfo(".$item['id'].")'>".$item['refname']."</span></td>";
 echo "<td align='center'>".$item['packcode']."</td>";
 echo "<td align='center'>".$item['qty']."</td>";
 echo "<td align='center'>".$item['available']."</td></tr>";
}
?>
</table>
<?php

?>
<!--<div class="totals-footer">
 <table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr><td rowspan='2' valign='middle'><input type='button' class='button-blue' value='Stampa' onclick="Print(this)"/></td>
	  <td align='center'><span class='smalltext'>prod. esauriti</span></td>
	  <td align='center'><span class='smalltext'>in esaurimento</span></td>
	  <td align='right'><span class='smalltext'>Valore <?php echo $storeInfo ? "magazzino" : "magazzini"; ?></span></td></tr>
  <tr><td align='center'><span class='smalltext'><?php echo $soldoutCount; ?></span></td>
	  <td align='center'><span class='smalltext'><?php echo $underminstockCount; ?></span></td>
	  <td align='right'><span class='bigtext'><b><?php echo number_format($storeInfo ? $selstoreStockValue : $stockValue,2,',','.'); ?> &euro;</b></span></td></tr>
 </table>
</div> -->

<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
?>
<script>
var selectedStoreId = <?php echo $storeInfo ? $storeInfo['id'] : '0'; ?>;
var selectedStoreName = "<?php echo $storeInfo ? $storeInfo['name'] : ''; ?>";

var ON_PRINTING = false;
var ON_EXPORT = false;

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL;
	return false;
}

function gotoAboutConfig()
{
 window.open(ABSOLUTE_URL+"aboutconfig/store/");
}

Template.OnInit = function(){
	this.initBtn(document.getElementById('menubutton'), "popupmenu");
	this.initBtn(document.getElementById('storeselbutton'), "popupmenu");
	this.initEd(document.getElementById('rpp'), "dropdown").onchange = function(){
		 Template.SERP.RPP = this.getValue();
		 Template.SERP.reload(0);
		}

	/*this.initEd(document.getElementById("search"), AT).OnSearch = function(){
		 if(this.value && this.data)
		 {
		  Template.SERP.setVar("search",this.value);
		  Template.SERP.setVar("prodid",this.data['id']);
		  Template.SERP.setVar("ap",this.data['ap']);
		  Template.SERP.reload(0);
		 }
		 else
		 {
		  Template.SERP.setVar("search",this.value);
		  Template.SERP.unsetVar("prodid");
		  Template.SERP.reload(0);
		 }
		};
	this.initBtn(document.getElementById("searchbtn")).onclick = function(){document.getElementById("search").OnSearch();}*/

	this.SERP = new SERP("<?php echo $_SERP->OrderBy; ?>", "<?php echo $_SERP->OrderMethod; ?>", "<?php echo $_SERP->RPP; ?>", "<?php echo $_SERP->PG; ?>");
	this.initSortableTable(document.getElementById("productlist"), this.SERP.OrderBy, this.SERP.OrderMethod).OnSort = function(field, method){
		Template.SERP.OrderBy = field;
	    Template.SERP.OrderMethod = method;
		Template.SERP.reload(0);
	}
}

function showPackInfo(id)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 document.location.reload();
	}

 sh.sendCommand("gframe -f gstore/pack.info -params `id="+id+"`");
}

/*function showItemInfo(ap,id)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(a)
	  document.location.reload();
	}
 switch(AT)
 {
  case 'gmart' : sh.sendCommand("gframe -f gmart/edit.item -params 'ap="+ap+"&id="+id+"'"); break;
  case 'gproducts' : sh.sendCommand("gframe -f gproducts/edit.item -params 'ap="+ap+"&id="+id+"'"); break;
  case 'gpart' : sh.sendCommand("gframe -f gpart/edit.item -params 'ap="+ap+"&id="+id+"'"); break;
  case 'gmaterial' : sh.sendCommand("gframe -f gmaterial/edit.item -params 'ap="+ap+"&id="+id+"'"); break;
  case 'gbook' : sh.sendCommand("gframe -f gbook/edit.item -params 'ap="+ap+"&id="+id+"'"); break;
 }

}*/

function selectStore(id,li)
{
 Template.SERP.setVar("storeid",id);
 Template.SERP.reload(0);
}

function setShow(value)
{
 Template.SERP.setVar("show",value);
 Template.SERP.reload(0);
}

function ManualUpload()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload();}
 sh.sendCommand("gframe -f gstore/pack.upload -params `storeid=<?php echo $_REQUEST['storeid']; ?>`");
}

/*function ManualDownload()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload();}
 sh.sendCommand("gframe -f gstore/manual.download -params `storeid=<?php echo $_REQUEST['storeid']; ?>&at="+AT+"`");
}

function ManualTransfer()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload();}
 sh.sendCommand("gframe -f gstore/manual.move -params `storeid=<?php echo $_REQUEST['storeid']; ?>&at="+AT+"`");
}*/

/*function Print(printBtn)
{
 if(ON_PRINTING)
  return alert("Attendi che il processo per l'esportazione in PDF abbia terminato.");

 printBtn.disabled = true;
 ON_PRINTING = true;

 var xml = "<xml>";
 xml+= "<field name='Codice' tag='code_str' width='25' align='center'/"+">";
 xml+= "<field name='Descrizione' tag='name' width='55'/"+">";
 xml+= "<field name='Scorta min.' tag='minstock' width='15' align='center'/"+">";
 if(selectedStoreId)
 {
  xml+= "<field name='Giac. fis. a mag.' tag='store_"+selectedStoreId+"_qty' format='number' width='20' align='center'/"+">";
  xml+= "<field name='Giac. fis. totale' tag='storeqty' format='number' width='20' align='center'/"+">";
 }
 else
  xml+= "<field name='Giac. fis.' tag='storeqty' format='number' width='30' align='center'/"+">";
 xml+= "<field name='Prenotati' tag='booked' format='number' width='15' align='center'/"+">";
 xml+= "<field name='Ordinati' tag='incoming' format='number' width='15' align='center'/"+">";
 xml+= "<field name='Disponibili' tag='available' format='number' width='20' align='center'/"+">";
 xml+= "</xml>";

 var title = "Situazione magazzino";
 if(selectedStoreId) title+= " "+selectedStoreName;
 var fileName = "situazione-magazzino";
 if(selectedStoreId) fileName+= "-"+selectedStoreName;

 var header = "<div style='font-size:14pt;font-family:arial,sans-serif'>";
 header+= "Situazione magazzino"+(selectedStoreId ? " "+selectedStoreName : "");
 header+= "</div>";


 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnPreOutput = function(){}
 sh.OnOutput = function(o,a){
	 printBtn.disabled = false;
	 ON_PRINTING = false;
	 window.open(ABSOLUTE_URL+a['fullpath']);
	}
 sh.sendCommand("pdf fast-export -title `"+title+"` -header `"+header+"` -format A4 -rpp 27 -margin 10 -filename `"+fileName+"` -xmlfields `"+xml+"` -cmd `<?php echo $_CMD; ?>` -resfield items");
}

function ExportToExcel(exportBtn)
{
 if(ON_EXPORT)
  return alert("Attendi che il processo per l'esportazione in Excel abbia terminato.");

 exportBtn.disabled = true;
 ON_EXPORT = true;

 var xml = "<xml>";
 xml+= "<field name='Codice' tag='code_str'/"+">";
 xml+= "<field name='Descrizione' tag='name'/"+">";
 xml+= "<field name='Scorta min.' tag='minstock'/"+">";
 if(selectedStoreId)
 {
  xml+= "<field name='Giac. fis. a mag.' tag='store_"+selectedStoreId+"_qty' format='number'/"+">";
  xml+= "<field name='Giac. fis. totale' tag='storeqty' format='number'/"+">";
 }
 else
  xml+= "<field name='Giac. fis.' tag='storeqty' format='number'/"+">";
 xml+= "<field name='Prenotati' tag='booked' format='number'/"+">";
 xml+= "<field name='Ordinati' tag='incoming' format='number'/"+">";
 xml+= "<field name='Disponibili' tag='available' format='number'/"+">";
 xml+= "</xml>";

 var title = "Situazione magazzino";
 if(selectedStoreId) title+= " "+selectedStoreName;
 var fileName = "situazione-magazzino";
 if(selectedStoreId) fileName+= "-"+selectedStoreName;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnPreOutput = function(){}
 sh.OnOutput = function(o,a){
	 exportBtn.disabled = false;
	 ON_EXPORT = false;
	 document.location.href = ABSOLUTE_URL+"getfile.php?file="+a['filename'];
	}
 sh.sendCommand("excel fast-export -title `"+title+"` -filename `"+fileName+"` -xmlfields `"+xml+"` -cmd `<?php echo $_CMD; ?>` -resfield items");
}

function EditStock()
{
 var tb = document.getElementById("productlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun articolo è stato selezionato");

 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= ","+sel[c].getAttribute('refap')+":"+sel[c].id;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){document.location.reload();}
 sh.sendCommand("gframe -f gstore/edit.movements -params `ids="+q.substr(1)+"`");
}*/

</script>
<?php

$template->End();

?>


