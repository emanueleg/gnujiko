<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 17-09-2014
 #PACKAGE: packs-manager
 #DESCRIPTION: Pack info
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");
include_once($_BASE_PATH."include/userfunc.php");
$template = new GLightTemplate("widget");
$template->includeObject("gcal");
$template->includeObject("gmutable");

$template->Begin("Dettagli pacco");
$template->Header();

$packInfo = array();
$items = array();
if($_REQUEST['id'])
{
 $ret = GShell("pack info -id '".$_REQUEST['id']."' --get-item-list",$_REQUEST['sessid'],$_REQUEST['shellid']);
 if(!$ret['error'])
 {
  $packInfo = $ret['outarr'];
  $items = $packInfo['items'];
 }
}

//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0,0,10);
?>
<input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='menubutton' style='float:left'/>
 <ul class='popupmenu' id='mainmenu'>
  <li onclick='DeleteSelected()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/delete.gif"/>Elimina selezionati</li>
 </ul>
</td><td width='180' valign='middle'><span class='smalltext'>data carico: </span>
<input type='text' class='calendar' id='load-date' value="<?php echo date('d/m/Y',strtotime($packInfo['loadtime'])); ?>"/></td>
<td width='300' valign='middle'><span class='smalltext'><?php echo $packInfo['refcode']." ".$packInfo['refname']; ?></span></td>
<td width='180' valign='middle'><span class='smalltext'>cod. pacco: </span>
<span class='smalltext'><b><?php echo $packInfo['code']; ?></b></span></td>

<td>&nbsp;

<?php
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",800);
//-------------------------------------------------------------------------------------------------------------------//
?>
<style type='text/css'>
table.gmutable tr.status0 {background: #f44800;}
table.gmutable tr.status0:hover td {background: #fb8b00;}
table.gmutable tr.status2 {background: #4fef00;}
table.gmutable tr.status2:hover td {background: #b4ff8e;}
</style>

<div style='padding-left:10px;padding-top:10px'>
<span class='smalltext'>Qt&agrave; caricata: <b><?php echo $packInfo['qty']; ?></b></span>
<span class='smalltext' style='margin-left:10px'>Scaricata: <b><?php echo $packInfo['qty']-$packInfo['available']; ?></b></span>
<span class='smalltext' style='margin-left:10px'>Disponibile: <b><?php echo $packInfo['available']; ?></b></span>
</div>

<div class='gmutable' style="height:300px;width:760px;margin:10px;border:0px">
<table id="itemlist" class="gmutable" cellspacing='0' cellpadding='0' border='0'>
<tr><th width='32' style='text-align:center'><input type='checkbox' onclick='tb.selectAll(this.checked)'/></th>
    <th id='barcode' editable='true'>BARCODE</th>
	<th id='downloadtime' editable='true' format='date' width='80'>DATA SCARICO</th>
	<th width='18'>&nbsp;</th>
</tr>
<?php

for($c=0; $c < count($items); $c++)
{
 $item = $items[$c];
 $trclass = !$item['status'] ? "status0" : ($item['status'] == 2 ? "status2" : "");
 echo "<tr".($trclass ? " class='".$trclass."'" : "")." id='".$item['id']."'><td align='center'><input type='checkbox'/></td>";
 echo "<td><span class='graybold'>".$item['barcode']."</span></td>";
 echo "<td><span class='graybold'>".(strtotime($item['downloadtime']) ? date('d/m/Y',strtotime($item['downloadtime'])) : "")."</span></td>";
 echo "<td>&nbsp;</td></tr>";
}
?>
</table>
</div>

<?php
//-------------------------------------------------------------------------------------------------------------------//

$footer = "<input type='button' class='button-blue' value='Salva' onclick='SubmitAction()'/> ";
$footer.= "<input type='button' class='button-gray' value='Chiudi' onclick='Template.Exit();'/>";
$footer.= "<input type='button' class='button-red' value='Elimina pacco' style='float:right' onclick='DeletePack()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var PACK_ID = "<?php echo $packInfo['id']; ?>";
var UPDATED_ROWS = new Array();
var DELETED_ROWS = new Array();

Template.OnInit = function(){
 	this.initBtn(document.getElementById('menubutton'), "popupmenu");
	this.initEd(document.getElementById('load-date'), "date");

	tb = new GMUTable(document.getElementById('itemlist'), {autoresize:true, autoaddrows:false});
	tb.OnCellEdit = function(r,cell,value){}
	tb.OnBeforeAddRow = function(r){
		 r.cells[0].innerHTML = "<input type='checkbox'/ >"; r.cells[0].style.textAlign='center';
		 r.cells[1].style.textAlign='center'; r.cells[1].innerHTML = "<span class='graybold'></span>";
		}

	tb.OnCellEdit = function(r, cell, value, data){
		 switch(cell.tag)
		 {
		  case 'barcode' : {
			 // verifica che il barcode digitato non sia già esistente
			 for(var c=1; c < this.O.rows.length; c++)
			 {
			  if(this.O.rows[c] == r) continue;
			  if(this.O.rows[c].cell['barcode'].getValue() == value)
			  {
			   alert("Esiste già un articolo con questo codice in questo pacco.");
			   return cell.restoreOldValue();
			  }
			 }
			} break;
		 }
		 if(UPDATED_ROWS.indexOf(r) < 0) UPDATED_ROWS.push(r);
		}

	tb.OnDeleteRow = function(r){
		 if(UPDATED_ROWS.indexOf(r) > -1) UPDATED_ROWS.splice(UPDATED_ROWS.indexOf(r),1);
		 DELETED_ROWS.push(r);
		}
}

function SubmitAction()
{
 var loadDate = document.getElementById('load-date').isodate;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnFinish = function(o,a){gframe_close(o,a);}

 for(var c=0; c < UPDATED_ROWS.length; c++)
 {
  var r = UPDATED_ROWS[c];
  sh.sendCommand("pack edit-item -id '"+r.id+"' -barcode '"+r.cell['barcode'].getValue()+"'");
 }

 for(var c=0; c < DELETED_ROWS.length; c++)
 {
  var r = DELETED_ROWS[c];
  sh.sendCommand("pack delete-item -id '"+r.id+"'");
 }

 sh.sendCommand("pack edit -id '"+PACK_ID+"' -loadtime '"+loadDate+"'");
 
}

function DeletePack()
{
 if(!confirm("Sei sicuro di voler eliminare questo pacco?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){gframe_close(o,a);}
 sh.sendCommand("pack delete -id '"+PACK_ID+"'");
}

function DeleteSelected()
{
 var list = tb.GetSelectedRows();
 if(!list.length)
  return alert("Nessun articolo è stato selezionato");
 if(!confirm("Sei sicuro di voler rimuovere le righe selezionate?"))
  return;
 tb.DeleteSelectedRows();
}
</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

