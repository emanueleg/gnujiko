<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 17-09-2014
 #PACKAGE: packs-manager
 #DESCRIPTION: Upload packs
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");
include_once($_BASE_PATH."include/userfunc.php");
$template = new GLightTemplate("widget");
$template->includeInternalObject("productsearch");
$template->includeObject("gmutable");

$template->Begin("Caricamento manuale pacchi");
$template->Header();

$archiveTypes = array();
if(_userInGroup("lottomatica") && file_exists($_BASE_PATH."Lottomatica/index.php"))
 $archiveTypes['lottomatica'] = "lottomatica";
/*if(_userInGroup("gproducts") && file_exists($_BASE_PATH."FinalProducts/index.php"))
 $archiveTypes['gproducts'] = "prodotti finiti";
if(_userInGroup("gpart") && file_exists($_BASE_PATH."Parts/index.php"))
 $archiveTypes['gpart'] = "componenti";
if(_userInGroup("gmaterial") && file_exists($_BASE_PATH."Materials/index.php"))
 $archiveTypes['gmaterial'] = "materiali";
if(_userInGroup("gbook") && file_exists($_BASE_PATH."Books/index.php"))
 $archiveTypes['gbook'] = "libri";*/

$_AT = $_REQUEST['at'] ? $_REQUEST['at'] : 'lottomatica';

//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0,0,10);
?>
<input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='menubutton' style='float:left'/>
 <ul class='popupmenu' id='mainmenu'>
  <li onclick='DeleteSelected()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/delete.gif"/>Elimina selezionati</li>
 </ul>

<input type='button' class="button-gray menu" value="Visualizza" connect='columnsmenu' id='columnsmenubutton' style='float:left;margin-left:10px'/>
 <ul class='popupmenu' id='columnsmenu'>
  <li><input type='checkbox' onclick="tb.showHideColumn('date',this.checked)" checked='true'/>Data carico</li>
  <li><input type='checkbox' onclick="tb.showHideColumn('barcode',this.checked)" checked='true'/>Codice a barre</li>
  <li><input type='checkbox' onclick="tb.showHideColumn('code_str',this.checked)" checked='true'/>Codice articolo</li>
  <li><input type='checkbox' onclick="tb.showHideColumn('name',this.checked)" checked='true'/>Descrizione</li>
  <li><input type='checkbox' onclick="tb.showHideColumn('code_id',this.checked)" checked='true'/>Codice identificativo</li>
  <li><input type='checkbox' onclick="tb.showHideColumn('pack_code',this.checked)" checked='true'/>Codice pacco</li>
  <li><input type='checkbox' onclick="tb.showHideColumn('qty',this.checked)" checked='true'/>Qt&agrave;</li>
  <li><input type='checkbox' onclick="tb.showHideColumn('location',this.checked)"/>Ubicazione</li>
 </ul>

<input type='text' readonly='true' class='dropdown' id='archivetype' connect='archivetypelist' value="<?php echo $archiveTypes[$_AT]; ?>" retval="<?php echo $_AT; ?>" style='width:100px;float:left;margin-left:30px'/>
<ul class='popupmenu' id='archivetypelist'>
<?php
$db = new AlpaDatabase();
while(list($k,$v)=each($archiveTypes))
{
 $db->RunQuery("SELECT COUNT(*) FROM dynarc_archives WHERE archive_type='".$k."' AND trash='0'");
 if($db->Read())
 {
  echo "<li value='".$k."'>".$v."</li>";
  if(!$_AT) $_AT = $k;
 }
}
$db->Close();
$phsearch = "";
switch($_AT)
{
 case 'lottomatica' : $phsearch = "Cerca un articolo"; break;
 /*case 'gmart' : $phsearch = "Cerca un articolo"; break;
 case 'gproducts' : $phsearch = "Cerca un prodotto finito"; break;
 case 'gpart' : $phsearch = "Cerca un componente"; break;
 case 'gmaterial' : $phsearch = "Cerca un materiale"; break;
 case 'gbook' : $phsearch = "Cerca un libro"; break;*/
}
?>
</ul>
<input type='text' class='edit' style='width:290px;float:left' placeholder="<?php echo $phsearch; ?>" id='search' emptyonclick='true' at="<?php echo $_AT; ?>" fields="code_str,name"/>
<input type='button' class='button-search' id='searchbtn'/>
<!-- <input type='button' class='button-add' style='margin-left:20px' title="Aggiungi articolo non presente in catalogo" onclick="insertRow()"/> -->
<?php
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",800);
//-------------------------------------------------------------------------------------------------------------------//
?>
<div class='gmutable' style="height:400px;width:760px;margin:10px;border:0px">
<table id="itemlist" class="gmutable" cellspacing='0' cellpadding='0' border='0'>
<tr><th width='32' style='text-align:center'><input type='checkbox' onclick='tb.selectAll(this.checked)'/></th>
    <th width='80' id='date' editable='true' format='date'>DATA CARICO</th>
    <th width='100' id='barcode' editable='true' style='text-align:center'>BARCODE</th>
    <th width='80' id='code_str' editable='true' style='text-align:center'>COD. ART.</th>
    <th id='name' editable='true' style='minwidth:400px'>DESCRIZIONE</th>
	<th width='60' id='code_id' editable='true' style='text-align:center'>COD. ID</th>
	<th width='60' id='pack_code' editable='true' style='text-align:center'>COD. PACCO</th>
	<th width='60' id='qty' editable='true' style='text-align:center' format='number'>QTA'</th>
	<th width='60' id='location' editable='true' style='display:none'>UBICAZIONE</th>
	<th width='18'>&nbsp;</th>
</tr>
</table>
</div>
<textarea class="textarea" style="width:780px;height:50px;margin-bottom:5px;resize:none" placeholder="Inserisci qui eventuali note" id="notes"></textarea>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$ret = GShell("store list",$_REQUEST['sessid'],$_REQUEST['shellid']);
$list = $ret['outarr'];
$storeInfo = null;
if($_REQUEST['storeid'])
{
 for($c=0; $c < count($list); $c++)
 {
  if($list[$c]['id'] == $_REQUEST['storeid'])
  {
   $storeInfo = $list[$c];
   break;
  }
 }
}
if(!$storeInfo && count($list))
 $storeInfo = $list[0];

$ret = GShell("dynarc item-list -ap storemovcausals -ct UPLOAD",$_REQUEST['sessid'],$_REQUEST['shellid']);
$causalList = $ret['outarr']['items'];

$footer.= "<span class='smalltext'>Magazzino su cui caricare: </span>";
$footer.= "<input type='text' class='dropdown' readonly='true' connect='storelist' id='storeselect' placeholder='seleziona un magazzino' retval='"
	.($storeInfo ? $storeInfo['id'] : '')."'".($storeInfo ? " value='".$storeInfo['name']."'" : "")." style='width:180px'/>";
$footer.= "<ul class='popupmenu' id='storelist'>";
for($c=0; $c < count($list); $c++)
 $footer.= "<li value='".$list[$c]['id']."'><img src='".$_ABSOLUTE_URL."share/widgets/gstore/img/storeicon.png'/>".$list[$c]['name']."</li>";
$footer.= "</ul>";

$footer.= "<span class='smalltext' style='margin-left:20px'>Causale: </span>";
$footer.= "<input type='text' class='dropdown' readonly='true' connect='causallist' id='causalselect' style='width:180px'/>";
$footer.= "<ul class='popupmenu' id='causallist'>";
for($c=0; $c < count($causalList); $c++)
 $footer.= "<li value='".$causalList[$c]['code_str']."'>".$causalList[$c]['name']."</li>";
$footer.= "</ul>";


$footer.= "<input type='button' class='button-blue' value='Procedi &raquo;' style='float:right' onclick='SubmitAction()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AT = "<?php echo $_AT; ?>";

Template.OnInit = function(){
 	this.initBtn(document.getElementById('menubutton'), "popupmenu");
 	this.initBtn(document.getElementById('columnsmenubutton'), "popupmenu");
	this.initEd(document.getElementById('archivetype'), "dropdown").onchange = function(){
		 var sE = document.getElementById("search");
		 switch(this.getValue())
		 {
		  case 'lottomatica' : {sE.placeholder = "Cerca un articolo";} break;
		  /*case 'gmart' : {sE.placeholder = "Cerca un articolo";} break;
		  case 'gproducts' : {sE.placeholder = "Cerca un prodotto finito";} break;
		  case 'gpart' : {sE.placeholder = "Cerca un componente";} break;
		  case 'gmaterial' : {sE.placeholder = "Cerca un materiale";} break;
		  case 'gbook' : {sE.placeholder = "Cerca un libro";} break;*/
		 }
		 sE.setAT(this.getValue());
		};

	this.initEd(document.getElementById("search"), AT).OnSearch = function(){
		 if(this.value && this.data)
		  insertRow(this.data);
		};
	this.initBtn(document.getElementById("searchbtn")).onclick = function(){document.getElementById("search").OnSearch();}
	this.initEd(document.getElementById('storeselect'), "dropdown").onchange = function(){};
	this.initEd(document.getElementById('causalselect'), "dropdown").onchange = function(){};

	tb = new GMUTable(document.getElementById('itemlist'), {autoresize:true, autoaddrows:false});
	tb.OnCellEdit = function(r,cell,value){}
	tb.OnBeforeAddRow = function(r){
		 r.cells[0].innerHTML = "<input type='checkbox'/ >"; r.cells[0].style.textAlign='center';
		 r.cells[1].style.textAlign='center'; r.cells[1].innerHTML = "<span class='graybold'></span>";
		 r.cells[2].style.textAlign='center'; r.cells[2].innerHTML = "<span class='graybold'></span>";
		 r.cells[3].style.textAlign='center'; r.cells[3].innerHTML = "<span class='graybold'></span>";
		 r.cells[4].innerHTML = "<span class='graybold'></span>";

		 r.cells[5].style.textAlign='center'; r.cells[5].innerHTML = "<span class='graybold'></span>";
		 r.cells[6].style.textAlign='center'; r.cells[6].innerHTML = "<span class='graybold'></span>";
		 r.cells[7].style.textAlign='center'; r.cells[7].innerHTML = "<span class='graybold'></span>";
		 r.cells[8].style.textAlign='center'; r.cells[8].innerHTML = "<span class='graybold'></span>";
		}
	tb.OnDeleteRow = function(r){}
	document.getElementById("search").focus();
}

function insertRow(data)
{
 var date = new Date();

 var r = tb.AddRow();
 r.data = data;
 if(data)
 {
  r.cell['date'].setValue(date.printf('d/m/Y'));
  r.cell['code_str'].setValue(data['code_str']);
  r.cell['barcode'].setValue(data['barcode']);
  r.cell['name'].setValue(data['name']);

  r.cell['location'].setValue(data['location'] ? data['location'] : '');
 }
 else
  r.edit();
}

function SubmitAction()
{
 var storeId = document.getElementById('storeselect').getValue();
 if(!storeId)
  return alert("Devi selezionare un magazzino");
 var causal = document.getElementById('causalselect').getValue();

 if(tb.O.rows.length < 2)
  return alert("Nessun articolo da caricare.");

 var xml = "";
 for(var c=1; c < tb.O.rows.length; c++)
 {
  var r = tb.O.rows[c];

  if(!r.cell['code_id'].getValue())
   return alert("Codice ID non valido alla riga n."+c);
  if(!r.cell['pack_code'].getValue())
   return alert("Codice pacco non valido alla riga n."+c);
  if(!r.cell['qty'].getValue())
   return alert("Quantità errata alla riga n."+c);

  xml+= "<item date=\""+strdatetime_to_iso(r.cell['date'].getValue()).substr(0,10)+"\" ap=\""+r.data['ap']+"\" id=\""+r.data['id']+"\" barcode=\""+r.cell['barcode'].getValue()+"\" idcode=\""+r.cell['code_id'].getValue()+"\" pkgcode=\""+r.cell['pack_code'].getValue()+"\" qty=\""+r.cell['qty'].getValue()+"\" location=\""+r.cell['location'].getValue()+"\"/"+">";
 }
 
 var notes = document.getElementById("notes").value;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){gframe_close(o,a);}
 sh.sendCommand("pack fast-upload -xml `"+xml+"`");
 //sh.sendCommand("store upload -store `"+storeId+"`"+q+" -notes `"+notes+"` -causal '"+causal+"'");
}

function ImportFromExcel()
{
}

function ExportToExcel()
{
 var date = new Date();
 var fileName = "carico-magazzino-"+date.printf("dmYHi");
 tb.ExportToExcel(fileName);
}

function SendMail()
{
}

function PrintTable()
{
}

function DeleteSelected()
{
 var list = tb.GetSelectedRows();
 if(!list.length)
  return alert("Nessun articolo è stato selezionato");
 if(!confirm("Sei sicuro di voler rimuovere le righe selezionate?"))
  return;
 tb.DeleteSelectedRows();
}
</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

