/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2012 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 22-02-2012
 #PACKAGE: gchart
 #DESCRIPTION: Dynamic chart using pChart (http://pchart.sourceforge.net)
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/

/* THIS IS THE CLASS FOR USING GCHART WITH JAVASCRIPT */

function GChart()
{
}


