<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `gmaterial` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Materials/'");
if($db->Read())
 $db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Materiali...";
 $ret = GShell("system register-app -name `Materiali` -desc `Catalogo materiali personalizzabile` -url 'Materials/' -icon 'Materials/icon.png' -group gmaterial -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new archive */
$_SHELL_OUT.= "Create new archive Materiali...";
$ret = GShell("dynarc new-archive -name `Materiali` -prefix 'gmaterial' -type gmaterial -group 'gmaterial' -perms '660' --def-cat-perms '660' --def-item-perms '660' --functions-file `etc/dynarc/archive_funcs/__gmaterial/index.php` -launcher `gframe -f gmaterial/edit.item -params id=%d`",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension 'coding' -ap 'gmaterial'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension custompricing...";
$ret = GShell("dynarc install-extension 'custompricing' -ap 'gmaterial'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension gmaterial...";
$ret = GShell("dynarc install-extension 'gmaterial' -ap 'gmaterial'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension idoc...";
$ret = GShell("dynarc install-extension 'idoc' -ap 'gmaterial'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension pricing...";
$ret = GShell("dynarc install-extension 'pricing' -ap 'gmaterial'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension storeinfo...";
$ret = GShell("dynarc install-extension 'storeinfo' -ap 'gmaterial'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension thumbnails...";
$ret = GShell("dynarc install-extension 'thumbnails' -ap 'gmaterial'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension vendorprices...";
$ret = GShell("dynarc install-extension 'vendorprices' -ap 'gmaterial'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create category MARCHE MATERIALI...";
$ret = GShell("dynarc new-cat -ap 'brands' -name `MARCHE MATERIALI` -tag `gmaterial` -group 'gmaterial' -perms '664' --def-item-perms 664",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];