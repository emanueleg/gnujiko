<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: gmaterial
 #DESCRIPTION: Excel parser for GMaterial.
 #VERSION: 2.1beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.
 #TODO: verificare alla riga 332 se aggiorna correttamente i totali.
 
*/

function gnujikoexcelparser_gmaterial_info()
{
 $info = array('name' => "Materiali");
 $keys = array(
	/* BASIC INFO */
	"name"=>"Nome materiale / marca e modello",
	"desc"=>"Descrizione",
	"code"=>"Codice",
	"brand"=>"Marca",
	"model"=>"Modello",
	"barcode"=>"Codice a barre",
	"mancode"=>"Cod. art. Produttore",
	"vencode"=>"Cod. art. Fornitore",
	"units"=>"Unita di misura",
	"baseprice"=>"Prezzo di base",
	"vat"=>"Aliquota IVA",
	"vendorname"=>"Fornitore",
	"vendorprice"=>"Prezzo acquisto"
	);

 $ret = GShell("pricelists list");
 $list = $ret['outarr'];
 for($c=0; $c < count($list); $c++)
  $keys["pricelist_".$list[$c]['id']] = $list[$c]['name'];

 $keydict = array(
	/* BASIC INFO */
	"name"=> array("nome","titolo","materiale"),
	"desc"=> array("descrizione","desc."),
	"code"=> array("codice","cod."),
	"brand"=> array("marca"),
	"model"=> array("modello","mod."),
	"barcode"=> array("barcode","codice a barre","cod. a barre"),
	"mancode"=> array("codice art. produttore","cod. prod"),
	"vencode"=> array("codice art. fornitore","cod. forn","cod.art.forn"),
	"units"=> array("um","u.m.","unità di mis","unita di mis","unita_mis"),
	"baseprice"=> array("prezzo","pr. vendita","pr vendita"),
	"vat"=> array("iva","aliquota iva"),
	"vendorname"=> array("fornitore","forn."),
	"vendorprice"=> array("prezzo acq","pr acq","pr. acq")
	);

 for($c=0; $c < count($list); $c++)
  $keydict["pricelist_".$list[$c]['id']] = array(0=>strtolower($list[$c]['name']));

 return array('info'=>$info, 'keys'=>$keys, 'keydict'=>$keydict);
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoexcelparser_gmaterial_import($_DATA, $sessid, $shellid, $archivePrefix="gmaterial", $catId=0, $catTag="", $id=0)
{
 $ret = GShell("pricelists list",$sessid,$shellid);
 $pllist = $ret['outarr'];
 $mtime = date('Y-m-d H:i:s');

 $interface = array("name"=>"progressbar","steps"=>count($_DATA['items']));
 gshPreOutput($shellid,"Import from Excel to Components", "ESTIMATION", "", "PASSTHRU", $interface);

 $db2 = new AlpaDatabase();
 for($c=0; $c < count($_DATA['items']); $c++)
 {
  $itm = $_DATA['items'][$c];

  // verifica se l'materiale esiste gia //
  $checkQry = "SELECT id FROM dynarc_".$archivePrefix."_items WHERE ";
  if($itm['code'])
   $checkQry.= "code_str='".$itm['code']."'";
  else
  {
   $name = $db2->Purify($itm['name']);
   $checkQry.= "name='".$name."' OR name LIKE '".$name."%'";
  }

  $db2->RunQuery($checkQry." AND trash='0'");
  if($db2->Read())
  {
   gshPreOutput($shellid,"Update: ".$itm['name'].($itm['code'] ? "<i>cod.".$itm['code']."</i>" : ""),"PROGRESS", $itm);
   $qry = "dynarc edit-item -ap `".($archivePrefix ? $archivePrefix : "gmaterial")."` -id '".$db2->record['id']."' -name `".$itm['name']."` -code-str `"
	.$itm['code']."` -mtime '".$mtime."'";
  }
  else
  {
   gshPreOutput($shellid,"Import: ".$itm['name'].($itm['code'] ? "<i>cod.".$itm['code']."</i>" : ""),"PROGRESS", $itm);
   $qry = "dynarc new-item -ap `".($archivePrefix ? $archivePrefix : "gmaterial")."`"
	.($catId ? " -cat '".$catId."'" : ($catTag ? " -ct `".$catTag."`" : ""))." -name `".$itm['name']."` -mtime '".$mtime."'";
  }

  $set = "";
  $extset = "";
  if($itm['desc']) $qry.= " -desc `".$itm['desc']."`";
  if($itm['code']) $qry.= " -code-str `".$itm['code']."`";
  if($itm['baseprice']) $set.= ",baseprice='".(str_replace(",",".",$itm['baseprice']))."'";  
  if($itm['vat']) $set.= ",vat='".$itm['vat']."'";

  /* DETECT PRICELISTS */
  $pricelists = "";
  for($i=0; $i < count($pllist); $i++)
  {
   if($itm["pricelist_".$pllist[$i]['id']])
   {
	if((stripos($itm["pricelist_".$pllist[$i]['id']], "s") !== false) || (stripos($itm["pricelist_".$pllist[$i]['id']], "x") !== false))
	 $pricelists.= ",".$pllist[$i]['id'];
   }
  }
  if($pricelists)
   $set.= ",pricelists='".ltrim($pricelists,",")."'";

  if(!$itm['model'])
   $itm['model'] = $itm['name'];

  if($itm['brand']) $extset.= ",brand='''".$itm['brand']."'''";
  if($itm['model']) $extset.= ",model='''".$itm['model']."'''";
  if($itm['barcode']) $extset.= ",barcode='".$itm['barcode']."'";
  if($itm['mancode']) $extset.= ",mancode='".$itm['mancode']."'";
  if($itm['units']) $extset.= ",units='".$itm['units']."'";

  if($extset)
   $extset = "gmaterial.".ltrim($extset,",");

  /* DETECT VENDOR AND VENDOR PRICE */
  if($itm['vendorname'] || $itm['vendorprice'])
  {
   if($itm['vendorname'])
   {
	$ret = GShell("dynarc item-find -ap rubrica -into vendors `".$itm['vendorname']."`",$sessid,$shellid);
	if(count($ret['outarr']['items']))
	 $extset.=",vendorprices.vendorid='".$ret['outarr']['items'][0]['id']."',vendor='''".$ret['outarr']['items'][0]['name']."'''";
	else
	 $extset.=",vendorprices.vendor='''".$itm['vendorname']."'''";
   }
   else
	 $extset.=",vendorprices.vendor=''";
   $extset.=",code='".$itm['vencode']."',price='".(str_replace(",",".",$itm['vendorprice']))."',vat='".$itm['vat']."'";
  }

  $ret = GShell($qry.($set ? " -set `".ltrim($set,",")."`" : "").($extset ? " -extset `".ltrim($extset,",")."`" : ""),$sessid,$shellid);
  if($ret['error'])
   return $ret;

 }
 $db2->Close();

 return array('message'=>"done!");
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoexcelparser_gmaterial_fastimport($_KEYS, $_DATA, $sessid, $shellid, $_AP="", $catId=0, $catTag="", $id=0, $sessInfo)
{
 if(!$_AP) $_AP = "gmaterial";

 $ret = GShell("pricelists list",$sessid,$shellid);
 $_PRICELISTS = $ret['outarr'];

 /* get archive info */
 $ret = GShell("dynarc archive-info -prefix '".$_AP."'",$sessid,$shellid);
 if($ret['error'])
  return $ret;
 $archiveInfo = $ret['outarr'];

 if($catTag || $catId)
 {
  // get cat info
  $ret = GShell("dynarc cat-info -ap '".$_AP."'".($catId ? " -id '".$catId."'" : " -tag '".$catTag."'"),$sessid,$shellid);
  if(!$ret['error'])
  {
   $catId = $ret['outarr']['id'];
   $catInfo = $ret['outarr'];
  }
 }

 /* PROGRESS BAR */
 $interface = array("name"=>"progressbar","steps"=>count($_DATA['items']));
 gshPreOutput($shellid,"Import from Excel to Components", "ESTIMATION", "", "PASSTHRU", $interface);

 // default fields
 $fields = array('uid','gid','_mod','cat_id','name','description','ordering','ctime','mtime','hierarchy','code_str','brand','model','units',
'baseprice','vat','pricelists','barcode','manufacturer_code');
 $pricelists = "";
 for($c=0; $c < count($_PRICELISTS); $c++)
 {
  $fields[] = "pricelist_".$_PRICELISTS[$c]['id']."_baseprice";
  $fields[] = "pricelist_".$_PRICELISTS[$c]['id']."_mrate";
  $fields[] = "pricelist_".$_PRICELISTS[$c]['id']."_vat";
  $pricelists.= ",".$_PRICELISTS[$c]['id'];
 }
 $pricelists = ltrim($pricelists,",");

 $now = time();
 $ctime = date('Y-m-d H:i:s',$now);
 $mtime = $ctime;
 $uid = $sessInfo['uid'];
 $gid = $sessInfo['gid'];
 $mod = $archiveInfo['def_item_perms'] ? $archiveInfo['def_item_perms'] : 640;
 $hierarchy = $catId ? $catInfo['hierarchy'].$catInfo['id'] : ",";

 $_VENDOR = array();

 /* IMPORT ITEMS */
 $fieldsString = implode(",",$fields);
 $ordering = 0;
 for($c=0; $c < count($_DATA['items']); $c++)
 {
  $itm = $_DATA['items'][$c];
  $ordering++;
  $brand = $itm['brand'];
  $model = $itm['model'] ? $itm['model'] : $itm['name'];
  $isUpdated=false;

  // verifica se l'materiale esiste gia //
  $db = new AlpaDatabase();
  $checkQry = "SELECT id FROM dynarc_".$_AP."_items WHERE ";
  if($itm['code'])
   $checkQry.= "code_str='".$itm['code']."'";
  else
  {
   $name = $db->Purify($itm['name']);
   $checkQry.= "name='".$name."' OR name LIKE '".$name."%'";
  }

  $db->RunQuery($checkQry." AND trash='0'");
  if($db->Read())
  {
   $_ID = $db->record['id'];
   gshPreOutput($shellid,"Update: ".$itm['name'].($itm['code'] ? "<i>cod.".$itm['code']."</i>" : ""),"PROGRESS", $itm);
   $qry = "UPDATE dynarc_".$_AP."_items SET code_str='".$itm['code']."',name='"
	.$db->Purify($itm['name'] ? $itm['name'] : $itm['desc'])."',description='".$db->Purify($itm['desc'])."',mtime='".$mtime."',brand='"
	.$db->Purify($brand)."',model='".$db->Purify($model)."',units='".$itm['units']."',baseprice='".$itm['baseprice']."',vat='"
	.$itm['vat']."',pricelists='".$pricelists."',barcode='".$itm['barcode']."',manufacturer_code='".$itm['mancode']."'";
   // pricelists
   for($i=0; $i < count($_PRICELISTS); $i++)
    $qry.= ",pricelist_".$_PRICELISTS[$i]['id']."_baseprice='".$itm['baseprice']."',pricelist_".$_PRICELISTS[$i]['id']."_mrate='"
	.$_PRICELISTS[$i]['markuprate']."',pricelist_".$_PRICELISTS[$i]['id']."_vat='".$itm['vat']."'";
   $qry.= " WHERE id='".$_ID."'";

   $db2 = new AlpaDatabase();
   $db2->RunQuery($qry);
   if($db2->Error)
    return array("message"=>"MySQL Error: ".$db2->Error, "error"=>"MYSQL_ERROR");
   $db2->Close();
   $isUpdated=true;
  }
  else
  {
   gshPreOutput($shellid,"Import: ".$itm['name'].($itm['code'] ? "<i>cod.".$itm['code']."</i>" : ""),"PROGRESS", $itm);
   $qry = "INSERT INTO dynarc_".$_AP."_items (".$fieldsString.") VALUES('".$uid."','".$gid."','".$mod."','".$catId."','"
	.$db->Purify($itm['name'] ? $itm['name'] : $itm['desc'])."','".$db->Purify($itm['desc'])."','".$ordering."','".$ctime."','".$mtime."','"
	.$hierarchy."','".$itm['code']."','".$db->Purify($brand)."','".$db->Purify($model)."','".$itm['units']."','".$itm['baseprice']."','"
	.$itm['vat']."','".$pricelists."','".$itm['barcode']."','".$itm['mancode']."'";
   // pricelists
   for($i=0; $i < count($_PRICELISTS); $i++)
    $qry.= ",'".$itm['baseprice']."','".$_PRICELISTS[$i]['markuprate']."','".$itm['vat']."'";
   $qry.= ")";

   $db2 = new AlpaDatabase();
   $db2->RunQuery($qry);
   if($db2->Error)
    return array("message"=>"MySQL Error: ".$db2->Error, "error"=>"MYSQL_ERROR");
   $_ID = $db2->GetInsertId();
   $db2->Close();
  }
  $db->Close();

  if(in_array("vencode", $_KEYS) || in_array("vendorname",$_KEYS) || in_array("vendorprice",$_KEYS))
  {
   $vencode = $itm['vencode'];
   $vendorName = $itm['vendorname'];
   if($vendorName)
   {
    if(isset($_VENDOR[$vendorName]))
	 $vendorId = $_VENDOR[$vendorName];
	else
	{
	 $ret = GShell("dynarc item-find -ap rubrica -into vendors `".$vendorName."`",$sessid,$shellid);
	 if(!$ret['error'] && count($ret['outarr']['items']))
	  $_VENDOR[$vendorName] = $ret['outarr']['items'][0]['id'];
	 else
	  $_VENDOR[$vendorName] = 0;
	 $vendorId = $_VENDOR[$vendorName];
	}
   }
   $vendorPrice = $itm['vendorprice'];
   $db2 = new AlpaDatabase();
   if($isUpdated)
   {
    $db2->RunQuery("SELECT id FROM dynarc_".$_AP."_vendorprices WHERE item_id='".$_ID."' AND (vendor_id='".$vendorId."' OR vendor_name='"
	 .$db2->Purify($vendorName)."')");
	if($db2->Read())
	{
	 // aggiorna i prezzi fornitore
	 $db2->RunQuery("UPDATE dynarc_".$_AP."_vendorprices SET vendor_id='".$vendorId."',vendor_name='".$db2->Purify($vendorName)."',price='"
		.$vendorPrice."',vatrate='".$itm['vat']."' WHERE id='".$db2->record['id']."'");
     if($db2->Error)
      return array("message"=>"MySQL Error: ".$db2->Error, "error"=>"MYSQL_ERROR");
	}
    else
    {
	 // registra i prezzi fornitore
     $db2->RunQuery("INSERT INTO dynarc_".$_AP."_vendorprices (item_id,code,vendor_id,vendor_name,price,vatrate) VALUES('".$_ID."','"
	  .$vencode."','".$vendorId."','".$db2->Purify($vendorName)."','".$vendorPrice."','".$itm['vat']."')");
     if($db2->Error)
      return array("message"=>"MySQL Error: ".$db2->Error, "error"=>"MYSQL_ERROR");
    }
   }
   else
   {
	// registra i prezzi fornitore
    $db2->RunQuery("INSERT INTO dynarc_".$_AP."_vendorprices (item_id,code,vendor_id,vendor_name,price,vatrate) VALUES('".$_ID."','"
	 .$vencode."','".$vendorId."','".$db2->Purify($vendorName)."','".$vendorPrice."','".$itm['vat']."')");
    if($db2->Error)
     return array("message"=>"MySQL Error: ".$db2->Error, "error"=>"MYSQL_ERROR");
   }
   $db2->Close();
  }
 
 }

 if($catId)
 {
  // aggiorna i totali articoli e categorie
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT COUNT(*) FROM dynarc_".$_AP."_items WHERE trash='0' AND cat_id='".$catId."'");
  $db->Read();
  $totItems = $db->record[0];
  $db->RunQuery("SELECT COUNT(*) FROM dynarc_".$_AP."_categories WHERE trash='0' AND parent_id='".$catId."'");
  $db->Read();
  $totCats = $db->record[0];
  $db->RunQuery("UPDATE dynarc_".$_AP."_categories SET subcat_count='".$totCats."',items_count='".$totItems."',totitems_count='".$totItems."' WHERE id='".$catId."'");
  $db->Close();
 }

 return array('message'=>"done!");
}
//-------------------------------------------------------------------------------------------------------------------//

