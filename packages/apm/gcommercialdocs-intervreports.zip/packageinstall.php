<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `commdocs-intervreports` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new category */
$_SHELL_OUT.= "Create new category Rapportini di intervento...";
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Rapp. d'intervento` -tag INTERVREPORTS -group `commdocs-intervreports` --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) 
{ 
 $_SHELL_ERR = $ret['error']; 
 $_SHELL_OUT = $ret['message']; 
} 
else 
 $_SHELL_OUT.= $ret['message'];

// CREATE INTERVENTION REPORT PRINT MODEL //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag INTERVREPORTS",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Rapp. d'intervento` -tag `INTERVREPORTS` -pt commercialdocs -group commdocs-intervreports",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-intervreport.xml -ap `printmodels` -ct INTERVREPORTS",$_SESSION_ID,$_SHELL_ID);
}