/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2012 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 23-03-2012
 #PACKAGE: gorganizer
 #DESCRIPTION: Simple Organizer object
 #VERSION: 2.0beta
 #CHANGELOG:
 #DEPENDS: 23-03-2012 : Modificato gbox con gframe.
		   27-09-2011 : Non-working area added
 #TODO:
 
*/


function GOrganizer(obj, options, numofcolumns, datefrom)
{
 this.O = obj;
 this.options = options ? options : {toolbar : false}
 this.dateFrom = new Date();
 this.dateTo = new Date();
 if(datefrom)
  this.dateFrom.setFromISO(datefrom);
 this.Blocks = new Array();
 this.options.numofcolumns = numofcolumns ? numofcolumns : 7;

 /* EVENTS */
 this.OnBlockMove = null;
 this.OnBlockResize = null;
 this.OnUpdateRequest = null;
 this.OnBlockMenuButtonClick = null;
 this.OnDeleteBlock = null;
 this.OnNewColumn = null;

 this.init();
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype.init = function()
{
 var oThis = this;

 var tb = document.createElement('TABLE');
 tb.cellSpacing=0; tb.cellPadding=0; tb.border=0;
 tb.className = "gorganizer-mastertable";
 var r = tb.insertRow(-1);
 r.className = "days";
 r.insertCell(-1).innerHTML = "&nbsp"; r.cells[0].className = "topleft";
 this._masterTable = tb;

 /* DAYS DIV */ 
 var dD = document.createElement('DIV');
 dD.className = "days";
 r.insertCell(-1).appendChild(dD);

 var dtb = document.createElement('TABLE');
 dtb.cellSpacing=0; dtb.cellPadding=0; dtb.border=0;
 dtb.className = "daytb";

 dD.appendChild(dtb);
 this._daysDiv = dD;
 this._daysTable = dtb;

 this.O.appendChild(tb);
 dD.style.width = dD.offsetWidth;

 var d = new Date();
 var now = d.printf('H');

 var r = dtb.insertRow(-1);

 /* HOURS DIV */
 var r = tb.insertRow(-1);
 var hD = document.createElement('DIV');
 hD.className = "hours";
 hD.style.height = this.O.offsetHeight - dD.offsetHeight;
 for(var c=0; c < 24; c++)
 {
  var d = document.createElement('DIV');
  d.className = "hour";
  d.innerHTML = ((c<10) ? "0"+c : c)+":00";
  hD.appendChild(d);
 }
 r.insertCell(-1).appendChild(hD);

 /* GRID DIV */
 var gD = document.createElement('DIV');
 gD.className = "grid";
 gD.style.height = this.O.offsetHeight - dD.offsetHeight;
 gD.style.width = dD.offsetWidth;
 r.insertCell(-1).appendChild(gD);
 this._gridDiv = gD;

 /* COLUMNS */
 var gtb = document.createElement('TABLE');
 gtb.cellSpacing=0; gtb.cellPadding=0; gtb.border=0;
 var r = gtb.insertRow(-1);
 gD.appendChild(gtb);

 gtb.onmousedown = function(ev){
	 var mouse = _SDDmouseCoords(ev);
	 oThis._gridDiv.mdown = true;
	 oThis._gridDiv.style.cursor = "move";
	 oThis._gridDiv.lastmouse = mouse;
	 oThis._gridDiv.lastscrolltop = oThis._gridDiv.scrollTop;
	 oThis._gridDiv.lastscrollleft = oThis._gridDiv.scrollLeft;
	}

 gtb.onmouseup = function(ev){
	 oThis._gridDiv.style.cursor = "";
	 oThis._gridDiv.mdown = false;
	}

 gtb.ondblclick = function(ev){
	 oThis._onDblClick(ev);
	}

 gD.onmousemove = function(ev){
	 if(!this.mdown)
	  return;
	 var mouse = _SDDmouseCoords(ev);
	 var y = this.lastmouse.y - mouse.y;
	 var x = this.lastmouse.x - mouse.x;
	 this.scrollTop = this.lastscrolltop+y;
	 this.scrollLeft = this.lastscrollleft+x;
	 if(this.scrollLeft >= (this.scrollWidth-this.offsetWidth))
	 {
	  oThis.addColumn();
	 }
	 else if(this.scrollLeft <= 0)
	 {
	  var d = oThis.insertColumn(0);
	  this.scrollLeft+= d.offsetWidth;
	  this.lastscrollleft = this.scrollLeft;
	  this.lastmouse = mouse;
	  var list = this.getElementsByTagName("*");
	  for(var c=0; c < list.length; c++)
	  {
	   if((_SDDgetStyle(list[c],"position") == "absolute") || list[c].style.position=="absolute")
		list[c].style.left = parseFloat(list[c].style.left)+this.sdd_dropoptions.horizontalsnap;
	  }
	 }
	}

 gD.brother = hD;
 gD.sister = dD;
 gD.onscroll = function(){
	 this.brother.scrollTop = this.scrollTop;
	 this.sister.scrollLeft = this.scrollLeft;
	}
 this._gridTable = gtb;
 SDD_HANDLER.setDropableContainer(this._gridDiv,{dragmode : "free", verticalsnap : 19, horizontalsnap : 80},{name:"organizer"});
 this._gridDiv.canDrop = function(obj, objClone, srcContainer){
	 if(oThis.canDrop)
	  return oThis.canDrop(obj, objClone, srcContainer);
	 var d = document.createElement('DIV');
	 d.className = "gcalendarblock";
	 if(obj.tagName == "TR")
	  d.innerHTML = obj.cells[0].innerHTML;
	 else
	  d.innerHTML = obj.innerHTML;
	 this.appendChild(d);
	 SDD_HANDLER.setDraggableObject(d);
	 SDD_HANDLER.setResizeableObject(d, {handles : new Array("top","bottom"), minheight : 19});
	 return d;
	}

 this._gridDiv.canDropExt = function(obj){
	 if(oThis.canDropExt)
	  return oThis.canDropExt(obj);
	 var d = document.createElement('DIV');
	 d.className = "gcalendarblock";
	 if(obj.tagName == "TR")
	  d.innerHTML = obj.cells[0].innerHTML;
	 else
	  d.innerHTML = obj.innerHTML;
	 this.appendChild(d);
	 SDD_HANDLER.setDraggableObject(d);
	 SDD_HANDLER.setResizeableObject(d, {handles : new Array("top","bottom"), minheight : 19});
	 return d;
	}

 for(var c=0; c < this.options.numofcolumns; c++) // default 7
 {
  this.addColumn();
 }

 var from = this._daysTable.rows[0].cells[0].getAttribute('isodate');
 var to = this._daysTable.rows[0].cells[this._daysTable.rows[0].cells.length-1].getAttribute('isodate');
 this.dateFrom.setFromISO(from+" 00:00:00");
 this.dateTo.setFromISO(to+" 00:00:00");
 this.dateTo.NextDate();

 this.startAt(now+":00");
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype.createColumn = function()
{
 var d = document.createElement('DIV');
 d.className = "day-column";
 return d;
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype.addColumn = function()
{
 var se = this._gridDiv.scrollLeft;
 var d = this.createColumn();
 this._gridTable.rows[0].insertCell(-1).appendChild(d);
 var dd = new Date();
 var today = dd.printf('Y-m-d');
 if(this._daysTable.rows[0].cells.length)
 {
  dd.setFromISO(this._daysTable.rows[0].cells[this._daysTable.rows[0].cells.length-1].getAttribute('isodate')+" 00:00:00");
  dd.NextDate();
 }
 else
 {
  dd.setFromISO(this.dateFrom.printf('Y-m-d'));
  dd.Midnight();
 }
 var cell = this._daysTable.rows[0].insertCell(-1);
 var daydiv = document.createElement('DIV');
 daydiv.className = (today == dd.printf('Y-m-d')) ? "today" : "day";
 daydiv.innerHTML = dd.printf('D d/m');
 cell.setAttribute('isodate',dd.printf('Y-m-d'));
 cell.appendChild(daydiv);
 this._gridDiv.scrollLeft = se;

 var from = this._daysTable.rows[0].cells[0].getAttribute('isodate');
 var to = this._daysTable.rows[0].cells[this._daysTable.rows[0].cells.length-1].getAttribute('isodate');
 this.dateFrom.setFromISO(from+" 00:00:00");
 this.dateTo.setFromISO(to+" 00:00:00");

 if(dd.getDay() == 0)
  d.className = "sunday-column";
 else if(today == dd.printf('Y-m-d'))
  d.className = "today-column";

 var f = dd.getTime();
 dd.NextDate();
 var t = dd.getTime();

 if(this.OnUpdateRequest)
  this.OnUpdateRequest(f,t);
 return d;
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype.insertColumn = function(pos)
{
 var se = this._gridDiv.scrollLeft;
 var d = this.createColumn();
 this._gridTable.rows[0].insertCell(pos).appendChild(d);
 var dd = new Date();
 var today = dd.printf('Y-m-d');
 dd.setFromISO(this._daysTable.rows[0].cells[pos].getAttribute('isodate')+" 00:00:00");
 dd.PrevDate();
 var cell = this._daysTable.rows[0].insertCell(pos);
 var daydiv = document.createElement('DIV');
 daydiv.className = (today == dd.printf('Y-m-d')) ? "today" : "day";
 daydiv.innerHTML = dd.printf('D d/m');
 cell.setAttribute('isodate',dd.printf('Y-m-d'));
 cell.appendChild(daydiv);
 this._gridDiv.scrollLeft = se;

 var from = this._daysTable.rows[0].cells[0].getAttribute('isodate');
 var to = this._daysTable.rows[0].cells[this._daysTable.rows[0].cells.length-1].getAttribute('isodate');
 this.dateFrom.setFromISO(from+" 00:00:00");
 this.dateTo.setFromISO(to+" 00:00:00");

 if(dd.getDay() == 0)
  d.className = "sunday-column";
 else if(today == dd.printf('Y-m-d'))
  d.className = "today-column";

 var f = dd.getTime();
 dd.NextDate();
 var t = dd.getTime();

 if(this.OnUpdateRequest)
  this.OnUpdateRequest(f,t);

 return d;
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype.createBlock = function(title, timelength, options)
{
 var oThis = this;
 var tl = 1800;
 
 if(timelength)
 {
  switch(typeof(timelength))
  {
   case 'string' : tl = parse_timelength(timelength); break;
   default : tl = timelength; break;
  }
 }

 /* Detect total height for the block */
 var minutes = tl/60;
 var height = Math.ceil(minutes*1.26);


 var block = document.createElement('DIV');
 block.options = options ? options : {type:"default", color:null};

 var className = "gcalendarblock";
 switch(block.options.type)
 {
  case 'workingarea' : className = "gcalendarblock-wa"; break;
  case 'nonworkingarea' : className = "gcalendarblock-nonwa"; break;
  default : className = "gcalendarblock"; break;
 }

 block.className = className;
 block.style.height = height;
 
 var header = document.createElement('DIV');
 header.className = className+"-header";
 header.innerHTML = "<span>&nbsp;</span>";
 block.appendChild(header);

 if((block.options.type != "workingarea") && (block.options.type != "nonworkingarea"))
 {
  var menuBtn = document.createElement('DIV');
  menuBtn.className = "menubutton";
  menuBtn.innerHTML = "&nbsp;";
  menuBtn.blockref = block;
  menuBtn.onclick = function(){oThis._onBlockMenuButtonClick(this.blockref,this);}
  header.appendChild(menuBtn);
 }

 var contents = document.createElement('DIV');
 contents.className = className+"-contents";
 contents.innerHTML = title;
 contents.title = title;
 contents.style.height = height-24; // 12px for header and 12px for the footer //
 block.appendChild(contents);

 var footer = document.createElement('DIV');
 footer.className = className+"-footer";
 footer.innerHTML = "<span>=</span>";
 block.appendChild(footer);

 block.header = header;
 block.contents = contents;
 block.contents.blockref = block;
 block.footer = footer;

 block.dateFrom = new Date();
 block.dateTo = new Date();
 block.oldDateFrom = new Date();
 block.oldDateTo = new Date();


 block.duringmove = function(){
	 var x = parseFloat(this.style.left);
	 var column = x>0 ? x/oThis._gridDiv.sdd_dropoptions.horizontalsnap : 0;
	 var date = oThis._daysTable.rows[0].cells[column].getAttribute('isodate');
	 this.dateFrom.setFromISO(date);
	 this.dateTo.setFromISO(date);

	 var startmm = Math.floor((60/76)*parseFloat(this.style.top));
	 this.dateFrom.setHours(Math.floor(startmm/60));
	 this.dateFrom.setMinutes(startmm-(this.dateFrom.getHours()*60));
	 this.dateFrom.setSeconds(0);
	 var endmm = Math.ceil((60/76)*(parseFloat(this.style.top)+parseFloat(this.style.height)));
	 this.dateTo.setHours(Math.floor(endmm/60));
	 this.dateTo.setMinutes(endmm-(this.dateTo.getHours()*60));
	 this.dateTo.setSeconds(0);
	 var minFrom = (this.dateFrom.getHours()*60) + this.dateFrom.getMinutes();
	 var minTo = (this.dateTo.getHours()*60) + this.dateTo.getMinutes();
	 this.timeLength = minTo-minFrom;

	 this.header.getElementsByTagName('SPAN')[0].innerHTML = this.dateFrom.printf('H:i')+" - "+this.dateTo.printf('H:i');
	 if(SDD_HANDLER.selectedObjectClone)
	  SDD_HANDLER.selectedObjectClone.getElementsByTagName('SPAN')[0].innerHTML = this.dateFrom.printf('H:i')+" - "+this.dateTo.printf('H:i');
	}

 block.duringresize = function(){
	 this.contents.style.height = parseFloat(this.style.height)-24;
	 var startmm = Math.floor((60/76)*parseFloat(this.style.top));
	 this.dateFrom.setHours(Math.floor(startmm/60));
	 this.dateFrom.setMinutes(startmm-(this.dateFrom.getHours()*60));
	 this.dateFrom.setSeconds(0);
	 var endmm = Math.ceil((60/76)*(parseFloat(this.style.top)+parseFloat(this.style.height)));
	 this.dateTo.setHours(Math.floor(endmm/60));
	 this.dateTo.setMinutes(endmm-(this.dateTo.getHours()*60));
	 this.dateTo.setSeconds(0);
	 this.header.getElementsByTagName('SPAN')[0].innerHTML = this.dateFrom.printf('H:i')+" - "+this.dateTo.printf('H:i');
	 var minFrom = (this.dateFrom.getHours()*60) + this.dateFrom.getMinutes();
	 var minTo = (this.dateTo.getHours()*60) + this.dateTo.getMinutes();
	 this.timeLength = minTo-minFrom;
	}

 block.update = function(){
	 oThis._onBlockUpdate(this);
	 this.contents.style.height = parseFloat(this.style.height)-24;
	 this.header.getElementsByTagName('SPAN')[0].innerHTML = this.dateFrom.printf('H:i')+" - "+this.dateTo.printf('H:i');
	}

 block.setColor = function(col){
	 var path = BASE_PATH+"var/objects/gorganizer/themes/default/blocks/";
	 this.header.style.backgroundImage = "url("+path+"std"+col+"_left.png)";
	 this.header.getElementsByTagName('SPAN')[0].style.backgroundImage = "url("+path+"std"+col+".png)";
	 var color = "";
	 switch(col)
	 {
	  case 'blue' : color = "#3364C3"; break;
	  case 'green' : color = "#339900"; break;
	  case 'maroon' : color = "#816647"; break;
	  case 'orange' : color = "#fb8b00"; break;
	  case 'red' : color = "#e52525"; break;
	  case 'sky' : color = "#0197fd"; break;
	 }
	 this.contents.style.background = color;
	 this.footer.style.backgroundImage = "url("+path+"std"+col+"_left.png)";
	 this.footer.getElementsByTagName('SPAN')[0].style.backgroundImage = "url("+path+"std"+col+".png)";
	}


 block.onmove = function(){
	 oThis._onBlockMove(this);
	}

 block.onresize = function(){
	 oThis._onBlockResize(this);
	}

 if((block.options.type != "workingarea") && (block.options.type != "nonworkingarea"))
  block.contents.onclick = function(){
	 oThis._onBlockClick(this.blockref);
	}
 
 if((block.options.type == "workingarea") || (block.options.type == "nonworkingarea"))
 {
  block.onmousedown = this._gridTable.onmousedown;
  block.onmouseup = this._gridTable.onmouseup;
  block.ondblclick = this._gridTable.ondblclick;
 }

 if(block.options.color)
  block.setColor(block.options.color);

 this.Blocks.push(block);


 return block;
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype.addBlock = function(from, to, title, options)
{
 var block = this.createBlock(title, null, options);
 if(typeof(from) == "string")
  block.dateFrom.setFromISO(from);
 else
  block.dateFrom.setTime(from);
 if(typeof(to) == "string")
  block.dateTo.setFromISO(to);
 else
  block.dateTo.setTime(to);

 block.oldDateFrom.setTime(block.dateFrom.getTime());
 block.oldDateTo.setTime(block.dateTo.getTime());

 this._gridDiv.appendChild(block);

 if((block.options.type != "workingarea") && (block.options.type != "nonworkingarea"))
 {
  SDD_HANDLER.setDraggableObject(block);
  SDD_HANDLER.setResizeableObject(block, {handles : new Array("top","bottom"), minheight : 19});
 }

 block.update();

 return block;
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype._onBlockMove = function(block)
{
 if(this.OnBlockMove)
  this.OnBlockMove(block);
 block.oldDateFrom.setTime(block.dateFrom.getTime());
 block.oldDateTo.setTime(block.dateTo.getTime());
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype._onBlockResize = function(block)
{
 if(this.OnBlockResize)
  this.OnBlockResize(block);
 block.oldDateFrom.setTime(block.dateFrom.getTime());
 block.oldDateTo.setTime(block.dateTo.getTime());
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype._onBlockUpdate = function(block)
{
 var gorgFrom = this._daysTable.rows[0].cells[0].getAttribute('isodate');
 var gorgTo = this._daysTable.rows[0].cells[this._daysTable.rows[0].cells.length-1].getAttribute('isodate');

 var dF = new Date();
 dF.setFromISO(gorgFrom);
 var dT = new Date();
 dT.setFromISO(gorgTo);
 dT.NextDate();

 if(block.dateFrom.getTime() < dF.getTime())
  return;
 if(block.dateFrom.getTime() > dT.getTime())
  return;

 var day = 86400*1000;
 var diff = block.dateFrom.getTime() - dF.getTime();
 var column = Math.floor(diff/day);
 
 block.timeLength = Math.floor(((block.dateTo.getTime()-block.dateFrom.getTime())/1000)/60);
 block.style.height = (76/60) * block.timeLength;

 /* Move the block */
 block.style.left = column*this._gridDiv.sdd_dropoptions.horizontalsnap;
 block.style.top = Math.floor( (block.dateFrom.getHours()*76)+(block.dateFrom.getMinutes()*(76/60)) );

}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype._onBlockClick = function(block)
{
 if(this.OnBlockClick)
  this.OnBlockClick(block);
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype.update = function()
{
 if(this.OnUpdateRequest)
  this.OnUpdateRequest(this.dateFrom.getTime(), this.dateTo.getTime());
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype.reload = function()
{
 for(var c=0; c < this.Blocks.length; c++)
 {
  var block = this.Blocks[c];
  SDD_HANDLER.unsetDraggableObject(block);
  if(block.parentNode)
   block.parentNode.removeChild(block);
 }
 this.update();
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype._onBlockMenuButtonClick = function(block,elem)
{
 var oThis = this;
 if(this.OnBlockMenuButtonClick)
  return this.OnBlockMenuButtonClick(block);

 var sh = new GShell();
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 switch(a['action'])
	 {
	  case 'delete-event' : {
		 if(oThis.OnDeleteBlock)
		  oThis.OnDeleteBlock(block);
		} break;
	 }
	 oThis.reload();
	}

 if(block.data)
 {
  if(block.data['is_recurrence'])
   sh.sendCommand("gframe -f cronevent.edit -params `ap="+block.data['archive']+"&rid="+block.data['id']+"&from="+block.dateFrom.printf('Y-m-d')+"` --fullspace");
  else
   sh.sendCommand("gframe -f cronevent.edit -params `ap="+block.data['archive']+"&id="+block.data['id']+"` --fullspace");
 }
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype._onDblClick = function(ev)
{
 var oThis = this;

 var mouse = _SDDmouseCoords(ev);
 var pos = _SDDgetObjectPosition(this._gridTable);
 var x = mouse.x - pos.x;
 var y = mouse.y - pos.y;
 x+= this._gridDiv.scrollLeft;
 y+= this._gridDiv.scrollTop;
 var column = x>0 ? Math.floor(x/this._gridDiv.sdd_dropoptions.horizontalsnap) : 0;
 var date = this._daysTable.rows[0].cells[column].getAttribute('isodate');
 var dateFrom = new Date();
 dateFrom.setFromISO(date);

 var startmm = Math.floor((60/76)*parseFloat( Math.floor(y/38)*38 ));
 dateFrom.setHours(Math.floor(startmm/60));
 dateFrom.setMinutes(startmm-(dateFrom.getHours()*60));
 dateFrom.setSeconds(0);

 if(this.OnDblClick)
  return this.OnDblClick(dateFrom);

 var sh = new GShell();
 sh.OnOutput = function(){
	 oThis.reload();
	}
 sh.sendCommand("gframe -f cronevent.new -params `from="+dateFrom.printf('Y-m-d H:i')+"` --fullspace");
}
//-------------------------------------------------------------------------------------------------------------------//
GOrganizer.prototype.startAt = function(timeStr)
{
 var t = new Date();
 t.setFromISO(t.printf('Y-m-d')+" "+timeStr);
 this._gridDiv.scrollTop = Math.floor( (t.getHours()*76)+(t.getMinutes()*(76/60)) );
}
//-------------------------------------------------------------------------------------------------------------------//


