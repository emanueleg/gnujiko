<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2011 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 09-05-2011
 #PACKAGE: gorganizer
 #DESCRIPTION: Simple Organizer object
 #VERSION: 2.0beta
 #CHANGELOG:
 #DEPENDS:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;

include_once($_BASE_PATH."var/objects/superdraganddrop/index.php");
include_once($_BASE_PATH."var/objects/htmlgutility/menu.php");

?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL; ?>var/objects/gorganizer/themes/default/default.css" type="text/css" />
<script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>var/objects/gorganizer/gorganizer.js" type="text/javascript"></script>
<?php

