<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2018 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 15-01-2018
 #PACKAGE: gnujiko-template
 #DESCRIPTION: Header class for Gnujiko Template.
 #VERSION: 2.2beta
 #CHANGELOG: 15-01-2018 : Aggiornata funzione SendCommand.
			 22-05-2017 : Aggiunto parametro agentid su funzione addObjectSearch.
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;

include_once($_BASE_PATH."include/htmlparsehelper.php");

class GnujikoTemplateExtendedTable
{
 var $Template, $ID, $Style, $Fields, $Rows, $debug, $THead, $SERP;

 function GnujikoTemplateExtendedTable($tplH, $id, $style='default', $params=null)
 {
  if(!$params) $params = array();
  $this->Template = $tplH;
  $this->ID = $id;
  $this->Style = $style ? $style : "default";
  $this->Fields = array();
  $this->FieldByTag = array();
  $this->Rows = array();
  $this->RowsDataKeys = array();
  $this->debug = "";
  $this->JavaScript = "";

  $this->THead = null;
  $this->TBody = null;
  $this->TFoot = null;

  // SERP
  $this->Template->includeInternalObject("serp");
  $_DEF_RPP = 50;
  $_ORDER_BY = (isset($_REQUEST['sortby']) && $_REQUEST['sortby']) ? $_REQUEST['sortby'] : "name";
  $_ORDER_METHOD = (isset($_REQUEST['sortmethod']) && $_REQUEST['sortmethod']) ? strtoupper($_REQUEST['sortmethod']) : "ASC";
  $_RPP = (isset($_REQUEST['rpp']) && $_REQUEST['rpp']) ? $_REQUEST['rpp'] : $_DEF_RPP;
  $_PG = (isset($_REQUEST['pg']) && $_REQUEST['pg']) ? $_REQUEST['pg'] : 1;

  $this->SERP = new SERP();
  $this->SERP->setOrderBy($_ORDER_BY);
  $this->SERP->setOrderMethod($_ORDER_METHOD);
  $this->SERP->setResultsPerPage($_RPP);
  $this->SERP->setCurrentPage($_PG);
  $this->Results = array();

  // STYLE
  $this->styleAP = "";
  $this->styleID = 0;
  $this->schemaHTML = "";
  $this->schemaCSS = "";

  // CONFIG
  $this->config = array(
	 'defaultrowheight' => 0
	);

  $this->ClassName = "sortable-table";

  $this->cache = array();
 }
 //------------------------------------------------------------------------------------------------------------------//
 function LoadStyle($styleId, $ap="idoc")
 {
  $ret = GShell("dynarc item-info -ap '".$ap."' -id '".$styleId."' -extget `css,javascript`");
  if(!$ret['error'])
  {
   $this->styleAP = $ap;
   $this->styleID = $styleId;
   $this->initStyle($ret['outarr']);
  }
 }
 //------------------------------------------------------------------------------------------------------------------//
 function SendCommand($_CMD,$retArrName="items",$secondretArrName="")
 {
  $ret = $this->SERP->SendCommand($_CMD,$retArrName,$secondretArrName);
  $this->Results = $this->SERP->Return;
  $list = $ret[$retArrName];
  for($c=0; $c < count($list); $c++)
   $this->AddRow($list[$c]);
 }
 //------------------------------------------------------------------------------------------------------------------//
 function DrawSerpButtons($includeResultsString=true)
 {
  $this->JavaScript.= "this.SERP = new SERP('".$this->SERP->OrderBy."','".$this->SERP->OrderMethod."','".$this->SERP->RPP."','".$this->SERP->PG."');\n";

  return $this->SERP->DrawSerpButtons($includeResultsString, "SERP", true);
 }
 //------------------------------------------------------------------------------------------------------------------//
 function DrawSerpRPP($id="rpp", $text="<span class='smalltext'>Mostra</span>")
 {
  $menu = array(
	 0 => array('title'=>'10 righe', 'value'=>'10'),
	 1 => array('title'=>'25 righe', 'value'=>'25'),
	 2 => array('title'=>'50 righe', 'value'=>'50'),
	 3 => array('title'=>'100 righe', 'value'=>'100'),
	 4 => array('title'=>'250 righe', 'value'=>'250'),
	 5 => array('title'=>'500 righe', 'value'=>'500'),
	);

  $out = $text;
  $out.= " <input type='text' class='dropdown' id='".$id."' value='".$this->SERP->RPP." righe' retval='"
	.$this->SERP->RPP."' readonly='true' connect='".$id."list' style='width:100px'/>";
  $out.= $this->Template->generatePopupMenu($menu, $id.'list', 'select');

  $this->JavaScript.= "this.initEd(document.getElementById('".$id."'), 'dropdown').onchange = function(){\n";
  $this->JavaScript.= "		 Template.SERP.RPP = this.getValue();\n";
  $this->JavaScript.= "		 Template.SERP.reload(0);\n";
  $this->JavaScript.= "		}\n";

  return $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function AddFields($dataFields)
 {
  if(!is_array($dataFields) || empty($dataFields)) return false;
  reset($dataFields);
  while(list($k,$v) = each($dataFields))
  {
   $field = $this->AddField($k, $v['title'], $v);
  }

 }
 //------------------------------------------------------------------------------------------------------------------//
 function AddField($key, $title="", $data)
 {
  $field = new GnujikoTemplateExtendedTableField($this, $key, $title, $data);
  $field->idx = count($this->Fields);
  $this->Fields[] = $field;
  $this->FieldByKey[$key] = $field;
  return $field;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function AddRow($data)
 {
  $row = new GnujikoTemplateExtendedTableRow($this, count($this->Rows), $data);
  $this->Rows[] = $row;
  return $row;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function Paint($retAsString=false)
 {
  if($this->styleAP && $this->styleID)
   return $this->PaintFromSchema($retAsString);
  
  $out = "<table width='100%' cellspacing='0' cellpadding='0' class='".$this->ClassName."' id='".$this->ID."'>";
  $out.= "<tr>";
  for($c=0; $c < count($this->Fields); $c++)
   $out.= $this->Fields[$c]->Paint(true);
  $out.= "</tr>";

  $rowIdx = 0;
  for($c=0; $c < count($this->Rows); $c++)
  {
   $out.= $this->Rows[$c]->Paint(true, "row".$rowIdx);
   $rowIdx = $rowIdx ? 0 : 1;
  }

  $out.= "</table>";

  $this->JavaScript.= " this.initSortableTable(document.getElementById('".$this->ID."'));\n";

  if($retAsString) return $out;
  echo $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function PaintFromSchema($retAsString=false)
 {
  // Detect start point
  $startPoint = 0;
  if($this->THead) $startPoint = $this->THead->startPointer;
  else if($this->TBody) $startPoint = $this->TBody->startPointer;

  $out = substr($this->schemaHTML, 0, $startPoint);

  if($this->THead) $out.= $this->PaintHead();
  if($this->TFoot) $out.= $this->PaintFooter();
  if($this->TBody) $out.= $this->PaintBody();

  // Detect end point
  $endPoint = 0;
  if($this->TBody) $endPoint = $this->TBody->endPointer;
  $out.= substr($this->schemaHTML, $endPoint);

  // Include CSS
  $out = $this->schemaCSS.$out;

  if($retAsString) return $out;
  echo $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function PaintHead()
 {
  $out.= $this->THead->Paint(true);
  for($c=0; $c < count($this->Fields); $c++)
   $this->addHeadColumn($this->Fields[$c]);

  for($c=0; $c < count($this->cache['thead']['rows']); $c++)
  {
   $TR = $this->cache['thead']['rows'][$c]['el'];
   $out.= $TR->Paint(true);
   for($i=0; $i < count($this->cache['thead']['rows'][$c]['cells']); $i++)
   {
	$cell = $this->cache['thead']['rows'][$c]['cells'][$i];
	if(!$cell) continue;
	$out.= $this->cache['thead']['rows'][$c]['cells'][$i]['content'];
   }
   $out.= "</tr>";
  }

  $out.= "</thead>";
  return $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function PaintFooter()
 {
  $out.= $this->TFoot->Paint(true);
  for($c=0; $c < count($this->Fields); $c++)
   $this->addFootColumn($this->Fields[$c]);

  for($c=0; $c < count($this->cache['tfoot']['rows']); $c++)
  {
   $TR = $this->cache['tfoot']['rows'][$c]['el'];
   $out.= $TR->Paint(true);
   for($i=0; $i < count($this->cache['tfoot']['rows'][$c]['cells']); $i++)
   {
	$cell = $this->cache['tfoot']['rows'][$c]['cells'][$i];
	if(!$cell) continue;
	$out.= $this->cache['tfoot']['rows'][$c]['cells'][$i]['content'];
   }
   $out.= "</tr>";
  }
  $out.= "</tfoot>";
  return $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function PaintBody()
 {
  $out.= $this->TBody->Paint(true);

   for($c=0; $c < count($this->Rows); $c++)
   {
	$Row = $this->Rows[$c];
    $rowIdx = $this->cache['tbody']['next_row_idx'];
    $TR = $this->cache['tbody']['rows'][$rowIdx]['el'];
    $out.= $TR->Paint(true);
    for($i=0; $i < count($this->cache['tbody']['rows'][$rowIdx]['cells']); $i++)
    {
	 $cell = $this->cache['tbody']['rows'][$rowIdx]['cells'][$i];
	 if(!$cell) continue;
	 $TD = $this->cache['tbody']['rows'][$rowIdx]['cells'][$i]['el'];
	 $CL = $Row->Cells[$i];
	 $content = $CL ? $CL->content : "";
	 $out.= $TD->Paint('true').$content."</td>";
    }
	$out.= "</tr>";
    $this->cache['tbody']['next_row_idx']++;
    if($this->cache['tbody']['next_row_idx'] > 1) $this->cache['tbody']['next_row_idx'] = 0;
   }
  

  $out.= "</body>";
  return $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function setRowsDataKeys($keys)
 {
  $this->RowsDataKeys = explode(",",$keys);
 }
 //------------------------------------------------------------------------------------------------------------------//
 function setRowHeight($height)
 {
  $this->config['defaultrowheight'] = $height;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function setClassName($className="")
 {
  $this->ClassName = "sortable-table".($className ? " ".$className : "");
 }
 //------------------------------------------------------------------------------------------------------------------//
 //--- PRIVATE ------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
 function initStyle($styleInfo)
 {
  $content = $styleInfo['desc'];

  $html = new HTMLParseHelper($content);
  // Get THEAD
  $list = $html->GetElementsByTagName('THEAD');
  if(count($list)) $this->initTHead($list[0]);

  // Get TFOOT  
  $list = $html->GetElementsByTagName('TFOOT');
  if(count($list)) $this->initTFoot($list[0]);

  // Get TBODY
  $list = $html->GetElementsByTagName('TBODY');
  if(count($list)) $this->initTBody($list[0]);

  if(count($styleInfo['css']))
   $this->schemaCSS.= "<style type='text/css'>".$styleInfo['css'][0]['content']."</style>";

  $this->schemaHTML.= $content;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function initTHead($node)
 {
  $this->THead = $node;
  $this->cache['thead'] = array('rows'=>array(), 'next_col_idx'=>0, 'schema_col_count'=>0, 'unclonable_cells_count'=>0);

  $list = $node->GetElementsByTagName('TR');
  if(!count($list)) return;
  for($c=0; $c < count($list); $c++)
  {
   $TR = $list[$c];
   $tdlist = $TR->GetElementsByTagName('TD');
   $this->cache['thead']['schema_col_count'] = count($tdlist);
   if(!is_array($this->cache['thead']['rows'][$c]))
	$this->cache['thead']['rows'][$c] = array('el'=>$TR, 'cells'=>array(), 'clonablecells'=>array());

   // get cells
   for($i=0; $i < count($tdlist); $i++)
   {
	$TD = $tdlist[$i];
	$TD->data['cellidx'] = $i;
	$clonable = ($TD->property['data-clonable'] == "false") ? false : true;
	$this->cache['thead']['rows'][$c]['cells'][] = array('el'=>$TD, 'clonable'=>$clonable, 'content'=>"");
	if($clonable) $this->cache['thead']['rows'][$c]['clonablecells'][] = $TD;
	else $this->cache['thead']['unclonable_cells_count']++;
	$rowspan = intval($TD->property['rowspan']);
	if($rowspan > 1)
	{
	 for($j=$c+1; $j < ($c+$rowspan); $j++)
	 {
	  $this->cache['thead']['rows'][$j] = array('el'=>$list[$j], 'cells'=>array(), 'clonablecells'=>array());
	  $this->cache['thead']['rows'][$j]['cells'][] = false;	// virtual hidden cell
	 }
	}
   }
  }
 }
 //------------------------------------------------------------------------------------------------------------------//
 function initTFoot($node)
 {
  $this->TFoot = $node;
  $this->cache['tfoot'] = array('rows'=>array(), 'next_col_idx'=>0, 'schema_col_count'=>0, 'unclonable_cells_count'=>0);

  $list = $node->GetElementsByTagName('TR');
  if(!count($list)) return;
  for($c=0; $c < count($list); $c++)
  {
   $TR = $list[$c];
   $tdlist = $TR->GetElementsByTagName('TD');
   $this->cache['tfoot']['schema_col_count'] = count($tdlist);
   if(!is_array($this->cache['tfoot']['rows'][$c]))
	$this->cache['tfoot']['rows'][$c] = array('el'=>$TR, 'cells'=>array(), 'clonablecells'=>array());

   // get cells
   for($i=0; $i < count($tdlist); $i++)
   {
	$TD = $tdlist[$i];
	$TD->data['cellidx'] = $i;
	$clonable = ($TD->property['data-clonable'] == "false") ? false : true;
	$this->cache['tfoot']['rows'][$c]['cells'][] = array('el'=>$TD, 'clonable'=>$clonable, 'content'=>"");
	if($clonable) $this->cache['tfoot']['rows'][$c]['clonablecells'][] = $TD;
	else $this->cache['tfoot']['unclonable_cells_count']++;
	$rowspan = intval($TD->property['rowspan']);
	if($rowspan > 1)
	{
	 for($j=$c+1; $j < ($c+$rowspan); $j++)
	 {
	  $this->cache['tfoot']['rows'][$j] = array('el'=>$list[$j], 'cells'=>array(), 'clonablecells'=>array());
	  $this->cache['tfoot']['rows'][$j]['cells'][] = false;	// virtual hidden cell
	 }
	}
   }
  }
 }
 //------------------------------------------------------------------------------------------------------------------//
 function initTBody($node)
 {
  $this->TBody = $node;
  $this->cache['tbody'] = array('rows'=>array(), 'next_col_idx'=>0, 'schema_col_count'=>0, 'unclonable_cells_count'=>0, 'next_row_idx'=>0);

  $list = $node->GetElementsByTagName('TR');
  if(!count($list)) return;
  for($c=0; $c < count($list); $c++)
  {
   $TR = $list[$c];
   $tdlist = $TR->GetElementsByTagName('TD');
   $this->cache['tbody']['schema_col_count'] = count($tdlist);
   if(!is_array($this->cache['tbody']['rows'][$c]))
	$this->cache['tbody']['rows'][$c] = array('el'=>$TR, 'cells'=>array(), 'clonablecells'=>array());

   // get cells
   for($i=0; $i < count($tdlist); $i++)
   {
	$TD = $tdlist[$i];
	$TD->data['cellidx'] = $i;
	$clonable = ($TD->property['data-clonable'] == "false") ? false : true;
	$this->cache['tbody']['rows'][$c]['cells'][] = array('el'=>$TD, 'clonable'=>$clonable, 'content'=>"");
	if($clonable) $this->cache['tbody']['rows'][$c]['clonablecells'][] = $TD;
	else $this->cache['tbody']['unclonable_cells_count']++;
	/*$rowspan = intval($TD->property['rowspan']);
	if($rowspan > 1)
	{
	 for($j=$c+1; $j < ($c+$rowspan); $j++)
	 {
	  $this->cache['tbody']['rows'][$j] = array('el'=>$list[$j], 'cells'=>array(), 'clonablecells'=>array());
	  $this->cache['tbody']['rows'][$j]['cells'][] = false;	// virtual hidden cell
	 }
	}*/
   }
  }
 }
 //------------------------------------------------------------------------------------------------------------------//
 function addHeadColumn($field)
 {
  $ncidx = $this->cache['thead']['next_col_idx'];
  $COL = array('cells'=>array(), 'idx'=>$ncidx);

  $idx = $ncidx;
  $addcol = false;
  $ccount = $this->cache['thead']['schema_col_count'];
  if($idx >= count($this->cache['thead']['rows'][0]['cells']))
  {
   $cclist = $this->cache['thead']['rows'][0]['clonablecells'];
   $cccount = count($cclist);
   if($cccount)
   {
	$idx = $ncidx - (floor($ncidx/$cccount)*$cccount) - $this->cache['thead']['unclonable_cells_count'];
	$el = $this->cache['thead']['rows'][0]['clonablecells'][$idx];
	$idx = $el->data['cellidx'] ? $el->data['cellidx'] : 0;
	$addcol = true;
   }
  } 

  for($c=0; $c < count($this->cache['thead']['rows']); $c++)
  {
   $row = $this->cache['thead']['rows'][$c];
   $cell = $row['cells'][$idx];
   if(!$cell) continue;
   $el = $cell['el'];
   if(!$el) continue;

   if($addcol)
	$this->cache['thead']['rows'][$c]['cells'][] = array('el'=>$el, 'clonable'=>true, 'content'=>$el->parseHTML(array('{FIELD_TITLE}','{FIELD_SUBTITLE}'), array($field->title,$field->data['subtitle'])));
   else
	$this->cache['thead']['rows'][$c]['cells'][$ncidx]['content'] = $el->parseHTML(array('{FIELD_TITLE}','{FIELD_SUBTITLE}'), array($field->title,$field->data['subtitle']));

   if(intval($el->property['rowspan']) > 1)
	$c+= intval($el->property['rowspan'])-1;
  }

  $this->cache['thead']['next_col_idx']++;
  $this->addBodyColumn($field);
  return $COL;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function addFootColumn($field)
 {
  $ncidx = $this->cache['tfoot']['next_col_idx'];
  $COL = array('cells'=>array(), 'idx'=>$ncidx);

  $idx = $ncidx;
  $addcol = false;
  $ccount = $this->cache['thead']['schema_col_count'];
  if($idx >= count($this->cache['tfoot']['rows'][0]['cells']))
  {
   $cclist = $this->cache['tfoot']['rows'][0]['clonablecells'];
   $cccount = count($cclist);
   if($cccount)
   {
	$idx = $ncidx - (floor($ncidx/$cccount)*$cccount) - $this->cache['tfoot']['unclonable_cells_count'];
	$el = $this->cache['tfoot']['rows'][0]['clonablecells'][$idx];
	$idx = $el->data['cellidx'] ? $el->data['cellidx'] : 0;
	$addcol = true;
   }
  } 

  for($c=0; $c < count($this->cache['tfoot']['rows']); $c++)
  {
   $row = $this->cache['tfoot']['rows'][$c];
   $cell = $row['cells'][$idx];
   if(!$cell) continue;
   $el = $cell['el'];
   if(!$el) continue;

   if($addcol)
	$this->cache['tfoot']['rows'][$c]['cells'][] = array('el'=>$el, 'clonable'=>true, 'content'=>$el->parseHTML(array('{FIELD_TITLE}','{FIELD_SUBTITLE}'), array($field->title,$field->data['subtitle'])));
   else
	$this->cache['tfoot']['rows'][$c]['cells'][$ncidx]['content'] = $el->parseHTML(array('{FIELD_TITLE}','{FIELD_SUBTITLE}'), array($field->title,$field->data['subtitle']));

   if(intval($el->property['rowspan']) > 1)
	$c+= intval($el->property['rowspan'])-1;
  }

  $this->cache['tfoot']['next_col_idx']++;
  return $COL;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function addBodyColumn($field)
 {
  $ncidx = $this->cache['tbody']['next_col_idx'];
  $COL = array('cells'=>array(), 'idx'=>$ncidx);

  $idx = $ncidx;
  $addcol = false;
  $ccount = $this->cache['tbody']['schema_col_count'];
  if($idx >= count($this->cache['tbody']['rows'][0]['cells']))
  {
   $cclist = $this->cache['tbody']['rows'][0]['clonablecells'];
   $cccount = count($cclist);
   if($cccount)
   {
	$idx = $ncidx - (floor($ncidx/$cccount)*$cccount) - $this->cache['tbody']['unclonable_cells_count'];
	$el = $this->cache['tbody']['rows'][0]['clonablecells'][$idx];
	$idx = $el->data['cellidx'] ? $el->data['cellidx'] : 0;
	$addcol = true;
   }
  } 

  for($c=0; $c < count($this->cache['tbody']['rows']); $c++)
  {
   $row = $this->cache['tbody']['rows'][$c];
   $cell = $row['cells'][$idx];
   if(!$cell) continue;
   $el = $cell['el'];
   if(!$el) continue;

   if($addcol)
	$this->cache['tbody']['rows'][$c]['cells'][] = array('el'=>$el, 'clonable'=>true, 'content'=>"");
   else
	$this->cache['tbody']['rows'][$c]['cells'][$ncidx]['content'] = "";

   /*if(intval($el->property['rowspan']) > 1)
	$c+= intval($el->property['rowspan'])-1;*/
  }

  $this->cache['tbody']['next_col_idx']++;
  return $COL;
 }
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//



//-------------------------------------------------------------------------------------------------------------------//
//--- CLASS - FIELD -------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
class GnujikoTemplateExtendedTableField
{
 var $Table, $key, $title, $data;
 function GnujikoTemplateExtendedTableField($tbH, $key, $title="", $data=null)
 {
  $this->Table = $tbH;
  $this->key = $key;
  $this->title = $title;
  $this->data = $data ? $data : array();
  $this->idx = 0;	// autoset by function Table->AddField
 }
 //------------------------------------------------------------------------------------------------------------------//
 function Paint($retAsString=false)
 {
  $out = "<th data-field='".$this->key."'";
  $style = "";

  if(($this->data['type'] == "checkbox") && !$this->data['width']) $this->data['width'] = 22;

  if($this->data['width'])			$out.= " width='".$this->data['width']."'";
  if($this->data['fieldalign'])		$style.= "text-align:".$this->data['fieldalign'].";";
  else if($this->data['align'])		$style.= "text-align:".$this->data['align'].";";

  if($style) $out.= " style='".$style."'";
  $out.= ">";

  switch($this->data['type'])
  {
   case 'checkbox' : $out.= "<input type='checkbox'/>"; break;
   default : $out.= $this->title ? $this->title : "&nbsp;"; break;
  }

  $out.= "</th>";

  if($retAsString) return $out;
  echo $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//

}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//



//-------------------------------------------------------------------------------------------------------------------//
//--- CLASS - ROW ---------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
class GnujikoTemplateExtendedTableRow
{
 var $Table, $Cells, $data, $idx, $htmlContent;
 function GnujikoTemplateExtendedTableRow($tbH, $idx, $data=null)
 {
  $this->Table = $tbH;
  $this->data = $data ? $data : array();
  $this->idx = $idx;
  $this->Cells = array();
  $this->htmlContent = "";

  $this->init();
 }
 //------------------------------------------------------------------------------------------------------------------//
 function init()
 {
  if(!empty($this->data))
  {
   for($c=0; $c < count($this->Table->Fields); $c++)
   {
    $field = $this->Table->Fields[$c];
    $cell = $this->AddCell($this->data[$field->key]);
   }
  }
 }
 //------------------------------------------------------------------------------------------------------------------//
 function SetHTML($html="") { $this->htmlContent = $html; }
 //------------------------------------------------------------------------------------------------------------------//
 function AddCell($data)
 {
  $cell = new GnujikoTemplateExtendedTableCell($this->Table, $this, count($this->Cells), $data);
  $this->Cells[] = $cell;
  return $cell;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function parseString($string="")
 {
  reset($this->data);
  while(list($k,$v) = each($this->data))
  {
   $string = str_replace("%".$k, $v, $string);
  }
  return $string;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function Paint($retAsString=false, $className="")
 {
  if($this->htmlContent)
  {
   if($retAsString)	return $this->htmlContent;
   echo $this->htmlContent;
   return;
  }

  $out = "<tr id='".$this->data['id']."'".($className ? " class='".$className."'" : "");
  for($c=0; $c < count($this->Table->RowsDataKeys); $c++)
  {
   $k = $this->Table->RowsDataKeys[$c];
   $v = $this->data[$k];
   $out.= " data-".$k."='".$v."'";
  }
  $out.= ">";

  for($c=0; $c < count($this->Cells); $c++)
   $out.= $this->Cells[$c]->Paint(true);
  $out.= "</tr>";

  if($retAsString)	return $out;
  echo $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//

}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//



//-------------------------------------------------------------------------------------------------------------------//
//--- CLASS - CELL --------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
class GnujikoTemplateExtendedTableCell
{
 var $Table, $Row, $idx, $data;
 function GnujikoTemplateExtendedTableCell($tbH, $rowH, $idx=0, $value="")
 {
  $this->Table = $tbH;
  $this->Row = $rowH;
  $this->value = $value;
  $this->idx = $idx;
  $this->content = "";
  $this->colspan = 1;

  $this->init();
 }
 //------------------------------------------------------------------------------------------------------------------//
 function init()
 {
  $field = $this->Table->Fields[$this->idx];
  $value = $this->value;
  $color = $field->data['color'] ? $field->data['color'] : "black";
  $RGBColor = (substr($color,0,1) == "#") ? $color : "";
  $fontSize = $field->data['fontsize'] ? $field->data['fontsize'] : 0;
  $fontFamily = $field->data['fontfamily'] ? $field->data['fontfamily'] : "";
  $fontWeight = $field->data['fontweight'] ? $field->data['fontweight'] : "";

  // Style of the object inner the cell (SPAN, or A, or DIV, or...)
  $style = "";
  if($RGBColor)			$style.= "color:".$RGBColor.";";
  if($fontSize)			$style.= "font-size:".$fontSize.";";
  if($fontFamily)		$style.= "font-family:".$fontFamily.";";
  if($fontWeight)		$style.= "font-weight:".$fontWeight.";";

  // get formatted value
  switch($field->data['type'])
  {
   case 'date' : {
	 $format = $field->data['format'] ? $field->data['format'] : "d/m/Y";
	 $time = ($field->data['inputformat'] == "numeric") ? $value : strtotime($value);
	 $value = date($format, $time);
	} break;

   case 'currency' : {
	 $decimals = $field->data['decimals'] ? $field->data['decimals'] : 2;
	 $value = number_format($value, $decimals, ',','.');
	} break;

   case 'percentage' : $value = str_replace("%","",$value)."%"; break;
  }

  // set output
  switch($field->data['type'])
  {
   case 'link' : {
	 if($field->data['href'])
	 {
	  $out = "<a href='".$this->Row->parseString($field->data['href'])."'";
	  if($field->data['target'])		$out.= " target=\"".$this->Row->parseString($field->data['target'])."\"";
	  if($style)						$out.= " style=\"".$style."\"";
	  $out.= ">".$value."</a>";
	 }
	 else
	 {
	  $out = "<span class='link".(!$RGBColor ? " ".$color : "")."'";
	  if($field->data['onclick'])		$out.= " onclick=\"".$this->Row->parseString($field->data['onclick'])."\"";
	  if($style)						$out.= " style=\"".$style."\"";
	  $out.= ">".$value."</span>";
	 }
	} break;

   case 'button' : {
	 if($field->data['src'] || $field->data['icon'])
	 {
	  $btnstyle = "cursor:pointer;";
	  if($field->data['style']) $btnstyle.= $field->data['style'];
	  $out = "<img src='".($field->data['src'] ? $field->data['src'] : $field->data['icon'])."' style='".$btnstyle."'";
	  if($field->data['imgwidth'] || $field->data['iconwidth'])
	   $out.= " width='".($field->data['imgwidth'] ? $field->data['imgwidth'] : $field->data['iconwidth'])."'";
	  if($field->data['imgheight'] || $field->data['iconheight'])
	   $out.= " height='".($field->data['imgheight'] ? $field->data['imgheight'] : $field->data['iconheight'])."'";
	  if($field->data['onclick'])		$out.= " onclick=\"".$this->Row->parseString($field->data['onclick'])."\"";
	  if($field->title) $out.= " title=\"".$field->title."\"";
	  $out.= "/>";
	 }
	 else
	 {
	  /* TODO: continuare da qui... */
	 }
	} break;

   case 'checkbox' : {
	 $out = "<input type='checkbox'/>";
	} break;

   case 'option' : {
	 $val = (is_array($field->data['values']) && $field->data['values'][$value]) ? $field->data['values'][$value] : "&nbsp;";
	 $out = $val;
	} break;

   case 'function' : {
	 if($field->data['function'] && is_callable($field->data['function'],true))
	  $out = call_user_func($field->data['function'], $this->Row->data);
	} break;

   case 'thumbnail' : {
	 if($value)
	 {
	  $style = "";
	  $out.= "<div class='".($field->data['class'] ? $field->data['class'] : 'thumbnail')."'";
	  if($field->data['width'])			$style.= "width:".$field->data['width']."px;";
	  if($field->data['height'])		$style.= "height:".$field->data['height']."px;";
	  if($field->data['margin'])		$style.= "margin:".$field->data['margin']."px;";
	  if($field->data['margin-left'])	$style.= "margin-left:".$field->data['margin-left']."px;";
	  if($field->data['margin-right'])	$style.= "margin-right:".$field->data['margin-right']."px;";
	  if($field->data['margin-top'])	$style.= "margin-top:".$field->data['margin-top']."px;";
	  if($field->data['margin-bottom'])	$style.= "margin-bottom:".$field->data['margin-bottom']."px;";

	  if($field->data['width'] && $field->data['height'])	$style.= "overflow:hidden;";
	  if($style)	$out.= " style='".$style."'";
	  $out.= ">";

	  $style = "";
	  $out.= "<img src='".$value."'";
	  /*if($field->data['width'])			$style.= "width:".$field->data['width']."px;";
	  else if($field->data['height'])	$style.= "height:".$field->data['height']."px;";*/

	  if($style)	$out.= " style='".$style."'";
	  $out.= "/></div>";
	 }
	 else
	  $out.= "&nbsp;";
	} break;

   case 'icon' : {
	 if($field->data['src'])
	 {
	  $style = "";
	  if($field->data['iconwidth'])		$style.= "width:".$field->data['iconwidth']."px;";
	  if($field->data['iconheight'])	$style.= "height:".$field->data['iconheight']."px;";
	  if($field->data['margin'])		$style.= "margin:".$field->data['margin']."px;";
	  if($field->data['margin-left'])	$style.= "margin-left:".$field->data['margin-left']."px;";
	  if($field->data['margin-right'])	$style.= "margin-right:".$field->data['margin-right']."px;";
	  if($field->data['margin-top'])	$style.= "margin-top:".$field->data['margin-top']."px;";
	  if($field->data['margin-bottom'])	$style.= "margin-bottom:".$field->data['margin-bottom']."px;";

	  $out.= "<img src='".$field->data['src']."'";
	  if($style)	$out.= " style='".$style."'";
	  $out.= "/>";
	 }
	 else
	  $out.= "&nbsp;";
	} break;

   default : {
	 $out = "<span".(!$RGBColor ? " class='".$color."'" : "");
	 if($style)							$out.= " style=\"".$style."\"";
	 $out.= ">".$value."</span>";
	} break;

  }

  $this->content = $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function SetContent($content="") { $this->content = $content; }
 //------------------------------------------------------------------------------------------------------------------//
 function Paint($retAsString=false)
 {
  $field = $this->Table->Fields[$this->idx];
  $style = "";
  if($this->Table->config['defaultrowheight'])	$style.= "height:".$this->Table->config['defaultrowheight']."px;";

  $out = "<td";
  // Properties
  if($this->colspan > 1)			$out.= " colspan='".$this->colspan."'";
  if($field->data['align'])			$out.= " align='".$field->data['align']."'";
  if($field->data['valign'])		$out.= " valign='".$field->data['valign']."'";
  // Events
  if($field->data['cellonclick'])	$out.= " onclick=\"".$this->Row->parseString($field->data['cellonclick'])."\"";
  // Style
  if($style)						$out.= " style='".$style."'";
  $out.= ">".$this->content."</td>";

  if($retAsString)	return $out;
  echo $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
}




