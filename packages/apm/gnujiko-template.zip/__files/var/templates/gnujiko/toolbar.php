<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2017 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 03-05-2017
 #PACKAGE: gnujiko-template
 #DESCRIPTION: Toolbar class for Gnujiko Template.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

class GnujikoTemplateToolbar
{
 var $Sections, $template, $height, $JavaScript;
 function GnujikoTemplateToolbar($tplH, $height, $fixed=false)
 {
  $this->template = $tplH;
  $this->Sections = array();
  $this->height = $height;
  $this->JavaScript = "";
  $this->fixed = $fixed;
 }
 //----------------------------------------------------------------------------------------------//
 function AddSection($width=0, $align='left')
 {
  $sec = new GnujikoTemplateToolbarSection($this, $width, $align);
  $this->Sections[] = $sec;

  return $sec;
 }
 //----------------------------------------------------------------------------------------------//
 function Paint()
 {
  $style = "height:".$this->height."px;";
  if($this->fixed)
   $style.= "position:fixed;left:0px;right:0px;top:".$this->template->cache['pagecontentmargintop']."px;";

  echo "<div class='gnujiko-template-toolbar'".($style ? " style=\"".$style."\"" : "").">";
  echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
  echo "<tr>";
  for($c=0; $c < count($this->Sections); $c++)
  {
   $sec = $this->Sections[$c];
   echo "<td valign='".($sec->valign ? $sec->valign : 'middle')."' height='".$this->height."'";
   if($sec->width)	echo " width='".$sec->width."'";
   if($sec->align)	echo " align='".$sec->align."'";
   echo ">";
   $sec->Paint();
   echo "</td>";
  }
  echo "</tr></table></div>";
  if($this->fixed)
  {
   $this->template->cache['pagecontentmargintop']+= $this->height;
   // div used as margin top in case of header fixed
   echo "<div class='gnujiko-template-header-topmargin' style='height:".$this->height."px'></div>";
  }
 }
 //----------------------------------------------------------------------------------------------//
 //----------------------------------------------------------------------------------------------//
 //----------------------------------------------------------------------------------------------//
}
//-------------------------------------------------------------------------------------------------------------------//
//--- T O O L B A R - S E C T I O N S -------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
class GnujikoTemplateToolbarSection
{
 var $toolbar, $template, $width, $align, $contents;

 function GnujikoTemplateToolbarSection($toolbar, $width, $align)
 {
  $this->toolbar = $toolbar;
  $this->template = $toolbar->template;
  $this->width = $width;
  $this->align = $align;
  $this->contents = "";
 }
 //----------------------------------------------------------------------------------------------//
 function Paint()
 {
  echo $this->contents;
 }
 //----------------------------------------------------------------------------------------------//
 function setContent($content="")
 {
  $this->contents = $content;
 }
 //----------------------------------------------------------------------------------------------//
 function addObject($type, $data=null)
 {
  switch($type)
  {
   case 'mainmenu' : case 'menu' : case 'menubutton' : return $this->addObjectMenuButton($data); break;
   case 'button' : 				return $this->addObjectButton('default',$data); break;
   case 'horizontalmenu' : 		return $this->addObjectHorizontalMenu($data); break;
   case 'toggles' : 			return $this->addObjectToggles($data); break;
  }
 }
 //----------------------------------------------------------------------------------------------//
 function addObjectMenuButton($data)
 {
  global $_ABSOLUTE_URL, $_TPLDIR;

  $id = $data['id'] ? $data['id'] : "mainmenu";
  $connect = $data['connect'] ? $data['connect'] : $id."list";
  $title = $data['title'] ? $data['title'] : "Menu";
  $icon = $data['icon'] ? $this->template->config['basepath'].$data['icon'] : $_TPLDIR."buttons/homeicon.png";
  if($data['icon'] === false) $icon = false;
  $color = $data['color'] ? $data['color'] : 'white';

  $content = "<button class='".$color."-menu-button' id='".$id."' connect='".$connect."'>";
  if($icon)
   $content.= "<img src='".$_ABSOLUTE_URL.$icon."'/> ";
  $content.= $title;
  $content.= "</button>";

  $content.= $this->template->generatePopupMenu($data['items'], $connect);

  $this->contents.= $content;
  $this->toolbar->JavaScript.= "Template.initBtn(document.getElementById('".$id."'), 'menu');\n";
 }
 //----------------------------------------------------------------------------------------------//
 function addObjectButton($type='default', $data=null)
 {
  $title = (is_array($data) && $data['title']) ? $data['title'] : "untitled";
  $hint = (is_array($data) && $data['hint']) ? $data['hint'] : "";
  $className = (is_array($data) && $data['class']) ? $data['class'] : "";
  $onClick = (is_array($data) && $data['onclick']) ? $data['onclick'] : "";

  if(!$className)
  {
   switch($type)
   {
    case 'exit' : {
	 $className = "button-exit";
	if(!is_array($data) || !$data['title'])	$title = i18n('Exit');
	if(!is_array($data) || !$data['hint'])	$hint = i18n('Back to home');
    if(!$onClick) $onClick="Template.Exit()";
	} break;

	default : $className = "button-".($data['color'] ? $data['color'] : 'gray'); break;
   }
  }

  $this->contents.= "<input type=\"button\" class=\"".$className."\" value=\"".$title."\" onclick=\"".$onClick."\" title=\"".$hint."\"/>";
 }
 //------------------------------------------------------------------------------------------------------------------//
 function addObjectHorizontalMenu($data)
 {
  global $_ABSOLUTE_URL, $_TPLDIR;

  $items = is_array($data['items']) ? $data['items'] : $data;
  $align = $data['align'] ? $data['align'] : 'center';
  
  $style = "";
  switch($align)
  {
   case 'left' : $style.= "margin-left:0px;margin-right:auto;"; break;
   case 'center' : $style.= "margin-left:auto;margin-right:auto;"; break;
   case 'right' : $style.= "margin-left:auto;margin-right:0px;"; break;
  }

  $content = "<ul class='horizontal-menu'".($style ? " style='".$style."'" : "").">";
  for($c=0; $c < count($items); $c++)
  {
   $item = $items[$c];
   $color = $item['color'] ? $item['color'] : 'blue';
   $selected = $item['selected'] ? $item['selected'] : false;

   if($selected)	$class = "selected ".$color."-selected";
   else 			$class = "item ".$color;

   $content.= "<a href='".$_ABSOLUTE_URL.$this->template->config['basepath'].$item['url']."'>";
   $content.= "<li class='".$class."'>".$item['title']."</li></a>";
  }
  $content.= "</ul>";

  $this->contents.= $content;
 }
 //----------------------------------------------------------------------------------------------//
 function addObjectToggles($data)
 {
  $id = (is_array($data) && $data['id']) ? $data['id'] : 0;
  $items = (is_array($data) && $data['items']) ? $data['items'] : array();
  $selected = (is_array($data) && $data['selected']) ? $data['selected'] : "";

  if(!$selected && count($items)) $items[0]['selected'] = true;
  else if($selected)
  {
   for($c=0; $c < count($items); $c++)
   {
	if($items[$c]['value'] == $selected)
	{
	 $items[$c]['selected'] = true;
	 break;
	}
   }
  }

  $this->contents.= $this->template->generateToggles($items, $id);
 }
 //----------------------------------------------------------------------------------------------//

}
//-------------------------------------------------------------------------------------------------------------------//
