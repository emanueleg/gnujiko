/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2017 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 08-08-2017
 #PACKAGE: gnujikotemplate
 #DESCRIPTION: Cat select class.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

function GnujikoTemplateCatSelect(obj, AP)
{
 this.O = obj;			// folder container (div)
 this.pathwayO = null;	// pathway object (div)
 this.AP = AP ? AP : "";

 this.activeCatId = 0;

 this.CATLIST = new Array();
 this.CAT_BY_ID = new Array();

 this.availableColors = ['lightgray','yellow','red','green','gray','sky','blue','pink','violet','black'];
 this.colorIdx = 0;
 this.setbgTimer = null;
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.init = function()
{
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.initPathway = function(obj)
{
 if(obj) this.pathwayO = obj;
 if(!this.pathwayO) return;
 var spanlist = this.pathwayO.getElementsByTagName('SPAN');
 for(var c=0; c < spanlist.length; c++)
  spanlist[c].catSelectHandler = this;
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.empty = function()
{
 this.O.innerHTML = "";
 this.colorIdx = 0;
 this._setbgloading();
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype._setbgloading = function()
{
 var oThis = this;
 if(this.setbgTimer) clearTimeout(this.setbgTimer);
 this.setbgTimer = setTimeout(function(){
	 oThis.O.className = oThis.O.className.replace(" folder-container-loading", "")+" folder-container-loading";
	}, 250);
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype._resetbg = function()
{
 if(this.setbgTimer) clearTimeout(this.setbgTimer);
 this.O.className = this.O.className.replace(" folder-container-loading", "");
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype._message = function(msg)
{
 var tb = document.createElement('TABLE');
 tb.className = "gnujikotemplatecatselect-message-container";
 tb.insertRow(-1).insertCell(-1).innerHTML = msg;

 this.O.innerHTML = "";
 this.O.appendChild(tb);
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.update = function(catId)
{
 if(!this.AP)
  return this._message("Attenzione!, nessun archivio specificato");

 var oThis = this;
 this.empty();

 this.getCatInfo(catId, function(){
	 var sh = new GShell();
	 sh.OnError = function(err){
		 oThis._resetbg();
		 alert("Update Error: "+err);
		}
	 sh.OnOutput = function(o,a){
		 oThis._resetbg();
		 oThis.activeCatId = catId;
		 oThis.updatePathway();
		 if(!a || !a.length) return;
		 for(var c=0; c < a.length; c++)
		  oThis.addItem(a[c]);
		}
	 sh.sendCommand("dynarc cat-list -ap '"+this.AP+"' --order-by 'name ASC'"+(catId ? " -parent '"+catId+"'" : ""));
	});

}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.addItem = function(data)
{
 var oThis = this;

 var div = document.createElement('DIV');
 div.id = data['id'];
 div.data = data;
 div.onclick = function(){oThis.update(this.data['id']);}

 var color = this.availableColors[this.colorIdx];
 this.colorIdx++;
 if(this.colorIdx >= this.availableColors.length) this.colorIdx = 0;

 div.className = "big-folder-block big-folder-"+color+"-bg";
 var fontSize = 0;
 var style = "";
 if(data['name'].length > 6) fontSize=14;
 if(data['name'].length > 8) fontSize=13;
 if(data['name'].length > 24) fontSize=12;
 if(fontSize) style+= "font-size:"+fontSize+"px;";

 var html = "<table class='big-folder-block-inner' cellspacing='0' cellpadding='0' border='0'>";
 html+= "<tr><td align='center' valign='middle'"+(style ? " style='"+style+"'" : "")+"><div>"+data['name']+"</div></td></tr>";
 html+= "</table>";

 div.innerHTML = html;

 this.O.appendChild(div);
 this.CATLIST.push(data);
 this.CAT_BY_ID[data['id']] = data;
 return div;
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.gotoParent = function()
{
 if(!this.activeCatId) return;
 if(!this.CAT_BY_ID[this.activeCatId]) return;
 var catInfo = this.CAT_BY_ID[this.activeCatId];

 this.update(catInfo['parent_id']);
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.updatePathway = function()
{
 if(!this.pathwayO) return;
 this.pathwayO.innerHTML = "";
 if(!this.activeCatId) return;
 if(!this.CAT_BY_ID[this.activeCatId]) return;
 var catInfo = this.CAT_BY_ID[this.activeCatId];

 var html = "<span class='selected' data-id='"+catInfo['id']+"'>"+catInfo['name']+"</span>";
 var parentId = catInfo['parent_id'];
 while(parentId)
 {
  if(!this.CAT_BY_ID[parentId]) break;
  var parentInfo = this.CAT_BY_ID[parentId];
  html = "<span data-id='"+parentInfo['id']+"' onclick=\"this.catSelectHandler.update(this.getAttribute('data-id'))\">"+parentInfo['name']+"</span> / "+html;
  parentId = parentInfo['parent_id'];
 }
 
 this.pathwayO.innerHTML = html;
 this.initPathway();
 this.pathwayO.scrollLeft = this.pathwayO.scrollWidth;
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.createNewCat = function(title, data)
{
 var oThis = this;
 var cmd = "dynarc new-cat -ap '"+this.AP+"' -name `"+title+"`";
 if(this.activeCatId)	cmd+= " -parent '"+this.activeCatId+"'";

 if(data)
 {
  if(data['desc'])				cmd+= " -desc `"+data['desc']+"`";
  else if(data['description'])	cmd+= " -desc `"+data['description']+"`";
  if(data['group'])				cmd+= " -group '"+data['group']+"'";
  if(data['perms'])				cmd+= " -perms '"+data['perms']+"'";
  if(data['tag'])				cmd+= " -tag '"+data['tag']+"'";
 }

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 oThis.addItem(a);
	}

 sh.sendCommand(cmd);
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.renameCat = function(id, title)
{
 var oThis = this;
 var catId = id ? id : this.activeCatId;
 if(!catId) return;

 var sh = new GShell();
 sh.OnError = function(err){alert("Rename category error: "+err);}
 sh.OnOutput = function(o,a){
	 oThis.CAT_BY_ID[catId]['name'] = title;
	 oThis.updatePathway();
	}

 sh.sendCommand("dynarc edit-cat -ap '"+this.AP+"' -id '"+catId+"' -name `"+title+"`"); 
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.deleteCat = function(id, procMsgTitle, procMsgSubtitle)
{
 var oThis = this;
 var catId = id ? id : this.activeCatId;
 if(!catId) return;
 var parentId = 0;

 if(this.CAT_BY_ID[catId])
 {
  var catInfo = this.CAT_BY_ID[catId];
  parentId = catInfo['parent_id'];
 }

 var sh = new GShell();

 if(procMsgTitle) sh.showProcessMessage(procMsgTitle, procMsgSubtitle);

 sh.OnError = function(err){ if(procMsgTitle) return this.processMessage.error(err); alert(err); }
 sh.OnOutput = function(o,a){ if(procMsgTitle) this.hideProcessMessage(); oThis.update(parentId); }

 sh.sendCommand("dynarc delete-cat -ap '"+this.AP+"' -id '"+catId+"'");
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.moveCat = function(id, destId, procMsgTitle, procMsgSubtitle)
{
 var oThis = this;
 var sh = new GShell();
 if(procMsgTitle) sh.showProcessMessage(procMsgTitle, procMsgSubtitle);
 sh.OnError = function(err){ if(procMsgTitle) return this.processMessage.error(err); alert(err); }
 sh.OnOutput = function(o,a){ if(procMsgTitle) this.hideProcessMessage(); oThis.addItem(a);	}
 sh.sendCommand("dynarc cat-move -ap '"+this.AP+"' -id '"+id+"' -into '"+destId+"'");
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.copyCat = function(id, destId, procMsgTitle, procMsgSubtitle)
{
 var oThis = this;
 var sh = new GShell();
 if(procMsgTitle) sh.showProcessMessage(procMsgTitle, procMsgSubtitle);
 sh.OnError = function(err){ if(procMsgTitle) return this.processMessage.error(err); alert(err); }
 sh.OnOutput = function(o,a){ if(procMsgTitle) this.hideProcessMessage(); oThis.addItem(a);	}
 sh.sendCommand("dynarc cat-copy -ap '"+this.AP+"' -id '"+id+"' -parent '"+destId+"'");
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.getCatInfo = function(id, callback)
{
 var oThis = this;
 if(!parseFloat(id)) { if(callback) callback(0); return; }

 var catInfo = this.CAT_BY_ID[id] ? this.CAT_BY_ID[id] : null;
 if(catInfo)
 {
  if(callback) callback(catInfo);
 }
 else
 {
  var sh = new GShell();
  sh.OnError = function(err){alert("getCatInfo Error: "+err);}
  sh.OnOutput = function(o,a){
	 catInfo = a;
	 oThis.CAT_BY_ID[id] = catInfo;
	 if(catInfo['pathway'])
	 {
	  for(var c=0; c < catInfo['pathway'].length; c++)
	  {
	   oThis.CAT_BY_ID[catInfo['pathway'][c]['id']] = catInfo['pathway'][c];
	  }
	 }
	 if(callback)
	  callback(catInfo);
	}

  sh.sendCommand("dynarc cat-info -ap '"+this.AP+"' -id '"+id+"' --include-path");
 }

 return catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.getCurrentCat = function()
{
 return this.CAT_BY_ID[this.activeCatId];
}
//-------------------------------------------------------------------------------------------------------------------//
GnujikoTemplateCatSelect.prototype.getPathway = function(asString)
{
 var list = new Array();
 var spanlist = this.pathwayO.getElementsByTagName('SPAN');
 var pathString = "";
 for(var c=0; c < spanlist.length; c++)
 {
  var a = new Array();
  a['id'] = spanlist[c].getAttribute('data-id');
  a['name'] = spanlist[c].textContent;
  list.push(a);
  pathString+= a['name']+" / ";
 }

 return asString ? pathString : list;
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//


