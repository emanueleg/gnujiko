<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2017 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 07-08-2017
#PACKAGE: gnujiko-template
#DESCRIPTION: Gnujiko Template - Dynarc category select.
#VERSION: 2.0beta
#CHANGELOG: 

#TODO: 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;
$_BASE_PATH = '../../../';

define('VALID-GNUJIKO',1);
include($_BASE_PATH.'var/templates/gnujiko/index.php');

$_AP = (isset($_REQUEST['ap']) && $_REQUEST['ap']) ? $_REQUEST['ap'] : ""; 
$_TITLE = (isset($_REQUEST['title']) && $_REQUEST['title']) ? $_REQUEST['title'] : "Seleziona una categoria";

$template = new GnujikoTemplate();
$template->IncludeCSS("share/widgets/gnujikotemplate/dynarc-catselect.css");
$template->IncludeJS("share/widgets/gnujikotemplate/dynarc-catselect.js");
$template->StartWidget($_TITLE, 630);
$template->WidgetHeader();
$template->StartWidgetSection(true);

$_OPTIONS = array(
	'cancreate' => true,
	'cansearch' => true,
	'candelete' => true
);

$_MODE = (isset($_REQUEST['mode']) && $_REQUEST['mode']) ? $_REQUEST['mode'] : 'default';
switch($_MODE)
{
 case 'selectonly' : {
	 $_OPTIONS['cancreate'] = false;
	 $_OPTIONS['candelete'] = false;
	} break;

}

/* MENU */
$_MAIN_MENU = array();

if($_OPTIONS['cancreate'])
{
 $_MAIN_MENU[] = array('title'=>'Crea nuova categoria', 'icon'=>$_ABSOLUTE_URL."share/icons/16x16/new_folder.gif", 'onclick'=>'NewCat()');
 $_MAIN_MENU[] = array('type'=>'separator');
 $_MAIN_MENU[] = array('title'=>'Rinomina...', 'icon'=>$_ABSOLUTE_URL."share/icons/16x16/pencil.gif", 'onclick'=>'RenameCat()');
 $_MAIN_MENU[] = array('type'=>'separator');
 $_MAIN_MENU[] = array('title'=>'Taglia', 'icon'=>$_ABSOLUTE_URL."share/icons/16x16/cut.gif", 'onclick'=>'Cut()');
 $_MAIN_MENU[] = array('title'=>'Copia', 'icon'=>$_ABSOLUTE_URL."share/icons/16x16/copy.png", 'onclick'=>'Copy()');
 $_MAIN_MENU[] = array('title'=>'Incolla', 'icon'=>$_ABSOLUTE_URL."share/icons/16x16/paste.gif", 'onclick'=>'Paste()');
}

if($_OPTIONS['candelete'])
{
 $_MAIN_MENU[] = array('type'=>'separator');
 $_MAIN_MENU[] = array('title'=>'Elimina questa categoria', 'icon'=>$_ABSOLUTE_URL."share/icons/16x16/trash.gif", 'onclick'=>'DeleteCurrentCat()');
}

//-------------------------------------------------------------------------------------------------------------------//
?>
<tr>
 <td><input type='text' class="edit noborder nopadding" placeholder="Cerca" id='search' style='width:98%' value="" ap="<?php echo $_AP; ?>" retfield="fullpathstring" retfullpath="true" disableonclick="true" limit="20"/></td>
 <td width='60'>&nbsp;</td>
</tr>

<?php
 if(count($_MAIN_MENU))
 {
  ?>
  <tr>
   <td style='height:50px'>
    <button class='white-menu-button' id='mainmenu' connect='mainmenulist'>
     <img src="<?php echo $_ABSOLUTE_URL; ?>var/templates/gnujiko/buttons/homeicon.png"/> Menu
    </button><?php echo $template->generatePopupMenu($_MAIN_MENU,'mainmenulist'); ?>
   </td>
   <td style='height:50px'>&nbsp;</td>
  </tr>
  <?php
 }
?>

<tr>
 <td><div class='pathway' id='gnujikotemplatecatselect-pathway' style='width:520px'></div></td>
 <td align='right' valign='middle'><img src="img/dir-up.png" style='cursor:pointer' onclick='gotoParentFolder()'/></td>
</tr>

<tr><td colspan='2' class='full'>
 <!-- FOLDER CONTAINER -->
 <div class='folder-container' id='gnujikotemplatecatselect'></div>
 <!-- EOF - FOLDER CONTAINER -->

 <?php
 if($_OPTIONS['cancreate'])
 {
  ?>
  <div style='height:32px;margin-top:10px'>
   <img src="round-buttons/add-blue.png" style="float:right;cursor:pointer" title="Crea nuova categoria" onclick="NewCat()"/>
  </div>
  <?php
 }
 ?>

</td></tr>

<?php
$template->EndWidgetSection();

$template->StartWidgetFooter(true);
?>
 
 <tr><td>
		<input type='button' class='button-blue' value='CONFERMA' onclick='Submit()'/>
		<input type='button' class='button-gray' value='ANNULLA' onclick='gframe_close()'/>
	 </td>
	 <td>
	  <?php
	  if($_OPTIONS['candelete'])
	  {
	   ?>
		<ul class='footer-menu'>
		 <li><input type='button' class='trash-icon' title="Elimina questa categoria" onclick='DeleteCurrentCat()'/></li>
	 	</ul>
	   <?php
	  }
	  else
	   echo "&nbsp;";
	 ?>
	 </td>
 </tr>

<?php
$template->EndWidgetFooter();
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";
var ID = "<?php echo $_ID; ?>";
var FOCUSED = <?php echo $itemInfo['focused'] ? 'true' : 'false'; ?>;
var ACTION = "";
var ACTION_CATID = 0;
var CATSELECT = null;

Template.OnInit = function()
{
 if(document.getElementById('mainmenu'))
  this.initBtn(document.getElementById('mainmenu'), 'menu');
 if(document.getElementById('search'))
  this.initEd(document.getElementById('search'), 'catfind').onchange = function(){ CATSELECT.update(this.getId()); this.reset(); }

 CATSELECT = new GnujikoTemplateCatSelect(document.getElementById('gnujikotemplatecatselect'), AP);
 CATSELECT.initPathway(document.getElementById('gnujikotemplatecatselect-pathway'));
 CATSELECT.update();
}

function Submit()
{
 var ret = CATSELECT.getCurrentCat();
 ret['pathway'] = CATSELECT.getPathway();
 ret['pathwaystring'] = CATSELECT.getPathway(true);
 gframe_close("Category #"+CATSELECT.activeCatId+" selected.", ret);
}

function NewCat()
{
 var title = prompt("Crea nuova categoria", "Digita un titolo");
 if(!title) return;
 CATSELECT.createNewCat(title);
}

function RenameCat()
{
 var catInfo = CATSELECT.getCurrentCat();
 if(!catInfo) return;
 var title = prompt("Rinomina questa categoria", catInfo['name']);
 if(!title) return;

 CATSELECT.renameCat(catInfo['id'], title);
}

function DeleteCurrentCat()
{
 if(!confirm("Sei sicuro di voler eliminare questa categoria?")) return;
 CATSELECT.deleteCat(null, 'Eliminazione in corso...', 'Attendere prego, &egrave; in corso l&lsquo;eliminazione della categoria selezionata.');
}

function Cut()
{
 var catInfo = CATSELECT.getCurrentCat();
 if(!catInfo) return;
 ACTION = "CUT";
 ACTION_CATID = catInfo['id'];
}

function Copy()
{
 var catInfo = CATSELECT.getCurrentCat();
 if(!catInfo) return;
 ACTION = "COPY";
 ACTION_CATID = catInfo['id'];
}

function Paste()
{
 var catInfo = CATSELECT.getCurrentCat();
 var destId = catInfo ? catInfo['id'] : 0;
 switch(ACTION)
 {
  case 'CUT' : CATSELECT.moveCat(ACTION_CATID, destId, 'Spostamento in corso','Attendere prego, &egrave; in corso lo spostamento della cartella selezionata'); break;
  case 'COPY' : CATSELECT.copyCat(ACTION_CATID, destId, 'Copia in corso','Attendere prego, &egrave; in corso la copia della cartella selezionata'); break;
 }
}

function gotoParentFolder()
{
 CATSELECT.gotoParent();
}

</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->EndWidget();
//-------------------------------------------------------------------------------------------------------------------//
?>
