<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2012 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 27-10-2012
 #PACKAGE: html2canvas
 #DESCRIPTION: HTML to Canvas utility.
 #VERSION: 2.0-0.33
 #CHANGELOG:
 #TODO:
 
*/
global $_BASE_PATH, $_ABSOLUTE_URL;
?>
<script type="text/javascript" src="<?php echo $_ABSOLUTE_URL; ?>var/objects/html2canvas/external/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="<?php echo $_ABSOLUTE_URL; ?>var/objects/html2canvas/build/html2canvas.js"></script>
<script type="text/javascript" src="<?php echo $_ABSOLUTE_URL; ?>var/objects/html2canvas/build/jquery.plugin.html2canvas.js"></script>

