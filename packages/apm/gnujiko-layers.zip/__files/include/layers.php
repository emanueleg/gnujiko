<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2012 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 21-01-2012
 #PACKAGE: gnujiko-layers
 #DESCRIPTION: Gnujiko layers support
 #VERSION: 2.0
 #CHANGELOG:
 #TODO:
 
*/
global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH;
include_once($_BASE_PATH."config.php");
include_once($_BASE_PATH."var/lib/database.php");
include_once($_BASE_PATH."include/session.php");
include_once($_BASE_PATH."var/lib/xmllib.php");
include_once($_BASE_PATH."include/js/xrequest.php");

?>
<script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>include/js/layers.js" type="text/javascript"></script>
<?php


