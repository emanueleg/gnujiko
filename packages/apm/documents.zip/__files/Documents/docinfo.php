<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 11-01-2015
 #PACKAGE: documents
 #DESCRIPTION: Document info.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_COMPANY_PROFILE;

$_BASE_PATH = "../";
$_AP = "documents";
$_RESTRICTED_ACCESS = "documents";
$_AP_MODELS = "documentmodels";

include($_BASE_PATH."var/templates/glight/index.php");
include_once($_BASE_PATH."include/userfunc.php");
include_once($_BASE_PATH."var/objects/htmlgutility/contentpreview.php");

$template = new GLightTemplate();
$template->includeCSS("docinfo.css");
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeObject("fckeditor");
$template->includeInternalObject("serp");
$template->includeInternalObject("contactsearch");
$template->includeInternalObject("attachments");

/* DOCUMENT INFO */
$docInfo = array();
$ret = GShell("dynarc item-info -ap ".$_AP." -id '".$_REQUEST['id']."' -extget css");
if(!$ret['error'])
 $docInfo = $ret['outarr'];

/* GET CONFIG */
$config = array();
$ret = GShell("aboutconfig get-config -app documents");
if(!$ret['error'])
 $config = $ret['outarr']['config'];

$template->Begin($docInfo['name']);

/* HEADER ---------------------------------------------------------------------------------------------------------- */
?>
<div class='docstyle-header'>
<table width='100%' cellspacing='0' cellpadding='0' border='0' class='docstyle'>
<tr><td class='docstyle-icon' rowspan='2'><img src='img/doc-icon.png'/></td>
	<td class='docstyle-title'><i id='doctitle' onclick='renameDocument()' title="Clicca per rinominare"><?php echo $docInfo['name'] ? $docInfo['name'] : 'senza titolo'; ?></i></td>
	<td rowspan='2' align='right' style='padding-right:20px'>
		<input type='button' class='button-blue' value='Anteprima' onclick="showPreview()"/>
		<input type='button' class='button-blue' value="Salva e chiudi" onclick="Submit('EXIT')" id='save-btn' <?php if($docInfo['closed']) echo "style='display:none'"; ?>/>
		<input type='button' class='button-exit' value="Esci" onclick='Template.Exit(true)'/></td></tr>
<tr><td class='docstyle-menu'>
	<input type='button' class='textualmenu' value='Menu' connect='mainmenu' id='mainmenubutton'/>
		<ul class='popupmenu' id='mainmenu'>
		 <li onclick='showPreview()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/eye.gif"/>Mostra anteprima</li>
		 <li class='separator'>&nbsp;</li>
		 <li onclick='Submit()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save.gif"/>Salva</li>
		 <li onclick='saveAs()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save_as.png"/>Salva con nome</li>
		 <li onclick='saveAsModel()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save_as.png"/>Salva come modello</li>
		 <li class='separator'>&nbsp;</li>
		 <li onclick='deleteDocument()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/delete.gif"/>Elimina</li>
		</ul>
	</td></tr>
</table>
</div>
<?php

$template->Body("monosection", 1000);
?>
<div class='docstyle-page' style='width:980px;'>
 <div class='docstyle-body'>
  <div id='CONTENT-PAGE'>
   <textarea style="width:700px;height:200px" id="contents"><?php echo $docInfo['desc']; ?></textarea>
  </div>
  <!-- CSS PAGE -->
  <div id='CSS-PAGE' style='display:none'>
   <textarea style="width:100%;height:600px" id="css"><?php echo $docInfo['css'][0] ? $docInfo['css'][0]['content'] : ""; ?></textarea>
  </div>

 </div>
 <div class='docstyle-footer' style='text-align:left'>
  <input type='button' class='button-blue' value='Salva' onclick="Submit()" id='save-btn2' <?php if($docInfo['closed']) echo "style='display:none'"; ?>/>
  <input type='button' class='button-exit' value='Esci' onclick="Template.Exit()"/>
  <input type='button' class='button-red' value='Elimina' onclick="deleteDocument()" style="float:right"/>
 </div>
</div>
<?php

/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
?>
<script>
var AP = "<?php echo $_AP; ?>";
var AP_MODELS = "<?php echo $_AP_MODELS; ?>";
var DOC_ID = "<?php echo $docInfo['id']; ?>";
var ON_PRINTING = false;
var ON_EXPORT = false;
var OLD_TITLE = "";
var OLD_CONTENTS = "";

Template.OnExit = function(checkChanges){
	if(checkChanges)
	{
	 /* TODO: da fare verifiche di cambiamento. */
	 /*if(!confirm("Desideri chiudere senza salvare le modifiche apportate?"))
	  return;*/
	}

	if(window.opener)
	{
	 window.opener.document.location.reload();
	 window.close();
	}
	else
	 document.location.href = ABSOLUTE_URL+"Documents/index.php";
	return false;
}

Template.OnInit = function(){
 /* INIT HTML EDITOR */
 document.getElementById("contents").style.height = (this.getScreenHeight()-200)+"px";
 this.initEd(document.getElementById("contents"), "fckeditor", "Extended");

 /* INIT MENU */
 this.initBtn(document.getElementById('mainmenubutton'), "popupmenu");

}

function showPreview()
{
 var CP = new GContentPreview(document.getElementById('doctitle').innerHTML);
 CP.setContent(document.getElementById('contents').getValue());
 CP.setCSS(document.getElementById('css').value);
 CP.show();
}

function Submit(action)
{
 var title = document.getElementById('doctitle').innerHTML;
 var contents = document.getElementById('contents').getValue();

 if(!title || (title == "senza titolo"))
 {
  var title = prompt("Devi assegnare un titolo a questo documento");
  if(!title) return;
  document.getElementById('doctitle').innerHTML = title;
 }

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 switch(action)
	 {
	  case 'PRINT' : printDocument(); break;
	  case 'EXIT' : Template.Exit(); break;
	  default : alert('Salvataggio completato!'); break;
	 }
	}
 sh.sendCommand("dynarc edit-item -ap '"+AP+"' -id '"+DOC_ID+"' -name `"+title+"` -desc `"+contents+"`");
}

function saveAs()
{
 var title = document.getElementById('doctitle').innerHTML;
 var contents = document.getElementById('contents').getValue();

 var tit = prompt("Salva con nome",title+" (copia)");
 if(!tit) return;
 if(tit == title) return alert("Devi indicare un'altro titolo");

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 document.getElementById('doctitle').innerHTML = a['name'];
	 DOC_ID = a['id'];
	 alert('Salvataggio completato');
	}
 sh.sendCommand("dynarc new-item -ap '"+AP+"' -name `"+tit+"` -desc `"+contents+"`");
}

function saveAsModel()
{
 var title = document.getElementById('doctitle').innerHTML;
 var contents = document.getElementById('contents').getValue();

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){alert('Salvataggio completato');}
 sh.sendCommand("dynarc new-item -ap '"+AP_MODELS+"' -name `"+title+"` -desc `"+contents+"`");
}

function renameDocument()
{
 var tit = prompt("Rinomina questo documento",document.getElementById('doctitle').innerHTML);
 if(!tit) return;
 document.getElementById('doctitle').innerHTML = tit;
}

function deleteDocument()
{
 if(!confirm("Sei sicuro di voler eliminare questo documento?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.Exit();}
 sh.sendCommand("dynarc delete-item -ap '"+AP+"' -id '"+DOC_ID+"'");
}

</script>
<?php

$template->End();

?>


