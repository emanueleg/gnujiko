<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 11-01-2015
 #PACKAGE: documents
 #DESCRIPTION: Document model list.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS;

$_BASE_PATH = "../";
$_RESTRICTED_ACCESS = "documents";
$_AP = "documentmodels";

include($_BASE_PATH."var/templates/glight/index.php");
include_once($_BASE_PATH."var/objects/htmlgutility/contentpreview.php");

$template = new GLightTemplate();
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeInternalObject("serp");
$template->includeCSS('doclist.css');

$template->Begin("Modelli di documenti");
//-------------------------------------------------------------------------------------------------------------------//
$dateFrom = $_REQUEST['from'] ? $_REQUEST['from'] : "";
$dateTo = $_REQUEST['to'] ? $_REQUEST['to'] : "";

$_DEF_RPP = 25;

$_COLUMNS = array(
 0 => array('title'=>'Codice', 			'field'=>'code_num', 		'width'=>70, 		'sortable'=>true, 	'visibled'=>true),
 1 => array('title'=>'Titolo',			'field'=>'name',			'sortable'=>true,	'visibled'=>true),
 2 => array('title'=>'Categoria',		'field'=>'cat_id',			'sortable'=>true,	'visibled'=>false),
 3 => array('title'=>'Data creaz.',		'field'=>'ctime',			'width'=>100,		'sortable'=>true,	'visibled'=>true,	'format'=>'date'),
 4 => array('title'=>'Ultima mod.',		'field'=>'mtime',			'width'=>100,		'sortable'=>true,	'visibled'=>true,	'format'=>'date'),
);

/* GET COLUMN SETTINGS */
$ret = GShell("aboutconfig get -app documents -sec documentmodelslist");
if(!$ret['error'])
{
 $settings = $ret['outarr']['defaultsettings'];
 if(is_array($settings['documentmodelslist']))
 {
  $visibledColumns = explode(",",$settings['documentmodelslist']['visibledcolumns']);
  for($c=0; $c < count($_COLUMNS); $c++)
  {
   $col = $_COLUMNS[$c];
   if(in_array($col['field'], $visibledColumns))
	$_COLUMNS[$c]['visibled'] = true;
   else
	$_COLUMNS[$c]['visibled'] = false;
  }
  if($settings['documentmodelslist']['rpp'])
   $_DEF_RPP = $settings['documentmodelslist']['rpp'];
 }
}

/* GET CONFIG */
$config = array();
$ret = GShell("aboutconfig get-config -app documents");
if(!$ret['error'])
 $config = $ret['outarr']['config'];

$ret = GShell("printenv DOCUMENTS_ACTION_COPY DOCUMENTS_ACTION_CUT");
$list = $ret['outarr'];
$_ACTION_COPY = $list['DOCUMENTS_ACTION_COPY'];
$_ACTION_CUT = $list['DOCUMENTS_ACTION_CUT'];


/* STYLE */
$style = "";
if($config['interface']['documentlistfontsize'])
{
 $style.= "table.sortable-table td {font-size: ".$config['interface']['documentlistfontsize']."px}\n";
}

if($style)
 echo "<style type='text/css'>".$style."</style>";

$centerContents = "<input type='text' class='edit' style='width:290px;float:left' placeholder='Cerca un modello' id='search' value=\""
	.htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\"/>";
$centerContents.= "<input type='button' class='button-search' id='searchbtn'/>";

$_DATE_FILTERS = array('ctime'=>'Filtra x data creazione', 'mtime'=>'Ultima modifica');
if(!$_REQUEST['datefilter'])
 $_REQUEST['datefilter'] = 'ctime';

$centerContents.= "<input type='edit' class='dropdown' id='datefilter' connect='datefilterlist' readonly='true' style='width:150px;margin-left:30px' value='".$_DATE_FILTERS[$_REQUEST['datefilter']]."' retval='".$_REQUEST['datefilter']."'/>";
$centerContents.= "<ul class='popupmenu' id='datefilterlist'>";
reset($_DATE_FILTERS);
while(list($k,$v)=each($_DATE_FILTERS)){ $centerContents.= "<li value='".$k."'>".$v."</li>"; }
$centerContents.= "</ul>";

$centerContents.= "<input type='text' class='calendar' value='".($dateFrom ? date('d/m/Y',strtotime($dateFrom)) : '')."' id='datefrom'/><span class='smalltext'> al </span><input type='text' class='calendar' value='".($dateTo ? date('d/m/Y',strtotime($dateTo)) : '')."' id='dateto'/>";


$template->Header("search", $centerContents, "BTN_EXIT", 800);
//-------------------------------------------------------------------------------------------------------------------//
$_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "ctime";
$_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "DESC";
$_RPP = $_REQUEST['rpp'] ? $_REQUEST['rpp'] : $_DEF_RPP;
$_PG = $_REQUEST['pg'] ? $_REQUEST['pg'] : 1;

$_SERP = new SERP();
$_SERP->setOrderBy($_ORDER_BY);
$_SERP->setOrderMethod($_ORDER_METHOD);
$_SERP->setResultsPerPage($_RPP);
$_SERP->setCurrentPage($_PG);


$_CAT_INFO = null;
$_ROOT_CAT = null;

/* RICERCA NORMALE */
/* TODO: verificare che estensioni bisogna riportare */
$cmd = "dynarc item-list -ap `".$_AP."`";
if($_REQUEST['cat'])
{
 $ret = GShell("dynarc cat-info -ap '".$_AP."' -id '".$_REQUEST['cat']."' --include-path");
 if(!$ret['error'])
 {
  $_CAT_INFO = $ret['outarr'];
  $_ROOT_CAT = count($_CAT_INFO['pathway']) ? $_CAT_INFO['pathway'][0] : $_CAT_INFO;
  $cmd.= " -cat '".$_CAT_INFO['id']."'";
 }
}
/*else
 $cmd.= " --all-cat";*/

$where = "";
if($_REQUEST['from'] || $_REQUEST['to'])
{
 switch($_REQUEST['datefilter'])
 {
   case 'ctime' : {	
	 if($_REQUEST['from'])	$where.= " AND ctime>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND ctime<'".$_REQUEST['to']." 23:59:59'";
	} break;

   case 'mtime' : {
	 if($_REQUEST['from'])	$where.= " AND mtime>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND mtime<'".$_REQUEST['to']." 23:59:59'";
	} break;

 }
}
if($_REQUEST['search'])
{
 $qry = $_REQUEST['search'];
 if((substr($qry,0,1) == "*") && (substr($qry,-1) == "*"))
  $where.= " AND name LIKE '%".substr($qry,1,-1)."%'";
 else if(substr($qry,0,1) == "*")
  $where.= " AND name LIKE '%".substr($qry,1)."'";
 else if(substr($qry,-1) == "*")
  $where.= " AND name LIKE '".substr($qry,0,-1)."%'";
 else
  $where.= " AND (name='".$qry."' OR name LIKE '".$qry."%' OR name LIKE '%".$qry."%' OR name LIKE '%".$qry."')";
}

if($where)	$cmd.= " -where <![CDATA[".ltrim($where,' AND ')."]]>";
$cmd.= " --get-cat-name";


$_CMD = $cmd;
$ret = $_SERP->SendCommand($cmd);
$documentList = $ret['items'];

/* GET CATEGORY LIST */
$ret = GShell("dynarc cat-list -ap '".$_AP."'".($_CAT_INFO ? " -parent '".$_CAT_INFO['id']."'" : "")." --order-by 'name ASC'");
$categoryList = $ret['outarr'];

//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0);
?>
 <input type='button' class='button-blue' value="Crea un nuovo modello" onclick="NewDocument()"/>
 </td>
 <td>
	<input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='mainmenubutton'/>
	<ul class='popupmenu' id='mainmenu'>
  	 <li onclick="NewDocument()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/new_file.png" height="16"/>Nuovo modello</li>
  	 <li onclick="NewCategory(<?php if($_CAT_INFO) echo $_CAT_INFO['id']; ?>)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/folder.gif" height="16"/>Nuova <?php echo $_CAT_INFO ? "sottocategoria" : "categoria"; ?></li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="Print(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/printer.gif"/>Stampa</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="CloneDocument()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/copy.png"/>Duplica modello</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="DeleteSelected()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/trash.gif"/>Elimina modelli selezionati</li>
	 <?php
	 if($_CAT_INFO)
	 {
	  echo "<li class='separator'>&nbsp;</li>";
	  echo "<li onclick='DeleteCategory(".$_CAT_INFO['id'].")'><img src='".$_ABSOLUTE_URL."share/icons/16x16/trash.gif'/>Elimina questa categoria</li>";
	 }
	 ?>
	</ul>

	<input type='button' class="button-gray menu" value="Modifica" connect="editmenu" id="editmenubutton"/>
	<ul class='popupmenu' id='editmenu'>
  	 <li onclick="actionCut()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/cut.gif" height="16"/>Taglia</li>
  	 <li onclick="actionCopy()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/copy.png" height="16"/>Copia</li>
  	 <li onclick="actionPaste()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/paste.gif" height="16"/>Incolla</li>
	</ul>

	<input type='button' class="button-gray menu" value="Visualizza" connect="viewmenu" id="viewmenubutton"/>
	<ul class='popupmenu' id='viewmenu'>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $checked = $col['visibled'] ? true : false;
	 echo "<li><input type='checkbox'".($checked ? " checked='true'" : "")." onchange=\"showColumn('".$col['field']."',this)\"/>".$col['title']."</li>";
	}
	?>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="saveGlobalSettings()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save.gif"/>Salva configurazione</li>
	</ul>
 </td>
 <td>
  &nbsp;
 </td>
 <td width='130'>
	<span class='smalltext'>Mostra</span>
	<input type='text' class='dropdown' id='rpp' value="<?php echo $_RPP; ?> righe" retval="<?php echo $_RPP; ?>" readonly='true' connect='rpplist' style='width:80px'/>
	<ul class='popupmenu' id='rpplist'>
	 <li value='10'>10 righe</li>
	 <li value='25'>25 righe</li>
	 <li value='50'>50 righe</li>
	 <li value='100'>100 righe</li>
	 <li value='250'>250 righe</li>
	 <li value='500'>500 righe</li>
	</ul>
 </td>
 <td width='223' align='right'>
	<?php $_SERP->DrawSerpButtons(true);
 
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("fullspace");
//-------------------------------------------------------------------------------------------------------------------//
?>
<table width="100%" height="80%" cellspacing="0" cellpadding="0" border="0" id="template-outer-mask">
 <tr><td class="bg-lightgray" style="width:270px;<?php if($_REQUEST['hideleftsection']) echo 'display:none'; ?>" valign="top" id="template-left-section">
	<?php
	/* MAIN MENU */
	showMainMenu($template);

	/* CATEGORY LIST */
	?>
	<div class="categorylist" id="categorylist" style="margin-left:20px;margin-top:20px;width:248px;height:500px">
	<?php
	$ret = GShell("dynarc cat-list -ap '".$_AP."' --order-by 'name ASC'");
	$list = $ret['outarr'];
	for($c=0; $c < count($list); $c++)
	{
	 $catInfo = $list[$c];
	 echo "<div class='category".($catInfo['id'] == $_ROOT_CAT['id'] ? " categoryselected" : "")."' title=\"".$catInfo['name']."\" onclick=\"openCat("
		.$catInfo['id'].")\">".$catInfo['name']."</div>";
	}
	?>
	</div>

	<!-- TRASH -->
	<div class="trash-button" onclick="showTrash('<?php echo $_AP; ?>')">
	<?php
	$ret = GShell("dynarc trash count -ap '".$_AP."'");
	if($ret['outarr']['categories'] || $ret['outarr']['items'])
	{
	 $text = "ci sono ";
	 if($ret['outarr']['categories'] && $ret['outarr']['items'])
	  $text.= "<b>".$ret['outarr']['categories']."</b> cat. e <b>".$ret['outarr']['items']."</b> modelli nel cestino.";
	 else if($ret['outarr']['categories'])
	  $text.= "<b>".$ret['outarr']['categories']."</b> categorie nel cestino.";
	 else if($ret['outarr']['items'])
	  $text.= "<b>".$ret['outarr']['items']."</b> modelli nel cestino.";
	 echo "<img src='icons/full-trash.png'/>";
	 echo "<span class='trash-button-title'>Cestino</span><br/>";
	 echo "<span class='trash-button-subtitle'>".$text."</span>";
	}
	else
	{
	 echo "<img src='icons/trash-empty.png'/>";
	 echo "<span class='trash-button-title'>Cestino</span><br/>";
	 echo "<span class='trash-button-subtitle'>il cestino &egrave; vuoto.</span>";
	}
	?>
	</div>

	</td>
	<td style="width:8px" valign="top"><div class="vertical-gray-separator" id="template-left-bar" <?php if($_REQUEST['hideleftsection']) echo "style='cursor:pointer' onclick='ShowLeftSection()' title='Mostra barra laterale'"; ?>></div></td>
	<td class="page-contents" valign="top">
	 <div class="page-contents-body" style="padding-top:10px">
	  <!-- START OF PAGE ------------------------------------------------------------------------->

 <div class="pathway">
  <?php
  if($_CAT_INFO && ($_CAT_INFO['id'] != $_ROOT_CAT['id']))
  {
   for($c=0; $c < count($_CAT_INFO['pathway']); $c++)
   {
	$cat = $_CAT_INFO['pathway'][$c];
    echo "<a href='#' class='pathlink' onclick='openCat(".$cat['id'].")'>".$cat['name']."</a> / ";
   }
   echo "<a href='#' class='pathlink' onclick='openCat(".$_CAT_INFO['id'].")'>".$_CAT_INFO['name']."</a>";
  }
  ?>
 </div>
	  
<div id='documentlist-container' style="height:100%;overflow:auto">
<?php
if(count($categoryList))
{
 ?>
 <div class="titlebar blue-bar"><span class="titlebar orange-bar">Sottocategorie</span></div>
 <table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='categorylist'>
 <tr><!-- <th width='16'><input type='checkbox'/></th> -->
	 <!-- <th width='70'>Codice</th> -->
	 <th>Categoria</th>
 </tr>
 <?php
 for($c=0; $c < count($categoryList); $c++)
 {
  $cat = $categoryList[$c];
  $hint = $cat['name'];

  echo "<tr class='row".$row."' id='".$cat['id']."' title=\"".$hint."\">";
  //echo "<td><input type='checkbox'/></td>";
  //echo "<td><a href='#' class='link blue' onclick='openCat(".$cat['id'].")'>".($cat['code'] ? $cat['code'] : '&nbsp;')."</a></td>";
  echo "<td><a href='#' class='link blue' onclick='openCat(".$cat['id'].")'><img src='img/folder.png' width='16' style='vertical-align:top'/> ".($cat['name'] ? html_entity_decode($cat['name']) : 'senza nome')."</a></td>";
  echo "</tr>";
 }
 ?>
 </table>
 <br/>
 <br/>
 <?php
}
?>
<div class="titlebar blue-bar"><span class="titlebar blue-bar"><?php echo $_CAT_INFO ? "Categoria: ".$_CAT_INFO['name'] : "LISTA MODELLI DI DOCUMENTI"; ?></span></div>
<table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='documentlist' noprinthidden='true'>
<tr><th width='16'><input type='checkbox'/></th>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $visibled = $col['visibled'] ? true : false;
	 echo "<th".(!$visibled ? " style='display:none'" : "");
	 if($col['width'])			echo " width='".$col['width']."'";
	 if($col['field'])			echo " field='".$col['field']."'";
	 if($col['format'])			echo " format='".$col['format']."'";
	 if($col['sortable'])		echo " sortable='true'";
	 echo ">".$col['title']."</th>";
	}
	?>
	<th width='44'>&nbsp;</th>
	<th width='22'>&nbsp;</th>
</tr>
<?php
$row = 0;
for($c=0; $c < count($documentList); $c++)
{
 $item = $documentList[$c];
 $hint = $item['name'];

 echo "<tr class='row".$row."' id='".$item['id']."' title=\"".$hint."\"><td><input type='checkbox'/></td>";
 for($i=0; $i < count($_COLUMNS); $i++)
 {
  $col = $_COLUMNS[$i];
  $visibled = $col['visibled'] ? true : false;
  echo "<td".(!$visibled ? " style='display:none'>" : ">");
  switch($col['field'])
  {
   case 'code_num' : echo "<a class='link blue' href='".$_ABSOLUTE_URL."Documents/modelinfo.php?id=".$item['id']."' target='DOC-".$item['id']."'>"
	.$item['code_num']."</a>"; break;

   case 'ctime' : echo "<a class='link blue' href='".$_ABSOLUTE_URL."Documents/modelinfo.php?id=".$item['id']."' target='DOC-".$item['id']."'>"
	.date('d/m/Y',$item['ctime'])."</a>"; break;

   case 'mtime' : echo $item['mtime'] ? date('d/m/Y',$item['mtime']) : '&nbsp;'; break;

   case 'name' : echo "<a class='link blue' href='".$_ABSOLUTE_URL."Documents/modelinfo.php?id=".$item['id']."' target='DOC-".$item['id']."'>"
	.$item['name']."</a>"; break;

   case 'cat_id' : {
	 echo $item['cat_name'] ? $item['cat_name'] : "&nbsp;"; 
	} break;
  }
  echo "</td>";
 }
 echo "<td><img src='".$_ABSOLUTE_URL."share/icons/16x16/printer.gif' onclick='showPreview(".$item['id'].")' style='cursor:pointer' title='Mostra anteprima'/>";
 echo "</td>";
 echo "</tr>";
 $row = $row ? 0 : 1;
}
?>
</table>
</div>

	  <!-- END OF PAGE --------------------------------------------------------------------------->
	 </div>
	</td>
 </tr>
</table>

<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
/*-------------------------------------------------------------------------------------------------------------------*/

?>
<script>
var AP = "<?php echo $_AP; ?>";
var CAT_ID = <?php echo $_CAT_INFO ? $_CAT_INFO['id'] : '0'; ?>;
var ON_PRINTING = false;
var ON_EXPORT = false;
var ATTACH_PDF = <?php echo $config['sendmail']['attachpdf'] ? 'true' : 'false'; ?>;

var ACTION_COPY = "<?php echo $_ACTION_COPY; ?>";
var ACTION_CUT = "<?php echo $_ACTION_CUT; ?>";

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL;
	return false;
}

Template.OnInit = function(){
 /* AUTORESIZE */
 var sH = this.getScreenHeight();
 var tb = document.getElementById("template-outer-mask");
 if(tb.offsetHeight < (sH-115))
  tb.style.height = (sH-115)+"px";

 document.getElementById('documentlist-container').style.height = (sH-170)+"px";
 document.getElementById('categorylist').style.height = (sH-260)+"px";

 /* EOF - AUTORESIZE */

	this.initEd(document.getElementById('rpp'), "dropdown").onchange = function(){
		 Template.SERP.RPP = this.getValue();
		 Template.SERP.reload(0);
		}


	document.getElementById("search").onchange = function(){
			 Template.SERP.setVar("search",this.value);
			 Template.SERP.reload(0);
			};
	this.initBtn(document.getElementById("searchbtn")).onclick = function(){document.getElementById("search").onchange();}

	this.initBtn(document.getElementById('mainmenubutton'), 'popupmenu');
	this.initBtn(document.getElementById('editmenubutton'), 'popupmenu');
	this.initBtn(document.getElementById('viewmenubutton'), 'popupmenu');


	this.initEd(document.getElementById("datefrom"), "date");
	this.initEd(document.getElementById("dateto"), "date").OnDateChange = function(date){
		 Template.SERP.setVar("from",document.getElementById("datefrom").isodate);
		 Template.SERP.setVar("to",date);
		 Template.SERP.reload();
		};

	this.initEd(document.getElementById('datefilter'), 'dropdown').onchange = function(){
		 Template.SERP.setVar('datefilter',this.getValue());
		};

	this.SERP = new SERP("<?php echo $_SERP->OrderBy; ?>", "<?php echo $_SERP->OrderMethod; ?>", "<?php echo $_SERP->RPP; ?>", "<?php echo $_SERP->PG; ?>");
	var tb = this.initSortableTable(document.getElementById("documentlist"), this.SERP.OrderBy, this.SERP.OrderMethod);
	tb.OnSort = function(field, method){
		Template.SERP.OrderBy = field;
	    Template.SERP.OrderMethod = method;
		Template.SERP.reload(0);
	}
}

function openCat(catId)
{
 Template.SERP.unsetVar("search");
 Template.SERP.unsetVar("from");
 Template.SERP.unsetVar("to");
 Template.SERP.setVar("cat",catId);
 Template.SERP.reload(0);
}

function showTrash(ap)
{
 document.location.href = ABSOLUTE_URL+"Documents/trash.php?ap="+ap;
}

function NewDocument()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 window.open(ABSOLUTE_URL+"Documents/modelinfo.php?id="+a['id'],"_blank");
	}
 sh.sendCommand("dynarc new-item -ap `"+AP+"`"+(CAT_ID ? " -cat '"+CAT_ID+"'" : "")+" -perms 664");
}

function NewCategory(parentId)
{
 var title = prompt("Digita il titolo per la nuova categoria");
 if(!title) return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){openCat(a['id']);}
 sh.sendCommand("dynarc new-cat -ap '"+AP+"' -name `"+title+"` -perms 664"+(parentId ? " -parent '"+parentId+"'" : ""));
}

function setFilter(filter)
{
 Template.SERP.setVar("filter",filter);
 Template.SERP.reload();
}

function setShow(show)
{
 Template.SERP.setVar("show",show);
 Template.SERP.reload();
}

function showColumn(field,cb)
{
 var tb = document.getElementById("documentlist");
 if(cb.checked == true)
  tb.showColumn(field);
 else
  tb.hideColumn(field);
}

function actionCut()
{
 var tb = document.getElementById("documentlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun documento selezionato");

 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= ","+sel[c].id;

 ACTION_COPY = "";
 ACTION_CUT = q.substr(1);

 var sh = new GShell();
 sh.sendCommand("export -var DOCUMENTS_ACTION_CUT -value '"+ACTION_CUT+"' && export -var DOCUMENTS_ACTION_COPY -value ''");
}

function actionCopy()
{
 var tb = document.getElementById("documentlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun documento selezionato");

 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= ","+sel[c].id;

 ACTION_CUT = "";
 ACTION_COPY = q.substr(1);

 var sh = new GShell();
 sh.sendCommand("export -var DOCUMENTS_ACTION_COPY -value '"+ACTION_COPY+"' && export -var DOCUMENTS_ACTION_CUT -value ''");
}

function actionPaste()
{
 if((ACTION_CUT == "") && (ACTION_COPY == ""))
  return alert("Niente da incollare");

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload(0);}

 if(ACTION_CUT != "")
 {
  var list = ACTION_CUT.split(",");
  var q = "";
  for(var c=0; c < list.length; c++)
   q+= " -id '"+list[c]+"'";
  
  sh.sendCommand("dynarc item-move -ap '"+AP+"' -cat '"+CAT_ID+"'"+q);
 }
 else if(ACTION_COPY != "")
 {
  var list = ACTION_COPY.split(",");
  var q = "";
  for(var c=0; c < list.length; c++)
   q+= " -id '"+list[c]+"'";
  
  sh.sendCommand("dynarc item-copy -ap '"+AP+"' -cat '"+CAT_ID+"'"+q);
 }

}

function DeleteSelected()
{
 var tb = document.getElementById("documentlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun modello selezionato");
 if(!confirm("Sei sicuro di voler eliminare i modelli selezionati?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload(0);}
 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= " -id '"+sel[c].id+"'";
 sh.sendCommand("dynarc delete-item -ap '"+AP+"'"+q);
}

function DeleteCategory(catId)
{
 if(!confirm("Sei sicuro di voler rimuovere questa categoria e tutti i modelli al suo interno?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 this.showPopupMessage("La categoria è stata cancellata", 70);
	 document.location.href = ABSOLUTE_URL+"Documents/models.php";
	}
 sh.sendCommand("dynarc delete-cat -ap '"+AP+"' -id '"+catId+"'");
}

function saveGlobalSettings()
{
 var xml = "<documentmodelslist";
 var visibledColumns = "";
 var rpp = document.getElementById('rpp').getValue();

 var tb = document.getElementById("documentlist");
 for(var c=0; c < tb.fields.length; c++)
 {
  var th = tb.fields[c];
  if(th.style.display != "none")
   visibledColumns+= ","+th.getAttribute('field');
 }
 if(visibledColumns)
  xml+= " visibledcolumns='"+visibledColumns.substr(1)+"'";

 xml+= " rpp='"+rpp+"'";
 xml+= "/"+">";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){alert("Configurazione salvata");}
 sh.sendSudoCommand("aboutconfig set-config -app documents -sec documentmodelslist -xml-settings `"+xml+"`");
}

function OpenDocument(id)
{
 window.open(ABSOLUTE_URL+"GCommercialDocs/modelinfo.php?id="+id, "GCD-"+id);
}

function showPreview(id)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 var CP = new GContentPreview(a['name']);
	 CP.setContent(a['desc']);
	 if(a['css'] && a['css'][0])
	  CP.setCSS(a['css'][0]['content']);
	 CP.show();
	}
 sh.sendCommand("dynarc item-info -ap '"+AP+"' -id '"+id+"' -extget css");
}

</script>
<?php

$template->End();

?>


