<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 23-11-2014
 #PACKAGE: documents
 #DESCRIPTION: Official Gnujiko Document System
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS;

$_BASE_PATH = "../";
//$_RESTRICTED_ACCESS = "documents";
$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : "documents";

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate();
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeInternalObject("serp");
$template->includeCSS('doclist.css');

$template->Begin("Documenti cestinati");
//-------------------------------------------------------------------------------------------------------------------//
$dateFrom = $_REQUEST['from'] ? $_REQUEST['from'] : "";
$dateTo = $_REQUEST['to'] ? $_REQUEST['to'] : "";

$_DEF_RPP = 25;

$_COLUMNS = array(
 0 => array('title'=>'Codice', 			'field'=>'code_num', 		'width'=>70, 		'sortable'=>true, 	'visibled'=>true),
 1 => array('title'=>'Titolo',			'field'=>'name',			'sortable'=>true,	'visibled'=>true),
 2 => array('title'=>'Rev.',			'field'=>'rev_num',			'sortable'=>true,	'visibled'=>false),
 3 => array('title'=>'Lingua',			'field'=>'lang',			'sortable'=>true,	'visibled'=>false),
 4 => array('title'=>'Data creaz.',		'field'=>'ctime',			'width'=>100,		'sortable'=>true,	'visibled'=>true,	'format'=>'date'),
 5 => array('title'=>'Ultima mod.',		'field'=>'mtime',			'width'=>100,		'sortable'=>true,	'visibled'=>true,	'format'=>'date'),
);

/* GET COLUMN SETTINGS */
$ret = GShell("aboutconfig get -app documents -sec documentlist");
if(!$ret['error'])
{
 $settings = $ret['outarr']['defaultsettings'];
 if(is_array($settings['documentlist']))
 {
  $visibledColumns = explode(",",$settings['documentlist']['visibledcolumns']);
  for($c=0; $c < count($_COLUMNS); $c++)
  {
   $col = $_COLUMNS[$c];
   if(in_array($col['field'], $visibledColumns))
	$_COLUMNS[$c]['visibled'] = true;
   else
	$_COLUMNS[$c]['visibled'] = false;
  }
  if($settings['documentlist']['rpp'])
   $_DEF_RPP = $settings['documentlist']['rpp'];
 }
}

/* GET CONFIG */
$config = array();
$ret = GShell("aboutconfig get-config -app documents");
if(!$ret['error'])
 $config = $ret['outarr']['config'];


/* STYLE */
$style = "";
if($config['interface']['documentlistfontsize'])
{
 $style.= "table.sortable-table td {font-size: ".$config['interface']['documentlistfontsize']."px}\n";
}

if($style)
 echo "<style type='text/css'>".$style."</style>";

$centerContents = "<input type='text' class='edit' style='width:290px;float:left' placeholder='Cerca un documento' id='search' value=\""
	.htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\"/>";
$centerContents.= "<input type='button' class='button-search' id='searchbtn'/>";

$_DATE_FILTERS = array('ctime'=>'Filtra x data creazione', 'mtime'=>'Ultima modifica');
if(!$_REQUEST['datefilter'])
 $_REQUEST['datefilter'] = 'ctime';

$centerContents.= "<input type='edit' class='dropdown' id='datefilter' connect='datefilterlist' readonly='true' style='width:150px;margin-left:30px' value='".$_DATE_FILTERS[$_REQUEST['datefilter']]."' retval='".$_REQUEST['datefilter']."'/>";
$centerContents.= "<ul class='popupmenu' id='datefilterlist'>";
reset($_DATE_FILTERS);
while(list($k,$v)=each($_DATE_FILTERS)){ $centerContents.= "<li value='".$k."'>".$v."</li>"; }
$centerContents.= "</ul>";

$centerContents.= "<input type='text' class='calendar' value='".($dateFrom ? date('d/m/Y',strtotime($dateFrom)) : '')."' id='datefrom'/><span class='smalltext'> al </span><input type='text' class='calendar' value='".($dateTo ? date('d/m/Y',strtotime($dateTo)) : '')."' id='dateto'/>";


$template->Header("search", $centerContents, "BTN_EXIT", 800);
//-------------------------------------------------------------------------------------------------------------------//
$_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "ctime";
$_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "DESC";
$_RPP = $_REQUEST['rpp'] ? $_REQUEST['rpp'] : $_DEF_RPP;
$_PG = $_REQUEST['pg'] ? $_REQUEST['pg'] : 1;

$_SERP = new SERP();
$_SERP->setOrderBy($_ORDER_BY);
$_SERP->setOrderMethod($_ORDER_METHOD);
$_SERP->setResultsPerPage($_RPP);
$_SERP->setCurrentPage($_PG);


$_CAT_INFO = null;

/* RICERCA NORMALE */
$cmd = "dynarc trash list -ap `".$_AP."`";
$where = "";
if($_REQUEST['from'] || $_REQUEST['to'])
{
 switch($_REQUEST['datefilter'])
 {
   case 'ctime' : {	
	 if($_REQUEST['from'])	$where.= " AND ctime>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND ctime<'".$_REQUEST['to']." 23:59:59'";
	} break;

   case 'mtime' : {
	 if($_REQUEST['from'])	$where.= " AND mtime>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND mtime<'".$_REQUEST['to']." 23:59:59'";
	} break;

 }
}

if($where)	$cmd.= " -where `".ltrim($where,' AND ')."`";

$_CMD = $cmd;
$ret = $_SERP->SendCommand($cmd,"items","categories");
$catList = $ret['categories'];
$docList = $ret['items'];
//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0);
?>
 <input type='button' class='button-blue' value="Svuota il cestino" onclick="EmptyTrash()"/>
 </td>
 <td width='200'>
	<input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='mainmenubutton'/>
	<ul class='popupmenu' id='mainmenu'>
  	 <li onclick="RestoreSelected()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/new_file.png" height="16"/>Ripristina selezionati</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="DeleteSelected()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/trash.gif"/>Rimuovi definitivamente</li>
	</ul>

	<input type='button' class="button-gray menu" value="Visualizza" connect="viewmenu" id="viewmenubutton"/>
	<ul class='popupmenu' id='viewmenu'>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $checked = $col['visibled'] ? true : false;
	 echo "<li><input type='checkbox'".($checked ? " checked='true'" : "")." onchange=\"showColumn('".$col['field']."',this)\"/>".$col['title']."</li>";
	}
	?>
	</ul>
 </td>
 <td>
  &nbsp;
 </td>
 <td width='130'>
	<span class='smalltext'>Mostra</span>
	<input type='text' class='dropdown' id='rpp' value="<?php echo $_RPP; ?> righe" retval="<?php echo $_RPP; ?>" readonly='true' connect='rpplist' style='width:80px'/>
	<ul class='popupmenu' id='rpplist'>
	 <li value='10'>10 righe</li>
	 <li value='25'>25 righe</li>
	 <li value='50'>50 righe</li>
	 <li value='100'>100 righe</li>
	 <li value='250'>250 righe</li>
	 <li value='500'>500 righe</li>
	</ul>
 </td>
 <td width='223' align='right'>
	<?php $_SERP->DrawSerpButtons(true);
 
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("fullspace");
//-------------------------------------------------------------------------------------------------------------------//
?>
<table width="100%" height="80%" cellspacing="0" cellpadding="0" border="0" id="template-outer-mask">
 <tr><td class="bg-lightgray" style="width:270px;<?php if($_REQUEST['hideleftsection']) echo 'display:none'; ?>" valign="top" id="template-left-section">
	<?php
	/* MAIN MENU */
	showMainMenu($template);
	?>
	</td>
	<td style="width:8px" valign="top"><div class="vertical-gray-separator" id="template-left-bar" <?php if($_REQUEST['hideleftsection']) echo "style='cursor:pointer' onclick='ShowLeftSection()' title='Mostra barra laterale'"; ?>></div></td>
	<td class="page-contents" valign="top">
	 <div class="page-contents-body">
	  <!-- START OF PAGE ------------------------------------------------------------------------->
	  

<div id='documentlist-container' style="height:100%;overflow:auto">
<?php
if(count($catList))
{
 ?>
 <div class="titlebar blue-bar"><span class="titlebar orange-bar">CATEGORIE NEL CESTINO</span></div>
 <table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='categorylist'>
 <tr><th width='16'><input type='checkbox'/></th>
	 <th width='70'>Codice</th>
	 <th>Categoria</th>
 </tr>
 <?php
 for($c=0; $c < count($catList); $c++)
 {
  $cat = $catList[$c];
  $hint = $cat['name'];

  echo "<tr class='row".$row."' id='".$cat['id']."' title=\"".$hint."\"><td><input type='checkbox'/></td>";
  echo "<td>".($cat['code'] ? $cat['code'] : '&nbsp;')."</td>";
  echo "<td>".($cat['name'] ? html_entity_decode($cat['name']) : 'senza nome')."</td>";
  echo "</tr>";
 }
 ?>
 </table>
 <br/>
 <br/>
 <?php
}
?>


<div class="titlebar blue-bar"><span class="titlebar blue-bar">DOCUMENTI NEL CESTINO</span></div>
<table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='documentlist'>
<tr><th width='16'><input type='checkbox'/></th>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $visibled = $col['visibled'] ? true : false;
	 echo "<th".(!$visibled ? " style='display:none'" : "");
	 if($col['width'])			echo " width='".$col['width']."'";
	 if($col['field'])			echo " field='".$col['field']."'";
	 if($col['format'])			echo " format='".$col['format']."'";
	 if($col['sortable'])		echo " sortable='true'";
	 echo ">".$col['title']."</th>";
	}
	?>
	<th width='44'>&nbsp;</th>
	<th width='22'>&nbsp;</th>
</tr>
<?php
$row = 0;
for($c=0; $c < count($docList); $c++)
{
 $item = $docList[$c];
 $hint = $item['name'];

 echo "<tr class='row".$row."' id='".$item['id']."' title=\"".$hint."\"><td><input type='checkbox'/></td>";
 for($i=0; $i < count($_COLUMNS); $i++)
 {
  $col = $_COLUMNS[$i];
  $visibled = $col['visibled'] ? true : false;
  echo "<td".(!$visibled ? " style='display:none'>" : ">");
  switch($col['field'])
  {
   case 'code_num' : echo "<a class='link blue' href='".$_ABSOLUTE_URL."Documents/docinfo.php?id=".$item['id']."' target='DOC-".$item['id']."'>"
	.$item['code_num']."</a>"; break;

   case 'ctime' : echo "<a class='link blue' href='".$_ABSOLUTE_URL."Documents/docinfo.php?id=".$item['id']."' target='DOC-".$item['id']."'>"
	.date('d/m/Y',$item['ctime'])."</a>"; break;

   case 'mtime' : echo $item['mtime'] ? date('d/m/Y',$item['mtime']) : '&nbsp;'; break;

   case 'name' : echo "<a class='link blue' href='".$_ABSOLUTE_URL."Documents/docinfo.php?id=".$item['id']."' target='DOC-".$item['id']."'>"
	.$item['name']."</a>"; break;

   case 'rev_num' : echo $item['rev_num'] ? $item['rev_num'] : "&nbsp;"; break;

   case 'lang' : echo $item['lang'] ? $item['lang'] : "&nbsp;"; break;

   case 'category' : {
	 echo $item['cat_name'] ? $item['cat_name'] : "&nbsp;"; 
	} break;
  }
  echo "</td>";
 }
 echo "<td><img src='".$_ABSOLUTE_URL."share/icons/16x16/printer.gif' onclick='PrintDocument(".$item['id'].",\""
	.$_PDF_FILENAME."\")' style='cursor:pointer' title='Stampa'/>";
 echo "</td>";
 /*if($item['send_datetime'])
  echo "<td><img src='".$_ABSOLUTE_URL."Documents/img/emailsent.png' onclick='SendMail(".$item['id'].",\"".$_PDF_FILENAME."\")' style='cursor:pointer' title='Document inviato il ".date('d/m/Y H:i')."'/></td>";
 else
  echo "<td><img src='".$_ABSOLUTE_URL."Documents/img/sendmail.png' onclick='SendMail(".$item['id'].",\"".$_PDF_FILENAME."\")' style='cursor:pointer' title='Invia x email'/></td>";*/
 echo "</tr>";
 $row = $row ? 0 : 1;
}
?>
</table>
</div>

	  <!-- END OF PAGE --------------------------------------------------------------------------->
	 </div>
	</td>
 </tr>
</table>

<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
/*-------------------------------------------------------------------------------------------------------------------*/
$excelExportStatusArgStr = "";
/*reset($_STATUS);
while(list($k,$v) = each($_STATUS))
 $excelExportStatusArgStr.= ";".$k."=".$v;
$excelExportStatusArgStr = ltrim($excelExportStatusArgStr, ";");*/

?>
<script>
var AP = "<?php echo $_AP; ?>";
var ON_PRINTING = false;
var ON_EXPORT = false;
var ATTACH_PDF = <?php echo $config['sendmail']['attachpdf'] ? 'true' : 'false'; ?>;

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL;
	return false;
}

Template.OnInit = function(){
 /* AUTORESIZE */
 var sH = this.getScreenHeight();
 var tb = document.getElementById("template-outer-mask");
 if(tb.offsetHeight < (sH-115))
  tb.style.height = (sH-115)+"px";

 document.getElementById('documentlist-container').style.height = (sH-165)+"px";

 /* EOF - AUTORESIZE */

	this.initEd(document.getElementById('rpp'), "dropdown").onchange = function(){
		 Template.SERP.RPP = this.getValue();
		 Template.SERP.reload(0);
		}


	/*this.initEd(document.getElementById("search"), "contactextended").OnSearch = function(){
			 Template.SERP.setVar("refap","");
			 Template.SERP.setVar("refid",0);
			 if(this.value && this.data)
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",this.data['id']);
			 }
			 else
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",0);
			 }
			 Template.SERP.reload(0);
			};*/
	this.initBtn(document.getElementById("searchbtn")).onclick = function(){document.getElementById("search").OnSearch();}

	this.initBtn(document.getElementById('mainmenubutton'), 'popupmenu');
	this.initBtn(document.getElementById('viewmenubutton'), 'popupmenu');


	this.initEd(document.getElementById("datefrom"), "date");
	this.initEd(document.getElementById("dateto"), "date").OnDateChange = function(date){
		 Template.SERP.setVar("from",document.getElementById("datefrom").isodate);
		 Template.SERP.setVar("to",date);
		 Template.SERP.reload();
		};

	this.initEd(document.getElementById('datefilter'), 'dropdown').onchange = function(){
		 Template.SERP.setVar('datefilter',this.getValue());
		};

	this.SERP = new SERP("<?php echo $_SERP->OrderBy; ?>", "<?php echo $_SERP->OrderMethod; ?>", "<?php echo $_SERP->RPP; ?>", "<?php echo $_SERP->PG; ?>");
	var tb = this.initSortableTable(document.getElementById("documentlist"), this.SERP.OrderBy, this.SERP.OrderMethod);
	tb.OnSort = function(field, method){
		Template.SERP.OrderBy = field;
	    Template.SERP.OrderMethod = method;
		Template.SERP.reload(0);
	}

	if(document.getElementById("categorylist"))
	{
	 this.initSortableTable(document.getElementById("categorylist"), this.SERP.OrderBy, this.SERP.OrderMethod);
	}
}

function EmptyTrash()
{
 if(!confirm("Sei sicuro di voler vuotare il cestino? Tutti i documenti saranno rimossi per sempre e non sarà più possibile ripristinarli."))
  return;
 
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 alert("Il cestino è stato vuotato.");
	 document.location.href = ABSOLUTE_URL+"Documents/index.php";
	}
 sh.sendCommand("dynarc trash empty -ap '"+AP+"'");
}

function RestoreSelected()
{
 var tb = document.getElementById("documentlist");
 var tb2 = document.getElementById("categorylist");
 var selItems = tb.getSelectedRows();
 var selCats = tb2 ? tb2.getSelectedRows() : new Array();

 if(!selCats.length && !selItems.length)
  return alert("Nessuna categoria o documento selezionato");
 else if(selCats.length && selItems.length)
 {
  if(!confirm("Verranno ripristinate le categorie e i documenti selezionati. Continuare?"))
   return;
 }
 else if(selCats.length)
 {
  if(!confirm("Verranno ripristinate le categorie selezionate. Continuare?"))
   return;
 }
 else if(selItems.length)
 {
  if(!confirm("Verranno ripristinati i documenti selezionati. Continuare?"))
   return;
 }
  
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload(0);}
 var q = "";
 for(var c=0; c < selCats.length; c++)
  q+= " -cat '"+selCats[c].id+"'";
 for(var c=0; c < selItems.length; c++)
  q+= " -id '"+selItems[c].id+"'";

 sh.sendCommand("dynarc trash restore -ap '"+AP+"' -r"+q);
}

function DeleteSelected()
{
 var tb = document.getElementById("documentlist");
 var tb2 = document.getElementById("categorylist");

 var selItems = tb.getSelectedRows();
 var selCats = tb2 ? tb2.getSelectedRows() : new Array();

 if(!selItems.length && !selCats.length)
  return alert("Nessuna categoria o documento selezionato");
 else if(selCats.length && selItems.length)
 {
  if(!confirm("Sei sicuro di voler eliminare per sempre sia le categorie che i documenti selezionati?"))
   return;
 }
 else if(selCats.length)
 {
  if(!confirm("Sei sicuro di voler eliminare per sempre le categorie selezionate?"))
   return;
 }
 else if(selItems.length)
 {
  if(!confirm("Sei sicuro di voler eliminare per sempre i documenti selezionati?"))
   return;
 }


 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload(0);}
 var q = "";
 for(var c=0; c < selCats.length; c++)
  q+= " -cat '"+selCats[c].id+"'";
 for(var c=0; c < selItems.length; c++)
  q+= " -id '"+selItems[c].id+"'";
 sh.sendCommand("dynarc trash remove -ap '"+AP+"'"+q);
}


function OpenDocument(id)
{
 window.open(ABSOLUTE_URL+"GCommercialDocs/docinfo.php?id="+id, "GCD-"+id);
}

</script>
<?php

$template->End();

?>


