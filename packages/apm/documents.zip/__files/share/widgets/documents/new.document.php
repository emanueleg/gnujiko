<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2014 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 24-12-2014
#PACKAGE: documents
#DESCRIPTION: 
#VERSION: 2.0beta
#CHANGELOG: 
#TODO: 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;
$_BASE_PATH = '../../../';

define('VALID-GNUJIKO',1);

include($_BASE_PATH.'var/templates/glight/index.php');

$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : "documents";
$_MODELAP = $_REQUEST['modelap'] ? $_REQUEST['modelap'] : "documentmodels";
$_CATID = $_REQUEST['cat'] ? $_REQUEST['cat'] : 0;

$template = new GLightTemplate('widget');
$template->includeObject("editsearch");
$template->includeCSS("share/widgets/documents/newdocument.css");

$template->Begin('Crea un nuovo documento');

if($_REQUEST['ct'])
{
 $ret = GShell("dynarc cat-info -ap '".$_AP."' -tag '".$_REQUEST['ct']."'",$_REQUEST['sessid'],$_REQUEST['shellid']);
 if(!$ret['error'])
  $_CATID = $ret['outarr']['id'];
}

?>
<div class='glight-widget-header bg-blue'><h3>Crea un nuovo documento</h3></div>
<?php
$template->Body('widget',520);

//-------------------------------------------------------------------------------------------------------------------//
?>
<div class='glight-widget-body' style='width:464px;height:400px'>
<table width='456' cellspacing='0' cellpadding='0' border='0' class='standardform'>
<tr><td><label>Titolo</label><br/><input type='text' class='edit' id='title' style='width:460px' value=""/></td></tr>

<tr><td><hr class='h20'/></td></tr>

<tr><td><small style='color:#777777;float:left;'>seleziona un modello</small>
  <div class='pathway' id='pathway'></div>
 <br/>
 <div class='modellist' id='modellist'>
  <?php
  $ret = GShell("dynarc cat-list -ap '".$_MODELAP."' --order-by 'name ASC'",$_REQUEST['sessid'], $_REQUEST['shellid']);
  if(!$ret['error'])
  {
   $catList = $ret['outarr'];
   for($c=0; $c < count($catList); $c++)
   {
	$catInfo = $catList[$c];
    echo "<div class='model' onclick='openCat(".$catInfo['id'].",this)'><img src='img/folder-48.png'/><div class='modeltitle'>".$catInfo['name']."</div></div>";
   }
  }

  $ret = GShell("dynarc item-list -ap '".$_MODELAP."' --order-by 'name ASC' -limit 100",$_REQUEST['sessid'], $_REQUEST['shellid']);
  if(!$ret['error'])
  {
   $modelList = $ret['outarr']['items'];
   for($c=0; $c < count($modelList); $c++)
   {
    $modelInfo = $modelList[$c];
    echo "<div class='model' onclick='selectModel(this,".$modelInfo['id'].")'><img src='img/document-48.png'/><div class='modeltitle'>".$modelInfo['name']."</div></div>";
   }
  }
  ?>
 </div>
</td></tr>

<tr><td><input type='text' class='search' style="width:460px" placeholder="Cerca un modello" id="modelsearch" ap="<?php echo $_MODELAP; ?>" fields="code_str,name"/></td></tr>

</table>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$footer = "<input type='button' class='button-gray' value='Annulla' onclick='abort()'/>";
$footer.= "<input type='button' class='button-blue' value='Crea' style='float:right' onclick='SubmitAction()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";
var MODEL_AP = "<?php echo $_MODELAP; ?>";
var CAT_ID = "<?php echo $_CATID; ?>";
var SELECTED_MODEL_ID = 0;
var activeModelDiv = null;
var pathway = new Array();

function abort(){Template.Exit();}

Template.OnInit = function(){

 this.initEd(document.getElementById('modelsearch'), "search");

}

function SubmitAction()
{
 var title = document.getElementById("title").value;
 if(!SELECTED_MODEL_ID) SELECTED_MODEL_ID = document.getElementById('modelsearch').getId();

 if(!title)
  title = prompt("Devi digitare un titolo");
 if(!title) return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 if(SELECTED_MODEL_ID)
 {
  sh.OnOutput = function(o,a){
	 if(!a || !a['items']) return;
	 gframe_close(o,a['items'][0]);
	}

  sh.sendCommand("dynarc export -ap '"+MODEL_AP+"' -id '"+SELECTED_MODEL_ID+"' || dynarc import -ap '"+AP+"' -name `"+title+"` -cat '"+CAT_ID+"' -xml *.xml");
 }
 else
 {
  sh.OnOutput = function(o,a){gframe_close(o,a);}

  sh.sendCommand("dynarc new-item -ap '"+AP+"' -name `"+title+"` -cat '"+CAT_ID+"'");
 }
}

function openCat(_id, _div)
{
 if(_div)
 {
  var catName = _div.getElementsByTagName('DIV')[0].innerHTML;
  pathway.push({id:_id, name:catName});
 }
 else if(_id)
 {
  for(var c=0; c < pathway.length; c++)
  {
   if(pathway[c].id == _id)
   {
	pathway.splice(c+1);
    break;
   }
  }
 }
 else
  pathway = new Array();
 updatePathway();


 var ML = document.getElementById('modellist');
 ML.innerHTML = "";

 var sh = new GShell();
 sh.OnOutput = function(o,a,aa){
	 var catList = a ? a : new Array();
	 var itemList = aa[0]['items'] ? aa[0]['items'] : new Array();

 	 if(catList.length)
	 {
	  for(var c=0; c < catList.length; c++)
	  {
	   var catInfo = catList[c];
	   var div = document.createElement('DIV');
	   div.className = "model";
	   div.data = catInfo;
	   div.onclick = function(){openCat(this.data['id'],this);}
	   div.innerHTML = "<img src='img/folder-48.png'/"+"><div class='modeltitle'>"+catInfo['name']+"</div>";
	   ML.appendChild(div);
	  }
	 }

	 if(itemList.length)
	 {
	  for(var c=0; c < itemList.length; c++)
	  {
	   var itemInfo = itemList[c];
	   var div = document.createElement('DIV');
	   div.className = "model";
	   div.data = itemInfo;
	   div.onclick = function(){selectModel(this,this.data['id']);}
	   div.innerHTML = "<img src='img/document-48.png'/"+"><div class='modeltitle'>"+itemInfo['name']+"</div>";
	   ML.appendChild(div);
	  }
	 }

	}

 var cmd = "dynarc item-list -ap '"+MODEL_AP+"'"+(_id ? " -cat '"+_id+"'" : "")+" --order-by 'name ASC' -limit 100 || dynarc cat-list -ap '"+MODEL_AP+"'"+(_id ? " -parent '"+_id+"'" : "")+" --order-by 'name ASC'";

 sh.sendCommand(cmd);
}

function selectModel(div, id)
{
 if(activeModelDiv)
  activeModelDiv.className = "model";
 activeModelDiv = div;
 activeModelDiv.className = "model modelselected";

 SELECTED_MODEL_ID = id;
}

function updatePathway()
{
 var O = document.getElementById('pathway');
 var html = "<img src='img/home12.png' style='cursor:pointer' onclick='openCat()'/"+">";

 for(var c=0; c < pathway.length; c++)
 {
  var dir = pathway[c];
  html+= " / "+((c == (pathway.length-1)) ? "<b>"+dir.name+"</b>" : "<a href='#' onclick='openCat("+dir.id+")'>"+dir.name+"</a>");
 }

 O.innerHTML = html;
}

</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//
?>
