<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Documents'");
if($db->Read())
 $db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Doc. interni...";
 $ret = GShell("system register-app -name `Doc. interni` -desc `Documenti aziendali interni, carte intestate, ecc...` -url 'Documents/' -icon 'Documents/icon.png'",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new group */
GShell("groupadd `documents` --first-user",$_SESSION_ID,$_SHELL_ID);
/* Create new archive */
$_SHELL_OUT.= "Create new archive Documenti...";
$ret = GShell("dynarc new-archive -name `Documenti` -prefix 'documents' -group 'documents' -type 'document' -perms '664' --def-cat-perms '664' --def-item-perms '664' -launcher 'url:Documents/docinfo.php?id=%d'",$_SESSION_ID,$_SHELL_ID);

$_SHELL_OUT.= "Create new archive Modelli di documenti...";
$ret = GShell("dynarc new-archive -name `Modelli di documenti` -prefix 'documentmodels' -group 'documents' -type 'document' -perms '664' --def-cat-perms '664' --def-item-perms '664' -launcher 'url:Documents/modelinfo.php?id=%d'",$_SESSION_ID,$_SHELL_ID);


/* Installing extension */
$_SHELL_OUT.= "Install extension labels...";
$ret = GShell("dynarc install-extension 'labels' -ap 'documents'",$_SESSION_ID,$_SHELL_ID);


$_SHELL_OUT.= "Install extension attachments...";
$ret = GShell("dynarc install-extension 'attachments' -ap 'documents'",$_SESSION_ID,$_SHELL_ID);


$_SHELL_OUT.= "Install extension css...";
$ret = GShell("dynarc install-extension 'css' -ap 'documents'",$_SESSION_ID,$_SHELL_ID);


$_SHELL_OUT.= "Install extension attachments...";
$ret = GShell("dynarc install-extension 'attachments' -ap 'documentmodels'",$_SESSION_ID,$_SHELL_ID);


$_SHELL_OUT.= "Install extension css...";
$ret = GShell("dynarc install-extension 'css' -ap 'documentmodels'",$_SESSION_ID,$_SHELL_ID);