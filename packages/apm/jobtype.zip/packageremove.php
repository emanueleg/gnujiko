<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$ret = GShell("dynarc delete-archive -r -ap jobtype",$_SESSION_ID, $_SHELL_ID);

