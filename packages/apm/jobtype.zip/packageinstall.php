<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new archive */
$_SHELL_OUT.= "Create new archive Tipi di lavoro...";
$ret = GShell("dynarc new-archive -name `Tipi di lavoro` -prefix jobtype -perms 666 --default-cat-perms 666 --default-item-perms 666 -launcher `gframe -f jobtype/edit -params id=%d`",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension coding -ap jobtype",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) 
{ 
 $_SHELL_ERR = $ret['error']; 
 $_SHELL_OUT = $ret['message']; 
} 
else 
 $_SHELL_OUT.= $ret['message'];

$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_jobtype_items` ADD `hourly_rate` DECIMAL(10,4) NOT NULL, ADD `overtime_rate` DECIMAL(10,4) NOT NULL , ADD  `default_operator` INT(11) NOT NULL");
$db->Close();


