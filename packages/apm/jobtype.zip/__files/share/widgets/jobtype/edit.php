<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 10-05-2014
 #PACKAGE: jobtype
 #DESCRIPTION: Gestione tipi di lavoro.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate("widget");
$template->includeObject("editsearch");
$template->includeObject("fckeditor");

$template->Begin("Nuovo tipo di lavoro");
//-------------------------------------------------------------------------------------------------------------------//
$_AP = "jobtype";
$_ID = $_REQUEST['id'];
$ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_ID."' --get-cat-name -get `hourly_rate,overtime_rate,default_operator`",$_REQUEST['sessid'],$_REQUEST['shellid']);
if(!$ret['error'])
{
 $itemInfo = $ret['outarr'];
 $operatorId = $itemInfo['default_operator'];
 $operatorName = "";
 if($operatorId)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT username,fullname FROM gnujiko_users WHERE id='".$operatorId."'");
  $db->Read();
  $operatorName = $db->record['fullname'] ? $db->record['fullname'] : $db->record['username'];
  $db->Close();
 }
}
//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-header bg-green"><h3>Dettagli tipo di lavoro</h3></div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",650);
//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-body" style="width:634px;height:360px">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td colspan='2' width='380'><label>Titolo</label><br/>
	 <input type="text" class="edit" id="title" style="width:360px" value="<?php echo htmlspecialchars($itemInfo['name'],ENT_QUOTES); ?>"/>
	</td>
	<td><label>Operatore predefinito</label><br/>
	 <input type='text' class='search' style='width:240px' id='operator' usrid="<?php echo $operatorId; ?>" value="<?php echo $operatorName; ?>"/>
	</td>
</tr>

<tr class='separator'><td colspan='3'>&nbsp;</td></tr>

<tr><td width='200'><label>Tariffa oraria</label>
	 <input type='text' class='edit' style='width:60px' id='hourly_rate' value="<?php echo number_format($itemInfo['hourly_rate'],2,',','.'); ?>"/> &euro;</td>
	<td width='180'><label>Tariffa straord.</label>	
	 <input type='text' class='edit' style='width:60px' id='overtime_rate' value="<?php echo number_format($itemInfo['overtime_rate'],2,',','.'); ?>"/> &euro;</td>
	<td><label>Categoria</label><br/>
	 <input type='text' class='dropdown' style='width:180px;float:left' id='cat' ap="<?php echo $_AP; ?>" catid="<?php echo $itemInfo['cat_id']; ?>" value="<?php echo $itemInfo['cat_name']; ?>"/>
	 <input type='button' class='button-folder' ap="<?php echo $_AP; ?>" connect="cat" id="btnselcat"/>
	</td>
</tr>

<tr class='separator'><td colspan="3"><hr style="width:630px"/></td></tr>

<tr><td colspan='3'><label>Dettagli</label><br/>
	 <textarea class="textarea" id="description" style="width:630px;height:200px"><?php echo $itemInfo['desc']; ?></textarea>
    </td></tr>
</table>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$footer = "<input type='button' class='button-blue' value='Salva' style='float:left' onclick='SubmitAction()'/>";
$footer.= "<input type='button' class='button-gray' value='Chiudi' style='float:left;margin-left:10px' onclick='Template.Exit()'/>";
$footer.= "<input type='button' class='button-red' value='Elimina' style='float:right' onclick='DeleteJobType()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";
var ID = "<?php echo $itemInfo['id']; ?>";

Template.OnInit = function(){
	 this.initEd(document.getElementById("cat"), "catfind");
	 this.initBtn(document.getElementById("btnselcat"), "catselect");
	 this.initEd(document.getElementById("description"), "fckeditor", "Basic");
	 this.initEd(document.getElementById("operator"), "userfind");
	 this.initEd(document.getElementById("hourly_rate"), "currency");
	 this.initEd(document.getElementById("overtime_rate"), "currency");
}

function SubmitAction()
{
 var title = document.getElementById("title").value;
 var catId = document.getElementById("cat").getId();
 var operatorName = document.getElementById("operator").value;
 var operatorId = document.getElementById("operator").getId();
 var hourlyRate = parseCurrency(document.getElementById("hourly_rate").value);
 var overtimeRate = parseCurrency(document.getElementById("overtime_rate").value);
 var description = document.getElementById("description").getValue();

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 a['hourly_rate'] = hourlyRate;
	 a['overtime_rate'] = overtimeRate;
	 a['operator_id'] = operatorId;
	 a['operator_name'] = operatorName;
	 gframe_close(o,a);
	}

 sh.sendCommand("dynarc edit-item -ap '"+AP+"' -id '"+ID+"'"+(catId ? " -cat '"+catId+"'" : "")+" -name `"+title+"` -desc `"+description+"` -set `hourly_rate='"+hourlyRate+"',overtime_rate='"+overtimeRate+"',default_operator='"+operatorId+"'`");
}

function DeleteJobType()
{
 if(!confirm("Sei sicuro di voler eliminare questo tipo di lavoro?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 a['removed'] = true;
	 gframe_close(o,a);
	}
 sh.sendCommand("dynarc delete-item -ap '"+AP+"' -id '"+ID+"' -r");
}

</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

