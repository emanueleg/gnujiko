<?php

header('Location:../');
