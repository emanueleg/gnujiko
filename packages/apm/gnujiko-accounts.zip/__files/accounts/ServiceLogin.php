<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2010 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 14-11-2009
 #PACKAGE: gnujiko-accounts
 #DESCRIPTION: Account manager for Gnujiko
 #VERSION: 1.1beta
 #CHANGELOG:
 #TODO:
 
*/


