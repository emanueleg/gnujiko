<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;	 

/* 11-05-2016 : Integrato con Rubrica. */
if(version_compare($_INSTALLED_VER,"2.19beta","<" ))
{
 $_SHELL_OUT.= "Updating table gnujiko_users...";
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `gnujiko_users` ADD `rubrica_id` INT(11) NOT NULL");
 if($db->Error) 
 {
  $_SHELL_OUT.= "failed!\nMySQL Error:".$db->Error;
  $_SHELL_ERR= "MYSQL_ERROR";
 }
 else
  $_SHELL_OUT.= "done!\n";
 $db->Close();
}