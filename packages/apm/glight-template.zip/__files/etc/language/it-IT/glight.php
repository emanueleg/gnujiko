<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 27-02-2014
 #PACKAGE: glight-template
 #DESCRIPTION: Italian translation for template GLight
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_DICTIONARY;

$_DICTIONARY['Exit'] = "Esci";
$_DICTIONARY['Save and close'] = "Salva e chiudi";
$_DICTIONARY['Search...'] = "Cerca...";

