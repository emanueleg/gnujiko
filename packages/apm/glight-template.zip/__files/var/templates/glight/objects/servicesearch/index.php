<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 21-09-2014
 #PACKAGE: glight-template
 #DESCRIPTION: GLight Template - Service search object
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;

?>
<script type="text/javascript" src="<?php echo $_ABSOLUTE_URL; ?>var/templates/glight/objects/servicesearch/servicesearch.js"></script>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL; ?>var/templates/glight/objects/servicesearch/servicesearch.css" type="text/css" />

