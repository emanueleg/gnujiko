<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `glabor` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Labors/'");
if($db->Read())
 $db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Lavorazioni...";
 $ret = GShell("system register-app -name `Lavorazioni` -desc `Archivio lavorazioni` -url 'Labors/' -icon 'Labors/icon.png' -group glabor -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new archive */
$_SHELL_OUT.= "Create new archive Lavorazioni...";
$ret = GShell("dynarc new-archive -name `Lavorazioni` -prefix 'glabor' -type glabor -group 'glabor' -perms '660' --def-cat-perms '660' --def-item-perms '660' --functions-file `etc/dynarc/archive_funcs/__glabor/index.php` -launcher `gframe -f glabor/edit.item -params id=%d`",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension 'coding' -ap 'glabor'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension custompricing...";
$ret = GShell("dynarc install-extension 'custompricing' -ap 'glabor'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension glabor...";
$ret = GShell("dynarc install-extension 'glabor' -ap 'glabor'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension idoc...";
$ret = GShell("dynarc install-extension 'idoc' -ap 'glabor'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension pricing...";
$ret = GShell("dynarc install-extension 'pricing' -ap 'glabor'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension thumbnails...";
$ret = GShell("dynarc install-extension 'thumbnails' -ap 'glabor'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension vendorprices...";
$ret = GShell("dynarc install-extension 'vendorprices' -ap 'glabor'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];