<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2016 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 24-10-2016
#PACKAGE: glabor
#DESCRIPTION: 
#VERSION: 2.1beta
#CHANGELOG: 24-10-2016 : MySQLi integration.
#TODO: 
*/

global $_BASE_PATH;

function dynarcextension_labors_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_".$archiveInfo['prefix']."_labors` (
 `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
 `item_id` INT(11) NOT NULL ,
 `ref_ap` VARCHAR(64) NOT NULL ,
 `ref_id` INT(11) NOT NULL ,
 `code` VARCHAR(64) NOT NULL ,
 `name` VARCHAR(255) NOT NULL ,
 `qty` FLOAT NOT NULL ,
 INDEX (`item_id`) 
)");
 $db->Close();

 return array("message"=>"Labors extension has been installed into archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DROP TABLE IF EXISTS `dynarc_".$archiveInfo['prefix']."_labors`");
 $db->Close();

 return array("message"=>"Labors extension has been removed from archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_catset($args, $sessid, $shellid, $archiveInfo, $catInfo){return $catInfo;}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_catunset($args, $sessid, $shellid, $archiveInfo, $catInfo){return $catInfo;}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_catget($args, $sessid, $shellid, $archiveInfo, $catInfo){return $catInfo;}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_labors_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'refap' : {$refAP=$args[$c+1]; $c++;} break;
   case 'refid' : {$refID=$args[$c+1]; $c++;} break;
   case 'code' : {$code=$args[$c+1]; $c++;} break;
   case 'name' : {$name=$args[$c+1]; $c++;} break;
   case 'qty' : {$qty=$args[$c+1]; $c++;} break;
  }

 if($id)
 {
  $db = new AlpaDatabase();
  $q = "";

  if(isset($refAP))		$q.= ",ref_ap='".$refAP."'";
  if(isset($refID))		$q.= ",ref_id='".$refID."'";
  if(isset($code))		$q.= ",code='".$code."'";
  if(isset($name))		$q.= ",name='".$db->Purify($name)."'";
  if(isset($qty))		$q.= ",qty='".$qty."'";

  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_labors SET ".ltrim($q,",")." WHERE id='".$id."'");
  $db->Close();
 }
 else
 {
  $db = new AlpaDatabase();
  $db->RunQuery("INSERT INTO dynarc_".$archiveInfo['prefix']."_labors(item_id,ref_ap,ref_id,code,name,qty) VALUES('"
	.$itemInfo['id']."','".$refAP."','".$refID."','".$code."','".$db->Purify($name)."','".$qty."')");
  $id = $db->GetInsertId();
  $db->Close();
 }

 $itemInfo['last_labor'] = array('id'=>$id, 'item_id'=>$itemInfo['id'], 'refap'=>$refAP, 'refid'=>$refID, 'code'=>$code,
	'name'=>$name, 'qty'=>$qty);

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_labors_catunset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'all' : $all=true; break;
  }

 $db = new AlpaDatabase();
 if($id)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_labors WHERE id='".$id."'");
 else if($all)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_labors WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_labors_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 $itemInfo['labors'] = array();

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$archiveInfo['prefix']."_labors WHERE item_id='".$itemInfo['id']."' ORDER BY id ASC");
 while($db->Read())
 {
  $a = array("id"=>$db->record['id'], 'refap'=>$db->record['ref_ap'], 'refid'=>$db->record['ref_id'], 'code'=>$db->record['code'],
	'name'=>$db->record['name'], 'qty'=>$db->record['qty']);
  $itemInfo['labors'][] = $a;
 }

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 $xml = "<labors />";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 if(!$node)
  return ;

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_labors WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_labors_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("TRUNCATE TABLE dynarc_".$archiveInfo['prefix']."_labors");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
