<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

/* 23-03-2015 : Aggiunto campo format */
if(version_compare($_INSTALLED_VER, "2.33beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_printmodels_items` ADD `format` VARCHAR(10) NOT NULL");
 $db->Close();
}

/* 01-05-2015 : Aggiunto prima pagina e ultima pagina */
if(version_compare($_INSTALLED_VER, "2.34beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_printmodels_items` ADD `firstpage_content` LONGTEXT NOT NULL , ADD `lastpage_content` LONGTEXT NOT NULL");
 $db->Close();
}


/* 23-02-2016 : Aggiunto campo orientation */
if(version_compare($_INSTALLED_VER, "2.35beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_printmodels_items` ADD `orientation` VARCHAR(1) NOT NULL");
 $db->Close();
}