<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */

GShell("groupadd `printmodels` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new archive */

$_SHELL_OUT.= "Create new archive Modelli di stampa...";
$ret = GShell("dynarc new-archive -name `Modelli di stampa` -prefix printmodels -group `printmodels` -type document --default-cat-perms 664 --default-item-perms 664 -launcher `url:PrintModels/edit.php?id=%d`",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];

/* Installing extension */

$_SHELL_OUT.= "Install extension printmodelinfo...";
$ret = GShell("dynarc install-extension printmodelinfo -ap printmodels",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */

$_SHELL_OUT.= "Install extension css...";
$ret = GShell("dynarc install-extension css -ap printmodels",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Insert into config menu */
GShell("system cfg-add-element -name `Modelli di stampa` -sec managerial -perms 444 -icon /share/widgets/config/icons/printmodels.png -file /share/widgets/config/managerial/printmodels.php",$_SESSION_ID, $_SHELL_ID);