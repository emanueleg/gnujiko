<?php 
global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Remove archive Aliquote IVA */
$_SHELL_OUT.= "Removing archive Modelli di stampa...";
$ret = GShell("dynarc delete-archive -prefix printmodels -r",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];

/* Remove from config menu */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_config_menu WHERE cfg_file='/share/widgets/config/managerial/printmodels.php'");
if($db->Read())
 GShell("system cfg-delete-element -id `".$db->record['id']."`",$_SESSION_ID, $_SHELL_ID);
$db->Close();