<?php

/* Add basic sections */
GShell("system cfg-sec-add -name System -tag system -perms 444",$_SESSION_ID, $_SHELL_ID);
GShell("system cfg-sec-add -name `Business Management` -tag managerial -perms 444",$_SESSION_ID, $_SHELL_ID);
GShell("system cfg-sec-add -name Applications -tag apps -perms 444",$_SESSION_ID, $_SHELL_ID);

/* Add elements */
GShell("system cfg-add-element -name `Menu manager` -sec system -perms 444 -icon /share/widgets/config/icons/menumanager.png -file /share/widgets/config/system/menumanager.php",$_SESSION_ID, $_SHELL_ID);
GShell("system cfg-add-element -name `Users and Groups` -sec system -perms 444 -icon /share/widgets/config/icons/usergroups.gif -file /share/widgets/config/system/usergroups.php",$_SESSION_ID, $_SHELL_ID);
GShell("system cfg-add-element -name `Console` -sec system -perms 444 -icon /share/widgets/config/icons/terminal.png -file /share/widgets/config/system/terminal.php",$_SESSION_ID, $_SHELL_ID);
GShell("system cfg-add-element -name `FTP access` -sec system -perms 444 -icon /share/widgets/config/icons/ftp.png -file /share/widgets/config/system/ftp.php",$_SESSION_ID, $_SHELL_ID);
GShell("system cfg-add-element -name `System backup` -sec system -perms 444 -icon /share/widgets/config/icons/backup.png -file /share/widgets/config/system/systembackup.php",$_SESSION_ID, $_SHELL_ID);