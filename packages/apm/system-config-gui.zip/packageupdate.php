<?php global $_BASE_PATH, $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

/* 25-03-2013 - Aggiunto System Backup */
if(version_compare($_INSTALLED_VER, "2.14beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM gnujiko_config_menu WHERE cfg_file='/share/widgets/config/system/systembackup.php' LIMIT 1");
 if(!$db->Read())
  GShell("system cfg-add-element -name `System backup` -sec system -perms 444 -icon /share/widgets/config/icons/backup.png -file /share/widgets/config/system/systembackup.php",$_SESSION_ID, $_SHELL_ID);
 $db->Close();
}