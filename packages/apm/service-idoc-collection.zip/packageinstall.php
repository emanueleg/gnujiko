<?php

/* Verifica se esiste la cartella TECHNICAL-DATA-SHEET nell'archivio IDOC */
$ret = GShell("dynarc cat-info -ap idoc -tag `TECHNICAL-DATA-SHEET`",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 $ret = GShell("dynarc new-cat -ap idoc -tag `TECHNICAL-DATA-SHEET` -name `Schede tecniche` -code `TDS-` -group idoc",$_SESSION_ID, $_SHELL_ID);

$ret = GShell("dynarc cat-info -ap idoc -tag `GSERV` -into `TECHNICAL-DATA-SHEET`",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 $ret = GShell("dynarc new-cat -ap idoc -tag `GSERV` -name `Servizi` -code `TDS-GSERV-` -group gserv -pt `TECHNICAL-DATA-SHEET`",$_SESSION_ID, $_SHELL_ID);

$ret = GShell("dynarc cat-info -ap idoc -tag `gserv-generic` -into `GSERV`",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 $ret = GShell("dynarc new-cat -ap idoc -tag `gserv-generic` -name `Generici` -code `TDS-GSERV-1` -group gserv -pt `GSERV`",$_SESSION_ID, $_SHELL_ID);

/* INSTALLA L'ESTENSIONE IDOC NELL'ARCHIVIO SERVIZI */
$ret = GShell("dynarc install-extension idoc -ap gserv",$_SESSION_ID, $_SHELL_ID);

/* IMPORT XML MODEL */
$ret = GShell("dynarc import -ap idoc -ct `gserv-generic` -group gserv --overwrite -f tmp/scheda-servizio.xml",$_SESSION_ID, $_SHELL_ID);

