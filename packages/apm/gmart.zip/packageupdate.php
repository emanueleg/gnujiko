<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

/* ??-10-2013 : Aggiunto location */
if(version_compare($_INSTALLED_VER, "2.69beta","<"))
{
 $db = new AlpaDatabase();
 $db2 = new AlpaDatabase();
 $db->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE archive_type='gmart'");
 while($db->Read())
 {
  $db2->RunQuery("ALTER TABLE `dynarc_".$db->record['tb_prefix']."_items` ADD `item_location` VARCHAR(64) NOT NULL");
 }
 $db2->Close();
 $db->Close();
}

/* 23-10-2013 : aggiunto gebinde e division */
if(version_compare($_INSTALLED_VER, "2.70beta","<"))
{
 $db = new AlpaDatabase();
 $db2 = new AlpaDatabase();
 $db->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE archive_type='gmart'");
 while($db->Read())
 {
  $db2->RunQuery("ALTER TABLE `dynarc_".$db->record['tb_prefix']."_items` ADD `gebinde` VARCHAR(32) NOT NULL , ADD `gebinde_code` VARCHAR(32) NOT NULL, ADD `division` VARCHAR(32) NOT NULL");
 }
 $db2->Close();
 $db->Close();
}

/* 02-06-2014 : CREA CATEGORIA NELLE MARCHE */
if(version_compare($_INSTALLED_VER, "2.71beta","<"))
{
 $ret = GShell("dynarc cat-info -ap brands -tag gmart",$_SESSION_ID,$_SHELL_ID);
 if($ret['error'])
  GShell("dynarc new-cat -ap brands -tag gmart -name 'MARCHE ARTICOLI' -group gmart",$_SESSION_ID,$_SHELL_ID);

 /* Installing extension */
 GShell("dynarc install-extension pricesbyqty -ap gmart",$_SESSION_ID,$_SHELL_ID);
 GShell("dynarc install-extension varcodes -ap gmart",$_SESSION_ID,$_SHELL_ID);
}

/* 26-09-2015 : aggiunto hide_in_store */
if(version_compare($_INSTALLED_VER, "2.72beta","<"))
{
 $db = new AlpaDatabase();
 $db2 = new AlpaDatabase();
 $db->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE archive_type='gmart'");
 while($db->Read())
 {
  $db2->RunQuery("ALTER TABLE `dynarc_".$db->record['tb_prefix']."_items` ADD `hide_in_store` TINYINT(1) NOT NULL, ADD INDEX (`hide_in_store`)");
 }
 $db2->Close();
 $db->Close();	
}

/* 02-03-2016 : aggiornamenti importanti */
if(version_compare($_INSTALLED_VER, "2.73beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE archive_type='gmart'");
 while($db->Read())
 {
  GShell("gmart update-counters -ap '".$db->record['tb_prefix']."'", $_SESSION_ID, $_SHELL_ID);
 }
 $db->Close();
}	 

/* 03-12-2016 : aggiornamenti importanti */
if(version_compare($_INSTALLED_VER, "2.79beta","<"))
{
 $db = new AlpaDatabase();
 $_SHELL_OUT.= "Create table product_sku...";
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `product_sku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(40) NOT NULL,
  `referrer` varchar(64) NOT NULL,
  `ref_at` varchar(64) NOT NULL,
  `ref_ap` varchar(64) NOT NULL,
  `ref_id` int(11) unsigned NOT NULL,
  `variant_id` int(11) unsigned NOT NULL,
  `coltint` varchar(64) NOT NULL,
  `sizmis` varchar(64) NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sku` (`sku`,`ref_ap`,`ref_id`),
  KEY `variant_id` (`variant_id`)
)");
 if($db->Error)
 {
  $_SHELL_OUT.= "failed!\nMySQL Error: ".$db->Error;
  $_SHELL_ERR = "MYSQL_ERROR";
  $db->Close();
  return;
 }
 $_SHELL_OUT.= "done!\n";
 $_SHELL_OUT.= "Create table product_spid...";
  
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `product_spid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_at` varchar(64) NOT NULL,
  `ref_ap` varchar(64) NOT NULL,
  `ref_id` int(11) NOT NULL,
  `asin` varchar(10) NOT NULL,
  `ean` varchar(13) NOT NULL,
  `gcid` varchar(40) NOT NULL,
  `gtin` varchar(40) NOT NULL,
  `upc` varchar(10) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `coltint` varchar(64) NOT NULL,
  `sizmis` varchar(64) NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ref_ap` (`ref_ap`,`ref_id`,`asin`,`ean`,`gcid`,`gtin`,`upc`)
)");
 if($db->Error)
 {
  $_SHELL_OUT.= "failed!\nMySQL Error: ".$db->Error;
  $_SHELL_ERR = "MYSQL_ERROR";
  $db->Close();
  return;
 }
 $_SHELL_OUT.= "done!\n";
}