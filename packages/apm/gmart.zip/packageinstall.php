<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `gmart` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Products/'");
if($db->Read())
$db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Prodotti...";
 $ret = GShell("system register-app -name `Prodotti` -desc `Catalogo articoli personalizzabile` -url 'Products/' -icon 'Products/icon.png' -group gmart -perms 640",$_SESSION_ID, $_SHELL_ID);
 $_SHELL_OUT.= $ret['message'];
}

$_SHELL_OUT.= "Create table product_sku...";
$db->RunQuery("CREATE TABLE IF NOT EXISTS `product_sku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(40) NOT NULL,
  `referrer` varchar(64) NOT NULL,
  `ref_at` varchar(64) NOT NULL,
  `ref_ap` varchar(64) NOT NULL,
  `ref_id` int(11) unsigned NOT NULL,
  `variant_id` int(11) unsigned NOT NULL,
  `coltint` varchar(64) NOT NULL,
  `sizmis` varchar(64) NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sku` (`sku`,`ref_ap`,`ref_id`),
  KEY `variant_id` (`variant_id`)
)");

if($db->Error)
{
 $_SHELL_OUT.= "failed!\nMySQL Error: ".$db->Error;
 $_SHELL_ERR = "MYSQL_ERROR";
 $db->Close();
 return;
}

$_SHELL_OUT.= "done!\n";

$_SHELL_OUT.= "Create table product_spid...";
$db->RunQuery("CREATE TABLE IF NOT EXISTS `product_spid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_at` varchar(64) NOT NULL,
  `ref_ap` varchar(64) NOT NULL,
  `ref_id` int(11) NOT NULL,
  `asin` varchar(10) NOT NULL,
  `ean` varchar(13) NOT NULL,
  `gcid` varchar(40) NOT NULL,
  `gtin` varchar(40) NOT NULL,
  `upc` varchar(10) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `coltint` varchar(64) NOT NULL,
  `sizmis` varchar(64) NOT NULL,
  `trash` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ref_ap` (`ref_ap`,`ref_id`,`asin`,`ean`,`gcid`,`gtin`,`upc`)
)");

if($db->Error)
{
 $_SHELL_OUT.= "failed!\nMySQL Error: ".$db->Error;
 $_SHELL_ERR = "MYSQL_ERROR";
 $db->Close();
 return;
}
$_SHELL_OUT.= "done!\n";

$db->Close();

/* Create new archive */
$_SHELL_OUT.= "Create new archive Catalogo prodotti...";
$ret = GShell("dynarc new-archive -name `Catalogo prodotti` -prefix gmart -group `gmart` -type gmart --default-cat-perms 664 --default-item-perms 664 --functions-file etc/dynarc/archive_funcs/__gmart/index.php --hidden",$_SESSION_ID,$_SHELL_ID);

/* Installing extension */
$_SHELL_OUT.= "Install extension gmart...";
$ret = GShell("dynarc install-extension gmart -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension coding -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension pricing...";
$ret = GShell("dynarc install-extension pricing -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension custompricing...";
$ret = GShell("dynarc install-extension custompricing -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension storeinfo...";
$ret = GShell("dynarc install-extension storeinfo -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension thumbnails...";
$ret = GShell("dynarc install-extension thumbnails -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension vendorprices...";
$ret = GShell("dynarc install-extension vendorprices -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension idoc...";
$ret = GShell("dynarc install-extension idoc -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension variants...";
$ret = GShell("dynarc install-extension variants -ap gmart",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc install-extension variantstock -ap gmart",$_SESSION_ID, $_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* CREA CATEGORIA NELLE MARCHE */
$ret = GShell("dynarc cat-info -ap brands -tag gmart",$_SESSION_ID,$_SHELL_ID);
if($ret['error'])
 GShell("dynarc new-cat -ap brands -tag gmart -name 'MARCHE ARTICOLI' -group gmart",$_SESSION_ID,$_SHELL_ID);

/* Installing extension */
$_SHELL_OUT.= "Install extension pricesbyqty...";
$ret = GShell("dynarc install-extension pricesbyqty -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension varcodes...";
$ret = GShell("dynarc install-extension varcodes -ap gmart",$_SESSION_ID,$_SHELL_ID);
$_SHELL_OUT.= $ret['message'];