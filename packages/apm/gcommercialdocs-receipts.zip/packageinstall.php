<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `commdocs-receipts` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new category */
$_SHELL_OUT.= "Create new category Ricevute Fiscali...";
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Ricevute Fiscali` -tag RECEIPTS -group `commdocs-receipts` --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) 
{ 
 $_SHELL_ERR = $ret['error']; 
 $_SHELL_OUT = $ret['message']; 
} 
else 
 $_SHELL_OUT.= $ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create new category Ricevute Fiscali...";
$ret = GShell("dynarc new-cat -ap printmodels -name `Ricevute Fiscali` -tag RECEIPTS -pt commercialdocs -group `commdocs-receipts`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/demo-receipt.xml -ap `printmodels` -ct RECEIPTS",$_SESSION_ID,$_SHELL_ID);