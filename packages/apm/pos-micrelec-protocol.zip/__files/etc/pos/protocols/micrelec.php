<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 09-12-2013
 #PACKAGE: pos-micrelec-protocol
 #DESCRIPTION: POS module - Micrelec printer protocols file.
 #VERSION: 2.2beta
 #CHANGELOG: 09-12-2013 : Bug fix.
			 06-12-2013 : Modificato IVA al 22 (Rg 60, Col 120)
 #TODO:
 
*/
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoposprotocol_micrelec_info()
{
 return array("description"=>"Micrelec 310");
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoposprotocol_micrelec_parse($_AP, $_ID, $sessid, $shellid, $fileName="")
{
 global $_BASE_PATH, $_ABSOLUTE_URL, $_COMPANY_PROFILE;
 include_once($_BASE_PATH."include/company-profile.php");
 $_CO = $_COMPANY_PROFILE;

 /* GET ORDER INFO */
 $ret = GShell("dynarc item-info -ap `".$_AP."` -id `".$_ID."` -extget `cdinfo,cdelements`",$sessid,$shellid);
 if(!$ret['error'])
  $docInfo = $ret['outarr'];

 /* GET DOCUMENT CAT INFO */
 $ret = GShell("dynarc cat-info -ap '".$_AP."' -id `".$docInfo['cat_id']."`",$sessid,$shellid);
 if(!$ret['error'])
  $docInfo['catinfo'] = $ret['outarr'];

 /* GET CAT TAG */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT tag,parent_id FROM dynarc_".$_AP."_categories WHERE id='".$itemInfo['cat_id']."'");
 if($db->Read())
 {
  if($db->record['parent_id'])
  {
   $db->RunQuery("SELECT tag FROM dynarc_".$_AP."_categories WHERE id='".$db->record['parent_id']."'");
   $db->Read();
   $_CAT_TAG = $db->record['tag']; 
  }
  else
   $_CAT_TAG = $db->record['tag'];
 }
 $db->Close();

 $output = "";
 for($c=0; $c < count($docInfo['elements']); $c++)
 {
  $el = $docInfo['elements'][$c];
  $vat = $el['price'] ? (($el['price']/100)*$el['vatrate']) : 0;
  $output.= "3/S/".trim(substr($el['name'],0,20))."//".sprintf("%.3f",$el['qty'])."/".sprintf("%.2f",$el['price'])."/1/22/\n"; 
 }
 $output.= "5/1/0.00//1.000000/SALDO/\n";

 if(!$fileName)
  $fileName = "tmp/scontrino.txt";
 $ret = GShell("echo `".$output."` > `".$fileName."`",$sessid,$shellid);
 if(!$ret['error'])
  $ret['outarr'] = array('filename' => $fileName);
 return $ret;
}
//-------------------------------------------------------------------------------------------------------------------//

