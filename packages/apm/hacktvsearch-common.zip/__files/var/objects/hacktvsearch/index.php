<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 04-06-2013
 #PACKAGE: hacktvsearch-common
 #DESCRIPTION: HackTVT Search Engine, common files.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

include_once($_BASE_PATH."var/objects/hacktvtse/index.php");

?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL; ?>var/objects/hacktvsearch/hacktvsearch.css" type="text/css" />
<script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>var/objects/hacktvsearch/hacktvsearch.js" type="text/javascript"></script>

