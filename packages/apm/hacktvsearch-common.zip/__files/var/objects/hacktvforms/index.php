<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 04-06-2013
 #PACKAGE: hacktvsearch-common
 #DESCRIPTION: Collection of interactive forms.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

include_once($_BASE_PATH."include/layers.php");
include_once($_BASE_PATH."var/objects/htmlgutility/screenshot.php");

?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL; ?>var/objects/hacktvforms/css/hacktvforms-common.css" type="text/css" />
<script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>var/objects/hacktvforms/js/hacktvforms-common.js" type="text/javascript"></script>


