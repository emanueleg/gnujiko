<?php

/* Verifica se esiste la cartella TECHNICAL-DATA-SHEET nell'archivio IDOC */
$ret = GShell("dynarc cat-info -ap idoc -tag `TECHNICAL-DATA-SHEET`",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 $ret = GShell("dynarc new-cat -ap idoc -tag `TECHNICAL-DATA-SHEET` -name `Schede tecniche` -code `TDS-` -group idoc",$_SESSION_ID, $_SHELL_ID);

$ret = GShell("dynarc cat-info -ap idoc -tag `RUBRICA` -into `TECHNICAL-DATA-SHEET`",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 $ret = GShell("dynarc new-cat -ap idoc -tag `RUBRICA` -name `Rubrica` -code `TDS-RUBRICA-` -group rubrica -pt `TECHNICAL-DATA-SHEET`",$_SESSION_ID, $_SHELL_ID);

$ret = GShell("dynarc cat-info -ap idoc -tag `rubrica-generic` -into `RUBRICA`",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 $ret = GShell("dynarc new-cat -ap idoc -tag `rubrica-generic` -name `Generici` -code `TDS-RUBRICA-1` -group rubrica -pt `RUBRICA`",$_SESSION_ID, $_SHELL_ID);

/* IMPORT XML MODEL */
$ret = GShell("dynarc import -ap idoc -ct `rubrica-generic` -group rubrica --overwrite -f tmp/scheda-dipendente-collaboratore.xml",$_SESSION_ID, $_SHELL_ID);

