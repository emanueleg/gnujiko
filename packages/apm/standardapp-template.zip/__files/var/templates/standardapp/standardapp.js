/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-12-2013
 #PACKAGE: standardapp-template
 #DESCRIPTION: 
 #VERSION: 2.2beta
 #CHANGELOG: 24-12-2013 : Aggiunto funzionalità di selezione su tabella.
 #TODO:
 
*/

//-------------------------------------------------------------------------------------------------------------------//
function StandardAppHandler()
{
}
//-------------------------------------------------------------------------------------------------------------------//
StandardAppHandler.prototype.makeSortableTable = function(tb, defField, defSort)
{
 tb.activeFieldA = null;
 
 /* EVENTS */
 tb.OnSort = function(field, method){};
 tb.OnSelect = function(){};

 /* INJECT FIELDS */
 for(var c=0; c < tb.rows[0].cells.length; c++)
 {
  var th = tb.rows[0].cells[c];
  if(th.getAttribute('sortable') == 'true')
  {
   var a = document.createElement('A');
   a.innerHTML = th.innerHTML;
   a.href = "#";
   a.th = th;
   a.tb = tb;
   a.onclick = function(){
	 if(this.tb.activeFieldA == this)
	 {
	  this.className = (this.className == "sortasc") ? "sortdesc" : "sortasc";
	 }
	 else
	 {
	  if(this.tb.activeFieldA)
	   this.tb.activeFieldA.className = "";
	  this.className = "sortasc";
	  this.tb.activeFieldA = this;
	 }
     // shot event
	 tb.OnSort(this.th.getAttribute('field'), (this.className == "sortasc") ? "ASC" : "DESC");
	}
   
   if(defField == th.getAttribute('field'))
   {
	a.className = (defSort.toUpperCase() == "ASC") ? "sortasc" : "sortdesc";
    tb.activeFieldA = a;
   }

   th.innerHTML = "";
   th.appendChild(a);
  }

 }

 /* INJECT CHECKBOX FOR THE FIRST ROW */
 if(tb.rows[0])
 {
  var cb = tb.rows[0].cells[0].getElementsByTagName('INPUT')[0];
  if(cb)
  {
   cb.tb = tb;
   cb.onclick = function(){
	 if(this.checked)
	  this.tb.selectAll();
	 else
	  this.tb.unselectAll();
	}
  }
 }

 /* INJECT ROWS */
 for(var c=1; c < tb.rows.length; c++)
 {
  var r = tb.rows[c];
  r.tb = tb;
  var cb = r.cells[0].getElementsByTagName('INPUT')[0];
  if(cb)
  {
   cb.r = r;
   cb.onclick = function(){this.r.toggleSelect();}
  }

  r.select = function(shotEvent){
	 this.className = "selected";
	 var cb = this.cells[0].getElementsByTagName('INPUT')[0];
	 if(cb)
	  cb.checked = true;
	 if(shotEvent && this.tb.OnSelect)
	  this.tb.OnSelect(this.tb.getSelectedRows());
	};
  
  r.unselect = function(shotEvent){
	 this.className = "";
	 var cb = this.cells[0].getElementsByTagName('INPUT')[0];
	 if(cb)
	  cb.checked = false;
	 if(shotEvent && this.tb.OnSelect)
	  this.tb.OnSelect(this.tb.getSelectedRows());
	};

  r.toggleSelect = function(){
	 var cb = this.cells[0].getElementsByTagName('INPUT')[0];
	 if(!cb)
	  return;
	 this.className = cb.checked ? "selected" : "";
	 if(this.tb.OnSelect)
	  this.tb.OnSelect(this.tb.getSelectedRows());
	}
 }

 /* INJECT OTHER FUNCTIONS */
 tb.getSelectedRows = function(){
	 var ret = new Array();
	 for(var c=1; c < this.rows.length; c++)
	 {
	  var cb = this.rows[c].cells[0].getElementsByTagName('INPUT')[0];
	  if(!cb)
	   continue;
	  if(cb.checked)
	   ret.push(this.rows[c]);
	 }
	 return ret;
	};

 tb.selectAll = function(){
	 if(!this.rows.length)
	  return;
	 for(var c=1; c < this.rows.length; c++)
	  this.rows[c].select();
	 var cb = this.rows[0].cells[0].getElementsByTagName('INPUT')[0];
	 if(!cb)
	  return;
	 cb.checked = true;

	 if(this.OnSelect)
	  this.OnSelect(this.getSelectedRows());
	};

 tb.unselectAll = function(){
	 if(!this.rows.length)
	  return;
	 for(var c=1; c < this.rows.length; c++)
	  this.rows[c].unselect();
	 var cb = this.rows[0].cells[0].getElementsByTagName('INPUT')[0];
	 if(!cb)
	  return;
	 cb.checked = false;

	 if(this.OnSelect)
	  this.OnSelect(this.getSelectedRows());
	};


 return tb;
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
var StandardApp = new StandardAppHandler();
//-------------------------------------------------------------------------------------------------------------------//

