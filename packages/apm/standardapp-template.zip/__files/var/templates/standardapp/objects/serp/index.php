<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 10-12-2013
 #PACKAGE: standardapp-template
 #DESCRIPTION: SERP Object.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;

?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL; ?>var/templates/standardapp/objects/serp/serp.css" type="text/css" />
<script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>var/templates/standardapp/objects/serp/serp.js" type="text/javascript"/></script>
<?php

class SERP
{
 // public
 var $ORDER_BY, $ORDER_METHOD, $RPP, $PG;
 var $Results, $MaxPG;
 // private
 var $lastErrorCode, $lastErrorMsg;

 function SERP()
 {
  $this->OrderBy = "";
  $this->OrderMethod = "ASC";
  $this->RPP = 0;
  $this->PG = 1;
  $this->MaxPG = 1;

  $this->Results = array("from"=>0, "to"=>0, "count"=>0, "items"=>array());

  // PRIVATE //
  $this->lastErrorCode = "";
  $this->lastErrorMsg = "";
 }

 function setOrderBy($orderBy){$this->OrderBy=$orderBy;}
 function setOrderMethod($orderMethod){$this->OrderMethod=$orderMethod;}
 function setResultsPerPage($rpp){$this->RPP=$rpp;}
 function setCurrentPage($page){$this->PG=$page;}
 function getErrorCode(){return $this->lastErrorCode;}
 function getErrorMessage(){return $this->lastErrorMsg;}

 /* PRIVATE FUNCTIONS ---------------------------------------------------------------------------------------------- */
 function returnError($ret){$this->lastErrorCode=$ret['error']; $this->lastErrorMsg=$ret['message']; return false;}

 /* OUBLIC FUNCTIONS ----------------------------------------------------------------------------------------------- */
 function SendCommand($cmd)
 {
  if($this->OrderBy)
   $cmd.= " --order-by '".$this->OrderBy." ".($this->OrderMethod ? $this->OrderMethod : "ASC")."'";
  if($this->RPP)
  {
   if($this->PG > 1)
   {
    $this->Results['from'] = ($this->RPP*($this->PG-1))+1;
    $limit = ($this->RPP*($this->PG-1)).",".$this->RPP;
   }
   else
   {
    $this->Results['from'] = 1;
    $limit = $this->RPP;
   }
   $cmd.= " -limit '".$limit."'";
  }

  $ret = GShell($cmd);
  if($ret['error'])
   return $this->returnError($ret);

  $this->Results['to'] = ($this->Results['from']-1)+$this->RPP;
  $this->Results['count'] = $ret['outarr']['count'];
  
  if($this->Results['to'] > $this->Results['count'])
   $this->Results['to'] = $this->Results['count'];

  if($this->Results['count'])
   $this->MaxPG = ceil($this->Results['count']/$this->RPP);
  
  $this->Results['items'] = $ret['outarr']['items'];

  return $this->Results;
 }


}

