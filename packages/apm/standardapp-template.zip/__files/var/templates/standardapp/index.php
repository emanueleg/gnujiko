<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 23-11-2013
 #PACKAGE: standardapp-template
 #DESCRIPTION: Template for standard applications
 #VERSION: 2.0beta
 #CHANGELOG: 23-11-2013 : Aggiunta classe StandardApp con funzioni varie.
 #TODO:
 
*/
global $_BASE_PATH, $_ABSOLUTE_URL, $_DESKTOP_SHOW_TOOLBAR, $_DESKTOP_TITLE, $_APPLICATION_CONFIG;

$_DESKTOP_SHOW_TOOLBAR = false;
$_DESKTOP_BACKGROUND = "#ffffff";
//$_DESKTOP_TITLE = "Untitled Application";
$_TPLDIR = "var/templates/standardapp/";

define("VALID-GNUJIKO",1);

include($_BASE_PATH.'init/init1.php');
include($_BASE_PATH.'include/session.php');
include_once($_BASE_PATH."include/gshell.php");

//-------------------------------------------------------------------------------------------------------------------//
class StandardApp
{
 var $AppName, $PageTitle, $Config;
 var $mainMenuSelIdx, $subMenuSelIdx;
 //------------------------------------------------------------------------------------------------------------------//
 function StandardApp($title="")
 {
  global $_ABSOLUTE_URL, $_APPLICATION_CONFIG;
  if(!file_exists("config.php"))
  {
   /* TODO: ritornare un errore */
   return;
  }
  include_once("config.php");
  $this->Config = $_APPLICATION_CONFIG;
  $this->AppName = $title ? $title : $this->Config['appname'];

  /* Get selected page */
  $this->mainMenuSelIdx = 0;
  for($c=0; $c < count($this->Config['mainmenu']); $c++)
  {
   $itm = $this->Config['mainmenu'][$c];
   $url = $this->Config['basepath'].$itm['url'];
   $active = (strpos($_SERVER['REQUEST_URI'],$url) !== FALSE) ? true : false;
   if($active)
	$this->mainMenuSelIdx = $c;
  }
  $this->PageTitle = $this->Config['mainmenu'][$this->mainMenuSelIdx]['title'];
  ?>
  <html><head><meta http-equiv="content-type" content="text/html; charset=UTF-8"><title><?php echo $this->AppName." - ".$this->PageTitle; ?></title></head>
  <link rel="shortcut icon" href="<?php echo $_ABSOLUTE_URL; ?>share/images/favicon.png" />
  <link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL; ?>var/templates/standardapp/css/template.css" type="text/css" />
  <script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>var/templates/standardapp/standardapp.js" type="text/javascript"></script>
  <?php
 }
 //------------------------------------------------------------------------------------------------------------------//
 function StartPage($pageTitle="")
 {
  global $_BASE_PATH, $_ABSOLUTE_URL, $_DESKTOP_TITLE;
  $_DESKTOP_TITLE = $pageTitle ? $pageTitle : $this->PageTitle;
  include($_BASE_PATH.'include/headings/desktop.php');
  if(($this->Config['access'] == "restricted") && ($_SESSION['UNAME'] != "root"))
  {
   $continue = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
   /* ACCESS DENIED */
   ?>
   <div class='access-denied'><h3>ACCESSO NEGATO</h3>
   <form method='POST' action="<?php echo $_ABSOLUTE_URL; ?>accounts/LoginAuth.php">
    <input type='hidden' name='continue' value="<?php echo $continue; ?>"/>
    <input type='hidden' name='Username' value="root"/>
    <p>L'accesso a questa pagina è riservato esclusivamente all'amministratore di sistema. (<b>root</b>)</p>
    <p><img src="<?php echo $_ABSOLUTE_URL; ?>var/templates/standardapp/img/access-key.png" style="vertical-align:top;text-align:left;margin:12px;float:left;"/>
	<small>Per accedere all'area riservata devi digitare la password di <b>root</b>.</small><br/><br/>
	<small>Password:</small><br/>
	 <input type='password' name='Password' size='12' maxlength='40' id='password'/> <input type="submit" class="submit" name="signIn" value="Accedi"/>
	<?php
	if($_REQUEST['err'] == "badlogin")
	 echo "<br/><small style='color:red;'>La password inserita è sbagliata!</small>";
	?>
    </p>
   </form>
   </div>
   <script>
   document.getElementById('password').focus();
   </script>   
   <?php

   $this->Finish();
   return false;
  }
  return true;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function StartHeader($title="")
 {
  global $_BASE_PATH, $_ABSOLUTE_URL;
  if(!$title) $title = $this->AppName;
  echo "<div class='standardapp-header'>";
  echo "<table width='1000' cellspacing='0' cellpadding='0' border='0' class='standardapp-header-inner'>";
  echo "<tr><td width='175' valign='middle' class='standardapp-header-title'>".$title."</td>";
  echo "<td valign='middle' align='left'>";
 }
 //------------------------------------------------------------------------------------------------------------------//
 function EndHeader()
 {
  global $_BASE_PATH, $_ABSOLUTE_URL;
  echo "</td></tr></table></div>";
 }
 //------------------------------------------------------------------------------------------------------------------//
 function StartContent()
 {
  global $_BASE_PATH, $_ABSOLUTE_URL;
  
  echo "<table width='1000' cellspacing='0' cellpadding='0' border='0' class='standardapp-content-inner'>";
  echo "<tr><td width='220' valign='top'>";
  /* MAIN MENU */
  echo "<ul class='standardapp-main-menu'>";
  for($c=0; $c < count($this->Config['mainmenu']); $c++)
  {
   $itm = $this->Config['mainmenu'][$c];
   $url = $this->Config['basepath'].$itm['url'];
   $active = ($this->mainMenuSelIdx == $c) ? true : false;
   echo "<a href='".$_ABSOLUTE_URL.$url."'><li class='item".($active ? " selected" : "")."'>".$itm['title']."</li></a>";
  }
  echo "</ul>";
  echo "<hr style='width:190px;float:left'/>";
  if(isset($this->Config['submenu']) && count($this->Config['submenu']))
  {
   /* SUB MENU */
   echo "<ul class='standardapp-sub-menu' style='float:left'>";
   for($c=0; $c < count($this->Config['submenu']); $c++)
   {
    $itm = $this->Config['submenu'][$c];
    $url = $this->Config['basepath'].$itm['url'];
    $active = $itm['active'];
    echo "<a href='".($itm['onclick'] ? "#" : $_ABSOLUTE_URL.$url)."'"
	.($itm['onclick'] ? " onclick=\"".$itm['onclick']."\"" : "")."><li class='item".($active ? " selected" : "")."'>".$itm['title']."</li></a>";
   }
   echo "</ul>";
  }
  echo "</td><td valign='top'>";
 }
 //------------------------------------------------------------------------------------------------------------------//
 function showPageTitle($text="", $rightContent="")
 {
  if(!$text) $text = $this->PageTitle;
  echo "<div class='standardapp-content-title'>";
  echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
  echo "<tr><td valign='middle' align='left' class='standardapp-content-title-text'>".$text."</td>";
  echo "<td align='right'>".($rightContent ? $rightContent : "&nbsp;")."</td></tr>";
  echo "</table>";
  echo "</div>";
 }
 //------------------------------------------------------------------------------------------------------------------//
 function showAlert($text="", $rightContent="", $style="")
 {
  echo "<div class='standardapp-alert-title'".($style ? " style='".$style."'" : "").">";
  echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
  echo "<tr><td valign='middle' align='left' class='standardapp-alert-title-text'>".$text."</td>";
  echo "<td align='right'>".($rightContent ? $rightContent : "&nbsp;")."</td></tr>";
  echo "</table>";
  echo "</div>";
 }
 //------------------------------------------------------------------------------------------------------------------//
 function EndContent()
 {
  global $_BASE_PATH, $_ABSOLUTE_URL;
  echo "</td></tr></table>";
 }
 //------------------------------------------------------------------------------------------------------------------//
 function Finish()
 {
  global $_BASE_PATH, $_ABSOLUTE_URL;
  include($_BASE_PATH.'include/footers/desktop.php');
  echo "</body></html>";
 }
 //------------------------------------------------------------------------------------------------------------------//
}
//--- EOF CLASS -----------------------------------------------------------------------------------------------------//

