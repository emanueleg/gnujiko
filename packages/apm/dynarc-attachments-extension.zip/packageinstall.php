<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2012 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 21-11-2012
 #PACKAGE: dynarc-attachments-extension
 #DESCRIPTION: Attachments support for categories and items into archives managed by Dynarc. Installer file.
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `dynattachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `_mod` varchar(3) NOT NULL,
  `archive_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `tag` varchar(80) NOT NULL,
  `tbtag` varchar(255) NOT NULL,
  `name` varchar(80) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `linktype` varchar(16) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ctime` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`gid`,`_mod`,`archive_id`,`item_id`,`tag`,`tbtag`,`name`,`keywords`,`linktype`,`url`),
  KEY `cat_id` (`cat_id`)
)");
$db->Close();