<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* 25-08-2014 : Sostituito float con decimal su ship_costs e price */
$db = new AlpaDatabase();
$db->RunQuery("SELECT archive_id FROM dynarc_archive_extensions WHERE extension_name='vendorprices'");
while($db->Read())
{
 $db2 = new AlpaDatabase();
 $db2->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE id='".$db->record['archive_id']."'");
 if($db2->Read())
 {
  $db2->RunQuery("ALTER TABLE `dynarc_".$db2->record['tb_prefix']."_items` CHANGE `ship_costs` `ship_costs` DECIMAL(10,4) NOT NULL, CHANGE `price` `price` DECIMAL(10,4) NOT NULL");
 }
 $db2->Close();
}
$db->Close();