<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

GShell("system unregister-app -name `Tickets`",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc delete-archive -ap tickets -r",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc delete-archive -ap tickettypes -r",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc delete-cat -ap 'printmodels' -tag ticketsystem -r",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc delete-archive -ap ticketzones -r",$_SESSION_ID, $_SHELL_ID);