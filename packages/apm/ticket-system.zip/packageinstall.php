<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `tickets` --first-user",$_SESSION_ID,$_SHELL_ID);
/* Create new archive */
$_SHELL_OUT.= "Create new archive Tickets...";
$ret = GShell("dynarc new-archive -name `Tickets` -prefix 'tickets' -group 'tickets' -perms '660' --def-cat-perms '660' --def-item-perms '660' --functions-file etc/dynarc/archive_funcs/__tickets/index.php -launcher `url:Tickets/ticketinfo.php?id=%d`",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];


/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Tickets/'");
if($db->Read())
 $db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Tickets...";
 $ret = GShell("system register-app -name `Tickets` -desc `Ticket System` -url 'Tickets/' -icon 'Tickets/icon.png' -group tickets -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

$_SHELL_OUT.= "Create new archive Tipi di Ticket...";
$ret = GShell("dynarc new-archive -name `Tipi di Ticket` -prefix 'tickettypes' -group 'tickets' -perms '660' --def-cat-perms '660' --def-item-perms '660'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension 'coding' -ap 'tickets'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension ticketinfo...";
$ret = GShell("dynarc install-extension 'ticketinfo' -ap 'tickets'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension cdelements...";
$ret = GShell("dynarc install-extension 'cdelements' -ap 'tickets'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension cronevents...";
$ret = GShell("dynarc install-extension 'cronevents' -ap 'tickets'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension 'coding' -ap 'tickettypes'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension tickettype...";
$ret = GShell("dynarc install-extension 'tickettype' -ap 'tickettypes'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create category Ticket System...";
$ret = GShell("dynarc new-cat -ap 'printmodels' -name `Ticket System` -tag `ticketsystem` -group 'tickets' -perms '664'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Create category Tickets...";
$ret = GShell("dynarc new-cat -ap 'printmodels' -name `Tickets` -tag `tickets` -pt ticketsystem -group 'tickets' -perms '664'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

GShell("dynarc import -f tmp/demo-ticket.xml -ap `printmodels` -ct tickets",$_SESSION_ID,$_SHELL_ID);

GShell("dynarc new-item -ap tickettypes -name `Intervento in sede` -code-str IIS -group tickets -perms 664",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap tickettypes -name `Intervento presso cliente` -code-str IPC -group tickets -perms 664",$_SESSION_ID,$_SHELL_ID);

GShell("dynarc install-extension interventions -ap tickets",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc new-archive -name `Ticket - Zone` -prefix ticketzones -group tickets -perms 660 --def-cat-perms 660 --def-item-perms 660",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc install-extension coding -ap ticketzones",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc new-cat -ap rubrica -name Dipendenti -tag employees -group rubrica -perms 664 --if-not-exists --publish",$_SESSION_ID, $_SHELL_ID);