<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

if(version_compare($_INSTALLED_VER,"2.35beta","<" ))
{
 $ret = GShell("dynarc edit-archive -ap tickets -launcher `url:Tickets/ticketinfo.php?id=%d`",$_SESSION_ID, $_SHELL_ID);
 GShell("dynarc install-extension interventions -ap tickets",$_SESSION_ID, $_SHELL_ID);
 GShell("dynarc new-archive -name `Ticket - Zone` -prefix ticketzones -group tickets -perms 660 --def-cat-perms 660 --def-item-perms 660",$_SESSION_ID, $_SHELL_ID);
 GShell("dynarc install-extension coding -ap ticketzones",$_SESSION_ID, $_SHELL_ID);
 GShell("dynarc new-cat -ap rubrica -name Dipendenti -tag employees -group rubrica -perms 664 --if-not-exists --publish",$_SESSION_ID, $_SHELL_ID);
}
 
/* 04-10-2014 : Fix vendor_id into table elements */
if(version_compare($_INSTALLED_VER,"2.36beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_tickets_elements` ADD `vendor_id` INT(11) NOT NULL");
 $db->Close();
}

/* 15-10-2014 : Sistemato gli status */
if(version_compare($_INSTALLED_VER,"2.37beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_tickets_items` ADD `print_datetime` DATETIME NOT NULL, ADD `print_filename` VARCHAR(255) NOT NULL, ADD `send_datetime` DATETIME NOT NULL, ADD `send_email` VARCHAR(255) NOT NULL");
 $db->Close();
}

/* 18-10-2014 : Aggiunto campo ticket_ref_file */
if(version_compare($_INSTALLED_VER,"2.38beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_tickets_items` ADD `ticket_ref_file` VARCHAR(255) NOT NULL");
 $db->Close();
}

/* 01-12-2014 : Aggiunto campi */
if(version_compare($_INSTALLED_VER,"2.39beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_tickets_items` ADD `hw_id` INT(11) NOT NULL,
ADD `hw_name` VARCHAR(32) NOT NULL ,
ADD `shelf` VARCHAR(32) NOT NULL ,
ADD `request` TEXT NOT NULL ,
ADD `datatosave` TEXT NOT NULL ,
ADD `accessories` TEXT NOT NULL ,
ADD INDEX (`hw_id`,`shelf`)");
 $db->Close();
}

/* 16-12-2014 : Aggiunto rit. acconto */
if(version_compare($_INSTALLED_VER,"2.40beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_tickets_elements` ADD `rit_acc_apply` TINYINT(1) NOT NULL");
 $db->Close();
}

/* 03-02-2014 : Aggiunto xml_data */
if(version_compare($_INSTALLED_VER,"2.41beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_tickets_elements` ADD `xml_data` TEXT NOT NULL");
 $db->Close();
}

/* 10-05-2016 : Aggiunto campi customer e commiss */
if(version_compare($_INSTALLED_VER,"2.44beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_tickets_items` ADD `customer_id` INT(11) NOT NULL, ADD `customer_name` VARCHAR(48) NOT NULL, ADD `commiss_id` INT(11) NOT NULL, ADD `commiss_name` VARCHAR(48) NOT NULL, ADD INDEX (`customer_id`,`commiss_id`)");
 $db->Close();
}	 

/* 25-05-2016 : Aggiunto campo ext_contract_ref e vat_id */
if(version_compare($_INSTALLED_VER,"2.45beta","<" ))
{
 $_SHELL_OUT.= "Update table dynarc_tickets_items...";
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_tickets_items` ADD `ext_contract_ref` VARCHAR(32) NOT NULL, ADD `vat_id` INT(11) NOT NULL");
 if($db->Error)
 {
  $_SHELL_OUT.= "failed!\nMySQL Error: ".$db->Error;
  $_SHELL_ERR = "MYSQL_ERROR";
 }
 else
  $_SHELL_OUT.= "done!\n";
 $db->Close();
}

// 12/11/2016 - Rev. 2.56beta
if(version_compare($_INSTALLED_VER,"2.56beta","<" ))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_tickets_items` ADD `priority` TINYINT(1) UNSIGNED NOT NULL, ADD `phone` VARCHAR(14) NOT NULL, ADD INDEX (`priority`)");
 $db->Close();
}