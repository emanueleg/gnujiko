<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 17-06-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Official Gnujiko Ticket System
 #VERSION: 2.12beta
 #CHANGELOG: 17-06-2016 : Aggiunti chiavi su sendAlert e sendMail ed inclusione degli allegati interni.
			 07-06-2016 : Aggiunto chiavi su funzioni sendMail e sendTechMail.
			 27-05-2016 : Aggiunta funzione sendTechMail
			 26-05-2016 : Aggiornata funzione sendAlert e generate-invoice.
			 17-05-2016 : Aggiunta funzione sendalert ed aggiornate chiavi su generate-invoice.
			 30-11-2014 : Aggiunto nuovi campi su funzione clone ed exportExploded.
			 15-11-2014 : Aggiunta funzione export-exploded
			 14-11-2014 : Creata funzione per duplicare ticket.
			 10-11-2014 : Bug fix su status chiusura ticket.
			 01-11-2014 : Bug fix indirizzi su funzione sendmail.
			 18-10-2014 : Aggiornata funzione sendmail.
			 14-10-2014 : Aggiunta funzione sendmail.
 
 #TODO: Aggiornare funzione sendTechMail una volta inserito campi sendtechtime e sendtechmail su estensione ticketinfo.
 
*/

function shell_ticket($args, $sessid, $shellid=0)
{
 $output = "";
 $outArr = array();

 if(count($args) == 0)
  return ticket_invalidArguments();

 switch($args[0])
 {
  case "generate-preemptive" : return ticket_generatePreemptive($args, $sessid, $shellid); break;
  case "generate-invoice" : return ticket_generateInvoice($args, $sessid, $shellid); break;
  case "generate-receipt" : return ticket_generateReceipt($args, $sessid, $shellid); break;
  case "sendmail" : case "send-mail" : return ticket_sendMail($args, $sessid, $shellid); break;
  case "sendtechmail" : case "send-tech-mail" : return ticket_sendTechMail($args, $sessid, $shellid); break;
  case "sendalert" : case "send-alert" : return ticket_sendAlert($args, $sessid, $shellid); break;
  case "clone" : return ticket_clone($args, $sessid, $shellid); break;
  case "export-exploded" : return ticket_exportExploded($args, $sessid, $shellid); break;
  case "interv-summary-bytech" : return ticket_intervSummaryByTech($args, $sessid, $shellid); break;
  case "interv-summary-bycustomer" : return ticket_intervSummaryByCustomer($args, $sessid, $shellid); break;
  case "request-list" : return ticket_requestList($args, $sessid, $shellid); break;
  case "request-info" : return ticket_requestInfo($args, $sessid, $shellid); break;
  case "edit-request" : return ticket_editRequest($args, $sessid, $shellid); break;
  case "delete-request" : return ticket_deleteRequest($args, $sessid, $shellid); break;
  case "generate-from-request" : return ticket_generateFromRequest($args, $sessid, $shellid); break;

  default : return ticket_invalidArguments(); break;
 }
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_invalidArguments()
{
 return array("message"=>"Invalid arguments.", "error"=>"INVALID_ARGUMENTS");
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_generatePreemptive($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();
 $_AP = "tickets";

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_ID=$args[$c+1]; $c++;} break;
   case '-status' : {$status=$args[$c+1]; $c++;} break;
  }

 $ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_ID."' -extget `cdelements` -get subject_id",$sessid,$shellid);
 if($ret['error'])
  return $ret;
 $docInfo = $ret['outarr'];

 /* generate preemptive */
 $ret = GShell("commercialdocs generate-fast-document -type preemptives -subjectid '".$docInfo['subject_id']."'"
	.(isset($status) ? " -status '".$status."'" : ""),$sessid,$shellid);
 if($ret['error'])
  return array("message"=>"Unable to create preemptive.\n".$ret['message'], "error"=>$ret['error']);
 $preemptiveInfo = $ret['outarr'];
 $docId = $preemptiveInfo['id'];

 /* INSERT ELEMENTS */
 for($i=0; $i < count($docInfo['elements']); $i++)
 {
  $el = $docInfo['elements'][$i];
  GShell("dynarc edit-item -ap `commercialdocs` -id `".$docId."` -extset `cdelements.type='".$el['type']."',refap='".$el['ref_ap']."',refid='"
	.$el['ref_id']."',code='".$el['code']."',sn='".$el['serialnumber']."',lot='".$el['lot']."',accountid='".$el['account_id']."',name='''"
	.$el['name']."''',desc='''".$el['desc']."''',qty='".$el['qty']."',price='".$el['price']."',discount='".$el['discount']."',discount2='"
	.$el['discount2']."',discount3='".$el['discount3']."',vatrate='".$el['vatrate']."',vatid='".$el['vatid']."',vattype='"
	.$el['vattype']."',units='".$el['units']."',pricelistid='".$el['pricelist_id']."',bypass-vatregister-update=true`");
 }

 $out.= "The preemptive has been generated! ID=".$docId;

 /* set preemptive reference */
 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE dynarc_".$_AP."_items SET preemptive_id='".$docId."' WHERE id='".$docInfo['id']."'");
 $db->Close();

 /* UPDATING TOTALS */
 $out.= "\nUpdating totals...";
 $ret = GShell("commercialdocs updatetotals -id '".$docId."'",$sessid,$shellid);
 if($ret['error'])
  $out.= "failed\n".$ret['message'];
 else
 {
  $out.= "\ndone!\n".$ret['message'];
  $outArr = $ret['outarr'];
 }

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_generateInvoice($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();
 $_AP = "tickets";
 $_ID = 0;
 $_IDS = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_ID=$args[$c+1]; $c++;} break;
   case '-ids' : {$_IDS=explode(',',$args[$c+1]); $c++;} break;
   case '-status' : {$status=$args[$c+1]; $c++;} break;
  }

 $_REF_SCHEMA = "Rif. Ticket n.{NUM} del {DATE}";
 $_REF_SCHEMANOTE = "";

 $_REF_KEYS = array('{NUM}','{DATE}','{TIME}','{TKTREF}','{TYPE}','{CUSTOMER}','{FULLADDRESS}','{ZONE}','{CLOSEDATE}','{CLOSETIME}'
	,'{OPERATOR}','{TECH1}','{TECH2}','{TAXDELIVERY}','{ADDR_CODE}','{ADDR_TITLE}','{ADDR_ADDRESS}','{ADDR_CITY}','{ADDR_ZIP}'
	,'{ADDR_PROV}','{ADDR_CC}','{ADDR_NOTE}','{INTERVDATE}','{INTERVDESC}');

 /* GET CONFIG */
 $ret = GShell("aboutconfig get-config -app tickets",$sessid,$shellid);
 if(!$ret['error'])
 {
  $config = $ret['outarr']['config'];
  if($config['closure']['ticketrefschema'])
   $_REF_SCHEMA = $config['closure']['ticketrefschema'];
  if($config['closure']['ticketrefschemanote'])
   $_REF_SCHEMANOTE = $config['closure']['ticketrefschemanote'];
 }

 if(count($_IDS))
 {
  $outArr['invoices'] = array();
  /* Raggruppa i tickets per cliente e genera le rispettive fatture */
  $_TICKETS = array();
  $_TICKET_BY_SUBJECT = array();
  for($c=0; $c < count($_IDS); $c++)
  {
   $ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_IDS[$c]."' -extget `ticketinfo,cdelements,interventions`",$sessid,$shellid);
   if($ret['error']) return $ret;
   $ticketInfo = $ret['outarr'];

   $_TICKETS[] = $ticketInfo;
   if(!$_TICKET_BY_SUBJECT[$ticketInfo['subject_id']])
	$_TICKET_BY_SUBJECT[$ticketInfo['subject_id']] = array();
   $_TICKET_BY_SUBJECT[$ticketInfo['subject_id']][] = $ticketInfo;
  }

  reset($_TICKET_BY_SUBJECT);
  while(list($subjectId,$ticketList) = each($_TICKET_BY_SUBJECT))
  {
   /* generate invoice */
   $ret = GShell("commercialdocs generate-fast-document -type invoices -subjectid '".$subjectId."'".(isset($status) ? " -status '".$status."'" : ""),$sessid,$shellid);
   if($ret['error']) return array("message"=>"Unable to create invoice.\n".$ret['message'], "error"=>$ret['error']);
   $invoiceInfo = $ret['outarr'];

   /* insert elements */
   for($c=0; $c < count($ticketList); $c++)
   {
	$ticketInfo = $ticketList[$c];
    $intervInfo = (is_array($ticketInfo['interventions']) && count($ticketInfo['interventions'])) ? $ticketInfo['interventions'][0] : null;
	$_REF_VALUES = array(
		 $ticketInfo['code_num'],
		 date('d/m/Y',$ticketInfo['ctime']),
		 date('H:i',$ticketInfo['ctime']),
		 $ticketInfo['ext_ticket_ref'],
		 $ticketInfo['type_name'],
		 $ticketInfo['subject_name'],
		 $ticketInfo['address'],
		 $ticketInfo['zone'],
		 date('d/m/Y',strtotime($ticketInfo['finish_datetime'])),
		 date('H:i',strtotime($ticketInfo['finish_datetime'])),
		 $ticketInfo['operator_name'],
		 $ticketInfo['tech_1_name'],
		 $ticketInfo['tech_2_name'],
		 date('d/m/Y',strtotime($ticketInfo['tax_delivery'])),
		 $ticketInfo['addr_code'],
		 $ticketInfo['addr_title'],
		 $ticketInfo['addr_address'],
		 $ticketInfo['addr_city'],
		 $ticketInfo['addr_zipcode'],
		 $ticketInfo['addr_province'],
		 $ticketInfo['addr_cc'],
		 $ticketInfo['addr_note'],
		 $intervInfo ? $intervInfo['date'] : '',
		 $intervInfo ? $intervInfo['name'] : ''
		);
	$reference = str_replace($_REF_KEYS, $_REF_VALUES, $_REF_SCHEMA);
	$referenceNote = str_replace($_REF_KEYS, $_REF_VALUES, $_REF_SCHEMANOTE);

	// verifica se tutti gli elementi hanno la stessa aliquota IVA, altrimenti è necessario inserire ogni elemento //
	$ok = true;
	$vatId = null;
	$vatRate = 0;
	$vatType = "";
	for($i=0; $i < count($ticketInfo['elements']); $i++)
	{
	 $el = $ticketInfo['elements'][$i];
	 if(!$el['price'])
	  continue;
	 if(!isset($vatId))
	 {
	  $vatId = $el['vatid'];
	  $vatRate = $el['vatrate'];
	  $vatType = $el['vattype'];
	  continue;
	 }
	 if($el['vatid'] != $vatId)
	 {
	  $ok = false;
	  break;
	 }
	}

	if(!$vatId && $ticketInfo['vat_id'])
	{
	 $db = new AlpaDatabase();
	 $db->RunQuery("SELECT vat_type,percentage FROM dynarc_vatrates_items WHERE id='".$ticketInfo['vat_id']."'");
	 if($db->Read())
	 {
	  $vatId = $ticketInfo['vat_id'];
	  $vatRate = $db->record['percentage'];
	  $vatType = $db->record['vat_type'];
	 }
	 $db->Close();
	}

	if($ok)
	{
	 GShell("dynarc edit-item -ap `commercialdocs` -id `".$invoiceInfo['id']."` -extset `cdelements.type='custom',name='''"
		.$reference."''',qty='1',price='".$ticketInfo['amount']."',vatrate='".$vatRate."',vatid='".$vatId."',vattype='"
		.$vatType."',bypass-vatregister-update=true`",$sessid,$shellid);
	 if($referenceNote)
	  GShell("dynarc edit-item -ap `commercialdocs` -id `".$invoiceInfo['id']."` -extset `cdelements.type='note',desc='''"
		.$referenceNote."''',bypass-vatregister-update=true`",$sessid,$shellid);
	}
	else
	{
	 GShell("dynarc edit-item -ap `commercialdocs` -id `".$invoiceInfo['id']."` -extset `cdelements.type='note',desc='''"
		.$reference."''',bypass-vatregister-update=true`",$sessid,$shellid);
	 if($referenceNote)
	  GShell("dynarc edit-item -ap `commercialdocs` -id `".$invoiceInfo['id']."` -extset `cdelements.type='note',desc='''"
		.$referenceNote."''',bypass-vatregister-update=true`",$sessid,$shellid);

	 for($i=0; $i < count($ticketInfo['elements']); $i++)
  	 {
   	  $el = $ticketInfo['elements'][$i];
   	  GShell("dynarc edit-item -ap `commercialdocs` -id `".$invoiceInfo['id']."` -extset `cdelements.type='".$el['type']."',refap='"
		.$el['ref_ap']."',refid='".$el['ref_id']."',code='".$el['code']."',sn='".$el['serialnumber']."',lot='".$el['lot']."',accountid='"
		.$el['account_id']."',name='''".$el['name']."''',desc='''".$el['desc']."''',qty='".$el['qty']."',price='".$el['price']."',discount='"
		.$el['discount']."',discount2='".$el['discount2']."',discount3='".$el['discount3']."',vatrate='".$el['vatrate']."',vatid='"
		.$el['vatid']."',vattype='".$el['vattype']."',units='".$el['units']."',pricelistid='".$el['pricelist_id']."',bypass-vatregister-update=true`",$sessid,$shellid);
  	 }
	}

    /* set invoice reference */
    $db = new AlpaDatabase();
    $db->RunQuery("UPDATE dynarc_".$_AP."_items SET invoice_id='".$invoiceInfo['id']."',status='110' WHERE id='".$ticketInfo['id']."'");
    $db->Close();

    if($ticketInfo['preemptive_id'])
     GShell("dynarc edit-item -ap commercialdocs -id `".$ticketInfo['preemptive_id']."` -extset `cdinfo.conv-id='".$invoiceInfo['id']."',status='8'`",$sessid,$shellid);
   }
   $outArr['invoices'][] = $invoiceInfo;
   $out.= "The invoice for ".$ticketList[0]['subject_name']." has been generated! ID=".$invoiceInfo['id']."\n";

   /* updating totals */
   $out.= "\nUpdating totals...";
   $ret = GShell("commercialdocs updatetotals -id '".$invoiceInfo['id']."'",$sessid,$shellid);
   if($ret['error']) $out.= "failed\n".$ret['message'];
   else $out.= "\ndone!\n".$ret['message'];
  }
 }
 else
 {
  /* Genera fattura da un ticket */
  $ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_ID."' -extget `cdelements,interventions` -get `subject_id,preemptive_id,payment_mode,total,vat_id`",$sessid,$shellid);
  if($ret['error']) return $ret;
  $docInfo = $ret['outarr'];
  $intervInfo = (is_array($docInfo['interventions']) && count($docInfo['interventions'])) ? $docInfo['interventions'][0] : null;

  /* generate invoice */
  $ret = GShell("commercialdocs generate-fast-document -type invoices -subjectid '".$docInfo['subject_id']."'"
	.(isset($status) ? " -status '".$status."'" : ""),$sessid,$shellid);
  if($ret['error']) return array("message"=>"Unable to create invoice.\n".$ret['message'], "error"=>$ret['error']);
  $invoiceInfo = $ret['outarr'];
  $docId = $invoiceInfo['id'];

	$_REF_VALUES = array(
		 $docInfo['code_num'],
		 date('d/m/Y',$docInfo['ctime']),
		 date('H:i',$docInfo['ctime']),
		 $docInfo['ext_ticket_ref'],
		 $docInfo['type_name'],
		 $docInfo['subject_name'],
		 $docInfo['address'],
		 $docInfo['zone'],
		 date('d/m/Y',strtotime($docInfo['finish_datetime'])),
		 date('H:i',strtotime($docInfo['finish_datetime'])),
		 $docInfo['operator_name'],
		 $docInfo['tech_1_name'],
		 $docInfo['tech_2_name'],
		 date('d/m/Y',strtotime($docInfo['tax_delivery'])),
		 $docInfo['addr_code'],
		 $docInfo['addr_title'],
		 $docInfo['addr_address'],
		 $docInfo['addr_city'],
		 $docInfo['addr_zipcode'],
		 $docInfo['addr_province'],
		 $docInfo['addr_cc'],
		 $docInfo['addr_note'],
		 $intervInfo ? $intervInfo['date'] : '',
		 $intervInfo ? $intervInfo['name'] : ''
		);
	$reference = str_replace($_REF_KEYS, $_REF_VALUES, $_REF_SCHEMA);
	$referenceNote = str_replace($_REF_KEYS, $_REF_VALUES, $_REF_SCHEMANOTE);

  /* INSERT REFERENCE */
  GShell("dynarc edit-item -ap `commercialdocs` -id `".$invoiceInfo['id']."` -extset `cdelements.type='note',desc='''"
	.$reference."''',bypass-vatregister-update=true`",$sessid,$shellid);
  if($referenceNote)
   GShell("dynarc edit-item -ap `commercialdocs` -id `".$invoiceInfo['id']."` -extset `cdelements.type='note',desc='''"
	.$referenceNote."''',bypass-vatregister-update=true`",$sessid,$shellid);
  /* INSERT ELEMENTS */
  for($i=0; $i < count($docInfo['elements']); $i++)
  {
   $el = $docInfo['elements'][$i];
   GShell("dynarc edit-item -ap `commercialdocs` -id `".$docId."` -extset `cdelements.type='".$el['type']."',refap='".$el['ref_ap']."',refid='"
	.$el['ref_id']."',code='".$el['code']."',sn='".$el['serialnumber']."',lot='".$el['lot']."',accountid='".$el['account_id']."',name='''"
	.$el['name']."''',desc='''".$el['desc']."''',qty='".$el['qty']."',price='".$el['price']."',discount='".$el['discount']."',discount2='"
	.$el['discount2']."',discount3='".$el['discount3']."',vatrate='".$el['vatrate']."',vatid='".$el['vatid']."',vattype='"
	.$el['vattype']."',units='".$el['units']."',pricelistid='".$el['pricelist_id']."',bypass-vatregister-update=true`",$sessid,$shellid);
  }

  $out.= "The invoice has been generated! ID=".$docId;

  /* set invoice reference */
  $db = new AlpaDatabase();
  $db->RunQuery("UPDATE dynarc_".$_AP."_items SET invoice_id='".$docId."' WHERE id='".$docInfo['id']."'");
  $db->Close();

  if($docInfo['preemptive_id'])
   GShell("dynarc edit-item -ap commercialdocs -id `".$docInfo['preemptive_id']."` -extset `cdinfo.conv-id='".$docId."',status='8'`",$sessid,$shellid);

  /* UPDATING TOTALS */
  $out.= "\nUpdating totals...";
  $ret = GShell("commercialdocs updatetotals -id '".$docId."'",$sessid,$shellid);
  if($ret['error'])
   $out.= "failed\n".$ret['message'];
  else
  {
   $out.= "\ndone!\n".$ret['message'];
   $outArr = $ret['outarr'];
  }

  switch($docInfo['payment_mode'])
  {
   case 'bancomat' : case 'creditcard' : case 'cash' : {
	 $ret = ticket_setInvoicePaid($invoiceInfo,$docInfo['total'],$sessid,$shellid);
	 if($ret['error'])
	  return $ret;
	} break;
  }
 }

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_generateReceipt($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();
 $_AP = "tickets";

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_ID=$args[$c+1]; $c++;} break;
   case '-status' : {$status=$args[$c+1]; $c++;} break;
  }

 $ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_ID."' -extget `cdelements` -get `subject_id,preemptive_id,payment_mode,total`",$sessid,$shellid);
 if($ret['error'])
  return $ret;
 $docInfo = $ret['outarr'];

 /* generate invoice */
 $ret = GShell("commercialdocs generate-fast-document -type receipts -subjectid '".$docInfo['subject_id']."'"
	.(isset($status) ? " -status '".$status."'" : ""),$sessid,$shellid);
 if($ret['error'])
  return array("message"=>"Unable to create receipt.\n".$ret['message'], "error"=>$ret['error']);
 $invoiceInfo = $ret['outarr'];
 $docId = $invoiceInfo['id'];

 /* INSERT ELEMENTS */
 for($i=0; $i < count($docInfo['elements']); $i++)
 {
  $el = $docInfo['elements'][$i];
  GShell("dynarc edit-item -ap `commercialdocs` -id `".$docId."` -extset `cdelements.type='".$el['type']."',refap='".$el['ref_ap']."',refid='"
	.$el['ref_id']."',code='".$el['code']."',sn='".$el['serialnumber']."',lot='".$el['lot']."',accountid='".$el['account_id']."',name='''"
	.$el['name']."''',desc='''".$el['desc']."''',qty='".$el['qty']."',price='".$el['price']."',discount='".$el['discount']."',discount2='"
	.$el['discount2']."',discount3='".$el['discount3']."',vatrate='".$el['vatrate']."',vatid='".$el['vatid']."',vattype='"
	.$el['vattype']."',units='".$el['units']."',pricelistid='".$el['pricelist_id']."',bypass-vatregister-update=true`");
 }

 $out.= "The receipt has been generated! ID=".$docId;

 /* set receipt reference */
 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE dynarc_".$_AP."_items SET invoice_id='".$docId."' WHERE id='".$docInfo['id']."'");
 $db->Close();

 if($docInfo['preemptive_id'])
  GShell("dynarc edit-item -ap commercialdocs -id `".$docInfo['preemptive_id']."` -extset `cdinfo.conv-id='".$docId."',status='8'`",$sessid,$shellid);

 /* UPDATING TOTALS */
 $out.= "\nUpdating totals...";
 $ret = GShell("commercialdocs updatetotals -id '".$docId."'",$sessid,$shellid);
 if($ret['error'])
  $out.= "failed\n".$ret['message'];
 else
 {
  $out.= "\ndone!\n".$ret['message'];
  $outArr = $ret['outarr'];
 }

 switch($docInfo['payment_mode'])
 {
  case 'bancomat' : case 'creditcard' : case 'cash' : {
	 $ret = ticket_setInvoicePaid($invoiceInfo,$docInfo['total'],$sessid,$shellid);
	 if($ret['error'])
	  return $ret;
	} break;
 }


 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_setInvoicePaid($docInfo, $amount, $sessid, $shellid)
{
 /* get first resource */
 $ret = GShell("cashresources list",$sessid, $shellid);
 $list = $ret['outarr'];
 $resInfo = $list[0];

 $now = date('Y-m-d');
 $subjectId = $docInfo['subject_id'];

 $ret = GShell("dynarc new-item -ap `pettycashbook` -group pettycashbook -ctime `".$now."` -name `Saldo` -extset `pettycashbook.resin='"
	.$resInfo['id']."',in='".$amount."',docap='commercialdocs',docid='".$docInfo['id']."',subjectid='".$subjectId."'` && dynarc edit-item -ap `commercialdocs` -id `".$docInfo['id']."` -extset `cdinfo.status=10,payment-date='".$now."',mmr.setallpaid='1',payment='".$now."'`", $sessid,$shellid);

 return $ret;
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_sendMail($args, $sessid, $shellid)
{
 global $_BASE_PATH, $_APPLICATION_CONFIG;

 include_once($_BASE_PATH."Tickets/config.php");

 $out = "";
 $outArr = array();
 $_AP = "tickets";
 
 $cc = array();
 $bcc = array();

 $extraVar = array("attachments"=>array());
 $attachments = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_ID=$args[$c+1]; $c++;} break;

   case '-from' : {$mailFrom=$args[$c+1]; $c++;} break;
   case '-fromname' : {$fromName=$args[$c+1]; $c++;} break;
   case '-to' : case '-recp' : {$recp = $args[$c+1]; $c++;} break;
   case '-cc' : {$cc[] = $args[$c+1]; $c++;} break;
   case '-bcc' : {$bcc[] = $args[$c+1]; $c++;} break;
   case '--reply-to' : {$replyTo = $args[$c+1]; $c++;} break;
   case '--reply-to-name' : {$replyToName = $args[$c+1]; $c++;} break;
   case '-subject' : {$subject = $args[$c+1]; $c++;} break;
   case '-message' : {$message = $args[$c+1]; $c++;} break;
   case '-attachment' : {$attachments[] = ltrim($args[$c+1],"/"); $c++;} break;

   case '--preview-only' : case '--only-preview' : $onlyPreview=true; break;
  }

 // GET TICKET INFO
 $ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_ID."' -extget `ticketinfo,interventions`",$sessid,$shellid);
 if($ret['error']) return $ret;
 $ticketInfo = $ret['outarr'];
 $intervInfo = (is_array($ticketInfo['interventions']) && count($ticketInfo['interventions'])) ? $ticketInfo['interventions'][0] : null;

 $_SUBJECT_SCHEMA = "Rif. Ticket n.{NUM} del {DATE}";
 $_MESSAGE_SCHEMA = "";
 $_REF_KEYS = array('{NUM}','{DATE}','{TIME}','{TKTREF}','{EXT_CONTRACT_REF}','{TYPE}','{CUSTOMER}','{FULLADDRESS}','{ZONE}','{CLOSEDATE}','{CLOSETIME}'
	,'{OPERATOR}','{TECH1}','{TECH2}','{TAXDELIVERY}','{ADDR_CODE}','{ADDR_TITLE}','{ADDR_ADDRESS}','{ADDR_CITY}','{ADDR_ZIP}'
	,'{ADDR_PROV}','{ADDR_CC}','{ADDR_NOTE}','{INTERVDATE}','{INTERVTIMEFROM}','{INTERVTIMETO}','{INTERVDESC}','{STATUS}');


 /* GET CONFIG */
 $ret = GShell("aboutconfig get-config -app tickets",$sessid,$shellid);
 if(!$ret['error'])
 {
  $config = $ret['outarr']['config'];
  if($config['sendmail']['subject'])
   $_SUBJECT_SCHEMA = $config['sendmail']['subject'];
  if($config['sendmail']['messageap'] && $config['sendmail']['messageid'])
  {
   $ret = GShell("dynarc item-info -ap '".$config['sendmail']['messageap']."' -id '".$config['sendmail']['messageid']."'",$sessid,$shellid);
   if(!$ret['error'])
	$_MESSAGE_SCHEMA = $ret['outarr']['desc'];
  }

  if(!$mailFrom)		$mailFrom = $config['sendmail']['senderemail'];
  if(!$fromName)		$fromName = $config['sendmail']['sendername'];
 }


 if(!$recp)
 {
  // determina l'email del destinatario //
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT default_email FROM dynarc_rubrica_items WHERE id='".$ticketInfo['subject_id']."'");
  $db->Read();
  if($db->record['default_email'])
   $recp = $db->record['default_email'];
  else
  {
   $db->RunQuery("SELECT email,email2,email3 FROM dynarc_rubrica_contacts WHERE item_id='".$ticketInfo['subject_id']."' ORDER BY isdefault DESC LIMIT 1");
   $db->Read();
   if($db->record['email'])
	$recp = $db->record['email'];
   else if($db->record['email2'])
	$recp = $db->record['email2'];
   else if($db->record['email3'])
	$recp = $db->record['email3'];
  }
  $db->Close();
 }

 if(!$recp && !$onlyPreview)
  return array("message"=>"Invalid recipient", "error"=>"INVALID_RECIPIENT");

 $_REF_VALUES = array(
	 $ticketInfo['code_num'],
	 date('d/m/Y',$ticketInfo['ctime']),
	 date('H:i',$ticketInfo['ctime']),
	 $ticketInfo['ext_ticket_ref'],
	 $ticketInfo['ext_contract_ref'],
	 $ticketInfo['type_name'],
	 $ticketInfo['subject_name'],
	 $ticketInfo['address'],
	 $ticketInfo['zone'],
	 date('d/m/Y',strtotime($ticketInfo['finish_datetime'])),
	 date('H:i',strtotime($ticketInfo['finish_datetime'])),
	 $ticketInfo['operator_name'],
	 $ticketInfo['tech_1_name'],
	 $ticketInfo['tech_2_name'],
	 date('d/m/Y',strtotime($ticketInfo['tax_delivery'])),
	 $ticketInfo['addr_code'],
	 $ticketInfo['addr_title'],
	 $ticketInfo['addr_address'],
	 $ticketInfo['addr_city'],
	 $ticketInfo['addr_zipcode'],
	 $ticketInfo['addr_province'],
	 $ticketInfo['addr_cc'],
	 $ticketInfo['addr_note'],
	 ($intervInfo && $intervInfo['date'] && ($intervInfo['date'] != "0000-00-00") && ($intervInfo['date'] != "1970-01-01")) ? date('d/m/Y',strtotime($intervInfo['date'])) : "",
	 $intervInfo ? $intervInfo['start_time'] : "",
	 $intervInfo ? $intervInfo['end_time'] : "",
	 $intervInfo ? $intervInfo['name'] : "",
	 $_APPLICATION_CONFIG['ticketstatus'][$ticketInfo['status']]['name']
	);
 
 if(!$subject) $subject = str_replace($_REF_KEYS, $_REF_VALUES, $_SUBJECT_SCHEMA);
 if(!$message) $message = str_replace($_REF_KEYS, $_REF_VALUES, $_MESSAGE_SCHEMA);

 if(!count($attachments))
 {
  if($ticketInfo['print_filename'] && $config['sendmail']['attachpdf']) $extraVar['attachments'][] = $ticketInfo['print_filename'];
  if($ticketInfo['ticket_ref_file'] && $config['sendmail']['attachtktref']) $extraVar['attachments'][] = $ticketInfo['ticket_ref_file'];
  if($config['sendmail']['attachint'])
  {
   $ret = GShell("dynattachments list -ap '".$_AP."' -refid '".$ticketInfo['id']."'",$sessid,$shellid);
   if(!$ret['error'])
   {
	if(count($ret['outarr']['items']))
    {
	 for($c=0; $c < count($ret['outarr']['items']); $c++)
	 {
	  $file = $ret['outarr']['items'][$c];
	  if($file['type'] != "WEB")
	   $extraVar['attachments'][] = $file['url'];
	 }
    }
   }
  }
 }
 else
  $extraVar['attachments'] = $attachments;

 if(!$onlyPreview)
 {
  // SEND EMAIL
  $cmd = "sendmail";
  if($mailFrom)			$cmd.= " -from `".$mailFrom."`";
  if($fromName)			$cmd.= " -fromname `".$fromName."`";
  if($recp)				$cmd.= " -recp `".$recp."`";
  if($replyTo)			$cmd.= " --reply-to `".$replyTo."`";
  if($replyToName)		$cmd.= " --reply-to-name `".$replyToName."`";
  if($subject)			$cmd.= " -subject `".$subject."`";
  if($message)			$cmd.= " -message `".$message."`";
 
  if(count($cc)) { for($c=0; $c < count($cc); $c++) $cmd.= " -cc `".$cc[$c]."`"; }
  if(count($bcc)){ for($c=0; $c < count($bcc); $c++) $cmd.= " -bcc `".$bcc[$c]."`"; }

  $ret = GShell($cmd, $sessid, $shellid, $extraVar);
  if($ret['error']) return $ret;
  $out.= $ret['message'];
  $outArr = $ret['outarr'];

  $ret = GShell("dynarc edit-item -ap '".$_AP."' -id '".$_ID."' -extset `ticketinfo.sendtime='now',sendemail='".$recp."'`",$sessid,$shellid);
  if($ret['error']) return array('message'=>$out."\n".$ret['message'], 'error'=>$ret['error']);
 }
 else
 {
  $outArr = array('sender'=>$mailFrom, 'sendername'=>$fromName, 'recp'=>$recp, 'replyto'=>$replyTo, 'replytoname'=>$replyToName, 
	'subject'=>$subject, 'message'=>$message, 'attachments'=>$extraVar['attachments']);
 }

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_sendTechMail($args, $sessid, $shellid)
{
 global $_BASE_PATH, $_APPLICATION_CONFIG;

 include_once($_BASE_PATH."Tickets/config.php");

 $out = "";
 $outArr = array();
 $_AP = "tickets";
 
 $cc = array();
 $bcc = array();

 $extraVar = array("attachments"=>array());
 $attachments = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_ID=$args[$c+1]; $c++;} break;
   case '-techid' : {$techId=$args[$c+1]; $c++;} break;

   case '-from' : {$mailFrom=$args[$c+1]; $c++;} break;
   case '-fromname' : {$fromName=$args[$c+1]; $c++;} break;
   case '-to' : case '-recp' : {$recp = $args[$c+1]; $c++;} break;
   case '-cc' : {$cc[] = $args[$c+1]; $c++;} break;
   case '-bcc' : {$bcc[] = $args[$c+1]; $c++;} break;
   case '--reply-to' : {$replyTo = $args[$c+1]; $c++;} break;
   case '--reply-to-name' : {$replyToName = $args[$c+1]; $c++;} break;
   case '-subject' : {$subject = $args[$c+1]; $c++;} break;
   case '-message' : {$message = $args[$c+1]; $c++;} break;
   case '-attachment' : {$attachments[] = ltrim($args[$c+1],"/"); $c++;} break;

   case '--preview-only' : case '--only-preview' : $onlyPreview=true; break;
  }

 // GET TICKET INFO
 $ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_ID."' -extget `ticketinfo,interventions`",$sessid,$shellid);
 if($ret['error']) return $ret;
 $ticketInfo = $ret['outarr'];
 $intervInfo = (is_array($ticketInfo['interventions']) && count($ticketInfo['interventions'])) ? $ticketInfo['interventions'][0] : null;

 $_SUBJECT_SCHEMA = "Rif. Ticket n.{NUM} del {DATE}";
 $_MESSAGE_SCHEMA = "";
 $_REF_KEYS = array('{NUM}','{DATE}','{TIME}','{TKTREF}','{TYPE}','{CUSTOMER}','{FULLADDRESS}','{ZONE}','{CLOSEDATE}','{CLOSETIME}'
	,'{OPERATOR}','{TECH1}','{TECH2}','{TAXDELIVERY}','{ADDR_CODE}','{ADDR_TITLE}','{ADDR_ADDRESS}','{ADDR_CITY}','{ADDR_ZIP}'
	,'{ADDR_PROV}','{ADDR_CC}','{ADDR_NOTE}','{NC_CLIENTE}','{NC_COMMITTENTE}','{EXT_CONTRACT_REF}','{APP_DATETIME}'
	,'{INTERVDATE}','{INTERVTIMEFROM}','{INTERVTIMETO}','{INTERVDESC}','{STATUS}');


 /* GET CONFIG */
 $ret = GShell("aboutconfig get-config -app tickets",$sessid,$shellid);
 if(!$ret['error'])
 {
  $config = $ret['outarr']['config'];
  if($config['sendtechmail']['subject'])
   $_SUBJECT_SCHEMA = $config['sendtechmail']['subject'];
  if($config['sendtechmail']['messageap'] && $config['sendtechmail']['messageid'])
  {
   $ret = GShell("dynarc item-info -ap '".$config['sendtechmail']['messageap']."' -id '".$config['sendtechmail']['messageid']."'",$sessid,$shellid);
   if(!$ret['error'])
	$_MESSAGE_SCHEMA = $ret['outarr']['desc'];
  }

  if(!$mailFrom)		$mailFrom = $config['sendtechmail']['senderemail'];
  if(!$fromName)		$fromName = $config['sendtechmail']['sendername'];
 }

 if(!$recp && $techId)
 {
  // determina l'email del destinatario //
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT default_email FROM dynarc_rubrica_items WHERE id='".$techId."'");
  $db->Read();
  if($db->record['default_email'])
   $recp = $db->record['default_email'];
  else
  {
   $db->RunQuery("SELECT email,email2,email3 FROM dynarc_rubrica_contacts WHERE item_id='".$techId."' ORDER BY isdefault DESC LIMIT 1");
   $db->Read();
   if($db->record['email'])
	$recp = $db->record['email'];
   else if($db->record['email2'])
	$recp = $db->record['email2'];
   else if($db->record['email3'])
	$recp = $db->record['email3'];
  }
  $db->Close();
 }

 if(!$recp && !$onlyPreview)
  return array("message"=>"Invalid recipient", "error"=>"INVALID_RECIPIENT");

 $_REF_VALUES = array(
	 $ticketInfo['code_num'],
	 date('d/m/Y',$ticketInfo['ctime']),
	 date('H:i',$ticketInfo['ctime']),
	 $ticketInfo['ext_ticket_ref'],
	 $ticketInfo['type_name'],
	 $ticketInfo['subject_name'],
	 $ticketInfo['address'],
	 $ticketInfo['zone'],
	 date('d/m/Y',strtotime($ticketInfo['finish_datetime'])),
	 date('H:i',strtotime($ticketInfo['finish_datetime'])),
	 $ticketInfo['operator_name'],
	 $ticketInfo['tech_1_name'],
	 $ticketInfo['tech_2_name'],
	 date('d/m/Y',strtotime($ticketInfo['tax_delivery'])),
	 $ticketInfo['addr_code'],
	 $ticketInfo['addr_title'],
	 $ticketInfo['addr_address'],
	 $ticketInfo['addr_city'],
	 $ticketInfo['addr_zipcode'],
	 $ticketInfo['addr_province'],
	 $ticketInfo['addr_cc'],
	 $ticketInfo['addr_note'],
	 $ticketInfo['customer_name'],
	 $ticketInfo['commiss_name'],
	 $ticketInfo['ext_contract_ref'],
	 $ticketInfo['app_datetime'] ? date('d/m/Y H:i',strtotime($ticketInfo['app_datetime'])) : "",
	 ($intervInfo && $intervInfo['date'] && ($intervInfo['date'] != "0000-00-00") && ($intervInfo['date'] != "1970-01-01")) ? date('d/m/Y',strtotime($intervInfo['date'])) : "",
	 $intervInfo ? $intervInfo['start_time'] : "",
	 $intervInfo ? $intervInfo['end_time'] : "",
	 $intervInfo ? $intervInfo['name'] : "",
	 $_APPLICATION_CONFIG['ticketstatus'][$ticketInfo['status']]['name']
	);
 
 if(!$subject) $subject = str_replace($_REF_KEYS, $_REF_VALUES, $_SUBJECT_SCHEMA);
 if(!$message) $message = str_replace($_REF_KEYS, $_REF_VALUES, $_MESSAGE_SCHEMA);

 if(!count($attachments))
 {
  if($ticketInfo['print_filename'] && $config['sendtechmail']['attachpdf']) $extraVar['attachments'][] = $ticketInfo['print_filename'];
  if($ticketInfo['ticket_ref_file'] && $config['sendtechmail']['attachtktref']) $extraVar['attachments'][] = $ticketInfo['ticket_ref_file'];
  if($config['sendtechmail']['attachint'])
  {
   $ret = GShell("dynattachments list -ap '".$_AP."' -refid '".$ticketInfo['id']."'",$sessid,$shellid);
   if(!$ret['error'])
   {
	if(count($ret['outarr']['items']))
    {
	 for($c=0; $c < count($ret['outarr']['items']); $c++)
	 {
	  $file = $ret['outarr']['items'][$c];
	  if($file['type'] != "WEB")
	   $extraVar['attachments'][] = $file['url'];
	 }
    }
   }
  }
 }
 else
  $extraVar['attachments'] = $attachments;

 if(!$onlyPreview)
 {
  // SEND EMAIL
  $cmd = "sendmail";
  if($mailFrom)			$cmd.= " -from `".$mailFrom."`";
  if($fromName)			$cmd.= " -fromname `".$fromName."`";
  if($recp)				$cmd.= " -recp `".$recp."`";
  if($replyTo)			$cmd.= " --reply-to `".$replyTo."`";
  if($replyToName)		$cmd.= " --reply-to-name `".$replyToName."`";
  if($subject)			$cmd.= " -subject `".$subject."`";
  if($message)			$cmd.= " -message `".$message."`";
 
  if(count($cc)) { for($c=0; $c < count($cc); $c++) $cmd.= " -cc `".$cc[$c]."`"; }
  if(count($bcc)){ for($c=0; $c < count($bcc); $c++) $cmd.= " -bcc `".$bcc[$c]."`"; }

  $ret = GShell($cmd, $sessid, $shellid, $extraVar);
  if($ret['error']) return $ret;
  $out.= $ret['message'];
  $outArr = $ret['outarr'];

  /*$ret = GShell("dynarc edit-item -ap '".$_AP."' -id '".$_ID."' -extset `ticketinfo.sendtime='now',sendemail='".$recp."'`",$sessid,$shellid);
  if($ret['error']) return array('message'=>$out."\n".$ret['message'], 'error'=>$ret['error']);*/
 }
 else
 {
  $outArr = array('sender'=>$mailFrom, 'sendername'=>$fromName, 'recp'=>$recp, 'replyto'=>$replyTo, 'replytoname'=>$replyToName, 
	'subject'=>$subject, 'message'=>$message, 'attachments'=>$extraVar['attachments']);
 }

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_sendAlert($args, $sessid, $shellid)
{
 global $_BASE_PATH, $_APPLICATION_CONFIG, $_SMTP_USERNAME;

 include_once($_BASE_PATH."Tickets/config.php");

 $out = "";
 $outArr = array();
 $_AP = "tickets";
 $_ID = 0;
 
 $extraVar = array("attachments"=>array());
 $attachments = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_ID=$args[$c+1]; $c++;} break;
  }

 /* GET CONFIG */
 $out.= "Get config...";
 $ret = GShell("aboutconfig get-config -app tickets -sec alerts",$sessid,$shellid);
 if($ret['error']) return array('message'=>"Configuration for alerts disabled.");
 $out.= "done!\n";
 $config = $ret['outarr']['config'];

 // GET TICKET INFO
 $out.= "Get ticket info...";
 $ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_ID."' -extget `ticketinfo,interventions`",$sessid,$shellid);
 if($ret['error']) return array('message'=>$out."failed!\n".$ret['message'], 'error'=>$ret['error']);
 $ticketInfo = $ret['outarr'];
 $intervInfo = (is_array($ticketInfo['interventions']) && count($ticketInfo['interventions'])) ? $ticketInfo['interventions'][0] : null;
 $out.= "done!\n";

 $_SUBJECT_SCHEMA = "Il ticket n. {NUM} &egrave; stato modificato";
 $_MESSAGE_SCHEMA = "";
 $_REF_KEYS = array('{NUM}','{DATE}','{TIME}','{TKTREF}','{TYPE}','{CUSTOMER}','{FULLADDRESS}','{ZONE}','{CLOSEDATE}','{CLOSETIME}'
	,'{OPERATOR}','{TAXDELIVERY}','{ADDR_CODE}','{ADDR_TITLE}','{ADDR_ADDRESS}','{ADDR_CITY}','{ADDR_ZIP}'
	,'{ADDR_PROV}','{ADDR_CC}','{ADDR_NOTE}','{STATUS}','{INTERVDATE}','{INTERVTIMEFROM}','{INTERVTIMETO}','{INTERVDESC}'
	,'{TECH_1}','{TECH_2}','{NC_CLIENTE}','{NC_COMMITTENTE}','{EXT_CONTRACT_REF}','{APP_DATETIME}');


 if($config['statusalert']['subject'])
   $_SUBJECT_SCHEMA = $config['statusalert']['subject'];
 if($config['statusalert']['messageap'] && $config['statusalert']['messageid'])
 {
  $ret = GShell("dynarc item-info -ap '".$config['statusalert']['messageap']."' -id '".$config['statusalert']['messageid']."'",$sessid,$shellid);
  if(!$ret['error'])
   $_MESSAGE_SCHEMA = $ret['outarr']['desc'];
 }

 $mailFrom = $config['statusalert']['senderemail'] ? $config['statusalert']['senderemail'] : ($_SMTP_USERNAME ? $_SMTP_USERNAME : $_SESSION['EMAIL']);
 $fromName = $config['statusalert']['sendername'] ? $config['statusalert']['sendername'] : ($_SESSION['FULLNAME'] ? $_SESSION['FULLNAME'] : $_SESSION['UNAME']);
 $recp = $config['statusalert']['recp'];

 $_REF_VALUES = array(
	 $ticketInfo['code_num'],
	 date('d/m/Y',$ticketInfo['ctime']),
	 date('H:i',$ticketInfo['ctime']),
	 $ticketInfo['ext_ticket_ref'],
	 $ticketInfo['type_name'],
	 $ticketInfo['subject_name'],
	 $ticketInfo['address'],
	 $ticketInfo['zone'],
	 date('d/m/Y',strtotime($ticketInfo['finish_datetime'])),
	 date('H:i',strtotime($ticketInfo['finish_datetime'])),
	 $intervInfo ? $intervInfo['operator_name'] : '',
	 date('d/m/Y',strtotime($ticketInfo['tax_delivery'])),
	 $ticketInfo['addr_code'],
	 $ticketInfo['addr_title'],
	 $ticketInfo['addr_address'],
	 $ticketInfo['addr_city'],
	 $ticketInfo['addr_zipcode'],
	 $ticketInfo['addr_province'],
	 $ticketInfo['addr_cc'],
	 $ticketInfo['addr_note'],
	 $_APPLICATION_CONFIG['ticketstatus'][$ticketInfo['status']]['name'],
	 ($intervInfo && $intervInfo['date'] && ($intervInfo['date'] != "0000-00-00") && ($intervInfo['date'] != "1970-01-01")) ? date('d/m/Y',strtotime($intervInfo['date'])) : "",
	 $intervInfo ? $intervInfo['start_time'] : "",
	 $intervInfo ? $intervInfo['end_time'] : "",
	 $intervInfo ? $intervInfo['name'] : '',
	 $ticketInfo['tech_1_name'],
	 $ticketInfo['tech_2_name'],
	 $ticketInfo['customer_name'],
	 $ticketInfo['commiss_name'],
	 $ticketInfo['ext_contract_ref'],
	 $ticketInfo['app_datetime'] ? date('d/m/Y H:i',strtotime($ticketInfo['app_datetime'])) : ''
	);
 
 $subject = str_replace($_REF_KEYS, $_REF_VALUES, $_SUBJECT_SCHEMA);
 $message = str_replace($_REF_KEYS, $_REF_VALUES, $_MESSAGE_SCHEMA); 


 // SEND EMAIL
 $cmd = "sendmail";
 if($mailFrom)			$cmd.= " -from `".$mailFrom."`";
 if($fromName)			$cmd.= " -fromname `".$fromName."`";
 if($recp)				$cmd.= " -recp `".$recp."`";
 if($subject)			$cmd.= " -subject `".$subject."`";
 if($message)			$cmd.= " -message `".$message."`";
 
 $ret = GShell($cmd, $sessid, $shellid, $extraVar);
 if($ret['error']) return $ret;
 $out.= $ret['message'];
 $outArr = $ret['outarr'];

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_clone($args, $sessid, $shellid)
{
 $_AP = "tickets";
 $out = "";
 $outArr = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_IDS[] = $args[$c+1]; $c++;} break;
   case '-ids' : {$_IDS = explode(",",$args[$c+1]); $c++;} break;
  }

 /* GET CONFIG */
 $ret = GShell("aboutconfig get-config -app tickets",$sessid,$shellid);
 if(!$ret['error'])
 {
  $config = $ret['outarr']['config'];
 }

 $out.= "Generating tickets...";
 for($c=0; $c < count($_IDS); $c++)
 {
  $_ID = $_IDS[$c];
  /* Get ticket info */
  $ret = GShell("dynarc item-info -ap ".$_AP." -id '".$_ID."' -extget `ticketinfo`", $sessid, $shellid);
  if($ret['error']) return array('message'=>$out."failed!\n".$ret['message'], 'error'=>$ret['error']);
  $ticketInfo = $ret['outarr'];

  $command = "dynarc new-item -ap tickets -group tickets -perms 664";
  if($config['options']['clonectime'])			$command.= " -ctime '".date('Y-m-d H:i:s',$ticketInfo['ctime'])."'";
  if($config['options']['clonedescription'])	$command.= " -desc `".$ticketInfo['desc']."`";

  $extset = "";
  if($config['options']['clonecustomer'])
   $extset.= ",subjid='".$ticketInfo['subject_id']."',subjname='''".$ticketInfo['subject_name']."'''";
  if($config['options']['cloneaddress'])		$extset.= ",contactid='".$ticketInfo['contact_id']."'";
  if($config['options']['cloneexpiry'])			$extset.= ",taxdelivery='".$ticketInfo['tax_delivery']."'";
  if($config['options']['clonetype'])
  {
   if($config['options']['clonetype'] == 'clone')
	$extset.= ",type='".$ticketInfo['type']."'";
   else
	$extset.= ",type='".$config['options']['clonetype']."'";
  }
  if($config['options']['cloneoperator'])
  {
   if($config['options']['cloneoperator'] == 'clone')
	$extset.= ",operatorid='".$ticketInfo['operator_id']."'";
   else
	$extset.= ",operatorid='".$config['options']['cloneoperator']."'";
  }
  if($config['options']['clonezone'])			$extset.= ",zone='''".$ticketInfo['zone']."''',zoneid='".$ticketInfo['zone_id']."'";
  if($config['options']['cloneexttktref'])		$extset.= ",extticketref='''".$ticketInfo['ext_ticket_ref']."'''";
  if($config['options']['clonetktreffile'])		$extset.= ",ticketreffile='''".$ticketInfo['ticket_ref_file']."'''";
  if($config['options']['clonenote'])			$extset.= ",note='''".$ticketInfo['note']."'''";

  if($config['options']['clonehardware'])		$extset.= ",hwid='".$ticketInfo['hw_id']."',hwname='''".$ticketInfo['hw_name']."'''";
  if($config['options']['cloneshelf'])			$extset.= ",shelf='''".$ticketInfo['shelf']."'''";
  if($config['options']['clonerequest'])		$extset.= ",request='''".$ticketInfo['request']."'''";
  if($config['options']['clonedatatosave'])		$extset.= ",datatosave='''".$ticketInfo['datatosave']."'''";
  if($config['options']['cloneaccessories'])	$extset.= ",accessories='''".$ticketInfo['accessories']."'''";

  if($extset)
   $command.= " -extset `ticketinfo.".ltrim($extset,',')."`";

  $ret = GShell($command,$sessid,$shellid);
  if($ret['error'])	return array('message'=>$out."failed!\n".$ret['message'], 'error'=>$ret['error']);
  $outArr[] = $ret['outarr'];
 }
 $out.= "done!\n".count($_IDS)." tickets have been duplicated.";

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_exportExploded($args, $sessid, $shellid)
{
 $_AP = "tickets";
 $out = "";
 $outArr = array();
 $_DECIMALS = 2;
 $fileName = "ticketlist.xlsx";

 $_IDS = array();
 $_COLUMNS = array(
	 'num'=> array('format'=>'string', 'title'=>'Num.'),
	 'type'=> array('format'=>'string', 'title'=>'Tipologia'),
	 'tktref'=> array('format'=>'string', 'title'=>'N. ticket di rif.'),
	 'date'=> array('format'=>'date', 'title'=>'Data apertura'),
	 'appdate'=> array('format'=>'date', 'title'=>'Data appuntamento'),
	 'taxdelivery'=> array('format'=>'date', 'title'=>'Data scadenza'),
	 'closedate'=> array('format'=>'date', 'title'=>'Data chisura'),
	 'customer'=> array('format'=>'string', 'title'=>'Cliente'),
	 'fulladdress'=> array('format'=>'string', 'title'=>'Indirizzo completo'),
	 'addrcode'=> array('format'=>'string', 'title'=>'Cod. indirizzo'),
	 'addrtitle'=> array('format'=>'string', 'title'=>'Insegna / Citofono'),
	 'addraddress'=> array('format'=>'string', 'title'=>'Indirizzo'),
	 'addrcity'=> array('format'=>'string', 'title'=>'Citta'),
	 'addrzipcode'=> array('format'=>'string', 'title'=>'C.A.P.'),
	 'addrprov'=> array('format'=>'string', 'title'=>'Provincia'),
	 'addrcc'=> array('format'=>'string', 'title'=>'Paese'),
	 'addrnote'=> array('format'=>'string', 'title'=>'Note indirizzo'),
	 'zone'=> array('format'=>'string', 'title'=>'Zona'),
	 'operator'=> array('format'=>'string', 'title'=>'Operatore'),
	 'tech1'=> array('format'=>'string', 'title'=>'Tecnico 1'),
	 'tech2'=> array('format'=>'string', 'title'=>'Tecnico 2'),
	 'hardware'=> array('format'=>'string', 'title'=>'Hardware'),
	 'shelf'=> array('format'=>'string', 'title'=>'Scaffale'),
	 'request'=> array('format'=>'string', 'title'=>'Richiesta'),
	 'datatosave'=> array('format'=>'string', 'title'=>'Dati da salvare'),
	 'accessories'=> array('format'=>'string', 'title'=>'Accessori ritirati'),
	 'note'=> array('format'=>'string', 'title'=>'Note'),
	 'description'=> array('format'=>'string', 'title'=>'Descrizione dettagliata'),
	 'element'=> array('format'=>'string', 'title'=>'Voce da fatt.'),
	 'qty'=> array('format'=>'number', 'title'=>'Qta'),
	 'amount'=> array('format'=>'currency', 'title'=>'Imponibile'),
	 'vat'=> array('format'=>'currency', 'title'=>'I.V.A.'),
	 'total'=> array('format'=>'currency', 'title'=>'Totale'),
	);

 $_SELECTED_COLUMNS = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_IDS[]=$args[$c+1]; $c++;} break;
   case '-ids' : {$_IDS=explode(",",$args[$c+1]); $c++;} break;
   case '-f' : case '-file' : {$fileName=$args[$c+1]; $c++;} break;

   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 if(!count($_IDS)) return array('message'=>'You must specify at least one document to export.', 'error'=>'NO_TICKET_SELECTED');

 /* GET CONFIG */
 $ret = GShell("aboutconfig get-config -app tickets",$sessid,$shellid);
 if(!$ret['error'])
  $config = $ret['outarr']['config'];
 $tmp = 0;
 if(is_array($config['exexcolumns']))
 {
  for($c=0; $c < count($config['exexcolumns']); $c++)
  {
   $col = $config['exexcolumns'][$c];
   if($_COLUMNS[$col['tag']])
   {
	$_COLUMNS[$col['tag']]['title'] = $col['title'];
	$_SELECTED_COLUMNS[$col['tag']] = $_COLUMNS[$col['tag']];
    $tmp++;
   }
  }
 }
 if(!$tmp)
  $_SELECTED_COLUMNS = $_COLUMNS;

 /* Generate selected columns formats to string */
 $formats = "";
 reset($_SELECTED_COLUMNS);
 while(list($k,$v)=each($_SELECTED_COLUMNS))
 {
  $formats.",".$v['format'];
 }
 $formats = ltrim($formats,",");

 /* MAKE HTML TABLE */
 $tb = "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
 $tb.= "<tr>";
 reset($_SELECTED_COLUMNS);
 while(list($k,$v)=each($_SELECTED_COLUMNS)) { $tb.= "<th>".$v['title']."</th>"; }
 $tb.= "</tr>";

 for($c=0; $c < count($_IDS); $c++)
 {
  $_ID = $_IDS[$c];
  $ret = GShell("dynarc item-info -ap '".$_AP."' -id '".$_ID."' -extget `ticketinfo,cdelements`",$sessid,$shellid);
  if($ret['error']) return $ret;
  $docInfo = $ret['outarr'];

  if($verbose)
   $out.= "Im preparing to export the ticket #".$docInfo['code_num']." of ".date('d/m/Y',$docInfo['ctime'])."...";

  $count = 0;
  for($i=0; $i < count($docInfo['elements']); $i++)
  {
   $el = $docInfo['elements'][$i];
   if(strtolower($el['type']) == "note") continue;
   $qty = $el['qty']; if(!$qty) continue;

   $tb.= "<tr>";
   reset($_SELECTED_COLUMNS);
   while(list($k,$v)=each($_SELECTED_COLUMNS))
   {
	switch($k)
	{
	 case 'type' : 			$tb.= "<td>".$docInfo['type_name']."</td>"; break;
	 case 'num' : 			$tb.= "<td>".$docInfo['code_num']."</td>"; break;
	 case 'date' : 			$tb.= "<td>".date('d/m/Y',$docInfo['ctime'])."</td>"; break;
	 case 'appdate' : 		$tb.= "<td>".($docInfo['app_datetime'] ? date('d/m/Y',strtotime($docInfo['app_datetime'])) : '')."</td>"; break;
	 case 'taxdelivery' : 	$tb.= "<td>".($docInfo['tax_delivery'] ? date('d/m/Y',strtotime($docInfo['tax_delivery'])) : '')."</td>"; break;
	 case 'customer' : 		$tb.= "<td>".$docInfo['customer']."</td>"; break;
	 case 'tktref' : 		$tb.= "<td>".$docInfo['ext_ticket_ref']."</td>"; break;
	 case 'closedate' : 	$tb.= "<td>".($docInfo['finish_datetime'] ? date('d/m/Y',strtotime($docInfo['finish_datetime'])) : '')."</td>"; break;
	 case 'fulladdress' : 	$tb.= "<td>".$docInfo['address']."</td>"; break;
	 case 'addrcode' : 		$tb.= "<td>".$docInfo['addr_code']."</td>"; break;
	 case 'addrtitle' : 	$tb.= "<td>".$docInfo['addr_title']."</td>"; break;
	 case 'addraddress' : 	$tb.= "<td>".$docInfo['addr_address']."</td>"; break;
	 case 'addrcity' : 		$tb.= "<td>".$docInfo['addr_city']."</td>"; break;
	 case 'addrzipcode' : 	$tb.= "<td>".$docInfo['addr_zipcode']."</td>"; break;
	 case 'addrprov' : 		$tb.= "<td>".$docInfo['addr_province']."</td>"; break;
	 case 'addrcc' : 		$tb.= "<td>".$docInfo['addr_cc']."</td>"; break;
	 case 'addrnote' : 		$tb.= "<td>".$docInfo['addr_note']."</td>"; break;
	 case 'zone' : 			$tb.= "<td>".$docInfo['zone']."</td>"; break;
	 case 'operator' : 		$tb.= "<td>".$docInfo['operator_name']."</td>"; break;
	 case 'tech1' : 		$tb.= "<td>".$docInfo['tech_1_name']."</td>"; break;
	 case 'tech2' : 		$tb.= "<td>".$docInfo['tech_2_name']."</td>"; break;
	 case 'hardware' : 		$tb.= "<td>".$docInfo['hw_name']."</td>"; break;
	 case 'shelf' : 		$tb.= "<td>".$docInfo['shelf']."</td>"; break;
	 case 'request' : 		$tb.= "<td>".$docInfo['request']."</td>"; break;
	 case 'datatosave' : 	$tb.= "<td>".$docInfo['datatosave']."</td>"; break;
	 case 'accessories' : 	$tb.= "<td>".$docInfo['accessories']."</td>"; break;
	 case 'note' : 			$tb.= "<td>".$docInfo['note']."</td>"; break;
	 case 'description' : 	$tb.= "<td>".$docInfo['desc']."</td>"; break;
	 case 'element' : 		$tb.= "<td>".$el['name']."</td>"; break;
	 case 'qty' : 			$tb.= "<td>".$el['qty']."</td>"; break;
	 case 'amount' : 		$tb.= "<td>".number_format($el['amount'],2,',','.')."</td>"; break;
	 case 'vat' : 			$tb.= "<td>".number_format($el['vat'],2,',','.')."</td>"; break;
	 case 'total' : 		$tb.= "<td>".number_format($el['total'],2,',','.')."</td>"; break;
	}
   }
   $tb.= "</tr>";
   $count++;
  }
  /* EOF - FOR ELEMENTS */ 
  if($count)
  {
   if($verbose) $out.= "done! ".$count." elements found.\n";
  }
  else 
  {
   $tb.= "<tr>";
   reset($_SELECTED_COLUMNS);
   while(list($k,$v)=each($_SELECTED_COLUMNS))
   {
	switch($k)
	{
	 case 'type' : 			$tb.= "<td>".$docInfo['type_name']."</td>"; break;
	 case 'num' : 			$tb.= "<td>".$docInfo['code_num']."</td>"; break;
	 case 'date' : 			$tb.= "<td>".date('d/m/Y',$docInfo['ctime'])."</td>"; break;
	 case 'appdate' : 		$tb.= "<td>".($docInfo['app_datetime'] ? date('d/m/Y',strtotime($docInfo['app_datetime'])) : '')."</td>"; break;
	 case 'taxdelivery' : 	$tb.= "<td>".($docInfo['tax_delivery'] ? date('d/m/Y',strtotime($docInfo['tax_delivery'])) : '')."</td>"; break;
	 case 'customer' : 		$tb.= "<td>".$docInfo['customer']."</td>"; break;
	 case 'tktref' : 		$tb.= "<td>".$docInfo['ext_ticket_ref']."</td>"; break;
	 case 'closedate' : 	$tb.= "<td>".($docInfo['finish_datetime'] ? date('d/m/Y',strtotime($docInfo['finish_datetime'])) : '')."</td>"; break;
	 case 'fulladdress' : 	$tb.= "<td>".$docInfo['address']."</td>"; break;
	 case 'addrcode' : 		$tb.= "<td>".$docInfo['addr_code']."</td>"; break;
	 case 'addrtitle' : 	$tb.= "<td>".$docInfo['addr_title']."</td>"; break;
	 case 'addraddress' : 	$tb.= "<td>".$docInfo['addr_address']."</td>"; break;
	 case 'addrcity' : 		$tb.= "<td>".$docInfo['addr_city']."</td>"; break;
	 case 'addrzipcode' : 	$tb.= "<td>".$docInfo['addr_zipcode']."</td>"; break;
	 case 'addrprov' : 		$tb.= "<td>".$docInfo['addr_province']."</td>"; break;
	 case 'addrcc' : 		$tb.= "<td>".$docInfo['addr_cc']."</td>"; break;
	 case 'addrnote' : 		$tb.= "<td>".$docInfo['addr_note']."</td>"; break;
	 case 'zone' : 			$tb.= "<td>".$docInfo['zone']."</td>"; break;
	 case 'operator' : 		$tb.= "<td>".$docInfo['operator_name']."</td>"; break;
	 case 'tech1' : 		$tb.= "<td>".$docInfo['tech_1_name']."</td>"; break;
	 case 'tech2' : 		$tb.= "<td>".$docInfo['tech_2_name']."</td>"; break;
	 case 'hardware' : 		$tb.= "<td>".$docInfo['hw_name']."</td>"; break;
	 case 'shelf' : 		$tb.= "<td>".$docInfo['shelf']."</td>"; break;
	 case 'request' : 		$tb.= "<td>".$docInfo['request']."</td>"; break;
	 case 'datatosave' : 	$tb.= "<td>".$docInfo['datatosave']."</td>"; break;
	 case 'accessories' : 	$tb.= "<td>".$docInfo['accessories']."</td>"; break;
	 case 'note' : 			$tb.= "<td>".$docInfo['note']."</td>"; break;
	 case 'description' : 	$tb.= "<td>".$docInfo['desc']."</td>"; break;
	 case 'element' : 		$tb.= "<td>Totale ticket</td>"; break;
	 case 'qty' : 			$tb.= "<td></td>"; break;
	 case 'amount' : 		$tb.= "<td>".number_format($docInfo['amount'],2,',','.')."</td>"; break;
	 case 'vat' : 			$tb.= "<td>".number_format($docInfo['vat'],2,',','.')."</td>"; break;
	 case 'total' : 		$tb.= "<td>".number_format($docInfo['total'],2,',','.')."</td>"; break;
	}
   }
   $tb.= "</tr>";
  }
 }
 /* EOF - FOR IDS */
 $tb.= "</table>";

 /* EXPORT TO EXCEL */
 $ret = GShell("excel write -f `".$fileName."` -htmltable `".$tb."` -formats `".$formats."`",$sessid,$shellid);
 if($ret['error']) return array('message'=>$out.= "\nError:".$ret['message'], 'error'=>$ret['error']);
 $outArr = $ret['outarr'];

 $out.= $ret['message']."\n".count($_IDS)." tickets has been exported into file ".$ret['outarr']['filename'].".";

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_intervSummaryByTech($args, $sessid, $shellid)
{
 $_AP = "tickets";
 $out = "";
 $outArr = array();

 $_DECIMALS = 2;
 $_LIST = array();		// results
 $_TOTALS = array();	// totals
 $status = null;
 $statusFrom = null;
 $statusTo = null;
 $orderBy = "ctime ASC";
 $fileName = "certificazione-tecnico.xlsx";

 $_TECH_IDS = array();
 $_HTML_CONTENTS = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-f' : case '-file' : {$fileName=$args[$c+1]; $c++;} break;
   case '-techid' : {$_TECH_IDS[] = $args[$c+1]; $c++;} break;
   case '-techids' : {$_TECH_IDS = explode(",",$args[$c+1]); $c++;} break;

   case '-from' : {$dateFrom=$args[$c+1]; $c++;} break;
   case '-to' : {$dateTo=$args[$c+1]; $c++;} break;

   case '-status' : {$status=$args[$c+1]; $c++;} break;
   case '-statusfrom' : {$statusFrom=$args[$c+1]; $c++;} break;
   case '-statusto' : {$statusTo=$args[$c+1]; $c++;} break;

   case '--order-by' : case '-orderby' : {$orderBy=$args[$c+1]; $c++;} break;

   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 $_COLUMNS = array(
	 'num'=> array('format'=>'string', 'title'=>'Num.'),
	 'tktref'=> array('format'=>'string', 'title'=>'N. ticket di rif.'),
	 'date'=> array('format'=>'date', 'title'=>'Data apertura'),
	 'appdate'=> array('format'=>'date', 'title'=>'Data appuntamento'),
	 'intervdate'=> array('format'=>'date', 'title'=>'Data intervento'),
	 'intervtimefrom'=> array('format'=>'time', 'title'=>'Ora inizio intervento'),
	 'intervtimeto'=> array('format'=>'time', 'title'=>'Ora fine intervento'),
	 'taxdelivery'=> array('format'=>'date', 'title'=>'Data scadenza'),
	 'closedate'=> array('format'=>'date', 'title'=>'Data chisura'),
	 'customer'=> array('format'=>'string', 'title'=>'Cliente'),
	 'fulladdress'=> array('format'=>'string', 'title'=>'Indirizzo completo'),
	 'addrcode'=> array('format'=>'string', 'title'=>'Cod. indirizzo'),
	 'addrtitle'=> array('format'=>'string', 'title'=>'Utente / Insegna / Citofono'),
	 'addraddress'=> array('format'=>'string', 'title'=>'Indirizzo'),
	 'addrcity'=> array('format'=>'string', 'title'=>'Citta'),
	 'addrzipcode'=> array('format'=>'string', 'title'=>'C.A.P.'),
	 'addrprov'=> array('format'=>'string', 'title'=>'Provincia'),
	 'addrcc'=> array('format'=>'string', 'title'=>'Paese'),
	 'addrnote'=> array('format'=>'string', 'title'=>'Note indirizzo'),
	 'zone'=> array('format'=>'string', 'title'=>'Zona'),
	 //'operator'=> array('format'=>'string', 'title'=>'Operatore'),
	 'tech'=> array('format'=>'string', 'title'=>'Tecnico/Collaboratore'),
	 'request'=> array('format'=>'string', 'title'=>'Richiesta'),
	 'note'=> array('format'=>'string', 'title'=>'Note'),
	 'description'=> array('format'=>'string', 'title'=>'Descrizione dettagliata'),
	 'amount'=> array('format'=>'currency', 'title'=>'Imponibile'),
	 'vat'=> array('format'=>'currency', 'title'=>'I.V.A.'),
	 'total'=> array('format'=>'currency', 'title'=>'Totale'),
	 'intervamount' => array('format'=>'currency', 'title'=>'Tot. comp. tecnico')
	);

 if(file_exists($_BASE_PATH."Tickets/config-custom.php"))
 {
  $_COLUMNS['customer_name'] = array('format'=>'string', 'title'=>'NC Cliente');
  $_COLUMNS['commiss_name'] = array('format'=>'string', 'title'=>'NC Committente');
  $_COLUMNS['ext_contract_ref'] = array('format'=>'string', 'title'=>'Rif. Contratto');
 }

 $_SELECTED_COLUMNS = array();

 
 /* GET CONFIG */
 $ret = GShell("aboutconfig get-config -app tickets",$sessid,$shellid);
 if(!$ret['error'])
  $config = $ret['outarr']['config'];
 $tmp = 0;


 if(is_array($config["excertcolumns"]))
 {
  for($c=0; $c < count($config["excertcolumns"]); $c++)
  {
   $col = $config["excertcolumns"][$c];
   if($_COLUMNS[$col['tag']])
   {
	$_COLUMNS[$col['tag']]['title'] = $col['title'];
	$_SELECTED_COLUMNS[$col['tag']] = $_COLUMNS[$col['tag']];
    $tmp++;
   }
  }
 }
 if(!$tmp)
  $_SELECTED_COLUMNS = $_COLUMNS;

 /* Generate selected columns formats to string */
 $formats = "";
 reset($_SELECTED_COLUMNS);
 while(list($k,$v)=each($_SELECTED_COLUMNS))
 {
  $formats.",".$v['format'];
 }
 $formats = ltrim($formats,",");

 /* GET RESULTS */
 $_FIELDS = "ctime,code_num,subject_id,subject_name,contact_id,zone,note,tax_delivery,status";
 $_FIELDS.= ",ext_ticket_ref,amount,vat,total,finish_datetime,app_datetime,closed,request";
 $_FIELDS.= ",customer_id,customer_name,commiss_id,commiss_name,ext_contract_ref";

 $_XF = "operator_name,date,name,tot_hours,tot_extra_hours,start_time_1,end_time_1,tot_amount";

 for($i=0; $i < count($_TECH_IDS); $i++)
 {
  $techId = $_TECH_IDS[$i];

  $_CMD = "dynarc cross-search -ap ".$_AP." -ext interventions -get `".$_FIELDS."` -xf `".$_XF."`";
  $_WHERE = "";
  if($dateFrom)				$_WHERE.= " AND date>='".$dateFrom."'";
  if($dateTo)				$_WHERE.= " AND date<='".$dateTo."'";
  if(isset($status))		$_WHERE.= " AND status='".$status."'";
  else
  {
   if(isset($statusFrom))	$_WHERE.= " AND status>='".$statusFrom."'";
   if(isset($statusTo))		$_WHERE.= " AND status<='".$statusTo."'";
  }

  $_CMD.= " -where `ext.operator_id=".$techId.$_WHERE."` --order-by '".$orderBy."' --no-get-default-fields --get-sum-fields amount,vat,total --get-extsum-fields tot_amount";
  $ret = GShell($_CMD, $sessid, $shellid);
  if($ret['error']) return array('message'=>$out."failed!\n".$ret['message'], 'error'=>$ret['error']);
  $_LIST = $ret['outarr']['items'];
  $_TOTALS = $ret['outarr']['totals'];

  // get tech name
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT name FROM dynarc_rubrica_items WHERE id='".$techId."'");
  if($db->Error) return array('message'=>$out."failed!\nMySQL Error:".$db->Error, 'error'=>'MYSQL_ERROR');
  $db->Read();
  $techName = $db->record['name'];

  /* MAKE HTML TABLE */
  $tb = "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
  $tb.= "<tr><td>Tecnico / Collaboratore: ".$techName."</td></tr>";
  $tb.= "<tr><td></td></tr>";
  $tb.= "<tr><td>Periodo dal ".date('d/m/Y', strtotime($dateFrom))." al ".date('d/m/Y',strtotime($dateTo))."</td></tr>";
  $tb.= "<tr><td></td></tr>";
  $tb.= "<tr>";
  reset($_SELECTED_COLUMNS);
  while(list($k,$v)=each($_SELECTED_COLUMNS)) { $tb.= "<th>".$v['title']."</th>"; }
  $tb.= "</tr>";

  for($c=0; $c < count($_LIST); $c++)
  {
   $item = $_LIST[$c];
   if((substr($item['finish_datetime'],0,10) == "1970-01-01") || (substr($item['finish_datetime'],0,10) == "0000-00-00"))
    $item['finish_datetime'] = 0;
   if((substr($item['tax_delivery'],0,10) == "1970-01-01") || (substr($item['tax_delivery'],0,10) == "0000-00-00"))
    $item['tax_delivery'] = 0;
   if((substr($item['date'],0,10) == "1970-01-01") || (substr($item['date'],0,10) == "0000-00-00"))
    $item['date'] = 0;
   if((substr($item['app_datetime'],0,10) == "1970-01-01") || (substr($item['app_datetime'],0,10) == "0000-00-00"))
    $item['app_datetime'] = 0;

   // get address info
   if($item['contact_id'])
   {
    $db->RunQuery("SELECT name,code,address,city,zipcode,province,countrycode,note FROM dynarc_rubrica_addresses WHERE id='".$item['contact_id']."'");
    $db->Read();
    $item['address'] = $db->record['name'];
    $address = "";
    if($db->record['code']) 		$address.= " - ".$db->record['code'];
    if($db->record['name'])			$address.= " - ".$db->record['name'];
    if($db->record['address']) 		$address.= " - ".$db->record['address'];
    if($db->record['city'])			$address.= " - ".$db->record['city'];
    if($db->record['province'])		$address.= " (".$db->record['province'].")";
    if($address) $item['address'] = ltrim($address, " - ");
    $item['addr_code'] = $db->record['code'];
    $item['addr_title'] = $db->record['name'];
    $item['addr_address'] = $db->record['address'];
    $item['addr_city'] = $db->record['city'];
    $item['addr_province'] = $db->record['province'];
    $item['addr_zipcode'] = $db->record['zipcode'];
    $item['addr_cc'] = $db->record['countrycode'];
    $item['addr_note'] = $db->record['note'];  
   }

   $tb.= "<tr>";
   reset($_SELECTED_COLUMNS);
   while(list($k,$v)=each($_SELECTED_COLUMNS))
   {
	switch($k)
	{
	 case 'num' : 			$tb.= "<td>".$item['code_num']."</td>"; break;
	 case 'tktref' : 		$tb.= "<td>".$item['ext_ticket_ref']."</td>"; break;
	 case 'date' : 			$tb.= "<td>".date('d/m/Y',strtotime($item['ctime']))."</td>"; break;
	 case 'appdate' : 		$tb.= "<td>".($item['app_datetime'] ? date('d/m/Y',strtotime($item['app_datetime'])) : '')."</td>"; break;
	 case 'intervdate' : 	$tb.= "<td>".($item['date'] ? date('d/m/Y',strtotime($item['date'])) : '')."</td>"; break;
	 case 'intervtimefrom' : $tb.= "<td>".$item['start_time_1']."</td>"; break;
	 case 'intervtimeto' :  $tb.= "<td>".$item['end_time_1']."</td>"; break;
	 case 'taxdelivery' : 	$tb.= "<td>".($item['tax_delivery'] ? date('d/m/Y',strtotime($item['tax_delivery'])) : '')."</td>"; break;
	 case 'closedate' : 	$tb.= "<td>".($item['finish_datetime'] ? date('d/m/Y',strtotime($item['finish_datetime'])) : '')."</td>"; break;
	 case 'customer' : 		$tb.= "<td>".$item['subject_name']."</td>"; break;
	 case 'fulladdress' : 	$tb.= "<td>".$item['address']."</td>"; break;
	 case 'addrcode' : 		$tb.= "<td>".$item['addr_code']."</td>"; break;
	 case 'addrtitle' : 	$tb.= "<td>".$item['addr_title']."</td>"; break;
	 case 'addraddress' : 	$tb.= "<td>".$item['addr_address']."</td>"; break;
	 case 'addrcity' : 		$tb.= "<td>".$item['addr_city']."</td>"; break;
	 case 'addrzipcode' : 	$tb.= "<td>".$item['addr_zipcode']."</td>"; break;
	 case 'addrprov' : 		$tb.= "<td>".$item['addr_province']."</td>"; break;
	 case 'addrcc' : 		$tb.= "<td>".$item['addr_cc']."</td>"; break;
	 case 'addrnote' : 		$tb.= "<td>".$item['addr_note']."</td>"; break;
	 case 'zone' : 			$tb.= "<td>".$item['zone']."</td>"; break;
	 //case 'operator' : 		$tb.= "<td>".$item['operator_name']."</td>"; break;
	 case 'tech' : 			$tb.= "<td>".$item['operator_name']."</td>"; break;
	 case 'request' : 		$tb.= "<td>".$item['request']."</td>"; break;
	 case 'note' : 			$tb.= "<td>".$item['note']."</td>"; break;
	 case 'description' : 	$tb.= "<td>".$item['name']."</td>"; break;
	 case 'amount' : 		$tb.= "<td>".number_format($item['amount'],$_DECIMALS,',','.')."</td>"; break;
	 case 'vat' : 			$tb.= "<td>".number_format($item['vat'],$_DECIMALS,',','.')."</td>"; break;
	 case 'total' : 		$tb.= "<td>".number_format($item['total'],$_DECIMALS,',','.')."</td>"; break;
	 case 'intervamount' : 	$tb.= "<td>".number_format($item['tot_amount'],$_DECIMALS,',','.')."</td>"; break;
	 case 'customer_name' : $tb.= "<td>".$item['customer_name']."</td>"; break;
	 case 'commiss_name' :  $tb.= "<td>".$item['commiss_name']."</td>"; break;
	 case 'ext_contract_ref' : $tb.= "<td>".$item['ext_contract_ref']."</td>"; break;
	}
   }
   $tb.= "</tr>";
  }
  $db->Close();

  /* FINALE */
  $tb.= "<tr><td></td></tr>";


  // TOTALI
  $_FOOTER = array();
  reset($_SELECTED_COLUMNS);
  while(list($k,$v)=each($_SELECTED_COLUMNS))
  {
   switch($k)
   {
	case 'amount' : case 'vat' : case 'total' : {
		 if(isset($_TOTALS[$k]))
		  $_FOOTER[] = number_format($_TOTALS[$k] ? $_TOTALS[$k] : 0,$_DECIMALS,',','.');
		 else
		  $_FOOTER[] = "";
		} break;

	case 'intervamount' : {
		 if(isset($_TOTALS['tot_amount']))
		  $_FOOTER[] = number_format($_TOTALS['tot_amount'] ? $_TOTALS['tot_amount'] : 0,$_DECIMALS,',','.');
		 else
		  $_FOOTER[] = "";
		} break;
   
    default : $_FOOTER[] = ""; break;
   }
  }

  for($c=0; $c < count($_FOOTER); $c++)
  {
   $idx = count($_FOOTER)-1-$c;
   if($idx && ($_FOOTER[$idx] != "") && ($_FOOTER[$idx] != "Totale") && ($_FOOTER[$idx-1] == ""))
	$_FOOTER[$idx-1] = "Totale";
  }

  $tb.= "<tr>"; 
  for($c=0; $c < count($_FOOTER); $c++)
   $tb.= "<td>".$_FOOTER[$c]."</td>";
  $tb.= "</tr>";

  $tb.= "</table>";

  $_HTML_CONTENTS[] = array('title'=>$techName, 'content'=>$tb);
 } // EOF - Filter by tech


 /* EXPORT TO EXCEL */
 $_CMD = "excel write -f `".$fileName."`";
 for($c=0; $c < count($_HTML_CONTENTS); $c++)
  $_CMD.= " -s `".$_HTML_CONTENTS[$c]['title']."` -htmltable `".$_HTML_CONTENTS[$c]['content']."` -throwidx 4";

 $ret = GShell($_CMD." -formats `".$formats."`",$sessid,$shellid);
 if($ret['error']) return array('message'=>$out.= "\nError:".$ret['message'], 'error'=>$ret['error']);
 $outArr = $ret['outarr'];

 $out.= $ret['message']."\nSummary by technician has been exported into file ".$ret['outarr']['filename'].".";

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_intervSummaryByCustomer($args, $sessid, $shellid)
{
 $_AP = "tickets";
 $out = "";
 $outArr = array();

 $_DECIMALS = 2;
 $_LIST = array();		// results
 $_TOTALS = array();	// totals
 $status = null;
 $statusFrom = null;
 $statusTo = null;
 $orderBy = "ctime ASC";
 $fileName = "consuntivo-cliente.xlsx";

 $_SUBJ_IDS = array();
 $_HTML_CONTENTS = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-f' : case '-file' : {$fileName=$args[$c+1]; $c++;} break;
   case '-subjid' : {$_SUBJ_IDS[] = $args[$c+1]; $c++;} break;
   case '-subjids' : {$_SUBJ_IDS = explode(",",$args[$c+1]); $c++;} break;

   case '-from' : {$dateFrom=$args[$c+1]; $c++;} break;
   case '-to' : {$dateTo=$args[$c+1]; $c++;} break;

   case '-status' : {$status=$args[$c+1]; $c++;} break;
   case '-statusfrom' : {$statusFrom=$args[$c+1]; $c++;} break;
   case '-statusto' : {$statusTo=$args[$c+1]; $c++;} break;

   case '--order-by' : case '-orderby' : {$orderBy=$args[$c+1]; $c++;} break;

   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 $_COLUMNS = array(
	 'num'=> array('format'=>'string', 'title'=>'Num.'),
	 'tktref'=> array('format'=>'string', 'title'=>'N. ticket di rif.'),
	 'date'=> array('format'=>'date', 'title'=>'Data apertura'),
	 'appdate'=> array('format'=>'date', 'title'=>'Data appuntamento'),
	 'intervdate'=> array('format'=>'date', 'title'=>'Data intervento'),
	 'intervtimefrom'=> array('format'=>'time', 'title'=>'Ora inizio intervento'),
	 'intervtimeto'=> array('format'=>'time', 'title'=>'Ora fine intervento'),
	 'taxdelivery'=> array('format'=>'date', 'title'=>'Data scadenza'),
	 'closedate'=> array('format'=>'date', 'title'=>'Data chisura'),
	 'customer'=> array('format'=>'string', 'title'=>'Cliente'),
	 'fulladdress'=> array('format'=>'string', 'title'=>'Indirizzo completo'),
	 'addrcode'=> array('format'=>'string', 'title'=>'Cod. indirizzo'),
	 'addrtitle'=> array('format'=>'string', 'title'=>'Utente / Insegna / Citofono'),
	 'addraddress'=> array('format'=>'string', 'title'=>'Indirizzo'),
	 'addrcity'=> array('format'=>'string', 'title'=>'Citta'),
	 'addrzipcode'=> array('format'=>'string', 'title'=>'C.A.P.'),
	 'addrprov'=> array('format'=>'string', 'title'=>'Provincia'),
	 'addrcc'=> array('format'=>'string', 'title'=>'Paese'),
	 'addrnote'=> array('format'=>'string', 'title'=>'Note indirizzo'),
	 'zone'=> array('format'=>'string', 'title'=>'Zona'),
	 //'operator'=> array('format'=>'string', 'title'=>'Operatore'),
	 'tech'=> array('format'=>'string', 'title'=>'Tecnico/Collaboratore'),
	 'request'=> array('format'=>'string', 'title'=>'Richiesta'),
	 'note'=> array('format'=>'string', 'title'=>'Note'),
	 'description'=> array('format'=>'string', 'title'=>'Descrizione dettagliata'),
	 'amount'=> array('format'=>'currency', 'title'=>'Imponibile'),
	 'vat'=> array('format'=>'currency', 'title'=>'I.V.A.'),
	 'total'=> array('format'=>'currency', 'title'=>'Totale'),
	 'intervamount' => array('format'=>'currency', 'title'=>'Tot. comp. tecnico')
	);

 if(file_exists($_BASE_PATH."Tickets/config-custom.php"))
 {
  $_COLUMNS['customer_name'] = array('format'=>'string', 'title'=>'NC Cliente');
  $_COLUMNS['commiss_name'] = array('format'=>'string', 'title'=>'NC Committente');
  $_COLUMNS['ext_contract_ref'] = array('format'=>'string', 'title'=>'Rif. Contratto');
 }

 $_SELECTED_COLUMNS = array();

 
 /* GET CONFIG */
 $ret = GShell("aboutconfig get-config -app tickets",$sessid,$shellid);
 if(!$ret['error'])
  $config = $ret['outarr']['config'];
 $tmp = 0;

 if(is_array($config["exconscolumns"]))
 {
  for($c=0; $c < count($config["exconscolumns"]); $c++)
  {
   $col = $config["exconscolumns"][$c];
   if($_COLUMNS[$col['tag']])
   {
	$_COLUMNS[$col['tag']]['title'] = $col['title'];
	$_SELECTED_COLUMNS[$col['tag']] = $_COLUMNS[$col['tag']];
    $tmp++;
   }
  }
 }
 if(!$tmp)
  $_SELECTED_COLUMNS = $_COLUMNS;

 /* Generate selected columns formats to string */
 $formats = "";
 reset($_SELECTED_COLUMNS);
 while(list($k,$v)=each($_SELECTED_COLUMNS))
 {
  $formats.",".$v['format'];
 }
 $formats = ltrim($formats,",");

 /* GET RESULTS */
 $_FIELDS = "ctime,code_num,subject_id,subject_name,contact_id,zone,note,tax_delivery,status";
 $_FIELDS.= ",ext_ticket_ref,amount,vat,total,finish_datetime,app_datetime,closed,request";
 $_FIELDS.= ",customer_id,customer_name,commiss_id,commiss_name,ext_contract_ref";

 $_XF = "operator_id,operator_name,date,name,tot_hours,tot_extra_hours,start_time_1,end_time_1,tot_amount";

 for($i=0; $i < count($_SUBJ_IDS); $i++)
 {
  $subjId = $_SUBJ_IDS[$i];

  $_CMD = "dynarc cross-search -ap ".$_AP." -ext interventions -get `".$_FIELDS."` -xf `".$_XF."`";
  $_WHERE = "";
  if($dateFrom)				$_WHERE.= " AND date>='".$dateFrom."'";
  if($dateTo)				$_WHERE.= " AND date<='".$dateTo."'";
  if(isset($status))		$_WHERE.= " AND status='".$status."'";
  else
  {
   if(isset($statusFrom))	$_WHERE.= " AND status>='".$statusFrom."'";
   if(isset($statusTo))		$_WHERE.= " AND status<='".$statusTo."'";
  }

  $_CMD.= " -where `subject_id=".$subjId.$_WHERE."` --order-by '".$orderBy."' --no-get-default-fields --get-sum-fields amount,vat,total --get-extsum-fields tot_amount";
  $ret = GShell($_CMD, $sessid, $shellid);
  if($ret['error']) return array('message'=>$out."failed!\n".$ret['message'], 'error'=>$ret['error']);
  $_LIST = $ret['outarr']['items'];
  $_TOTALS = $ret['outarr']['totals'];

  // get subject name
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT name FROM dynarc_rubrica_items WHERE id='".$subjId."'");
  if($db->Error) return array('message'=>$out."failed!\nMySQL Error:".$db->Error, 'error'=>'MYSQL_ERROR');
  $db->Read();
  $subjName = $db->record['name'];

  /* MAKE HTML TABLE */
  $tb = "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
  $tb.= "<tr><td>Cliente: ".$subjName."</td></tr>";
  $tb.= "<tr><td></td></tr>";
  $tb.= "<tr><td>Periodo dal ".date('d/m/Y', strtotime($dateFrom))." al ".date('d/m/Y',strtotime($dateTo))."</td></tr>";
  $tb.= "<tr><td></td></tr>";
  $tb.= "<tr>";
  reset($_SELECTED_COLUMNS);
  while(list($k,$v)=each($_SELECTED_COLUMNS)) { $tb.= "<th>".$v['title']."</th>"; }
  $tb.= "</tr>";

  for($c=0; $c < count($_LIST); $c++)
  {
   $item = $_LIST[$c];
   if((substr($item['finish_datetime'],0,10) == "1970-01-01") || (substr($item['finish_datetime'],0,10) == "0000-00-00"))
    $item['finish_datetime'] = 0;
   if((substr($item['tax_delivery'],0,10) == "1970-01-01") || (substr($item['tax_delivery'],0,10) == "0000-00-00"))
    $item['tax_delivery'] = 0;
   if((substr($item['date'],0,10) == "1970-01-01") || (substr($item['date'],0,10) == "0000-00-00"))
    $item['date'] = 0;
   if((substr($item['app_datetime'],0,10) == "1970-01-01") || (substr($item['app_datetime'],0,10) == "0000-00-00"))
    $item['app_datetime'] = 0;

   // get address info
   if($item['contact_id'])
   {
    $db->RunQuery("SELECT name,code,address,city,zipcode,province,countrycode,note FROM dynarc_rubrica_addresses WHERE id='".$item['contact_id']."'");
    $db->Read();
    $item['address'] = $db->record['name'];
    $address = "";
    if($db->record['code']) 		$address.= " - ".$db->record['code'];
    if($db->record['name'])			$address.= " - ".$db->record['name'];
    if($db->record['address']) 		$address.= " - ".$db->record['address'];
    if($db->record['city'])			$address.= " - ".$db->record['city'];
    if($db->record['province'])		$address.= " (".$db->record['province'].")";
    if($address) $item['address'] = ltrim($address, " - ");
    $item['addr_code'] = $db->record['code'];
    $item['addr_title'] = $db->record['name'];
    $item['addr_address'] = $db->record['address'];
    $item['addr_city'] = $db->record['city'];
    $item['addr_province'] = $db->record['province'];
    $item['addr_zipcode'] = $db->record['zipcode'];
    $item['addr_cc'] = $db->record['countrycode'];
    $item['addr_note'] = $db->record['note'];  
   }

   $tb.= "<tr>";
   reset($_SELECTED_COLUMNS);
   while(list($k,$v)=each($_SELECTED_COLUMNS))
   {
	switch($k)
	{
	 case 'num' : 			$tb.= "<td>".$item['code_num']."</td>"; break;
	 case 'tktref' : 		$tb.= "<td>".$item['ext_ticket_ref']."</td>"; break;
	 case 'date' : 			$tb.= "<td>".date('d/m/Y',strtotime($item['ctime']))."</td>"; break;
	 case 'appdate' : 		$tb.= "<td>".($item['app_datetime'] ? date('d/m/Y',strtotime($item['app_datetime'])) : '')."</td>"; break;
	 case 'intervdate' : 	$tb.= "<td>".($item['date'] ? date('d/m/Y',strtotime($item['date'])) : '')."</td>"; break;
	 case 'intervtimefrom' : $tb.= "<td>".$item['start_time_1']."</td>"; break;
	 case 'intervtimeto' :  $tb.= "<td>".$item['end_time_1']."</td>"; break;
	 case 'taxdelivery' : 	$tb.= "<td>".($item['tax_delivery'] ? date('d/m/Y',strtotime($item['tax_delivery'])) : '')."</td>"; break;
	 case 'closedate' : 	$tb.= "<td>".($item['finish_datetime'] ? date('d/m/Y',strtotime($item['finish_datetime'])) : '')."</td>"; break;
	 case 'customer' : 		$tb.= "<td>".$item['subject_name']."</td>"; break;
	 case 'fulladdress' : 	$tb.= "<td>".$item['address']."</td>"; break;
	 case 'addrcode' : 		$tb.= "<td>".$item['addr_code']."</td>"; break;
	 case 'addrtitle' : 	$tb.= "<td>".$item['addr_title']."</td>"; break;
	 case 'addraddress' : 	$tb.= "<td>".$item['addr_address']."</td>"; break;
	 case 'addrcity' : 		$tb.= "<td>".$item['addr_city']."</td>"; break;
	 case 'addrzipcode' : 	$tb.= "<td>".$item['addr_zipcode']."</td>"; break;
	 case 'addrprov' : 		$tb.= "<td>".$item['addr_province']."</td>"; break;
	 case 'addrcc' : 		$tb.= "<td>".$item['addr_cc']."</td>"; break;
	 case 'addrnote' : 		$tb.= "<td>".$item['addr_note']."</td>"; break;
	 case 'zone' : 			$tb.= "<td>".$item['zone']."</td>"; break;
	 //case 'operator' : 		$tb.= "<td>".$item['operator_name']."</td>"; break;
	 case 'tech' : 			$tb.= "<td>".$item['operator_name']."</td>"; break;
	 case 'request' : 		$tb.= "<td>".$item['request']."</td>"; break;
	 case 'note' : 			$tb.= "<td>".$item['note']."</td>"; break;
	 case 'description' : 	$tb.= "<td>".$item['name']."</td>"; break;
	 case 'amount' : 		$tb.= "<td>".number_format($item['amount'],$_DECIMALS,',','.')."</td>"; break;
	 case 'vat' : 			$tb.= "<td>".number_format($item['vat'],$_DECIMALS,',','.')."</td>"; break;
	 case 'total' : 		$tb.= "<td>".number_format($item['total'],$_DECIMALS,',','.')."</td>"; break;
	 case 'intervamount' : 	$tb.= "<td>".number_format($item['tot_amount'],$_DECIMALS,',','.')."</td>"; break;
	 case 'customer_name' : $tb.= "<td>".$item['customer_name']."</td>"; break;
	 case 'commiss_name' :  $tb.= "<td>".$item['commiss_name']."</td>"; break;
	 case 'ext_contract_ref' : $tb.= "<td>".$item['ext_contract_ref']."</td>"; break;
	}
   }
   $tb.= "</tr>";
  }
  $db->Close();

  /* FINALE */
  $tb.= "<tr><td></td></tr>";


  // TOTALI
  $_FOOTER = array();
  reset($_SELECTED_COLUMNS);
  while(list($k,$v)=each($_SELECTED_COLUMNS))
  {
   switch($k)
   {
	case 'amount' : case 'vat' : case 'total' : {
		 if(isset($_TOTALS[$k]))
		  $_FOOTER[] = number_format($_TOTALS[$k] ? $_TOTALS[$k] : 0,$_DECIMALS,',','.');
		 else
		  $_FOOTER[] = "";
		} break;

	case 'intervamount' : {
		 if(isset($_TOTALS['tot_amount']))
		  $_FOOTER[] = number_format($_TOTALS['tot_amount'] ? $_TOTALS['tot_amount'] : 0,$_DECIMALS,',','.');
		 else
		  $_FOOTER[] = "";
		} break;
   
    default : $_FOOTER[] = ""; break;
   }
  }

  for($c=0; $c < count($_FOOTER); $c++)
  {
   $idx = count($_FOOTER)-1-$c;
   if($idx && ($_FOOTER[$idx] != "") && ($_FOOTER[$idx] != "Totale") && ($_FOOTER[$idx-1] == ""))
	$_FOOTER[$idx-1] = "Totale";
  }

  $tb.= "<tr>"; 
  for($c=0; $c < count($_FOOTER); $c++)
   $tb.= "<td>".$_FOOTER[$c]."</td>";
  $tb.= "</tr>";

  $tb.= "</table>";

  $_HTML_CONTENTS[] = array('title'=>$subjName, 'content'=>$tb);
 } // EOF - Filter by subject


 /* EXPORT TO EXCEL */
 $_CMD = "excel write -f `".$fileName."`";
 for($c=0; $c < count($_HTML_CONTENTS); $c++)
  $_CMD.= " -s `".$_HTML_CONTENTS[$c]['title']."` -htmltable `".$_HTML_CONTENTS[$c]['content']."` -throwidx 4";

 $ret = GShell($_CMD." -formats `".$formats."`",$sessid,$shellid);
 if($ret['error']) return array('message'=>$out.= "\nError:".$ret['message'], 'error'=>$ret['error']);
 $outArr = $ret['outarr'];

 $out.= $ret['message']."\nSummary by customer has been exported into file ".$ret['outarr']['filename'].".";

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_requestList($args, $sessid, $shellid)
{
 $_TB = "extreqtickets";
 $out = "";
 $outArr = array('count'=>0, 'items'=>array());

 $limit = 100;
 $orderBy = "id ASC";
 $_WHERE = "";

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-from' : {$dateFrom=$args[$c+1]; $c++;} break;
   case '-to' : {$dateTo=$args[$c+1]; $c++;} break;
   case '-where' : {$where=$args[$c+1]; $c++;} break;
   case '-limit' : {$limit=$args[$c+1]; $c++;} break;
   case '--order-by' : {$orderBy=$args[$c+1]; $c++;} break;

   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 $db = new AlpaDatabase();

 if($dateFrom)			$_WHERE.= " AND ctime>='".$dateFrom."'";
 if($dateTo)			$_WHERE.= " AND ctime<'".$dateTo."'";
 if($where)				$_WHERE.= " AND ".$where;

 if(!$where) $_WHERE = "1";
 else $_WHERE = ltrim($_WHERE, " AND ");

 // get count //
 $db->RunQuery("SELECT COUNT(*) FROM ".$_TB." WHERE ".$_WHERE);
 if($db->Error) return array('message'=>"MySQL Error: ".$db->Error, 'error'=>"MYSQL_ERROR");
 $db->Read();
 $outArr['count'] = $db->record[0];

 // get items //
 $db->RunQuery("SELECT * FROM ".$_TB." WHERE ".$_WHERE." ORDER BY ".$orderBy." LIMIT ".$limit);
 if($db->Error) return array('message'=>"MySQL Error: ".$db->Error, 'error'=>"MYSQL_ERROR");
 while($db->Read())
 {
  $a = array('id'=>$db->record['id'], 'ctime'=>$db->record['ctime'], 'code_num'=>$db->record['code_num'], 
	'subject_name'=>$db->record['subject_name'], 'subject_phone'=>$db->record['subject_phone'], 'subject_email'=>$db->record['subject_email'],
	'hw_name'=>$db->record['hw_name'], 'request_msg'=>$db->record['request_msg']);
  $outArr['items'][] = $a;
 }
 $db->Close();

 if($verbose)
 {
  for($c=0; $c < count($outArr['items']); $c++)
  {
   $itm = $outArr['items'][$c];
   $out.= "#".$itm['id']." - ".date('d/m/Y H:i',strtotime($itm['ctime']))." - ".$itm['subject_name']."\n";
  }
 }
 if(!$outArr['count']) $out.= "No items found.\n";
 else $out.= $outArr['count']." requests found.\n";

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_requestInfo($args, $sessid, $shellid)
{
 $_TB = "extreqtickets";
 $out = "";
 $outArr = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$id=$args[$c+1]; $c++;} break;

   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 if(!$id) return array('message'=>"You must specify the request ID.", 'error'=>"INVALID_REQUEST_ID");

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM ".$_TB." WHERE id='".$id."'");
 if(!$db->Read())
 {
  $db->Close();
  return array("message"=>"No request found with ID:".$id, "error"=>"REQUEST_DOES_NOT_EXISTS");
 }
 $outArr = array('id'=>$db->record['id'], 'ctime'=>$db->record['ctime'], 'code_num'=>$db->record['code_num'], 
	'subject_name'=>$db->record['subject_name'], 'subject_phone'=>$db->record['subject_phone'], 'subject_email'=>$db->record['subject_email'],
	'hw_name'=>$db->record['hw_name'], 'request_msg'=>$db->record['request_msg']);
 $db->Close();

 if($verbose)
 {
  $out.= "Informations about request:\n";
  $out.= "ID: ".$outArr['id']."\n";
  $out.= "Date: ".date('d/m/Y H:i',strtotime($outArr['ctime']))."\n";
  $out.= "Code: ".$outArr['code_num']."\n";
  $out.= "Customer: ".$outArr['subject_name']."\n";
  $out.= "Phone: ".$outArr['subject_phone']."\n";
  $out.= "Email: ".$outArr['subject_email']."\n";
  $out.= "Hardware: ".$outArr['hw_name']."\n";
  $out.= "Message: ".$outArr['request_msg']."\n";
 }

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_editRequest($args, $sessid, $shellid)
{
 $_TB = "extreqtickets";
 $out = "";
 $outArr = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$id=$args[$c+1]; $c++;} break;
   case '-ctime' : {$ctime=$args[$c+1]; $c++;} break;
   case '-subjname' : case '-customer' : {$subjectName=$args[$c+1]; $c++;} break;
   case '-subjphone' : case '-phone' : {$subjectPhone=$args[$c+1]; $c++;} break;
   case '-subjemail' : case '-email' : {$subjectEmail=$args[$c+1]; $c++;} break;
   case '-hwname' : {$hwName=$args[$c+1]; $c++;} break;
   case '-message' : {$message=$args[$c+1]; $c++;} break;
  }

 if(!$id) return array('message'=>"You must specify the request ID.", 'error'=>"INVALID_REQUEST_ID");

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM ".$_TB." WHERE id='".$id."'");
 if(!$db->Read()) return array('message'=>"Request #".$id." does not exists.", "error"=>"REQUEST_DOES_NOT_EXISTS");

 $q = "";
 if($ctime)					$q.= ",ctime='".$ctime."'";
 if($subjectName)			$q.= ",subject_name='".$db->Purify($subjectName)."'";
 if(isset($subjectPhone))	$q.= ",subject_phone='".$db->Purify($subjectPhone)."'";
 if(isset($subjectEmail))	$q.= ",subject_email='".$db->Purify($subjectEmail)."'";
 if(isset($hwName))			$q.= ",hw_name='".$db->Purify($hwName)."'";
 if(isset($message))		$q.= ",request_msg='".$db->Purify($message)."'";
 
 $db->RunQuery("UPDATE ".$_TB." SET ".ltrim($q,",")." WHERE id='".$id."'");
 if($db->Error) return array('message'=>"MySQL Error: ".$db->Error, 'error'=>"MYSQL_ERROR");
 $db->Close();

 $out.= "Done! Request #".$id." has been updated.\n";

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_deleteRequest($args, $sessid, $shellid)
{
 $_TB = "extreqtickets";
 $out = "";
 $outArr = array();
 $_IDS = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$_IDS[]=$args[$c+1]; $c++;} break;
  }

 if(!count($_IDS)) return array('message'=>"You must specify the request ID.", 'error'=>"INVALID_REQUEST_ID");

 $db = new AlpaDatabase();
 for($c=0; $c < count($_IDS); $c++)
 {
  $id = $_IDS[$c];
  $db->RunQuery("DELETE FROM ".$_TB." WHERE id='".$id."'");
  if($db->Error) return array("message"=>"Request #".$id." does not exists.", "error"=>"REQUEST_DOES_NOT_EXISTS");
 }
 $db->Close();

 $out.= "Done! ".count($_IDS)." requests has been removed.\n";
 $outArr['id'] = $id;

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function ticket_generateFromRequest($args, $sessid, $shellid)
{
 $_TB = "extreqtickets";
 $out = "";
 $outArr = array();
 $_IDS = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-id' : {$_IDS[]=$args[$c+1]; $c++;} break;
  }

 if(!count($_IDS)) return array('message'=>"You must specify the request ID.", 'error'=>"INVALID_REQUEST_ID");

 for($i=0; $i < count($_IDS); $i++)
 {
  $id = $_IDS[$i];

  /* Get request info */
  $ret = GShell("ticket request-info -id '".$id."'",$sessid,$shellid);
  if($ret['error']) return $ret;

  $requestInfo = $ret['outarr'];


  /* Generate ticket */
  $cmd = "dynarc new-item -ap tickets -group tickets -perms 664";
  $cmd.= " -desc `".$requestInfo['request_msg']."` -extset `ticketinfo.subjname='''".$requestInfo['subject_name']."''',hwname='''".$requestInfo['hw_name']."'''`";

  $ret = GShell($cmd, $sessid, $shellid);
  if($ret['error']) return array("message"=>"Unable to generate ticket. ".$ret['message'], "error"=>$ret['error']);
  $ticketInfo = $ret['outarr'];

  $out.= "Done! Ticket has been generated from request #".$id.". Ticket ID=".$ticketInfo['id']."\n";

  $db = new AlpaDatabase();
  $db->RunQuery("UPDATE ".$_TB." SET ticket_id='".$ticketInfo['id']."' WHERE id='".$id."'");
  $db->Close();
 }

 if(count($_IDS) == 1)
  $outArr = $ticketInfo;
 else
  $outArr[] = $ticketInfo;

 return array('message'=>$out, 'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//

