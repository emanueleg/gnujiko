<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 12-06-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Official Gnujiko Ticket System
 #VERSION: 2.3beta
 #CHANGELOG: 12-06-2016 : Integrato con ticket custom.
			 15-10-2014 : Aggiustato lo status e rimosso gli appuntamenti annullati.
			 08-10-2014 : bug fix.
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS;

$_BASE_PATH = "../";
$_RESTRICTED_ACCESS = "tickets";
$_AP = "tickets";

if(!$_REQUEST['view'])
 $_REQUEST['view'] = "list";

$_EDIT_TICKET_FORM = "Tickets/ticketinfo.php";

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate();
$template->includeCSS("appointments-listview.css");
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeInternalObject("serp");
$template->includeInternalObject("contactsearch");
$template->includeInternalObject("addresssearch");
$template->includeObject("printmanager");

$template->Begin("Appuntamenti");
//-------------------------------------------------------------------------------------------------------------------//
$_DEF_RPP = 25;

$_STATUS = array();
reset($template->config['ticketstatus']);
while(list($k,$v)=each($template->config['ticketstatus']))
{
 $_STATUS[$k] = $v['name'];
}


if(is_array($template->config['display']))
{
 if($template->config['display']['edit-ticket-form'] && file_exists($_BASE_PATH.$template->config['display']['edit-ticket-form']))
  $_EDIT_TICKET_FORM = $template->config['display']['edit-ticket-form'];
}


$_COLUMNS = array(
 0 => array('title'=>'Data e ora', 		'field'=>'app_datetime', 	'width'=>110, 	'sortable'=>true, 	'visibled'=>true),
 1 => array('title'=>'N. ticket', 		'field'=>'code_str', 		'width'=>70, 	'sortable'=>true, 	'visibled'=>true),
 2 => array('title'=>'Rif. Ticket',		'field'=>'ext_ticket_ref',	'sortable'=>true,	'visibled'=>false),
 3 => array('title'=>'Data apertura',	'field'=>'ctime',			'width'=>100,	'sortable'=>true,	'visibled'=>false,	'format'=>'date'),
 4 => array('title'=>'Data scadenza',	'field'=>'tax_delivery',	'width'=>120,	'sortable'=>true,	'visibled'=>false,	'format'=>'date'),
 5 => array('title'=>'Data chiusura',	'field'=>'finish_datetime',	'width'=>120,	'sortable'=>true,	'visibled'=>false,	'format'=>'date'),
 6 => array('title'=>'Cliente',			'field'=>'subject_name',	'sortable'=>true,	'visibled'=>true),
 7 => array('title'=>'Tipologia',		'field'=>'ticket_type',		'sortable'=>true,	'visibled'=>false),
 8 => array('title'=>'Indirizzo',		'field'=>'contact_id',		'sortable'=>false,	'visibled'=>true),
 9 => array('title'=>'Zona',			'field'=>'zone',			'sortable'=>true,	'visibled'=>false),
 10 => array('title'=>'Operatore',		'field'=>'operator_id',		'sortable'=>true,	'visibled'=>false),
 11 => array('title'=>'Imponibile',		'field'=>'amount',			'sortable'=>true,	'visibled'=>false,	'format'=>'currency'),
 12 => array('title'=>'IVA',			'field'=>'vat',				'sortable'=>true,	'visibled'=>false,	'format'=>'currency'),
 13 => array('title'=>'Totale',			'field'=>'total',			'sortable'=>true,	'visibled'=>false,	'format'=>'currency'),
 14 => array('title'=>'Status',			'field'=>'status',			'sortable'=>true,	'visibled'=>false)
);

/* GET COLUMN SETTINGS */
$ret = GShell("aboutconfig get -app tickets -sec appointmentlist");
if(!$ret['error'])
{
 $settings = $ret['outarr']['defaultsettings'];
 if(is_array($settings['appointmentlist']))
 {
  $visibledColumns = explode(",",$settings['appointmentlist']['visibledcolumns']);
  for($c=0; $c < count($_COLUMNS); $c++)
  {
   $col = $_COLUMNS[$c];
   if(in_array($col['field'], $visibledColumns))
	$_COLUMNS[$c]['visibled'] = true;
   else
	$_COLUMNS[$c]['visibled'] = false;
  }
  if($settings['appointmentlist']['rpp'])
   $_DEF_RPP = $settings['appointmentlist']['rpp'];
 }
}

if(!$_REQUEST['from'] && !$_REQUEST['to'])
{
 $dateFrom = date("Y-m")."-01";
 $dateTo = date("Y-m-d",strtotime("+1 month",strtotime($dateFrom)));
}
else
{
 $dateFrom = $_REQUEST['from'] ? $_REQUEST['from'] : "";
 $dateTo = $_REQUEST['to'] ? $_REQUEST['to'] : "";
}
$centerContents = "<input type='text' class='edit' style='width:390px;float:left' placeholder='Cerca per cliente' id='search' value=\""
	.htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\" ct='customers'/>";
$centerContents.= "<input type='button' class='button-search' id='searchbtn'/>";
$centerContents.= "<input type='text' class='calendar' value='".($dateFrom ? date('d/m/Y',strtotime($dateFrom)) : '')."' id='datefrom' style='margin-left:30px'/>";
$centerContents.= "<span class='smalltext'> al </span> <input type='text' class='calendar' value='".($dateTo ? date('d/m/Y',strtotime($dateTo)) : '')."' id='dateto'/>";

/* GET CONFIG */
$config = array();
$ret = GShell("aboutconfig get-config -app tickets");
if(!$ret['error'])
 $config = $ret['outarr']['config'];

$template->Header("search", $centerContents, "BTN_EXIT", 800);
//-------------------------------------------------------------------------------------------------------------------//
$_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "app_datetime";
$_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "ASC";
$_RPP = $_REQUEST['rpp'] ? $_REQUEST['rpp'] : $_DEF_RPP;
$_PG = $_REQUEST['pg'] ? $_REQUEST['pg'] : 1;

$_SERP = new SERP();
$_SERP->setOrderBy($_ORDER_BY);
$_SERP->setOrderMethod($_ORDER_METHOD);
$_SERP->setResultsPerPage($_RPP);
$_SERP->setCurrentPage($_PG);

$cmd = "dynarc item-list -ap '".$_AP."' --all-cat --order-by `app_datetime ASC` -extget `ticketinfo`";
$where = " AND app_datetime>0";
if($config['calendar']['listviewmodal'] == 'onlyopen')	
 $where.= " AND closed='0' AND status!=20";

if($dateFrom)					$where.= " AND app_datetime>='".$dateFrom."'";
if($dateTo)						$where.= " AND app_datetime<='".$dateTo."'";
if($_REQUEST['subjid'])			$where.= " AND subject_id='".$_REQUEST['subjid']."'";

if($where)
 $cmd.= " -where `".ltrim($where,' AND ')."`";

$_CMD = $cmd;
$ret = $_SERP->SendCommand($cmd);
$ticketlist = $ret['items'];

//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0);
$imgPath = $_ABSOLUTE_URL.$template->config['basepath']."img/";
?>
 &nbsp;
 </td>
 <td width='200'>
	<input type='button' class="button-blue menuwhite" value='Menu' connect='mainmenu' id='mainmenubutton'/>
		<ul class='popupmenu' id='mainmenu'>
		 <!--<li onclick='newAppointment()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/time.png"/> Nuovo appuntamento</li>
		 <li class='separator'>&nbsp;</li>-->
		 <li onclick='deleteSelected()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/delete.gif"/> Elimina appuntamenti selezionati</li>
		 <li class='separator'>&nbsp;</li>
		 <li onclick='Print(this)'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/printer.gif"/> Stampa lista</li>
		</ul>

	<input type='button' class="button-gray menu" value="Visualizza" connect="viewmenu" id="viewmenubutton"/>
	<ul class='popupmenu' id='viewmenu'>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $checked = $col['visibled'] ? true : false;
	 echo "<li><input type='checkbox'".($checked ? " checked='true'" : "")." onchange=\"showColumn('".$col['field']."',this)\"/>".$col['title']."</li>";
	}
	?>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="saveGlobalSettings()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save.gif"/>Salva configurazione</li>
	</ul>

 </td>
 <td>
  <ul class='toggles'><?php
	  $view = array(
		 "calendar"=>array("title"=>"Mostra calendario", "icon"=>"calendar-view.png"),
		 "list"=>array("title"=>"Mostra lista", "icon"=>"list-view.png")
		);
	  $idx = 0;
	  while(list($k,$v)=each($view))
	  {
	   $class = "";
	   if($idx == 0)
		$class = "first";
	   else if($idx == (count($view)-1))
		$class = "last";
	   if($k == $_REQUEST['view'])
		$class.= " selected";
	   echo "<li".($class ? " class='".$class."'" : "")." onclick=\"setView('".$k."')\" title=\"".$v['title']."\"><img src='".$imgPath.$v['icon']."' class='largebutton'/></li>";
	   $idx++;
	  }
	?></ul>
 </td>
 <td width='130'>
	<span class='smalltext'>Mostra</span>
	<input type='text' class='dropdown' id='rpp' value="<?php echo $_RPP; ?> righe" retval="<?php echo $_RPP; ?>" readonly='true' connect='rpplist' style='width:80px'/>
	<ul class='popupmenu' id='rpplist'>
	 <li value='10'>10 righe</li>
	 <li value='25'>25 righe</li>
	 <li value='50'>50 righe</li>
	 <li value='100'>100 righe</li>
	 <li value='250'>250 righe</li>
	 <li value='500'>500 righe</li>
	</ul>
 </td>
 <td width='223' align='right'>
	<?php $_SERP->DrawSerpButtons(true);
 
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("fullspace");
//-------------------------------------------------------------------------------------------------------------------//
?>
<table width="100%" height="80%" cellspacing="0" cellpadding="0" border="0" id="template-outer-mask">
 <tr><td class="bg-lightgray" style="width:270px;" valign="top">
	<?php
	showMainMenu($template);
	?>
	</td>
	<td style="width:8px" valign="top"><div class="vertical-gray-separator"></div></td>
	<td class="page-contents" valign="top">
	 <div class="page-contents-body">
	  <!-- START OF PAGE ------------------------------------------------------------------------->
	  <div class="titlebar blue-bar"><span class="titlebar blue-bar">LISTA DEGLI APPUNTAMENTI</span></div>
<table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='ticketlist' noprinthidden='true'>
<tr><th width='16' printable='false'><input type='checkbox'/></th>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $visibled = $col['visibled'] ? true : false;
	 echo "<th".(!$visibled ? " style='display:none'" : "");
	 if($col['width'])			echo " width='".$col['width']."'";
	 if($col['field'])			echo " field='".$col['field']."'";
	 if($col['format'])			echo " format='".$col['format']."'";
	 if($col['sortable'])		echo " sortable='true'";
	 echo ">".$col['title']."</th>";
	}
	?>
</tr>
<?php

$row = 0;
for($c=0; $c < count($ticketlist); $c++)
{
 $item = $ticketlist[$c];
 $hint = $item['name']." - ".$item['subject_name'].($item['ext_ticket_ref'] ? " - Rif. ".$item['ext_ticket_ref'] : "");

 echo "<tr class='row".$row."' id='".$item['id']."' title=\"".$hint."\"><td><input type='checkbox'/></td>";
 for($i=0; $i < count($_COLUMNS); $i++)
 {
  $col = $_COLUMNS[$i];
  $visibled = $col['visibled'] ? true : false;
  echo "<td".(!$visibled ? " style='display:none'>" : ">");
  switch($col['field'])
  {
   case 'app_datetime' : echo date('d/m/Y H:i',strtotime($item['app_datetime'])); break;
   case 'code_str' : echo "<a class='link blue' href='".$_ABSOLUTE_URL.$_EDIT_TICKET_FORM."?id=".$item['id']."' target='TKT-".$item['id']."'>".$item['code_num']."</a>"; break;
   case 'ctime' : echo "<a class='link blue' href='".$_ABSOLUTE_URL.$_EDIT_TICKET_FORM."?id=".$item['id']."' target='TKT-".$item['id']."'>".date('d/m/Y',$item['ctime'])."</a>"; break;
   case 'tax_delivery' : echo $item['tax_delivery'] ? date('d/m/Y',strtotime($item['tax_delivery'])) : "&nbsp;"; break;
   case 'finish_datetime' : echo $item['finish_datetime'] ? date('d/m/Y',strtotime($item['finish_datetime'])) : "&nbsp;"; break;
   case 'subject_name' : echo $item['subject_name'] ? $item['subject_name'] : "&nbsp;"; break;
   case 'ticket_type' : echo $item['type_name'] ? $item['type_name'] : "&nbsp;"; break;
   case 'contact_id' : echo $item['address'] ? $item['address'] : '&nbsp;'; break;
   case 'zone' : echo $item['zone'] ? $item['zone'] : "&nbsp;"; break;
   case 'ext_ticket_ref' : echo "<a class='link blue' href='".$_ABSOLUTE_URL.$_EDIT_TICKET_FORM."?id=".$item['id']."' target='TKT-".$item['id']."'>"
	.($item['ext_ticket_ref'] ? $item['ext_ticket_ref'] : '&nbsp;')."</a>"; break;
   case 'operator_id' : echo $item['operator_name'] ? $item['operator_name'] : "&nbsp;"; break;
   case 'amount' : echo number_format($item['amount'],2,',','.'); break;
   case 'vat' : echo number_format($item['vat'],2,',','.'); break;
   case 'total' : echo number_format($item['total'],2,',','.'); break;
   case 'status' : echo $_STATUS[$item['status']]; break;
  }
  echo "</td>";
 }
 echo "</tr>";
 $row = $row ? 0 : 1;
}

?>
</table>
	  <!-- END OF PAGE --------------------------------------------------------------------------->
	 </div>
	</td>
 </tr>
</table>

<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
?>
<script>
var AP = "<?php echo $_AP; ?>";
var ON_PRINTING = false;
var ON_EXPORT = false;

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL;
	return false;
}

Template.OnInit = function(){
 /* AUTORESIZE */
 var sH = this.getScreenHeight();
 var tb = document.getElementById("template-outer-mask");
 if(tb.offsetHeight < (sH-115))
  tb.style.height = (sH-115)+"px";
 /* EOF - AUTORESIZE */

	this.initBtn(document.getElementById('mainmenubutton'), 'popupmenu');
	this.initBtn(document.getElementById('viewmenubutton'), 'popupmenu');

	this.initEd(document.getElementById("datefrom"), "date");
	this.initEd(document.getElementById("dateto"), "date").OnDateChange = function(date){
		 Template.SERP.setVar("from",document.getElementById("datefrom").isodate);
		 Template.SERP.setVar("to",date);
		 Template.SERP.reload();
		};

	this.initEd(document.getElementById('rpp'), "dropdown").onchange = function(){
		 Template.SERP.RPP = this.getValue();
		 Template.SERP.reload(0);
		}

	this.initEd(document.getElementById("search"), "contactextended").OnSearch = function(){
		 if(this.value && this.data)
		 {
		  Template.setVar("subjid",this.data['id']);
		  Template.setVar("search",this.value);
		 }
		 else
		 {
		  Template.unsetVar("subjid");
		  Template.unsetVar("search");
		 }
		 Template.reload(0);
		}

	document.getElementById("searchbtn").onclick = function(){document.getElementById("search").OnSearch();}
	this.SERP = new SERP("<?php echo $_SERP->OrderBy; ?>", "<?php echo $_SERP->OrderMethod; ?>", "<?php echo $_SERP->RPP; ?>", "<?php echo $_SERP->PG; ?>");
	this.initSortableTable(document.getElementById("ticketlist"), this.SERP.OrderBy, this.SERP.OrderMethod).OnSort = function(field, method){
		Template.SERP.OrderBy = field;
	    Template.SERP.OrderMethod = method;
		Template.SERP.reload(0);
	}

}

function setView(value)
{
 Template.setVar("view",value);
 Template.reload(0);
}

function setShow(value)
{
 Template.setVar("show",value);
 Template.reload(0);
}

function showColumn(field,cb)
{
 var tb = document.getElementById("ticketlist");
 if(cb.checked == true)
  tb.showColumn(field);
 else
  tb.hideColumn(field);
}


function editEvent(id,ap,refid)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){if(!a) return; document.location.reload();}
 sh.sendCommand("dynlaunch -ap '"+ap+"' -id '"+refid+"'");
}

function newAppointment()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){if(!a) return; document.location.reload();}
 sh.sendCommand("gframe -f appointment/new -params `ap="+AP+"`");
}

function Print(printBtn)
{
 var dateFrom = new Date();
 var dateTo = new Date();

 var title = "Appuntamenti";

 if(document.getElementById("datefrom").value)
 {
  dateFrom.setFromISO(document.getElementById("datefrom").isodate);
  title+= " - dal "+dateFrom.printf('d/m/Y');
 }
 if(document.getElementById("dateto").value)
 {
  dateTo.setFromISO(document.getElementById("dateto").isodate);
  title+= " al "+dateTo.printf('d/m/Y');
 }


 var doc = new GnujikoPrintableDocument("Appuntamenti", "A4");
 var header = "<div style='width:190mm' class='defaultheader'><h3>"+title+"</h3></div>";
 doc.setDefaultPageHeader(header);

 var footer = "<div style='width:190mm;margin-top:10mm' class='defaultfooter'>";
 footer+= "<table width='100%' cellspacing='0' cellpadding='0' border='0' class='footertable'>";
 footer+= "<tr><td style='width:160mm'>Pag.</td>";
 footer+= "<td style='width:20mm;text-align:center'>Tot. appuntamenti</td></tr>";

 footer+= "<tr><td>{PGC}</td>";
 footer+= "<td style='text-align:center'>"+(document.getElementById('ticketlist').rows.length-1)+"</td></tr>";

 footer+= "</table></div>";

 doc.setDefaultPageFooter(footer);
 doc.includeCSS("var/objects/printmanager/printabletable.css");
 var gpt = new GnujikoPrintableTable(document.getElementById('ticketlist'),true,true);
 var ppc = gpt.generatePrintPreview(190);
 for(var c=0; c < ppc.length; c++)
 {
  var page = doc.addPage();
  page.footer = page.footer.replace("{PGC}", (c+1)+"/"+ppc.length);
  page.setContents(ppc[c]);
 }

 doc.printAsPDF();
 document.location.href = "#search";
}

function deleteSelected()
{
 var tb = document.getElementById("ticketlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun appuntamento è stato selezionato.");
 if(!confirm("Sei sicuro di voler eliminare gli appuntamenti selezionati?"))
  return;
 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= " && dynarc edit-item -ap '"+AP+"' -id '"+sel[c].id+"' -extset `ticketinfo.apptime='0'`";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){document.location.reload();}

 sh.sendCommand(q.substr(4));
}

function saveGlobalSettings()
{
 var xml = "<appointmentlist";
 var visibledColumns = "";
 var rpp = document.getElementById('rpp').getValue();

 var tb = document.getElementById("ticketlist");
 for(var c=0; c < tb.fields.length; c++)
 {
  var th = tb.fields[c];
  if(th.style.display != "none")
   visibledColumns+= ","+th.getAttribute('field');
 }
 if(visibledColumns)
  xml+= " visibledcolumns='"+visibledColumns.substr(1)+"'";

 xml+= " rpp='"+rpp+"'";
 xml+= "/"+">";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){alert("Configurazione salvata");}
 sh.sendSudoCommand("aboutconfig set-config -app tickets -sec appointmentlist -xml-settings `"+xml+"`");
}

</script>
<?php

$template->End();

?>


