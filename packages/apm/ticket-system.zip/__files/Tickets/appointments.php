<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 07-10-2014
 #PACKAGE: ticket-system
 #DESCRIPTION: Official Gnujiko Ticket System
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS;

$_BASE_PATH = "../";
$_RESTRICTED_ACCESS = "tickets";
$_AP = "tickets";

if(!$_REQUEST['view'])
 $_REQUEST['view'] = "calendar";

switch($_REQUEST['view'])
{
 case 'list' : include("appointments-listview.php"); break;
 default : include("appointments-calendarview.php"); break;
}

