<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 12-06-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Official Gnujiko Ticket System
 #VERSION: 2.1beta
 #CHANGELOG: 12-06-2016 : Integrato con ticket custom.
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS;

$_BASE_PATH = "../";
$_RESTRICTED_ACCESS = "tickets";
$_AP = "tickets";

if(!$_REQUEST['view'])
 $_REQUEST['view'] = "calendar";

$_EDIT_TICKET_FORM = "Tickets/ticketinfo.php";

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate();
$template->includeCSS("appointments-calendarview.css");
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeObject("gorganizer");
$template->includeObject("gcalendar");
$template->includeInternalObject("contactsearch");

if(is_array($template->config['display']))
{
 if($template->config['display']['edit-ticket-form'] && file_exists($_BASE_PATH.$template->config['display']['edit-ticket-form']))
  $_EDIT_TICKET_FORM = $template->config['display']['edit-ticket-form'];
}

$template->Begin("Appuntamenti");
//-------------------------------------------------------------------------------------------------------------------//
$centerContents = "<input type='text' class='edit' style='width:390px;float:left' placeholder='Cerca negli appuntamenti' id='search' value=\""
	.htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\"/>";
$centerContents.= "<input type='button' class='button-search' id='searchbtn'/>";

$template->Header("search", $centerContents, "BTN_EXIT", 800);
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0);
$imgPath = $_ABSOLUTE_URL.$template->config['basepath']."img/";
?>
 &nbsp;
 </td>
 <!--<td width='200'>
	<input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='mainmenubutton'/>
	<ul class='popupmenu' id='mainmenu'>
  	 <li onclick="NewTicket()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/new_file.png" height="16"/>Nuovo ticket</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="ImportFromExcel(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/page_white_excel.gif"/>Importa da Excel</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="ExportToExcel(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Salva su Excel</li>
	 <li onclick="Print(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/printer.gif"/>Stampa</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="DeleteSelected()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/trash.gif"/>Elimina ticket selezionati</li>
	</ul>

	<input type='button' class="button-gray menu" value="Visualizza" connect="viewmenu" id="viewmenubutton"/>
	<ul class='popupmenu' id='viewmenu'>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $checked = $col['visibled'] ? true : false;
	 echo "<li><input type='checkbox'".($checked ? " checked='true'" : "")." onchange=\"showColumn('".$col['field']."',this)\"/>".$col['title']."</li>";
	}
	?>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="saveGlobalSettings()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save.gif"/>Salva configurazione</li>
	</ul>
 </td>-->
 <td>
  <ul class='toggles'><?php
	  $view = array(
		 "calendar"=>array("title"=>"Mostra calendario", "icon"=>"calendar-view.png"),
		 "list"=>array("title"=>"Mostra lista", "icon"=>"list-view.png")
		);
	  $idx = 0;
	  while(list($k,$v)=each($view))
	  {
	   $class = "";
	   if($idx == 0)
		$class = "first";
	   else if($idx == (count($view)-1))
		$class = "last";
	   if($k == $_REQUEST['view'])
		$class.= " selected";
	   echo "<li".($class ? " class='".$class."'" : "")." onclick=\"setView('".$k."')\" title=\"".$v['title']."\"><img src='".$imgPath.$v['icon']."' class='largebutton'/></li>";
	   $idx++;
	  }
	?></ul>
 </td>
 <td>
	<?php
 
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("fullspace");
//-------------------------------------------------------------------------------------------------------------------//
?>
<table width="100%" height="80%" cellspacing="0" cellpadding="0" border="0" id="template-outer-mask">
 <tr><td class="bg-lightgray" style="width:270px;" valign="top">
	<?php
	$Calendar = new GCalendar();
	$Calendar->Paint();
	echo "<div style='height:40px;border-bottom:1px solid #dadada'></div>";
	showMainMenu($template);
	?>
	</td>
	<td style="width:8px" valign="top"><div class="vertical-gray-separator"></div></td>
	<td class="page-contents" valign="top">
	 <div class="page-contents-body">
	  <!-- START OF PAGE ------------------------------------------------------------------------->
	  <div class="titlebar blue-bar"><span class="titlebar blue-bar">CALENDARIO APPUNTAMENTI</span></div>
	  <div id='gorganizer' style='width:700px;height:480px;'></div>
	  <!-- END OF PAGE --------------------------------------------------------------------------->
	 </div>
	</td>
 </tr>
</table>

<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
?>
<script>
var GOrg = null;
var Calendar = null;
var dateFrom = "<?php echo $_REQUEST['date'] ? $_REQUEST['date'] : date('Y-m-d'); ?>";

var AP = "<?php echo $_AP; ?>";
var ON_PRINTING = false;
var ON_EXPORT = false;

var EDIT_TICKET_FORM = "<?php echo $_EDIT_TICKET_FORM; ?>";

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL;
	return false;
}

Template.OnInit = function(){
 /* AUTORESIZE */
 var sH = this.getScreenHeight();
 var tb = document.getElementById("template-outer-mask");
 if(tb.offsetHeight < (sH-115))
  tb.style.height = (sH-115)+"px";
 /* EOF - AUTORESIZE */

 var gorgDiv = document.getElementById('gorganizer');
 gorgDiv.style.height = gorgDiv.parentNode.offsetHeight+"px";
 gorgDiv.style.width = (gorgDiv.parentNode.offsetWidth-20)+"px";
 GOrg = new GOrganizer(gorgDiv, null, 14, dateFrom);
 
 GOrg.OnDblClick = function(date){
	 
	}

 GOrg.OnBlockMove = function(block){
		 var sh = new GShell();
		 sh.OnError = function(err){alert(err);}
	 	 sh.OnOutput = function(o,a){if(!a) return;}
		 if(block.data)
		 {
		  if(block.data['is_recurrence'])
		   sh.sendCommand("cron recurrence2event -ap `"+block.data['archive']+"` -id `"+block.data['id']+"` -from `"+block.dateFrom.printf('Y-m-d H:i')+"` -to `"+block.dateTo.printf('Y-m-d H:i')+"` -exception `"+block.oldDateFrom.printf('Y-m-d H:i')+"`");
		  else
		   sh.sendCommand("cron edit-event -ap `"+block.data['archive']+"` -id `"+block.data['id']+"` -from `"+block.dateFrom.printf('Y-m-d H:i')+"` -to `"+block.dateTo.printf('Y-m-d H:i')+"` --update-doc-date");
		 }
	 	 else if(block.id && block.archive)
		 {
		  switch(block.archive)
		  {
		   default : sh.sendCommand("dynarc edit-item -ap `"+block.archive+"` -id `"+block.id+"` -ctime `"+block.dateFrom.printf('Y-m-d H:i')+"`-extset `cronevents.from='"+block.dateFrom.printf('Y-m-d H:i')+"',to='"+block.dateTo.printf('Y-m-d H:i')+"'`"); break;
		  }
		 }
		}

 GOrg.OnBlockResize = function(block){
	 	 if(!block.data) return;
	 	 var sh = new GShell();
		 sh.OnError = function(err){alert(err);}
		 sh.OnOutput = function(o,a){}
		 sh.sendCommand("cron edit-event -ap `"+block.data['archive']+"` -id `"+block.data['id']+"` -from `"+block.dateFrom.printf('Y-m-d H:i')+"` -to `"+block.dateTo.printf('Y-m-d H:i')+"` --update-doc-date");
		}

 GOrg.OnBlockClick = function(block){
	 	 if(!block.data) return;
		 switch(block.data['archive'])
		 {
		  case 'tickets' : {
			 window.open(ABSOLUTE_URL+EDIT_TICKET_FORM+"?id="+block.data['item_id'], "_blank");
			} break;
		  default : {
			 var sh = new GShell();
			 sh.OnError = function(err){alert(err);}
			 sh.OnOutput = function(o,a){GOrg.reload();}
			 sh.sendCommand("dynlaunch -ap `"+block.data['archive']+"` -id `"+block.data['item_id']+"`");
			} break;
		 }
		}


 GOrg.OnUpdateRequest = function(dateFrom, dateTo){
	  	 var from = new Date(dateFrom);
	 	 var to = new Date(dateTo);

		 var sh = new GShell();
		 sh.OnError = function(e,s){}
		 sh.OnOutput = function(o,a){
			 if(!a)
			  return;
			 for(var c=0; c < a.length; c++)
			 {
			  var data = a[c];
			  var opt = {};
			  if(data['tag'] == "WORKING_AREA")
			   opt.type = "workingarea";
			  else if(data['tag'] == "NONWORKING_AREA")
			   opt.type = "nonworkingarea";
			  switch(data['archive'])
			  {
			   case 'appointments' : opt.color = "orange"; break;
			   case 'todo' : opt.color = "sky"; break;
			  }
			  var block = GOrg.addBlock(data['dtfrom'], data['dtto'], data['name'], opt);
			  block.data = data;
			  if((data['archive'] == "todo") || (data['archive'] == "appointments"))
		   	  {
			   var sh2 = new GShell();
			   sh2.block = block;
			   sh2.OnError = function(err){alert(err);}
			   sh2.OnOutput = function(o,a){
					 switch(a['status'])
					 {
					  case '2' : this.block.setColor("blue"); break;
					  case '3' : this.block.setColor("orange"); break;
					  case '4' : this.block.setColor("red"); break;
					  case '5' : this.block.setColor("green"); break;
					  default : this.block.setColor("sky"); break;
					 }
					}

			   sh2.sendCommand("dynarc item-info -ap `"+data['archive']+"` -id "+data['item_id']+" -get status");
		      }
			 }
			}
		 sh.sendCommand("cron list -from "+from.printf('Y-m-d H:i')+" -to "+to.printf('Y-m-d H:i')+" -ap '"+AP+"'");
		 return true;
		}

 GOrg.reload();

 /* CALENDAR */
 Calendar = new GCalendar();
 Calendar.OnChange = function(datestr){
	 Template.setVar("date",datestr);
	 Template.reload();
	}

 /* SEARCH */
 this.initEd(document.getElementById("search"), "contactextended").OnSearch = function(){
	 if(this.value && this.data)
	 {
	  Template.setVar("view","list");
	  Template.setVar("subjid",this.data['id']);
	  Template.setVar("search",this.value);
	  Template.reload();
	 }
	}

 if(document.getElementById("archive"))
 {
  this.initEd(document.getElementById("archive"), "dropdown").onselect = function(){
	 Template.setVar("ap",this.getValue());
	 Template.reload(0);
	}
 }
}

function setView(value)
{
 Template.unsetVar("date");
 Template.setVar("view",value);
 Template.reload(0);
}

</script>
<?php

$template->End();

?>


