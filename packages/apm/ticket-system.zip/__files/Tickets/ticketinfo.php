<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2017 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 28-01-2017
 #PACKAGE: ticket-system
 #DESCRIPTION: Official Gnujiko Ticket System
 #VERSION: 2.15beta
 #CHANGELOG: 28-01-2017 : Aggiunto colonne sn,marca e colore su Lista servizi/manodopera/materiali. 
			 12-11-2016 : Aggiunto campo telefono e priorita.
			 11-09-2016 : Bug fix salvataggio indirizzo - aggiunto parametro bypassupdatecontact.
			 14-06-2016 : Bug fix su funzione sendMail (aggiunto --use-cache-contents).
			 12-05-2015 : Bug fix genera preventivo e fattura da ticket e aggiunto bottone genera preventivo su chiusura semplice..
			 27-04-2015 : Bug fix vari.
			 15-12-2014 : Bug fix su funzione saveHardwareInfo.
			 10-11-2014 : Aggiunto campo note.
			 01-11-2014 : Bug fix indirizzi.
			 27-10-2014 : Bug fix su chiusura ticket non fatturati, ed invio email da ticket.
			 18-10-2014 : Agiunto ticket file.
			 10-10-2014 : Aggiornato indirizzo.
			 08-10-2014 : Aggiornamenti vari.
			 07-10-2014 : Aggiornato sistema di determinazione data chiusura ticket.
			 06-10-2014 : Aggiornamenti vari.
 #TODO: se il plugin ticket-custhw-plugin non è installato deve lanciare subito callback sulla funzione saveHardwareInfo.
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_COMPANY_PROFILE, $docInfo, $_AP, $_HWAP, $_HWINFO, $_OSINFO;

$_BASE_PATH = "../";
$_AP = "tickets";
$_HWAP = "tktcusthw";

include($_BASE_PATH."var/templates/glight/index.php");
include_once($_BASE_PATH."include/userfunc.php");

$template = new GLightTemplate();
$template->includeCSS("ticketinfo.css");
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeObject("gmutable");
$template->includeObject("fckeditor");
$template->includeInternalObject("serp");
$template->includeInternalObject("contactsearch");
$template->includeInternalObject("productsearch");
$template->includeInternalObject("servicesearch");
$template->includeInternalObject("addresssearch");
$template->includeInternalObject("attachments");

include_once($_BASE_PATH."include/company-profile.php");
include_once($_BASE_PATH."include/countries.php");
include_once($_BASE_PATH."etc/commercialdocs/config.php");

$_DECIMALS = $_COMPANY_PROFILE['accounting']['decimals_pricing'];
$ret = GShell("pricelists list");
$_PRICELISTS = $ret['outarr'];
$_PRICELIST_BY_ID = array();
for($c=0; $c < count($_PRICELISTS); $c++)
 $_PRICELIST_BY_ID[$_PRICELISTS[$c]['id']] = $_PRICELISTS[$c];


/* GET LIST OF VAT RATES */
$ret = GShell("dynarc item-list -ap vatrates -get `percentage,vat_type`");
$_VAT_LIST = $ret['outarr']['items'];
$_VAT_BY_ID = array();
for($c=0; $c < count($_VAT_LIST); $c++)
 $_VAT_BY_ID[$_VAT_LIST[$c]['id']] = $_VAT_LIST[$c];

$_DEF_VAT = 0;
$_DEF_VAT_ID = $_COMPANY_PROFILE['accounting']['freq_vat_used'];
$_DEF_VAT_TYPE = "";
$_EVENT_ID = 0;
$_CUST_PLID = 0;

$_HWINFO = null;
$_OSINFO = null;
$_LABOR_ID = 0;

$_SUBJ_AVAIL_HOURS = 0;

/* TICKET INFO */
$docInfo = array();
$ret = GShell("dynarc item-info -ap ".$_AP." -id '".$_REQUEST['id']."' -extget `ticketinfo,cdelements,cronevents,interventions`");
if(!$ret['error'])
{
 $docInfo = $ret['outarr'];
 if($docInfo['subject_id'])
 {
  // get customer pricelist id and assist_avail_hours
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT pricelist_id,assist_avail_hours FROM dynarc_rubrica_items WHERE id='".$docInfo['subject_id']."'");
  $db->Read();
  $_CUST_PLID = $db->record['pricelist_id'];
  $_SUBJ_AVAIL_HOURS = $db->record['assist_avail_hours'];
  $db->Close();
 }
 if(count($docInfo['cronevents']))
  $_EVENT_ID = $docInfo['cronevents'][0]['id'];
 /* get labor id */
 if(count($docInfo['elements']))
 {
  for($c=0; $c < count($docInfo['elements']); $c++)
  {
   $el = $docInfo['elements'][$c];
   if($el['type'] == 'labor')
	$_LABOR_ID = $el['id'];
  }
 }

 if($docInfo['hw_id'])
 {
  /* get hardware info */
  $ret = GShell("dynarc item-info -ap '".$_HWAP."' -id '".$docInfo['hw_id']."' -extget oslist");
  if(!$ret['error'])
  {
   $_HWINFO = $ret['outarr'];
   if($_HWINFO['oslist'] && count($_HWINFO['oslist']))
	$_OSINFO = $_HWINFO['oslist'][0];
  }
 }
}

/* GET CONFIG */
$config = array();
$ret = GShell("aboutconfig get-config -app tickets");
if(!$ret['error'])
 $config = $ret['outarr']['config'];

$_LABOR_VAT_ID = $config['options']['laborvatid'] ? $config['options']['laborvatid'] : $_DEF_VAT_ID;
$_LABOR_VAT = $_VAT_BY_ID[$_LABOR_VAT_ID]['percentage'];
$_LABOR_VAT_TYPE = $_VAT_BY_ID[$_LABOR_VAT_ID]['vat_type'];

/* TITLE */
$_REF_SCHEMA = "Ticket n.{NUM} del {DATE}";
$_REF_KEYS = array('{NUM}','{DATE}','{TIME}','{TKTREF}','{TYPE}','{CUSTOMER}','{FULLADDRESS}','{ZONE}','{CLOSEDATE}','{CLOSETIME}'
	,'{OPERATOR}','{TECH1}','{TECH2}','{TAXDELIVERY}','{ADDR_CODE}','{ADDR_TITLE}','{ADDR_ADDRESS}','{ADDR_CITY}','{ADDR_ZIP}'
	,'{ADDR_PROV}','{ADDR_CC}','{ADDR_NOTE}');

if($config['interface']['tickettitleschema'])
  $_REF_SCHEMA = $config['interface']['tickettitleschema'];

$_REF_VALUES = array(
	 $docInfo['code_num'],
	 date('d/m/Y',$docInfo['ctime']),
	 date('H:i',$docInfo['ctime']),
	 $docInfo['ext_ticket_ref'],
	 $docInfo['type_name'],
	 $docInfo['subject_name'],
	 $docInfo['address'],
	 $docInfo['zone'],
	 $docInfo['finish_datetime'] ? date('d/m/Y',strtotime($docInfo['finish_datetime'])) : "",
	 $docInfo['finish_datetime'] ? date('H:i',strtotime($docInfo['finish_datetime'])) : "",
	 $docInfo['operator_name'],
	 $docInfo['tech_1_name'],
	 $docInfo['tech_2_name'],
	 $docInfo['tax_delivery'] ? date('d/m/Y',strtotime($docInfo['tax_delivery'])) : "",
	 $docInfo['addr_code'],
	 $docInfo['addr_title'],
	 $docInfo['addr_address'],
	 $docInfo['addr_city'],
	 $docInfo['addr_zipcode'],
	 $docInfo['addr_province'],
	 $docInfo['addr_cc'],
	 $docInfo['addr_note']
	);
$title = str_replace($_REF_KEYS, $_REF_VALUES, $_REF_SCHEMA);

/* PDF FILENAME */
$_PDF_SCHEMA = "Ticket-{NUM}";
if($config['options']['pdffileschema'])
 $_PDF_SCHEMA = $config['options']['pdffileschema'];
$_PDF_FILENAME = str_replace($_REF_KEYS, $_REF_VALUES, $_PDF_SCHEMA);
$_PDF_FILENAME = str_replace("/","-",$_PDF_FILENAME);

/* ADDRESS */
$_ADDRESS_SCHEMA = "{ADDRESS} - {CITY} ({PROV})";
$_ADDRESS_KEYS = array('{CODE}','{TITLE}','{ADDRESS}','{CITY}','{ZIP}','{PROV}','{CC}','{NOTE}');
if($config['interface']['ticketaddressschema'])
 $_ADDRESS_SCHEMA = $config['interface']['ticketaddressschema'];
$_ADDRESS_VALUES = array(
	 $docInfo['addr_code'],
	 $docInfo['addr_title'],
	 $docInfo['addr_address'],
	 $docInfo['addr_city'],
	 $docInfo['addr_zipcode'],
	 $docInfo['addr_province'],
	 $docInfo['addr_cc'],
	 $docInfo['addr_note']
	);
$address = str_replace($_ADDRESS_KEYS, $_ADDRESS_VALUES, $_ADDRESS_SCHEMA);
$docInfo['address'] = $address;

/* GET CUSTOMER DEFAULT CONTACT INFO */
$docInfo['default_contact_info'] = array();
if($docInfo['subject_id'])
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT name,address,city,zipcode,province,phone,phone2,fax,cell,email,email2,email3 FROM dynarc_rubrica_contacts WHERE item_id='"
	.$docInfo['subject_id']."' ORDER BY isdefault DESC LIMIT 1");
 if($db->Read())
 {
  $docInfo['default_contact_info'] = array('name'=>$db->record['name'], 'address'=>$db->record['address'], 'city'=>$db->record['city'],
	'zipcode'=>$db->record['zipcode'], 'province'=>$db->record['province'], 
	'phone'=>$db->record['phone'], 'phone2'=>$db->record['phone2'], 'fax'=>$db->record['fax'], 'cell'=>$db->record['cell'], 
	'email'=>$db->record['email'], 'email2'=>$db->record['email2'], 'email3'=>$db->record['email3']);
 }
 $db->Close();
}


/* INTERFACE */
$_HIDE_INTERVLIST = $config['interface']['hideintervlist'] ? true : false;
$_HIDE_ITEMLIST = $config['interface']['hideitemlist'] ? true : false;


/* CAMPI */
$_SECTION_FIELDS = array(
	'large' => array(
		0=>'customer',
		1=>'type',
	 ),

	'small' => array(
		0=>'ticketnum',
		1=>'ctime',

	 ),

	'medium' => array(
		0=>'extticketref',
		1=>'taxdelivery',

	 )
);

if(!$config['interface']['hidefieldaddress'])				$_SECTION_FIELDS['large'][] = 'address';
if(!$config['interface']['hidefieldphone'])					$_SECTION_FIELDS['large'][] = 'phone';
if(!$config['interface']['hidefieldappointment'])			$_SECTION_FIELDS['small'][] = 'appointment';
if(!$config['interface']['hidefieldoperator'])				$_SECTION_FIELDS['medium'][] = 'operator';
if(!$config['interface']['hidefieldpriority'])				$_SECTION_FIELDS['small'][] = 'priority';

if(!$config['interface']['hidefieldzone'])					$_SECTION_FIELDS['large'][] = 'zone';
if($config['interface']['showfieldhardware'])				$_SECTION_FIELDS['small'][] = 'hardware';
if($config['interface']['showfieldshelf'])					$_SECTION_FIELDS['medium'][] = 'shelf';

if(!$config['interface']['hidefieldnote'])					$_SECTION_FIELDS['large'][] = 'note';
if($config['interface']['showfieldos'])						$_SECTION_FIELDS['small'][] = 'os';
/* TODO: riattivare se necessario
if($config['interface']['showfielddisksize'])				$_SECTION_FIELDS['medium'][] = 'disksize';*/
if(!$config['interface']['hidefieldtktreffile'])			$_SECTION_FIELDS['medium'][] = 'tktreffile';

if($config['interface']['showfieldrequest'])				$_SECTION_FIELDS['large'][] = 'request';
if($config['interface']['showfielduser1'])					$_SECTION_FIELDS['small'][] = 'user';
if($config['interface']['showfieldpasswd1'])				$_SECTION_FIELDS['medium'][] = 'password';
if($config['interface']['showfielduser2'])					$_SECTION_FIELDS['small'][] = 'user2';
if($config['interface']['showfieldpasswd2'])				$_SECTION_FIELDS['medium'][] = 'password2';
if($config['interface']['showfielduser3'])					$_SECTION_FIELDS['small'][] = 'user3';
if($config['interface']['showfieldpasswd3'])				$_SECTION_FIELDS['medium'][] = 'password3';

if($config['interface']['showfielddatatosave'])				$_SECTION_FIELDS['large'][] = 'datatosave';
if($config['interface']['showfieldadmin'])					$_SECTION_FIELDS['small'][] = 'admin';
if($config['interface']['showfieldadminpasswd'])			$_SECTION_FIELDS['medium'][] = 'adminpassword';


if($config['interface']['showfieldaccessories'])			$_SECTION_FIELDS['large'][] = 'accessories';

$_SECTION_FIELDS['medium'][] = 'finishtime';

$template->Begin($title);

/* HEADER ---------------------------------------------------------------------------------------------------------- */
?>
<div class='docstyle-header'>
<table width='100%' cellspacing='0' cellpadding='0' border='0' class='docstyle'>
<tr><td class='docstyle-icon' rowspan='2'><img src='img/doc-icon.png'/></td>
	<td class='docstyle-title'><i><?php echo $docInfo['name']; ?></i></td>
	<td rowspan='2' align='right' width='220'>
	 <label style='color:#333'>PRIORITA&lsquo;: </label>
		<?php
		$options = $template->config['ticketpriority'];
		?>
		<input type='text' class='dropdown' id='priority' style='width:120px' connect='prioritylist' value="<?php echo $options[$docInfo['priority']]['name']; ?>" retval="<?php echo $docInfo['priority']; ?>">
		 <ul class='popupmenu' id='prioritylist'>
		  <?php
			while(list($k,$v)=each($options))
			 echo "<li value='".$k."'>".$v['name']."</li>";
		  ?>
		 </ul>
	</td>
	<td rowspan='2' align='right' width='270'>
		<label style='color:#333'>STATUS: </label>
		<?php
		$options = $template->config['ticketstatus'];
		?>
		<input type='text' class='dropdown' id='status' style='width:180px' connect='statuslist' value="<?php echo $options[$docInfo['status']]['name']; ?>" retval="<?php echo $docInfo['status']; ?>">
		 <ul class='popupmenu' id='statuslist'>
		  <?php
			while(list($k,$v)=each($options))
			 echo "<li value='".$k."'>".$v['name']."</li>";
		  ?>
		 </ul>
	</td>
	<td rowspan='2' align='right' width='300' style='padding-right:20px'>
		<input type='button' class='button-blue' value='Stampa' onclick="Print()"/>
		<?php
		if($docInfo['closed'])
		 echo "<input type='button' class='button-unlock' value='Sblocca' onclick='UnlockTicket()' id='unlock-btn'/>";
		?>
		<input type='button' class='button-blue' value="Salva e chiudi" onclick="Submit()" id='save-btn' <?php if($docInfo['closed']) echo "style='display:none'"; ?>/>
		<input type='button' class='button-exit' value="Esci" onclick='Template.Exit()'/></td></tr>
<tr><td class='docstyle-menu'><?php
 if($docInfo['ext_ticket_ref'])
  echo "Rif: <b>".$docInfo['ext_ticket_ref']."</b><br/>";
 echo "Data apertura: <b>".date('d/m/Y H:i',$docInfo['ctime'])."</b>";
?></td></tr>
</table>
</div>
<?php


$template->Body("monosection", 1000);
?>
<div class='docstyle-page' style='width:980px;'>
 <div class='docstyle-body'>
	<!-- APERTURA -->
	<fieldset>
	 <legend>Apertura</legend>
	 <table width='100%' cellspacing='0' cellpadding='0' border='0'>
	 <tr><td valign='top' width='450'>
	 <!-- LEFT SECTION -->
	 <?php
	 for($c=0; $c < count($_SECTION_FIELDS['large']); $c++)
	  insertField($_SECTION_FIELDS['large'][$c]);
	 ?>
	 </td><td valign='top' width='200'>
	 <!-- CENTER SECTION -->
	 <?php
	 for($c=0; $c < count($_SECTION_FIELDS['small']); $c++)
	  insertField($_SECTION_FIELDS['small'][$c]);
	 ?>
	 </td><td valign='top'>
	 <!-- RIGHT SECTION -->
	 <?php
	 for($c=0; $c < count($_SECTION_FIELDS['medium']); $c++)
	  insertField($_SECTION_FIELDS['medium'][$c]);
	 ?>
	 </td></tr>
	 </table>
	 <!-- EOF - BLOCK FIELDS -->
	</fieldset>
	<!-- OEF - APERTURA -->
	<br/>
	<!-- ---------------------------------------------------------------------------------------------------------- -->
	<!-- DETTAGLI INTERVENTO E ALLEGATI-->
	<fieldset>
	 <legend>Descrizione dettagliata</legend>
	 <table cellspacing='0' cellpadding='0' border='0'>
	 <tr><td width='700' valign='top'><textarea style="width:700px;height:<?php echo $config['interface']['ticketdesceditorheight'] ? $config['interface']['ticketdesceditorheight'] : '200'; ?>px" id="description"><?php echo $docInfo['desc']; ?></textarea></td>
		 <td width='20'>&nbsp;</td>
		 <td width='200' valign='top'>
			<div style='background:#d8d8d8;color:#ffffff;padding:3px;font-family:arial,sans-serif;font-size:12px'><b>ALLEGATI<b></div>
			<?php
			 $Attachments = new GLAttachments($_AP, $docInfo['id']);
			 $Attachments->height = "120px";
			 $docInfo['attachments'] = $Attachments->Items;
			 echo "<div class='attachments-container' id='attachments' style='height:"
				.($config['interface']['ticketdesceditorheight'] ? $config['interface']['ticketdesceditorheight']-80 : '120')."px;margin-bottom:10px'>";
			 $Attachments->Paint();
			 echo "</div>";
		 ?>
		 <input type='button' class='button-blue' value="Carica un allegato" id="attachbtn" refap="<?php echo $_AP; ?>" refid="<?php echo $docInfo['id']; ?>" destpath="Tickets/attachments/ticket-<?php echo $docInfo['code_num'].'-'.date('Y',$docInfo['ctime']).'/'; ?>" connect='attachments' style='width:200px;text-align:center'/>
		 </td>
	 </tr>
	 </table>
	</fieldset>
	<br/>
	<!-- ---------------------------------------------------------------------------------------------------------- -->
	<!-- MONTE ORE -->
	<br/>
	<fieldset id='availhours-fieldset' <?php if(!$_SUBJ_AVAIL_HOURS) echo "style='display:none'"; ?>><legend>Monte ore</legend>
	 Ore di assistenza disponibili per questo cliente: <b id='subject-avail-hours'><?php echo $_SUBJ_AVAIL_HOURS; ?></b>
	</fieldset>
	<br/>
	<!-- ---------------------------------------------------------------------------------------------------------- -->
	<?php
	if(!$_HIDE_INTERVLIST)
	{
	 ?>
	<br/>
	<fieldset><legend><?php echo $config['interface']['intervlisttitle'] ? $config['interface']['intervlisttitle'] : "Interventi effettuati"; ?></legend>
	 <!-- LISTA INTERVENTI -->
	 <div class="gmutable" style="width:920px;height:<?php echo $config['interface']['intervlistheight'] ? $config['interface']['intervlistheight'] : '150'; ?>px">
	 <table id="intervlist" class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
	 <tr>
	 <?php
	 $_INTERV_COLUMNS = array(
		"date"=>array("title"=>"Data", "default"=>true, "width"=>80, "format"=>"date", 'editable'=>true),
		"title"=>array("title"=>"Descrizione", "default"=>true, "minwidth"=>250, 'editable'=>true),
		"description"=> array('title'=>"Dettagli", 'editable'=>true, 'hidden'=>true),
		"operator"=>array("title"=>"Tecnico", "default"=>true, "width"=>150, 'editable'=>true),
	 	"hours"=> array('title'=>"Ore ord.", 'width'=>60, 'format'=>'time', 'hidden'=>true, 'editable'=>true),
	 	"extrahours"=> array('title'=>"Ore straord.", 'width'=>60, 'format'=>'time', 'hidden'=>true, 'editable'=>true),
		"tothours"=>array("title"=>"TOT. ORE", "default"=>true, "width"=>60, "format"=>"time"),
	 	"starttime"=> array('title'=>'Ora inizio', 'width'=>60, 'hidden'=>true, 'format'=>'time', 'editable'=>true),
		"endtime"=> array('title'=>'Ora fine', 'width'=>60, 'format'=>'time', 'hidden'=>true, 'editable'=>true),
		"starttime2"=> array('title'=>'Ora inizio 2', 'width'=>60, 'format'=>'time', 'hidden'=>true, 'editable'=>true),
		"endtime2"=> array('title'=>'Ora fine 2', 'width'=>60, 'format'=>'time', 'hidden'=>true, 'editable'=>true),
		"totamount"=>array("title"=>"TOT. IMPORTI", "default"=>true, "width"=>80, "format"=>"currency", 'editable'=>true)
	 );
	 $_COLUMNS = array();
	 if(is_array($config['intervcolumns']) && count($config['intervcolumns']))
	 {
	  for($c=0; $c < count($config['intervcolumns']); $c++)
	  {
	   $col = $config['intervcolumns'][$c];
	   $_COLUMNS[$col['tag']] = $_INTERV_COLUMNS[$col['tag']];
	   $_COLUMNS[$col['tag']]['title'] = $col['title'];
	   $_COLUMNS[$col['tag']]['width'] = $col['width'];
	   $_COLUMNS[$col['tag']]['hidden'] = false;
	  }
	  reset($_INTERV_COLUMNS);
	  while(list($k,$v) = each($_INTERV_COLUMNS))
	  {
	   if($_COLUMNS[$k]) continue;
	   $_COLUMNS[$k] = $v;
	   $_COLUMNS[$k]['hidden'] = true;
	  }
	  $_INTERV_COLUMNS = $_COLUMNS;
	 }
	 else
	  $_COLUMNS = $_INTERV_COLUMNS;

	 reset($_COLUMNS);
	 while(list($k,$v) = each($_COLUMNS))
	 {
	  echo "<th id='".$k."'";
	  if($v['width']) echo " width='".$v['width']."'";
	  if($v['sortable']) echo " sortable='true'";
	  if($v['editable']) echo " editable='true'";
	  if($v['minwidth']) echo " minwidth='".$v['minwidth']."'";
	  if($v['format']) echo " format='".$v['format']."'";
	  if($v['decimals']) echo " decimals='".$v['decimals']."'";
	  if($v['hidden'])
	   echo " style='display:none;".$v['style']."'";
	  else if($v['style'])
	   echo " style='".$v['style']."'";
	  echo ">".strtoupper($v['title'])."</th>";
	 }

	 ?>
	 <th style='width:22px' id='btninfo'>&nbsp;</th>
	 <th style='width:22px' id='btndel'>&nbsp;</th>
	 </tr>
	 <?php
	 $_TOTALS = 0;
	 $_TOT_HOURS = "0:00";
	 $_TOT_MINUTES = 0;
	 $_TOT_AMOUNT = 0;
	 for($c=0; $c < count($docInfo['interventions']); $c++)
	 {
 	  $itm = $docInfo['interventions'][$c];
	  echo "<tr id='interv-".$itm['id']."' operatorid='".$itm['operator_id']."'>";
	  reset($_COLUMNS);
	  while(list($k,$v)=each($_COLUMNS))
	  {
	   switch($k)
	   {
		case 'date' : echo "<td><span class='graybold'>".date('d/m/Y',strtotime($itm['date']))."</span></td>"; break;
		case 'title' : echo "<td><span class='graybold'>".$itm['name']."</span></td>"; break;
		case 'description' : echo "<td><span class='graybold doubleline'>".$itm['desc']."</td>"; break;
		case 'operator' : echo "<td><span class='graybold'>".$itm['operator_name']."</span></td>"; break;
	  	case 'hours' : echo "<td><span class='graybold'>".$itm['tot_hours']."</span></td>"; break;
	  	case 'extrahours' : echo "<td><span class='graybold'>".$itm['tot_extra_hours']."</span></td>"; break;
		case 'tothours' : echo "<td><span class='graybold'>".$itm['subtot_hours']."</span></td>"; break;
	    case 'starttime' : echo "<td><span class='graybold'>".$itm['start_time']."</span></td>"; break;
	    case 'endtime' : echo "<td><span class='graybold'>".$itm['end_time']."</span></td>"; break;
	    case 'starttime2' : echo "<td><span class='graybold'>".$itm['start_time2']."</span></td>"; break;
	    case 'endtime2' : echo "<td><span class='graybold'>".$itm['end_time2']."</span></td>"; break;
		case 'totamount' : echo "<td><span class='eurogreen'>".number_format($itm['tot_amount'],2,',','.')."</span></td>"; break;
	   }
	  }
	  echo "<td align='center'><img src='".$_ABSOLUTE_URL."share/icons/16x16/information.gif' onclick='EditIntervention(this.parentNode.parentNode,"
			.$itm['id'].")' style='cursor:pointer' title='Mostra dettagli intervento'/></td>";
	  echo "<td align='center'><img src='".$_ABSOLUTE_URL."Tickets/img/delete-black.png' onclick='DeleteIntervention(this.parentNode.parentNode,".$itm['id'].")' style='cursor:pointer' title='Elimina'/></td></tr>";
 	  $_TOT_MINUTES+= $itm['tot_minutes'];
 	  $_TOT_AMOUNT+= $itm['tot_amount'];
	 }
	 if($_TOT_MINUTES)
	 {
 	  $hh = floor($_TOT_MINUTES/60);
 	  $mm = $_TOT_MINUTES-($hh*60);
 	  $_TOT_HOURS = $hh.":".($mm<10 ? "0".$mm : $mm);
	 }
	 ?>
	 </table>
	 </div>
	 <div class='section-footer'>
	 <table width='100%' cellspacing='0' cellpadding='0' border='0'>
	 <tr><td rowspan='2'><input type='button' class='button-blue' value="Nuovo intervento" onclick="NewIntervention()"/></td>
		 <td width='100' align='center'><span class='tinytext'><b>TOT ORE</b></span></td>
		 <td width='100' align='center'><span class='tinytext'><b>TOT IMPORTI</b></span></td></tr>
	 <tr><td align='center'><span class='bigtext'><b id="interv-tothours"><?php echo $_TOT_HOURS; ?></b></span></td>
	 	 <td align='right'><span class='bigtext'><b id="interv-totamount"><?php echo number_format($_TOT_AMOUNT,2,',','.'); ?> &euro;</b></span></td></tr>
	 </table>
	 </div>
	<!-- EOF - LISTA INTERVENTI -->
	</fieldset>
	<!-- OEF - AVANZAMENTO -->
	<br/>
	<?php
	}
	?>
	<!-- ---------------------------------------------------------------------------------------------------------- -->
	<?php
	if(!$_HIDE_ITEMLIST)
	{
	 ?>
	<br/>
	<!-- SERVIZI MANODOPERA E MATERIALI -->
	<fieldset>
	 <legend><?php echo $config['interface']['itemlisttitle'] ? $config['interface']['itemlisttitle'] : "Servizi, manodopera e materiali"; ?></legend>
	 <?php
	 $_FILTERS = array("gmart"=>"articolo", "gserv"=>"servizio");
	 $_FILTER = "gmart";

	 ?>
	 <input type='button' class='button-blue' value="Aggiungi riga" onclick="InsertCustomRow()"/> 
	 <input type='button' class='button-blue' value="Aggiungi nota" onclick="InsertCustomRow('note')"/>
	 &nbsp;&nbsp;&nbsp;&nbsp;<span class='mediumtext'> oppure: </span>
	 <input type='text' class='search' style='width:240px' placeholder="Inserisci un articolo" id='prod-search' value="" emptyonclick='true'/>
	 <input type='text' class='search' style='width:240px' placeholder="Inserisci un servizio" id='serv-search' value="" emptyonclick='true'/>
	 <br/>
	 <?php
	 $_ITEMS_COLUMNS = array(
		"code"=>array("title"=>"Codice", "default"=>true, "width"=>60, "sortable"=>true, "editable"=>true),
		"sn"=>array("title"=>"S.N.", "width"=>100, "sortable"=>true, "editable"=>true),
		"brand"=>array("title"=>"Marca", "default"=>false, "width"=>100, "sortable"=>true, "editable"=>true),
		"description"=>array("title"=>"Articolo / Descrizione", "default"=>true, "minwidth"=>250, "sortable"=>true, "editable"=>true),
		"qty"=>array("title"=>"Qta", "default"=>true, "width"=>40, "editable"=>true, "style"=>"text-align:center"),
		"units"=>array("title"=>"U.M.", "default"=>true, "width"=>40, "editable"=>true, "style"=>"text-align:center"),
		"coltint"=>array("title"=>"Colore/Tinta", "width"=>100, "editable"=>true, "format"=>"dropdown", "style"=>"text-align:center"),
		"sizmis"=>array("title"=>"Taglia/Misura", "width"=>100, "editable"=>true, "format"=>"dropdown", "style"=>"text-align:center"),
		"unitprice"=>array("title"=>"Pr. Unit", "default"=>true, "width"=>60, "editable"=>true, "format"=>"currency", "decimals"=>$_DECIMALS),
		"discount"=>array("title"=>"Sconto", "default"=>true, "width"=>60, "editable"=>true, "format"=>"currency percentage", "decimals"=>$_DECIMALS),
		"vat"=>array("title"=>"I.V.A.", "default"=>true, "width"=>40, "editable"=>true, "format"=>"percentage", "style"=>"text-align:left"),
		"price"=>array("title"=>"Totale", "default"=>true, "width"=>120, "minwidth"=>100, "style"=>"text-align:center", "editable"=>true, "format"=>"currency", "decimals"=>$_DECIMALS),
		"vatprice"=>array("title"=>"Tot. + IVA", "width"=>120, "minwidth"=>100, "style"=>"text-align:center", "editable"=>true, "format"=>"currency", "decimals"=>$_DECIMALS),
		);

	 $_COLUMNS = array();
	 if(is_array($config['itemscolumns']) && count($config['itemscolumns']))
	 {
	  for($c=0; $c < count($config['itemscolumns']); $c++)
	  {
	   $col = $config['itemscolumns'][$c];
	   $_COLUMNS[$col['tag']] = $_ITEMS_COLUMNS[$col['tag']];
	   $_COLUMNS[$col['tag']]['title'] = $col['title'];
	   $_COLUMNS[$col['tag']]['width'] = $col['width'];
	   $_COLUMNS[$col['tag']]['hidden'] = false;
	  }
	  reset($_ITEMS_COLUMNS);
	  while(list($k,$v) = each($_ITEMS_COLUMNS))
	  {
	   if($_COLUMNS[$k]) continue;
	   $_COLUMNS[$k] = $v;
	   $_COLUMNS[$k]['hidden'] = true;
	  }
	  $_ITEMS_COLUMNS = $_COLUMNS;
	 }
	 else
	  $_COLUMNS = $_ITEMS_COLUMNS;
	 ?>
	 <div class="gmutable" style="height:<?php echo $config['interface']['itemlistheight'] ? $config['interface']['itemlistheight'] : '150'; ?>px;margin-top:16px;width:920px">
	 <table id='doctable' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
	 <tr>
	 <?php
	 reset($_COLUMNS);
	 while(list($k,$v) = each($_COLUMNS))
	 {
	  echo "<th id='".$k."'";
	  if($v['width']) echo " width='".$v['width']."'";
	  if($v['sortable']) echo " sortable='true'";
	  if($v['editable']) echo " editable='true'";
	  if($v['minwidth']) echo " minwidth='".$v['minwidth']."'";
	  if($v['format']) echo " format='".$v['format']."'";
	  if($v['decimals']) echo " decimals='".$v['decimals']."'";
	  if($v['hidden'])
	   echo " style='display:none;".$v['style']."'";
	  else if($v['style'])
	   echo " style='".$v['style']."'";
	  echo ">".strtoupper($v['title'])."</th>";
	 }

	 ?>
	 <th style='width:22px' id='btndel'>&nbsp;</th>
	 </tr>
	 <?php
	 $_TOTALS = 0;
 	 for($c=0; $c < count($docInfo['elements']); $c++)
	 {
	  $itm = $docInfo['elements'][$c];
	  echo "<tr id='".$itm['id']."' type='".$itm['type']."' refap='".$itm['ref_ap']."' refid='".$itm['ref_id']."' vatid='".$itm['vatid']."' vattype='"
		.$itm['vattype']."'>";
	  if(strtolower($itm['type']) == "note")
	   echo "<td colspan='9'><span class='graybold'>".$itm['desc']."</span></td><td><img src='".$_ABSOLUTE_URL."share/icons/32x32/edit-delete.png' width='22' onclick='DeleteRow(this.parentNode.parentNode)' style='cursor:pointer' title='Elimina'/></td>";
	  else
	  {
	   $qty = $itm['qty'];

	   $discount = $itm['discount_inc'] ? $itm['discount_inc'] : 0;
	   $discount2 = 0;
	   $discount3 = 0;

	   if($itm['discount_perc'])
	    $discount = $itm['price'] ? ($itm['price']/100)*$itm['discount_perc'] : 0;

	   $amount = round(((($itm['price']-$discount)-$discount2)-$discount3) * $qty, $_DECIMALS);
	   $total = $amount;

	   reset($_COLUMNS);
	   while(list($k,$v) = each($_COLUMNS))
	   {
		switch($k)
		{
		 case 'code' : echo "<td><span class='graybold'>".$itm['code']."</span></td>"; break;
		 case 'sn' : case 'serialnumber' : echo "<td><span class='graybold'>".$itm['serialnumber']."</span></td>"; break;
		 case 'lot' : echo "<td><span class='graybold'>".$itm['lot']."</span></td>"; break;
		 case 'brand' : echo "<td refid='".$itm['brand_id']."'><span class='graybold'>".$itm['brand_name']."</span></td>"; break; 
		 case 'description' : echo "<td><span class='graybold doubleline'>".$itm['name']."</span></td>"; break;
		 case 'qty' : echo "<td><span class='graybold 13 center'>".$itm['qty']."</span></td>"; break;
		 case 'units' : echo "<td><span class='graybold 13 center'>".$itm['units']."</span></td>"; break;
		 case 'coltint' : echo "<td><span class='graybold center'>".$itm['variant_coltint']."</span></td>"; break;
		 case 'sizmis' : echo "<td><span class='graybold center'>".$itm['variant_sizmis']."</span></td>"; break;
		 case 'unitprice' : echo "<td realvalue='".$itm['price']."'><span class='graybold' title='Valore reale: "
			.number_format($itm['price'],4,',','.')."'>".number_format($itm['price'],$_DECIMALS,',','.')."</span></td>"; break;
		 case 'plbaseprice' : echo "<td realvalue='".$itm['listbaseprice']."'><span class='graybold' title='Valore reale: "
			.number_format($itm['listbaseprice'],4,',','.')."'>".number_format($itm['listbaseprice'],$_DECIMALS,',','.')."</span></td>"; break;
		 case 'plmrate' : echo "<td><span class='graybold'>".$itm['listmrate']."%</span></td>"; break;
		 case 'pldiscperc' : echo "<td><span class='graybold'>".$itm['listdiscperc']."%</span></td>"; break;

		 case 'discount' : {
		     if($itm['discount_perc'])
		      echo "<td realvalue='".$itm['discount_perc']."%'><span class='graybold'>".$itm['discount_perc']."%</span></td>";
		     else if($itm['discount_inc'])
		      echo "<td realvalue='".$itm['discount_inc']."'><span class='graybold'>&euro;. ".number_format($itm['discount_inc'],$_DECIMALS,',','.')."</span></td>";
		     else
		      echo "<td><span class='graybold'>&nbsp;</span></td>";
			} break;
		 case 'discount2' : echo "<td><span class='graybold'>".($itm['discount2'] ? $itm['discount2'] : "0")."%</span></td>"; break;
		 case 'discount3' : echo "<td><span class='graybold'>".($itm['discount3'] ? $itm['discount3'] : "0")."%</span></td>"; break;
		 case 'vat' : echo "<td><span class='graybold center'>".$itm['vatrate']."%</span></td>"; break;
		 case 'price' : echo "<td realvalue='".$amount."'><span class='eurogreen' title='Valore reale: "
			.number_format($amount,4,',','.')."'><em>&euro;</em>".number_format($amount,$_DECIMALS,',','.')."</span></td>"; break;
		 case 'vatprice' : echo "<td realvalue='".($amount+$itm['vat'])."'><span class='eurogreen' title='Valore reale: ".number_format($amount+$itm['vat'],4,',','.')."'><em>&euro;</em>".number_format($amount+$itm['vat'],$_DECIMALS,',','.')."</span></td>"; break;
		 case 'pricelist' : echo "<td pricelistid='".$itm['pricelist_id']."'><span class='graybold'>".($itm['pricelist_id'] ? $_PRICELIST_BY_ID[$itm['pricelist_id']]['name'] : $_PLINFO['name'])."</span></td>"; break;
		 default : echo "<td><span class='graybold'>".$itm[$k]."</span></td>"; break;
		} // eof- switch
	   } // eof - while
	   echo "<td><img src='".$_ABSOLUTE_URL."Tickets/img/delete-black.png' width='22' onclick='DeleteRow(this.parentNode.parentNode)' style='cursor:pointer' title='Elimina'/></td>";
	  } // eof - else
	  $_TOTALS+= ($amount+$itm['vat']);
	  echo "</tr>";
	 } // eof - for
	 ?>
	 </table>
	 </div>
	 <table width='100%' class="glight-standard-table" width="100%" cellspacing="0" cellpadding="0" border="0">
	 <tr><th style="text-align:left">&nbsp;Totale</th>
		 <th id="footer-total" style="text-align:right;width:120px"><?php echo number_format($docInfo['total'],2,",","."); ?></th>
		 <th width='32'>&nbsp;</th></tr>
	 </table>	

	</fieldset>
	<!-- OEF - SERVIZI MANODOPERA E MATERIALI -->
	<br/>
	<?php
	}
	?>
	<!-- ---------------------------------------------------------------------------------------------------------- -->
	<br/>
	<!-- CHIUSURA AVANZATA-->
	<fieldset <?php if($config['closure']['modal'] == "simply") echo "style='display:none'"; ?>><legend>Chiusura</legend>
	 <table width='100%' cellspacing='0' cellpadding='0' border='0'>
	  <tr><td valign='top' width='160'><label>Modalit&agrave; di chiusura</label><br/><?php 
			$options = array(""=>"", "invoice"=>"Fattura", "receipt"=>"Scontrino");
			?>
		   <input type='text' readonly='true' class='dropdown' id='closure-modal' connect='closure-modal-list' style='width:130px' value="<?php echo $options[$docInfo['closure_modal']]; ?>" retval="<?php echo $docInfo['closure_modal']; ?>">
			<ul class='popupmenu' id='closure-modal-list'>
			<?php
			while(list($k,$v)=each($options))
			 echo "<li value='".$k."'>".$v."</li>";
			?>
		   </ul></td>

		   <td valign='top' width='300'><label>Modalit&agrave; di pagamento</label><br/><?php
			$options = array(""=>"", "other"=>"Altro", "bancomat"=>"Bancomat", "transfer"=>"Bonifico", "creditcard"=>"Carta di credito", "cash"=>"Contanti");
			?>
		   <input type='text' readonly='true' class='dropdown' id='payment-mode' connect='payment-mode-list' style='width:290px' value="<?php echo $options[$docInfo['payment_mode']]; ?>" retval="<?php echo $docInfo['payment_mode']; ?>">
			<ul class='popupmenu' id='payment-mode-list'>
			<?php		
			while(list($k,$v)=each($options))
			 echo "<li value='".$k."'>".$v."</li>";
			?>
		   </ul>
		  </td>

		  <td valign='top' rowspan='3' width='200' style="padding-left:30px">
		 	 <span class='smalltext' style='color:#777'><i>Preventivo di riferimento</i></span>
			 <div class="docref">
			 <?php
			  if($docInfo['preemptive_id'])
			  {
			   $ret = GShell("dynarc item-list -ap printmodels -ct preemptives -get thumbdata -limit 1");
			   $printModelInfo = $ret['outarr']['items'][0];
			   echo "<a href='".$_ABSOLUTE_URL."GCommercialDocs/docinfo.php?id=".$docInfo['preemptive_id']."' target='GCD-".$docInfo['preemptive_id']."'>";
			   if(strpos($printModelInfo['thumbdata'],"data:") !== false)
			    echo "<img src='".$printModelInfo['thumbdata']."' style='width:120px;margin-top:5px;border:0px'/>";
			   else
				echo "<img src='".$_ABSOLUTE_URL.$printModelInfo['thumbdata']."' style='width:120px;margin-top:5px;border:0'/>";
			   echo "</a>";
			  }
			  else
			   echo "<br/><br/><br/><small>nessun preventivo associato</small>"; 
			 ?>
			 </div>
			 <?php
			  if($docInfo['preemptive_id'])
			   echo "<input type='button' class='button-blue' style='width:150px;text-align:center' value='Visualizza' onclick='OpenDocument(".$docInfo['preemptive_id'].")'/>";
			  else
			   echo "<input type='button' class='button-blue' style='width:150px;text-align:center' value='Genera preventivo &raquo;' onclick='GeneratePreemptive(true)'/>";
			 ?>
		</td>
		<td valign='top' rowspan='3'>
		 	 <span class='smalltext' style='color:#777'><i>Fattura di riferimento</i></span>
			 <div class="docref">
			 <?php
			  if($docInfo['invoice_id'])
			  {
			   $ret = GShell("dynarc item-list -ap printmodels -ct invoices -get thumbdata -limit 1");
			   $printModelInfo = $ret['outarr']['items'][0];
			   echo "<a href='".$_ABSOLUTE_URL."GCommercialDocs/docinfo.php?id=".$docInfo['invoice_id']."' target='GCD-".$docInfo['invoice_id']."'>";
			   if(strpos($printModelInfo['thumbdata'],"data:") !== false)
			    echo "<img src='".$printModelInfo['thumbdata']."' style='width:120px;margin-top:5px;border:0px'/>";
			   else
				echo "<img src='".$_ABSOLUTE_URL.$printModelInfo['thumbdata']."' style='width:120px;margin-top:5px;border:0'/>";
			   echo "</a>";
			  }
			  else
			   echo "<br/><br/><br/><small>nessuna fattura associata</small>"; 
			 ?>
			 </div>
			 <?php
			  if($docInfo['invoice_id'])
			   echo "<input type='button' class='button-blue' style='width:150px;text-align:center' value='Visualizza' onclick='OpenDocument(".$docInfo['invoice_id'].")'/>";
			  else
			   echo "<input type='button' class='button-blue' style='width:150px;text-align:center' value='Genera fattura &raquo;' onclick='GenerateInvoice(true)'/>";
			 ?>
		</td>
	  </tr>
	  <tr><td colspan='2'>&nbsp;</td></tr>

	  <tr><td colspan='2'><label>Note di chisura</label><br/>
		   <textarea class='textarea' style='width:100%;height:100px' id='closurenote'><?php echo $docInfo['closure_note']; ?></textarea>	 
		  </td></tr>
	 </table>
	</fieldset>
	<!-- OEF - CHIUSURA -->
	<!-- CHIUSURA SEMPLICE -->
	<fieldset <?php if($config['closure']['modal'] != "simply") echo "style='display:none'"; ?>><legend>Chiusura</legend>
	 <?php
	 if($docInfo['closed'])
	  echo "<span class='mediumtext'>Questo ticket risulta gi&agrave; chiuso:</span> <input type='button' class='button-gray' value='Riapri ticket' onclick='ReOpenTicket()'/>";
	 else
	 {
	  ?>
	  <input type='button' class='button-blue' value="Chiuso da fatturare" onclick="CloseTicket(100)"/>
	  <input type='button' class='button-blue' value="Chiuso non fatturabile" onclick="CloseTicket(96)"/>
	  <input type='checkbox' class='checkbox' id='closeandsendmail'/> <span class='smalltext'>Invia ticket al cliente.</span>
	  <?php
	  if($docInfo['preemptive_id'])
	   echo "<input type='button' class='button-blue' style='float:right' value='Mostra preventivo' onclick='OpenDocument(".$docInfo['preemptive_id'].")'/>";
	  else
	   echo "<input type='button' class='button-blue' style='float:right' value='Genera preventivo &raquo;' onclick='GeneratePreemptive(true)'/>";
	 }
	 ?>
	</fieldset>
	<!-- EOF - CHIUSURA SEMPLICE -->
 </div>
 <div class='docstyle-footer' style='text-align:left'>
  <?php
  if($docInfo['closed'])
   echo "<input type='button' class='button-unlock' value='Sblocca' onclick='UnlockTicket()' id='unlock-btn2'/>";
  ?>
  <input type='button' class='button-blue' value='Salva' onclick="Submit()" id='save-btn2' <?php if($docInfo['closed']) echo "style='display:none'"; ?>/>
  <input type='button' class='button-exit' value='Esci' onclick="Template.Exit()"/>
  <input type='button' class='button-red' value='Elimina' onclick="DeleteTicket()" style="float:right"/>
 </div>
</div>
<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
/*-------------------------------------------------------------------------------------------------------------------*/
function insertField($field)
{
 global $docInfo, $template, $_BASE_PATH, $_ABSOLUTE_URL, $_AP, $_HWAP, $_HWINFO, $_OSINFO;

 switch($field)
 {
  case 'customer' : { ?><div class='blockfield-double'><label>Cliente</label><br/>
		<input type='text' class='contact' id='subject' placeholder="Digita il nome del cliente" modal='extended' fields='code_str,name' contactfields='phone,phone2,cell,email' ct='customers' style='width:400px' value="<?php echo $docInfo['subject_name']; ?>" refid="<?php echo $docInfo['subject_id']; ?>" tabindex="1"/></div> <?php } break;

  case 'type' : { ?><div class='blockfield-double'><label>Tipologia</label><br/>
		  <input type="text" class="dropdown" id="ticket-type" value="<?php echo $docInfo['type_name']; ?>" style="width:400px" readonly="true" connect="ticket-type-list" retval="<?php echo $docInfo['type']; ?>" tabindex="4"/>
		  <ul class='popupmenu' id='ticket-type-list'>			
			<li value='0'>&nbsp;</li>
			<?php
			 $ret = GShell("dynarc item-list -ap tickettypes");
			 $list = $ret['outarr']['items'];
			 for($c=0; $c < count($list); $c++)
			  echo "<li value='".$list[$c]['id']."'>".$list[$c]['name']."</li>";
			?>
		  </ul>
	  </div>
	<?php } break;

  case 'address' : { ?><div class='blockfield-double'><label>Indirizzo</label><br/>
		  <input type='text' class='search' id='address' value="<?php echo $docInfo['address']; ?>" refid="<?php echo $docInfo['contact_id']; ?>" subjid="<?php echo $docInfo['subject_id']; ?>" style="width:400px" tabindex="7"/>
		  <?php
		   if($docInfo['contact_id'])
			echo "<img id='addressbtn' src='".$_ABSOLUTE_URL."share/icons/16x16/pencil.gif' title='Modifica dettagli indirizzo' style='cursor:pointer' onclick='EditAddress()'/>";
		   else
			echo "<img id='addressbtn' src='".$_ABSOLUTE_URL."Tickets/img/add.png' title='Aggiungi un nuovo indirizzo' style='cursor:pointer' onclick='NewAddress()'/>";
		  ?>
	  </div>
	<?php } break;

  case 'phone' : { 
		 $phone = $docInfo['phone'];
		 if(!$phone)
		 {
		  if($docInfo['default_contact_info']['phone'])			$phone = $docInfo['default_contact_info']['phone'];
		  else if($docInfo['default_contact_info']['phone2'])	$phone = $docInfo['default_contact_info']['phone2'];
		  else if($docInfo['default_contact_info']['cell'])		$phone = $docInfo['default_contact_info']['cell'];
		 }
		?><div class='blockfield-double'><label>Telefono</label><br/>
		  <input type="text" class="edit" id="ticket-phone" value="<?php echo $phone; ?>" style="width:400px" tabindex="10"/>
	  </div>
	<?php } break;

  case 'zone' : { ?><div class='blockfield-double'><label>Zona</label><br/>
		  <input type="text" class="search" id="ticket-zone" value="<?php echo $docInfo['zone']; ?>" ap='ticketzones' limit='20' refid="<?php echo $docInfo['zone_id']; ?>" style="width:400px" tabindex="10"/>
	  </div>
	<?php } break;

  case 'note' : { ?><div class='blockfield-double'><label>Note</label><br/>
		<input type='text' class='edit' id='ticket-notes' value="<?php echo $docInfo['note']; ?>" style="width:400px" tabindex="13"/>
	  </div>
	<?php } break;

  case 'request' : { ?><div class='blockfield-double'><label>Richiesta</label><br/>
		<textarea class='textarea' style='width:400px;height:100px' id='request' tabindex="16"><?php echo $docInfo['request']; ?></textarea>
	  </div><?php } break; 
  case 'datatosave' : { ?><div class='blockfield-double'><label>Dati da salvare</label><br/>
		<textarea class='textarea' style='width:400px;height:100px' id='datatosave' tabindex="25"><?php echo $docInfo['datatosave']; ?></textarea>
	  </div><?php } break; 
  case 'accessories' : { ?><div class='blockfield-double'><label>Accessori ritirati</label><br/>
		<textarea class='textarea' style='width:400px;height:100px' id='accessories' tabindex="26"><?php echo $docInfo['accessories']; ?></textarea>
	  </div><?php } break; 

  case 'ticketnum' : {?><div class='blockfield-single'><label>N. Ticket</label><br/>
		  <input type='text' class='edit' id='code_num' style='width:150px' readonly="true" value="<?php echo $docInfo['code_num']; ?>" tabindex="2"/>
	  </div>
	<?php } break;

  case 'ctime' : {?><div class='blockfield-single'><label>Data e ora apertura</label><br/>
		  <input type='text' class='calendar' id='ctime' value="<?php echo date('d/m/Y H:i',$docInfo['ctime']); ?>" placeholder="gg/mm/aaaa hh:mm" style='width:140px' tabindex="5"/>
	  </div>
	<?php } break;

  case 'appointment' : {?><div class='blockfield-single'><label>Appuntamento</label><br/>
		  <input type='text' class='calendar' id='apptime' value="<?php echo $docInfo['app_datetime'] ? date('d/m/Y H:i',strtotime($docInfo['app_datetime'])) : ''; ?>" placeholder='gg/mm/aaaa hh:mm' style='width:140px' tabindex="8"/>
	  </div>
	<?php } break;

  case 'hardware' : { ?><div class='blockfield-single'><label>Hardware</label><br/>
		  <input type='text' class='dropdown' readonly='true' style='width:140px' id='hardware' value="<?php echo $docInfo['hw_name']; ?>" retval="<?php echo $docInfo['hw_id']; ?>" connect="hardware-list" tabindex="11"/> 
		  <img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/information.gif" title="Clicca per vedere/modificare le informazioni di questo hardware" onclick="editHardware()" id='hardware-info-button' style="cursor:pointer;<?php if(!$docInfo['hw_id']) echo 'visibility:hidden'; ?>"/>
		<ul class='popupmenu' id='hardware-list'>
		   <li value='0'>&nbsp;</li>
		   <?php
			$ret = GShell("dynarc item-list -ap `".$_HWAP."` -where `subject_id='".$docInfo['subject_id']."'`");
			$list = $ret['outarr']['items'];
			for($c=0; $c < count($list); $c++)
			 echo "<li value='".$list[$c]['id']."'>".$list[$c]['name']."</li>";
			?>
			<li class='separator' id='hardware-list-separator'>&nbsp;</li>
			<li><span class='linkblue' onclick="addNewHardware()">aggiungi nuovo hardware</span></li>
		</ul>
	</div><?php } break; 

  case 'os' : { ?><div class='blockfield-single'><label>Sistema Operativo</label><br/>
		  <input type='text' class='dropdown' readonly='true' style='width:140px' id='os' value="<?php echo $_OSINFO ? $_OSINFO['name'] : ''; ?>" retval="<?php echo $_OSINFO ? $_OSINFO['id'] : 0; ?>" connect='os-list' tabindex="14"/>
		<ul class='popupmenu' id='os-list'>
		   <li value='0'>&nbsp;</li>
		   <?php
			$ret = GShell("dynarc item-list -ap tktoslist");
			$list = $ret['outarr']['items'];
			for($c=0; $c < count($list); $c++)
			 echo "<li value='".$list[$c]['name']."'>".$list[$c]['name']."</li>";
			?>
			<li class='separator' id='os-list-separator'>&nbsp;</li>
			<li><span class='linkblue' onclick="addNewOS()">aggiungi nuovo s.o.</span></li>
		</ul>
	</div><?php } break; 

  case 'user' : { ?><div class='blockfield-single'><label>Utente</label><br/>
		  <input type='text' class='edit' style='width:140px' id='user' value="<?php echo $_OSINFO ? $_OSINFO['user1'] : ''; ?>" tabindex="18"/>
	</div><?php } break; 

  case 'user2' : { ?><div class='blockfield-single'><label>Utente 2</label><br/>
		  <input type='text' class='edit' style='width:140px' id='user2' value="<?php echo $_OSINFO ? $_OSINFO['user2'] : ''; ?>" tabindex="20"/>
	</div><?php } break; 

  case 'user3' : { ?><div class='blockfield-single'><label>Utente 3</label><br/>
		  <input type='text' class='edit' style='width:140px' id='user3' value="<?php echo $_OSINFO ? $_OSINFO['user3'] : ''; ?>" tabindex="22"/>
	</div><?php } break; 

  case 'admin' : { ?><div class='blockfield-single'><label>Amministratore</label><br/>
		  <input type='text' class='edit' style='width:140px' id='admin' value="<?php echo $_OSINFO ? $_OSINFO['rootuser'] : ''; ?>" tabindex="24"/>
	</div><?php } break; 

  case 'finishtime' : {?><div class='blockfield-single'><?php
			if($docInfo['closed'])
			{
			 ?>
			 <label>Data chiusura</label><br/>
		  	 <input type='text' class='calendar' id='finish_datetime' value="<?php echo $docInfo['finish_datetime'] ? date('d/m/Y H:i',strtotime($docInfo['finish_datetime'])) : ''; ?>" style="width:140px" tabindex="28"/>
			 <?php
			}
			else
			 echo "&nbsp;";
			?>
	  </div>
	<?php } break;

  case 'extticketref' : { ?><div class='blockfield-single'><label>Rif. ticket esterno</label><br/>
		  <input type='text' class='edit' id='ext-ticket-ref' style='width:180px' value="<?php echo $docInfo['ext_ticket_ref']; ?>" onchange="checkTicketRef(this)" tabindex="3"/>
	  </div>
	<?php } break;

  case 'taxdelivery' : { ?><div class='blockfield-single'><label>Data e ora scadenza</label><br/>
		  <input type='text' class='calendar' id='taxdelivery' value="<?php if($docInfo['tax_delivery']) echo date('d/m/Y H:i',strtotime($docInfo['tax_delivery'])); ?>" placeholder="gg/mm/aaaa hh:mm" style='width:140px'  tabindex="6"/>
		  <a href='#' style='font-size:12px' title="Imposta la scadenza a domani" onclick="setTaxDelivery(1)"><img src="img/next-orange.png"/></a>
	  </div>
	<?php } break;

  case 'operator' : { ?><div class='blockfield-single'><label>Operatore</label><br/>
		  <input type='text' class='dropdown' id='operator' value="<?php echo $docInfo['operator_name']; ?>" placeholder="Seleziona un operatore" style='width:200px' readonly='true' connect="operators" retval="<?php echo $docInfo['operator_id']; ?>" tabindex="9"/>
			<ul class='popupmenu' id='operators'>
			 <?php
			 $operators = _getGroupUserList(_getGID("tickets"));
			 for($c=0; $c < count($operators); $c++)
			  echo "<li value='".$operators[$c]['id']."'>".($operators[$c]['fullname'] ? $operators[$c]['fullname'] : $operators[$c]['name'])."</li>";
			 ?>
			</ul>
	  </div>
	<?php } break;

  case 'shelf' : { ?><div class='blockfield-single'><label>Scaffale</label><br/>
		  <input type='text' class='edit' style='width:200px' id='shelf' value="<?php echo $docInfo['shelf']; ?>" tabindex="12"/>
	</div><?php } break;

  /* TODO: riattivare e completare se necessario
  case 'disksize' : { ?><div class='blockfield-single'><label>Dimensioni disco</label><br/>
		  <input type='text' class='dropdown' readonly='true' style='width:200px' id='hdd' connect='hdd-list' value="<?php echo $docInfo['pc_hdd']; ?>" tabindex="15"/>
		<ul class='popupmenu' id='hdd-list'>
		   <li value='0'>&nbsp;</li>
		   <?php
			$ret = GShell("dynarc item-list -ap tkthddlist");
			$list = $ret['outarr']['items'];
			for($c=0; $c < count($list); $c++)
			 echo "<li value='".$list[$c]['name']."'>".$list[$c]['name']."</li>";
			?>
			<li class='separator' id='hdd-list-separator'>&nbsp;</li>
			<li><span class='linkblue' onclick="addNewHDD()">aggiungi nuovo hdd</span></li>
		</ul>
	</div><?php } break; */

  case 'password' : { ?><div class='blockfield-single'><label>Password</label><br/>
		  <input type='text' class='edit' style='width:200px' id='password' value="<?php echo $_OSINFO ? $_OSINFO['passwd1'] : ''; ?>" tabindex="19"/>
	</div><?php } break; 

  case 'password2' : { ?><div class='blockfield-single'><label>Password 2</label><br/>
		  <input type='text' class='edit' style='width:200px' id='password2' value="<?php echo $_OSINFO ? $_OSINFO['passwd2'] : ''; ?>" tabindex="21"/>
	</div><?php } break; 

  case 'password3' : { ?><div class='blockfield-single'><label>Password 3</label><br/>
		  <input type='text' class='edit' style='width:200px' id='password3' value="<?php echo $_OSINFO ? $_OSINFO['passwd3'] : ''; ?>" tabindex="23"/>
	</div><?php } break; 

  case 'adminpassword' : { ?><div class='blockfield-single'><label>Password amministratore</label><br/>
		  <input type='text' class='edit' style='width:200px' id='adminpassword' value="<?php echo $_OSINFO ? $_OSINFO['rootpasswd'] : ''; ?>" tabindex="24"/>
	</div><?php } break; 

  case 'tktreffile' : { 
		?><div class='blockfield-single' style="width:230px"><label>File ticket di riferimento</label><br/>
		  <input type='text' class='fileupload' id='tktreffile' style='width:200px' value="<?php echo basename($docInfo['ticket_ref_file']); ?>" filename="<?php echo $docInfo['ticket_ref_file']; ?>" readonly="true" tabindex="15" destpath="Tickets/files/ticket-<?php echo $docInfo['code_num'].'-'.date('Y',$docInfo['ctime']).'/'; ?>"/>
		  <img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/delete.gif" id='tktreffiledelbtn' style="cursor:pointer;<?php if(!$docInfo['ticket_ref_file']) echo 'visibility:hidden'; ?>" title="Rimuovi allegato" onclick="deleteTktRefFile()"/>
	  </div>
	<?php } break;
 }
}
/*-------------------------------------------------------------------------------------------------------------------*/
?>
<script>
var AP = "<?php echo $_AP; ?>";
var HWAP = "<?php echo $_HWAP; ?>";
var OSID = "<?php echo $_OSINFO ? $_OSINFO['id'] : '0'; ?>";
var TICKET_ID = "<?php echo $docInfo['id']; ?>";
var ON_PRINTING = false;
var ON_EXPORT = false;
var TB = null;
var TBINTERV = null;
var CUST_PLID = "<?php echo $_CUST_PLID; ?>";
var DECIMALS = <?php echo $_DECIMALS ? $_DECIMALS : "2"; ?>;
var PLID = <?php echo $_PLID ? $_PLID : "0"; ?>;
var CUSTPLID = PLID;
var DEF_VAT = <?php echo $_DEF_VAT ? $_DEF_VAT : '0'; ?>;
var DEF_VAT_ID = <?php echo $_DEF_VAT_ID ? $_DEF_VAT_ID : '0'; ?>;
var DEF_VAT_TYPE = "<?php echo $_DEF_VAT_TYPE; ?>";

var LABOR_ID = <?php echo $_LABOR_ID ? $_LABOR_ID : '0'; ?>;
var LABOR_VAT = <?php echo $_LABOR_VAT ? $_LABOR_VAT : '0'; ?>;
var LABOR_VAT_ID = <?php echo $_LABOR_VAT_ID ? $_LABOR_VAT_ID : '0'; ?>;
var LABOR_VAT_TYPE = "<?php echo $_LABOR_VAT_TYPE; ?>";

var NEW_ROWS = new Array();
var UPDATED_ROWS = new Array();
var DELETED_ROWS = new Array();

var NEW_HISTORY = new Array();
var UPDATED_HISTORY = new Array();
var DELETED_HISTORY = new Array();

var TOT_AMOUNT = "<?php echo $docInfo['amount']; ?>";
var TOT_VAT = "<?php echo $docInfo['vat']; ?>";
var TOT_TOTAL = "<?php echo $docInfo['total']; ?>";

var PREEMPTIVE_ID = <?php echo $docInfo['preemptive_id'] ? $docInfo['preemptive_id'] : '0'; ?>;
var INVOICE_ID = <?php echo $docInfo['invoice_id'] ? $docInfo['invoice_id'] : '0'; ?>;
var GENERATE_PREEMPTIVE = false;

var EVENT_ID = <?php echo $_EVENT_ID; ?>;

var AUTOINSLABOR = <?php echo $config['options']['autoinslabor'] ? 'true' : 'false'; ?>;
var FINISHDATEMODAL = "<?php echo $config['closure']['finishdatemodal'] ? $config['closure']['finishdatemodal'] : 'auto'; ?>";

var PDF_FILENAME = "<?php echo $_PDF_FILENAME; ?>";
var ATTACH_PDF = <?php echo $config['sendmail']['attachpdf'] ? 'true' : 'false'; ?>;

var HIDE_INTERVLIST = <?php echo $_HIDE_INTERVLIST ? 'true' : 'false'; ?>;
var HIDE_ITEMLIST = <?php echo $_HIDE_ITEMLIST ? 'true' : 'false'; ?>;

var SUBJECT_AVAIL_HOURS = <?php echo $_SUBJ_AVAIL_HOURS ? $_SUBJ_AVAIL_HOURS : '0'; ?>;

var FINAL_CALLBACK = null;

Template.OnExit = function(){
	if(window.opener)
	{
	 window.opener.document.location.reload();
	 window.close();
	}
	else
	 document.location.href = ABSOLUTE_URL+"Tickets/index.php";
	return false;
}

Template.OnInit = function(){
 this.initEd(document.getElementById("subject"), "contactextended").OnSearch = function(){
	 // aggiorna monte ore
	 SUBJECT_AVAIL_HOURS = this.data['assist_avail_hours'];
	 document.getElementById("subject-avail-hours").innerHTML = SUBJECT_AVAIL_HOURS;
	 if(SUBJECT_AVAIL_HOURS > 0)
	  document.getElementById('availhours-fieldset').style.display = "";
	 else
	  document.getElementById('availhours-fieldset').style.display = "none";

	 updateContactList();
	 updateHardwareList();
	};

 if(document.getElementById('hardware'))
 {
  this.initEd(document.getElementById('hardware'), "dropdown").onchange = function(){
	 if(this.getValue() && !isNaN(this.getValue()) && (this.getValue()!="") && (this.getValue()!="0"))
	 {
	  var sh = new GShell();
	  sh.OnError = function(err){alert(err);}
	  sh.OnOutput = function(o,a){
		 if(!a || !a['oslist'] || !a['oslist'].length)
		 {
		  /* RESET */
		  OSID = 0;
		  if(document.getElementById("os")) 					document.getElementById("os").setValue("",0);
		  if(document.getElementById("user"))					document.getElementById("user").value="";
		  if(document.getElementById("user2"))					document.getElementById("user2").value="";
		  if(document.getElementById("user3"))					document.getElementById("user3").value="";
		  if(document.getElementById("admin"))					document.getElementById("admin").value="";
		  if(document.getElementById("password"))				document.getElementById("password").value="";
		  if(document.getElementById("password2"))				document.getElementById("password2").value="";
		  if(document.getElementById("password3"))				document.getElementById("password3").value="";
		  if(document.getElementById("adminpassword"))			document.getElementById("adminpassword").value="";	  
		 }
		 else
		 {
		  var os = a['oslist'][0];
		  OSID = os['id'];
		  if(document.getElementById("os"))						document.getElementById("os").setValue(os['name'],os['id']);
		  if(document.getElementById("user"))					document.getElementById("user").value=os['user1'];
		  if(document.getElementById("user2"))					document.getElementById("user2").value=os['user2'];
		  if(document.getElementById("user3"))					document.getElementById("user3").value=os['user3'];
		  if(document.getElementById("admin"))					document.getElementById("admin").value=os['rootuser'];
		  if(document.getElementById("password"))				document.getElementById("password").value=os['passwd1'];
		  if(document.getElementById("password2"))				document.getElementById("password2").value=os['passwd2'];
		  if(document.getElementById("password3"))				document.getElementById("password3").value=os['passwd3'];
		  if(document.getElementById("adminpassword"))			document.getElementById("adminpassword").value=os['rootpasswd'];	  		  
		 }
		}
	  sh.sendCommand("dynarc item-info -ap `"+HWAP+"` -id `"+this.getValue()+"` -extget oslist");
	  document.getElementById('hardware-info-button').style.visibility = "visible";
	 }
	 else
	  document.getElementById('hardware-info-button').style.visibility = "hidden";
	};
 }
 if(document.getElementById('os')) 			this.initEd(document.getElementById('os'), "dropdown").onchange = function(){};
 if(document.getElementById('hdd')) 		this.initEd(document.getElementById('hdd'), "dropdown").onchange = function(){};

 if(document.getElementById('operator')) 	this.initEd(document.getElementById('operator'), "dropdown").onchange = function(){};
 if(document.getElementById('priority')) 	this.initEd(document.getElementById('priority'), "dropdown").onchange = function(){};
 this.initEd(document.getElementById('status'), "dropdown").onchange = function(){};
 this.initEd(document.getElementById("ctime"), "date");
 if(document.getElementById("taxdelivery")) this.initEd(document.getElementById("taxdelivery"), "date");
 if(document.getElementById("apptime")) 	this.initEd(document.getElementById("apptime"), "date");
 this.initEd(document.getElementById("closure-modal"), "dropdown");
 this.initEd(document.getElementById("payment-mode"), "dropdown");
 this.initEd(document.getElementById("description"), "fckeditor", "Default");
 this.initBtn(document.getElementById("attachbtn"), "attachupld").OnUpload = function(){};
 if(document.getElementById("tktreffile"))
 {
  this.initEd(document.getElementById("tktreffile"), "fileupload").OnUpload = function(){
	  document.getElementById('tktreffiledelbtn').style.visibility = "";
	 };
 }

 if(!HIDE_ITEMLIST)
 {
  this.initEd(document.getElementById("prod-search"), "gmart").OnSearch = function(){
	 if(this.value && this.data)
	  InsertRow(this.data['ap'], this.data['id'], "article", this.data);
	};

  this.initEd(document.getElementById("serv-search"), "gserv").OnSearch = function(){
	 if(this.value && this.data)
	  InsertRow(this.data['ap'], this.data['id'], "service", this.data);
	};
 }

 this.initEd(document.getElementById('ticket-type'), "dropdown").onchange = function(){};
 if(document.getElementById('address'))
 {
  this.initEd(document.getElementById('address'), "address", "<?php echo $_ADDRESS_SCHEMA; ?>").OnSearch = function(){
	 if(!this.value || !this.getId())
	 {
	  var img = document.getElementById('addressbtn');
	  img.src = ABSOLUTE_URL+"Tickets/img/add.png";
	  img.title = "Aggiungi un nuovo indirizzo";
	  img.onclick = function(){NewAddress();}
	 }
	 else if(this.data)
	 {
	  var img = document.getElementById('addressbtn');
	  img.src = ABSOLUTE_URL+"share/icons/16x16/pencil.gif";
	  img.title = "Modifica dettagli indirizzo";
	  img.onclick = function(){EditAddress();}
	 }
	};
 }

 if(document.getElementById('ticket-zone')) 			this.initEd(document.getElementById('ticket-zone'), "itemfind");
 if(document.getElementById('finish_datetime'))			this.initEd(document.getElementById("finish_datetime"), "date");

 if(!HIDE_INTERVLIST)
 {
  TBINTERV = new GMUTable(document.getElementById("intervlist"), {autoresize:true, autoaddrows:false});
  TBINTERV.FieldByName['operator'].enableSearch("dynarc item-find -ap rubrica -ct employees -field name `","` -limit 20 --order-by `name ASC`","id","name","items",true);

  TBINTERV.OnBeforeAddRow = function(r){
	   <?php
	   if(!$_HIDE_INTERVLIST)
	   {
	    reset($_INTERV_COLUMNS);
	    $idx = 0;
	    while(list($k,$v) = each($_INTERV_COLUMNS))
	    {
		 switch($k)
		 {
		  case 'description' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold doubleline'></span>\";\n"; break;
		  case 'totamount' : echo "r.cells[".$idx."].innerHTML = \"<span class='eurogreen'></span>\";\n"; break;
		  default : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold'></span>\";\n"; break;
		 }
	     $idx++;
	    }
	    echo "r.cells[".$idx."].style.textAlign='center';\n";
	    echo "r.cells[".($idx+1)."].style.textAlign='center';\n";
	   }
	   ?>
	}

   while(TBINTERV.O.rows.length < 3)
   {
    TBINTERV.AddRow();
   }

   TBINTERV.OnCellEdit = function(r,cell,value,data){
	 var q = "";
	 var id = r.id ? r.id.substr(7) : 0;
	 switch(cell.tag)
	 {
	  case 'date' : 			q+= ",date='"+strdatetime_to_iso(cell.getValue()).substr(0,10)+"'"; break;
	  case 'title' : 			q+= ",name='''"+value+"'''"; break;
	  case 'description' : 		q+= ",desc='''"+value+"'''"; break;
	  case 'hours' : 			{
		 q+= ",tothours='"+cell.getValue()+"'";
		 var h = parse_timelength(value);
		 var t = parse_timelength(r.cell['endtime'].getValue()) - parse_timelength(r.cell['starttime'].getValue());
		 t+= parse_timelength(r.cell['endtime2'].getValue()) - parse_timelength(r.cell['starttime2'].getValue());
		 if(t > 0)
		 {
		  if(h > t)
		  {
		   if(confirm("Il totale ore ordinarie che stai specificando manualmente supera il totale calcolato dai campi 'ora inizio' e 'ora fine'. Desideri continuare? (quindi devo resettare i campi ora inizio e fine perchè non hanno senso)"))
		   {
		    r.cell['starttime'].setValue("");		r.cell['endtime'].setValue("");
		    r.cell['starttime2'].setValue("");	   	r.cell['endtime2'].setValue("");
		    r.cell['extrahours'].setValue("");
			q+= ",starttime='',endtime='',starttime2='',endtime2='',totextrahours=''";
		   }
		  }
		  else
		  {
		   r.cell['extrahours'].setValue(timelength_to_str(t-h));
		   q+= ",totextrahours='"+timelength_to_str(t-h)+"'";
		  }
		 }
		} break;
	  case 'extrahours' : 		{
		 q+= ",totextrahours='"+cell.getValue()+"'"; 
		 var xh = parse_timelength(value);
		 var h = parse_timelength(r.cell['hours'].getValue());
		 var t = parse_timelength(r.cell['endtime'].getValue()) - parse_timelength(r.cell['starttime'].getValue());
		 t+= parse_timelength(r.cell['endtime2'].getValue()) - parse_timelength(r.cell['starttime2'].getValue());
		 if(t)
		 {
		  if(xh > t)
		  {
		   if(confirm("Il totale ore straordinarie che stai specificando manualmente supera il totale calcolato dai campi 'ora inizio' e 'ora fine'. Desideri continuare? (quindi devo resettare i campi ora inizio e fine perchè non hanno senso)"))
		   {
		    r.cell['starttime'].setValue("");		r.cell['endtime'].setValue("");
		    r.cell['starttime2'].setValue("");	   	r.cell['endtime2'].setValue("");
		    r.cell['hours'].setValue("");
			q+= ",starttime='',endtime='',starttime2='',endtime2='',tothours=''";
		   }
		  }
		  else
		  {
		   r.cell['hours'].setValue(timelength_to_str(t-xh));
		   q+= ",tothours='"+timelength_to_str(t-xh)+"'";
		  }
		 }
		} break;
	  case 'starttime' : 		{ 
		 q+= ",starttime='"+cell.getValue()+"'"; 
		 calculateHours(r); 
		 q+= ",tothours='"+r.cell['hours'].getValue()+"',totextrahours='"+r.cell['extrahours'].getValue()+"'";
		} break;
	  case 'endtime' : 			{ 
		 q+= ",endtime='"+cell.getValue()+"'"; 
		 calculateHours(r); 
		 q+= ",tothours='"+r.cell['hours'].getValue()+"',totextrahours='"+r.cell['extrahours'].getValue()+"'";
		} break;
	  case 'starttime2' : 		{ 
		 q+= ",starttime2='"+cell.getValue()+"'"; 
		 calculateHours(r); 
		 q+= ",tothours='"+r.cell['hours'].getValue()+"',totextrahours='"+r.cell['extrahours'].getValue()+"'";
		} break;
	  case 'endtime2' : 		{ 
		 q+= ",endtime2='"+cell.getValue()+"'"; 
		 calculateHours(r); 
		 q+= ",tothours='"+r.cell['hours'].getValue()+"',totextrahours='"+r.cell['extrahours'].getValue()+"'";
		} break;
	  case 'totamount' : 		q+= ",totamount='"+value+"'"; break;
	  case 'operator' : 		{
		 q+= ",opid='"+((value && data) ? data['id'] : 0)+"',opname='''"+value+"'''";
		 r.setAttribute('operatorid',(value && data) ? data['id'] : 0);
		} break;
	 }
	 if(!r.cell['date'].getValue())
	 {
	  var tmpDate = new Date();
	  r.cell['date'].setValue(tmpDate.printf('d/m/Y'));
	  q+= ",date='"+strdatetime_to_iso(r.cell['date'].getValue()).substr(0,10)+"'";
	 }
	 var cmd = "dynarc edit-item -ap '"+AP+"' -id '"+TICKET_ID+"' -extset `interventions."+(id ? "id='"+id+"'"+q : q.substr(1))+"`";
	 var sh = new GShell();
	 sh.OnError = function(err){alert(err);}
	 sh.OnOutput = function(o,a){
		 if(!id)
		 {
		  id = a['last_element']['id'];
		  r.id = "interv-"+id;
	 	  r.cell['btninfo'].innerHTML = "<img src='"+ABSOLUTE_URL+"share/icons/16x16/information.gif' onclick='EditIntervention(this.parentNode.parentNode,"+id+")' title='Mostra dettagli intervento' style='cursor:pointer'/"+">";
	 	  r.cell['btndel'].innerHTML = "<img src='"+ABSOLUTE_URL+"Tickets/img/delete-black.png' onclick='DeleteIntervention(this.parentNode.parentNode,"+id+")' style='cursor:pointer' title='Elimina'/"+">";
		 }
		 r.cell['tothours'].setValue(timelength_to_str(parse_timelength(r.cell['hours'].getValue()) + parse_timelength(r.cell['extrahours'].getValue())));
		 updateIntervTotals();
		}
	 sh.sendCommand(cmd);
	}
  }

 if(!HIDE_ITEMLIST)
 {
  TB = new GMUTable(document.getElementById('doctable'));
  TB.FieldByName['brand'].enableSearch("dynarc item-find -ap brands -ct gmart -field name `","` -limit 20 --order-by `name ASC`", "id","name","items",true);

  TB.OnBeforeAddRow = function(r){
		r.setAttribute('vatid',DEF_VAT_ID);
		r.setAttribute('vattype',DEF_VAT_TYPE);

	   <?php
	   if(!$_HIDE_ITEMLIST)
	   {
	    reset($_ITEMS_COLUMNS);
	    $idx = 0;
	    while(list($k,$v) = each($_ITEMS_COLUMNS))
	    {
		 switch($k)
		 {
		  case 'code' : case 'sn' : case 'serialnumber' : case 'lot' : case 'account' : case 'unitprice' : case 'discount' : case 'discount2' : case 'discount3' : case 'pricelist' : case 'plbaseprice' : case 'plmrate' : case 'pldiscperc' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold'></span>\";\n"; break;
		  case 'description' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold doubleline'></span>\";\n"; break;
		  case 'qty' : case 'units' : case 'weight' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold 13 center'></span>\";\n"; break;
		  case 'vat' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold center'>\"+DEF_VAT+\"%</span>\";\n"; break;
		  case 'price' : case 'vatprice' : echo "r.cells[".$idx."].innerHTML = \"<span class='eurogreen'></span>\";\n"; break;
		  case 'coltint' : case 'sizmis' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold center'></span>\";\n"; break;
		  default : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold'></span>\";\n"; break;
		 }
	     $idx++;
	    }
	   }
	   ?>
	   r.cells["<?php echo $idx; ?>"].innerHTML = "<img src='"+ABSOLUTE_URL+"Tickets/img/delete-black.png' width='22' onclick='DeleteRow(this.parentNode.parentNode)' style='cursor:pointer' title='Elimina'/"+">";

	   NEW_ROWS.push(r);
	};

  TB.OnSelectRow = function(r){};
  TB.OnUnselectRow = function(r){};
  TB.OnDeleteRow = function(r){
	 if(r.id)
	  DELETED_ROWS.push(r);
	};
  TB.OnBeforeCellEdit = function(r,cell,value){
	 switch(cell.tag)
	 {
	  case 'coltint' : case 'sizmis' : {
		 var subjectId = document.getElementById("subject").getId();
		 var refAP = r.getAttribute('refap');
		 var refID = r.getAttribute('refid');
		 var refVendorID = r.getAttribute('vendorid');
		 if(!r.itemInfo && refAP && refID)
		 {
		  var oThis = this;
		  var sh = new GShell();
		  sh.OnOutput = function(o,a){
		  	// variants //
			r.itemInfo = a;
		  	if(a && a['variants'])
		  	{
		  	 // colori e tinte //
		  	 var options = new Array();
		  	 if(a['variants']['colors'])
		  	 {
			  var arr = new Array();
			  for(var c=0; c < a['variants']['colors'].length; c++)
			   arr.push(a['variants']['colors'][c]['name']);
			  options.push(arr);
		  	 }
		   	 if(a['variants']['tint'])
		   	 {
			  var arr = new Array();
			  for(var c=0; c < a['variants']['tint'].length; c++)
			   arr.push(a['variants']['tint'][c]['name']);
			  options.push(arr);
		   	 }
		   	 r.cell['coltint'].setOptions(options);

		   	 // taglie, misure e altro //
		   	 var options = new Array();
		   	 if(a['variants']['sizes'])
		   	 {
			  var arr = new Array();
			  for(var c=0; c < a['variants']['sizes'].length; c++)
			   arr.push(a['variants']['sizes'][c]['name']);
			  options.push(arr);
		   	 }
		   	 if(a['variants']['dim'])
		   	 {
			  var arr = new Array();
			  for(var c=0; c < a['variants']['dim'].length; c++)
			   arr.push(a['variants']['dim'][c]['name']);
			  options.push(arr);
		   	 }
		   	 if(a['variants']['other'])
		   	 {
			  var arr = new Array();
			  for(var c=0; c < a['variants']['other'].length; c++)
			   arr.push(a['variants']['other'][c]['name']);
			  options.push(arr);
		   	 }
		   	 r.cell['sizmis'].setOptions(options);
		  	}

			// show popup menu
			oThis.editCell(cell);
		   }

		  sh.sendCommand("commercialdocs getfullinfo -ap `"+refAP+"` -id `"+refID+"` -subjectid `"+subjectId+"` -pricelistid `"+CUSTPLID+"` -vendorid '"+refVendorID+"' --get-variants -qty '"+r.cell['qty'].getValue()+"'");
		 }
		} break;
	 } // EOF SWITCH

	};

  TB.OnCellEdit = function(r,cell,value,data){
	 switch(cell.tag)
	 {
	  case 'qty' : updateTotals(r); break;
	  case 'unitprice' : {
		 r.unitpriceChanged=true;
		 cell.getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(parseCurrency(value),4);
		 updateTotals(r); 
		} break;

	  case 'discount' : {
		 if(value.indexOf("%") < 0)
		 {
		  value = value.replace(/\u20ac/g, "");
		  value = value.replace(". ","");
		  cell.getElementsByTagName('SPAN')[0].innerHTML = "&euro;. "+formatCurrency(parseCurrency(value),DECIMALS);
		 }
		 r.discountChanged=true;
		 updateTotals(r);
		} break;

	  case 'discount2' : {
		 r.discountChanged=true;
		 updateTotals(r);
		} break;

	  case 'discount3' : {
		 r.discountChanged=true;
		 updateTotals(r);
		} break;

	  case 'vat' : {
		 if(data)
		 {
		  r.setAttribute('vatid',data['id']);
		  r.setAttribute('vattype',data['vat_type']);
		  updateTotals(r);
		 }
		 else
		 {
		  var sh = new GShell();
		  sh.OnOutput = function(o,a){
			 if(!a)
			 {
		  	  r.setAttribute('vatid',0);
		  	  r.setAttribute('vattype',"");
			  updateTotals(r);
			  return;
			 }
			 r.setAttribute('vatid',a['items'][0]['id']);
			 r.setAttribute('vattype',a['items'][0]['vat_type']);
			 r.cell['vat'].setValue(a['items'][0]['percentage']);
			 updateTotals(r);
			}
		  sh.sendCommand("dynarc search -ap `vatrates` -fields code_str,name `"+value+"` -limit 1 --order-by `code_str ASC` -get percentage,vat_type");
		 }
		} break;

	  case 'price' : {
		 var unitPrice = 0;
		 var qty = parseFloat(r.cell['qty'].getValue());
		 if(!qty)
		  alert("Impossibile effettuare il calcolo con quantità a zero"); 
		 var disc1 = r.cell['discount'].getValue();
		 var disc2 = 0; //var disc2 = r.cell['discount2'].getValue();
		 var disc3 = 0; //var disc3 = r.cell['discount3'].getValue();
		 //if(disc2) disc2 = parseFloat(disc2);
		 //if(disc3) disc3 = parseFloat(disc3);

		 var amount = parseCurrency(value);
		 if(amount && qty)
		 {
		  if(disc3)
		   amount = (amount/(100-disc3))*100;
		  if(disc2)
		   amount = (amount/(100-disc2))*100;
		  if(disc1)
		  {
		   if(disc1.indexOf("%") < 0)
		   {
			disc1 = disc1.replace(/\u20ac/g, "");
			disc1 = disc1.replace(". ","");
			disc1 = parseCurrency(disc1);
			amount = amount+disc1;			
		   }
		   else
		   {
			disc1 = parseFloat(disc1);
			amount = (amount/(100-disc1))*100;
		   }
		  }
		  if(amount)
		   unitPrice = amount/qty;
		 }
		 r.cell['unitprice'].setValue(formatCurrency(unitPrice,DECIMALS),unitPrice);
		 if(r.getAttribute('refid'))
		  r.unitpriceChanged=true;
		 r.cell['unitprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(unitPrice,4);
		 cell.getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(unitPrice,4);
		 updateTotals(r); 
		} break;

	  case 'vatprice' : {
		 var unitPrice = 0;
		 var qty = parseFloat(r.cell['qty'].getValue());
		 if(!qty)
		  alert("Impossibile effettuare il calcolo con quantità a zero"); 
		 var vat = parseFloat(r.cell['vat'].getValue());

		 var disc1 = r.cell['discount'].getValue();
		 var disc2 = 0; //var disc2 = r.cell['discount2'].getValue();
		 var disc3 = 0; //var disc3 = r.cell['discount3'].getValue();
		 //if(disc2) disc2 = parseFloat(disc2);
		 //if(disc3) disc3 = parseFloat(disc3);

		 var amount = parseCurrency(value);
		 if(vat)
		  amount = (amount/(100+vat))*100;
		 if(amount && qty)
		 {
		  if(disc3)
		   amount = (amount/(100-disc3))*100;
		  if(disc2)
		   amount = (amount/(100-disc2))*100;
		  if(disc1)
		  {
		   if(disc1.indexOf("%") < 0)
		   {
			disc1 = disc1.replace(/\u20ac/g, "");
			disc1 = disc1.replace(". ","");
			disc1 = parseCurrency(disc1);
			amount = amount+disc1;			
		   }
		   else
		   {
			disc1 = parseFloat(disc1);
			amount = (amount/(100-disc1))*100;
		   }
		  }
		  if(amount)
		   unitPrice = amount/qty;
		 }
		 r.cell['unitprice'].setValue(formatCurrency(unitPrice,DECIMALS),unitPrice);
		 if(r.getAttribute('refid'))
		  r.unitpriceChanged=true;
		 r.cell['unitprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(unitPrice,4);
		 cell.getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(unitPrice,4);
		 updateTotals(r); 
		} break;

	  case 'coltint' : {
		 var sh = new GShell();
		 sh.OnOutput = function(o,a){
			 if(!a)
			 {
			  if(r.itemInfo)
			  {
			   r.cell['code'].setValue(r.itemInfo['code_str']);
			  }
			 }
			 else
			 {
			  if(a['code'])
			   r.cell['code'].setValue(a['code']);
			 }
			 updatePriceByQty(r, r.cell['qty'].getValue());
			}

		 sh.sendCommand("dynarc ext-find -ap '"+r.getAttribute('refap')+"' -itemid '"+r.getAttribute('refid')+"' -ext varcodes -types color,tint -name `"+value+"` -plid '"+CUSTPLID+"'");
		} break;

	  case 'sizmis' : {
		 var sh = new GShell();
		 sh.OnOutput = function(o,a){
			 if(!a)
			 {
			  if(r.itemInfo)
			  {
			   r.cell['code'].setValue(r.itemInfo['code_str']);
			  }
			 }
			 else
			 {
			  if(a['code'])
			   r.cell['code'].setValue(a['code']);
			 }
			 updatePriceByQty(r, r.cell['qty'].getValue());
			}

		 sh.sendCommand("dynarc ext-find -ap '"+r.getAttribute('refap')+"' -itemid '"+r.getAttribute('refid')+"' -ext varcodes -types size,dim,other -name `"+value+"` -plid '"+CUSTPLID+"'");
		} break;

	 } // EOF - SWITCH
	 if(r.id && (UPDATED_ROWS.indexOf(r) < 0))
	  UPDATED_ROWS.push(r);
	};

  TB.OnRowMove = function(r){
	 if(r.id && (UPDATED_ROWS.indexOf(r) < 0)) UPDATED_ROWS.push(r);
	 else if(!r.id && (NEW_ROWS.indexOf(r) < 0)) NEW_ROWS.push(r);
	}
 }
}

function Submit(callback)
{
 if(callback)
  FINAL_CALLBACK = callback;

 var type = document.getElementById("ticket-type").getValue();
 var subjectId = document.getElementById("subject").getId();
 var subjectName = document.getElementById("subject").value;
 var operatorId = (document.getElementById("operator") && document.getElementById("operator").value) ? document.getElementById("operator").getValue() : 0;
 var ctime = document.getElementById("ctime").isodatetime;
 var desc = document.getElementById("description").getValue();
 var extTicketRef = document.getElementById("ext-ticket-ref") ? document.getElementById("ext-ticket-ref").value : "";
 var contactId = document.getElementById('address') ? document.getElementById('address').getValue() : 0;
 var address = document.getElementById('address') ? document.getElementById('address').value.E_QUOT() : "";
 var taxDelivery = document.getElementById("taxdelivery") ? document.getElementById("taxdelivery").isodatetime : "";
 var zone = document.getElementById("ticket-zone") ? document.getElementById("ticket-zone").value.E_QUOT() : "";
 var zoneId = document.getElementById("ticket-zone") ? document.getElementById("ticket-zone").getId() : 0;
 var tktFileName = document.getElementById("tktreffile") ? document.getElementById("tktreffile").getValue() : "";
 var notes = document.getElementById('ticket-notes') ? document.getElementById('ticket-notes').value : "";
 var phone = document.getElementById('ticket-phone') ? document.getElementById('ticket-phone').value : "";

 var hwid = document.getElementById('hardware') ? document.getElementById('hardware').getValue() : 0;
 var hwname = document.getElementById('hardware') ? document.getElementById('hardware').value.E_QUOT() : "";
 var shelf = document.getElementById('shelf') ? document.getElementById('shelf').value.E_QUOT() : "";
 var request = document.getElementById('request') ? document.getElementById('request').value.E_QUOT() : "";
 var data2save = document.getElementById('datatosave') ? document.getElementById('datatosave').value.E_QUOT() : "";
 var accessories = document.getElementById('accessories') ? document.getElementById('accessories').value.E_QUOT() : ""; 

 var tech1 = "";
 var tech2 = "";
 var lastWorkDateTime = 0;
 if(!HIDE_INTERVLIST)
 {
  // determina i primi 2 tecnici dalla lista interventi //
  var techs = new Array();
  for(var c=1; c < TBINTERV.O.rows.length; c++)
  {
   var r = TBINTERV.O.rows[c];
   var opid = r.getAttribute('operatorid');
   if(!opid) continue;
   if(techs.indexOf(opid) < 0)
    techs.push(opid);
   if(techs.length == 2)
    break;
  }
  tech1 = techs[0] ? techs[0] : 0;
  tech2 = techs[1] ? techs[1] : 0;

  // determina l'ultima data e ora di intervento
  var tmpDate = new Date();
  for(var c=1; c < TBINTERV.O.rows.length; c++)
  {
   var r = TBINTERV.O.rows[c];
   var tmpTime = r.cell['endtime2'].getValue() ? r.cell['endtime2'].getValue() : r.cell['endtime'].getValue();
   tmpDate.setFromISO(strdatetime_to_iso(r.cell['date'].getValue()).substr(0,10)+" "+tmpTime);
   if(tmpDate.getTime() > lastWorkDateTime)
    lastWorkDateTime = tmpDate.getTime();
  }
 }

 var status = document.getElementById('status').getValue();
 var priority = document.getElementById('priority') ? document.getElementById('priority').getValue() : null;

 var closureModal = document.getElementById('closure-modal').getValue();
 var paymentMode = document.getElementById('payment-mode').getValue();
 var closureNote = document.getElementById('closurenote').value.E_QUOT();

 var appDateTime = document.getElementById('apptime') ? document.getElementById('apptime').isodatetime : "";
 

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!HIDE_ITEMLIST)
	  saveElements(a);
	 else
	  saveLabor();
	}

 var cmd = "dynarc edit-item -ap '<?php echo $_AP; ?>' -id '<?php echo $docInfo['id']; ?>' -ctime '"+ctime+"' -desc `"+desc+"`";
 cmd+= " -extset `ticketinfo.type='"+type+"',subjid='"+subjectId+"',subjname='''"+subjectName.E_QUOT()+"''',operatorid='"+operatorId+"',tech1='"+tech1+"',tech2='"+tech2+"',ticketref='''"+extTicketRef+"''',contactid='"+contactId+"',bypassupdatecontact=true,address='''"+address+"''',phone='"+phone+"',zone='''"+zone+"''',zoneid='"+zoneId+"',taxdelivery='"+taxDelivery+"',closuremodal='"+closureModal+"',paymentmode='"+paymentMode+"',closurenote='''"+closureNote+"''',apptime='"+appDateTime+"',ticketreffile='"+tktFileName+"',note='''"+notes.E_QUOT()+"'''";
 cmd+= ",amount='"+TOT_AMOUNT+"',vat='"+TOT_VAT+"',total='"+TOT_TOTAL+"'";
 cmd+= ",status='"+status+"'";

 if(document.getElementById('priority')) cmd+= ",priority='"+priority+"'";

 cmd+= ",hwid='"+hwid+"',hwname='''"+hwname+"''',shelf='''"+shelf+"''',request='''"+request+"''',datatosave='''"+data2save+"''',accessories='''"+accessories+"'''";

 if(parseFloat(status) >= 96)
 {
  // CLOSE TICKET
  if(!document.getElementById('finish_datetime'))
  {
   var finDate = new Date();
   switch(FINISHDATEMODAL)
   {
	case 'lastworktime' : {
		 if(lastWorkDateTime)
		  finDate.setTime(lastWorkDateTime);
		 else
		 {
	   	  var datestr = prompt("Digita la data e ora di chiusura",finDate.printf('d/m/Y H:i'));
		  finDate.setFromISO(strdatetime_to_iso(datestr));
		 }
		} break;
	case 'manual' : {
	   	 var datestr = prompt("Digita la data e ora di chiusura",finDate.printf('d/m/Y H:i'));
		 finDate.setFromISO(strdatetime_to_iso(datestr));
		} break;
   }
  }
  cmd+= ",closed='1',finishtime='"+(document.getElementById('finish_datetime') ? document.getElementById('finish_datetime').isodatetime : finDate.printf('Y-m-d H:i'))+"'";
 }

 if(appDateTime)
  cmd+= ",cronevents."+(EVENT_ID ? "id='"+EVENT_ID+"'," : "")+"from='"+appDateTime+"',tl='60',name='''"+subjectName.E_QUOT()+"'''";
 cmd+= "`";

 if(!appDateTime && EVENT_ID)
  cmd+= " -extunset `cronevents.id='"+EVENT_ID+"'`";

 sh.sendCommand(cmd);
}

function saveElements(a)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnFinish = function(){saveFinish();}

 for(var c=0; c < NEW_ROWS.length; c++)
 {
  var r = NEW_ROWS[c];
  var vatId = r.getAttribute('vatid') ? r.getAttribute('vatid') : 0;
  var vatType = r.getAttribute('vattype') ? r.getAttribute('vattype') : "";
  saveElement(r,sh);
 }

 for(var c=0; c < UPDATED_ROWS.length; c++)
 {
  var r = UPDATED_ROWS[c];
  var vatId = r.getAttribute('vatid') ? r.getAttribute('vatid') : 0;
  var vatType = r.getAttribute('vattype') ? r.getAttribute('vattype') : "";
  saveElement(r,sh,r.id);
 }

 for(var c=0; c < DELETED_ROWS.length; c++)
  sh.sendCommand("dynarc edit-item -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>` -extunset `cdelements.id="+DELETED_ROWS[c].id+"`");

 if(!NEW_ROWS.length && !UPDATED_ROWS.length && !DELETED_ROWS.length)
  return saveFinish();
}

function saveElement(r,sh,id)
{
 var vatId = r.getAttribute('vatid') ? r.getAttribute('vatid') : 0;
 var vatType = r.getAttribute('vattype') ? r.getAttribute('vattype') : "";
 var cdelementsQry = id ? "id="+id : "type='"+r.getAttribute('type')+"'";

 switch(r.getAttribute('type'))
 {
  case 'note' : cdelementsQry+= ",desc='''"+r.cells[0].getElementsByTagName('SPAN')[0].innerHTML+"''',ordering="+r.rowIndex; break;
  default : {
	 var discount = ((r.cell['discount'].getValue().indexOf("%") > 0) ? r.cell['discount'].getValue() : parseCurrency(r.cell['discount'].getValue()));
	 //var discount2 = r.cell['discount2'].getValue() ? parseFloat(r.cell['discount2'].getValue()) : 0;
	 //var discount3 = r.cell['discount3'].getValue() ? parseFloat(r.cell['discount3'].getValue()) : 0;
	 var coltint = r.cell['coltint'].getValue().E_QUOT();
	 var sizmis = r.cell['sizmis'].getValue().E_QUOT();

	 cdelementsQry+= ",refap='"+r.getAttribute('refap')+"',refid='"+r.getAttribute('refid')+"',code='"+r.cell['code'].getValue()+"'";
	 cdelementsQry+= ",sn='"+r.cell['sn'].getValue()+"'";
	 cdelementsQry+= ",brand_id='"+r.cell['brand'].getAttribute('brand_id')+"',brand='''"+r.cell['brand'].getValue()+"'''";
	 cdelementsQry+= ",name='''"+r.cell['description'].getValue()+"''',qty='"+r.cell['qty'].getValue()+"'";
	 cdelementsQry+= ",qty='"+r.cell['qty'].getValue()+"',units='"+r.cell['units'].getValue()+"'";
	 cdelementsQry+= ",price='"+parseCurrency(r.cell['unitprice'].getValue())+"',discount='"+discount+"'";
	 cdelementsQry+= ",vatrate='"+parseFloat(r.cell['vat'].getValue())+"',vatid='"+vatId+"',vattype='"+vatType+"'";
	 cdelementsQry+= ",coltint='''"+coltint+"''',sizmis='''"+sizmis+"'''";

	 cdelementsQry+= (!id ? ",ordering="+r.rowIndex : "");

	} break;
 }

 if(sh)
  sh.sendCommand("dynarc edit-item -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>` -extset `cdelements."+cdelementsQry+"`");
 else
  return cdelementsQry;
}

function saveLabor()
{
 var price = parseCurrency(document.getElementById('interv-totamount').innerHTML.replace(" &euro;",""));
 TOT_AMOUNT = price;
 TOT_VAT = (TOT_AMOUNT/100)*LABOR_VAT;
 TOT_TOTAL = TOT_AMOUNT+TOT_VAT;

cmd+= ",amount='"+TOT_AMOUNT+"',vat='"+TOT_VAT+"',total='"+TOT_TOTAL+"'";

 var sh = new GShell();
 var cmd = "dynarc edit-item -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>` -extset `ticketinfo.amount='"+TOT_AMOUNT+"',vat='"+TOT_VAT+"',total='"+TOT_TOTAL+"',cdelements.";
 if(LABOR_ID)
  cmd+= "id='"+LABOR_ID+"',price='"+price+"'`";
 else
  cmd+= "type='labor',name='''Manodopera''',qty='1',price='"+price+"',vatrate='"+LABOR_VAT+"',vatid='"+LABOR_VAT_ID+"',vattype='"+LABOR_VAT_TYPE+"'`";
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(a && !LABOR_ID && a['last_element'])
	  LABOR_ID = a['last_element']['id'];
	 saveFinish();
	}
 sh.sendCommand(cmd);
}

function saveFinish()
{
 var status = document.getElementById('status').getValue();
 if((parseFloat(status) >= 96) && (SUBJECT_AVAIL_HOURS > 0))
 {
  // scala dal monte ore
  return scalaMonteOre(function(){
	 saveHardwareInfo(function(){
		if(FINAL_CALLBACK)
		 FINAL_CALLBACK();
		else if(document.getElementById('closeandsendmail') && (document.getElementById('closeandsendmail').checked == true))
		 sendMail();
		else
		 Template.Exit();
		});
	});
 }

 saveHardwareInfo(function(){
	if(FINAL_CALLBACK)
	 FINAL_CALLBACK();
	else if(document.getElementById('closeandsendmail') && (document.getElementById('closeandsendmail').checked == true))
	 sendMail();
	else
	 Template.Exit();
	});
}

function scalaMonteOre(callback)
{
 var TL = document.getElementById("interv-tothours").innerHTML;
 if(parse_timelength(TL) == 0) return callback();

 TL = prompt("Digita le ore da scalare dal monte ore cliente",TL);
 if(!TL) return callback();
 var hours = (parse_timelength(TL)/60)/60;
 if(!hours) return callback();

 SUBJECT_AVAIL_HOURS = SUBJECT_AVAIL_HOURS - hours;
 if(SUBJECT_AVAIL_HOURS < 0) SUBJECT_AVAIL_HOURS = 0;

 var subjectId = document.getElementById("subject").getId();

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){callback();}
 sh.sendCommand("dynarc edit-item -ap rubrica -id '"+subjectId+"' -extset `rubricainfo.availhours='"+SUBJECT_AVAIL_HOURS+"'`");
}

function sendMail()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 var mtime = new Date(); mtime.setTime(parseFloat(a['mtime'])*1000);
	 var printTime = new Date(); printTime.setFromISO(a['print_datetime']);
	 if(ATTACH_PDF && (printTime.getTime() < mtime.getTime()))
	  return Print(function(){sendMail();});
	 
	 var sh2 = new GShell();
	 sh2.OnError = function(err){alert(err);}
	 sh2.OnOutput = function(o,a){Template.Exit();}
	 sh2.sendCommand("ticket sendmail -id '"+TICKET_ID+"' --only-preview || gframe -f tickets/sendmail -c *.message --use-cache-contents -params 'refap="+AP+"&refid="+TICKET_ID+"&sender='+*.sender+'&sendername='+*.sendername+'&recp='+*.recp+'&subject='+*.subject+'&attach1='+*.attachments[0]+'&attach2='+*.attachments[1]");
	}
 sh.sendCommand("dynarc item-info -ap '"+AP+"' -id '"+TICKET_ID+"' -get `print_datetime,print_filename`");
}

function InsertRow(ap, id, type, data)
{
 var subjectId = document.getElementById("subject").getId();

 var sh = new GShell();
 sh.OnOutput = function(o,a){  
	  if(!a)
	   return;

	  r = TB.AddRow();

	  r.setAttribute('type',type);
	  r.setAttribute('vatid',a['vatid']);
	  r.setAttribute('vattype',a['vattype']);
	  r.cell['code'].setValue(data['code_str']);
	  r.cell['brand'].setValue(a['brand']);
	  r.setAttribute('refid',a['id']);
	  r.setAttribute('refap',a['tb_prefix']);
	  r.cell['description'].setValue(a['name']);
	  r.cell['qty'].setValue(1);
	  
	  if(data)
	  {
	   // VARIANTS
	   switch(data['variant_type'])
	   {
		case 'color' : case 'tint' : r.cell['coltint'].setValue(data['variant_name']); break;
		case 'size' : case 'dim' : case 'other' : r.cell['sizmis'].setValue(data['variant_name']); break;
	   }
	  }

	  if(a['custompricing'])
	  {
	   if(a['custompricing']['discount_perc'])
		r.cell['discount'].setValue(a['custompricing']['discount_perc']+"%");
	   /*if(a['custompricing']['discount2'])
	    r.cell['discount2'].setValue(a['custompricing']['discount2']+"%");
	   if(a['custompricing']['discount3'])
	    r.cell['discount3'].setValue(a['custompricing']['discount3']+"%");*/
	  }
		  
	  r.cell['units'].setValue(a['units'] ? a['units'] : "PZ");
	  r.cell['unitprice'].setValue(a['finalprice']);
	  r.cell['unitprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(a['finalprice'],4);
	  /*r.cell['plbaseprice'].setValue(a['baseprice']);
	  r.cell['plbaseprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(a['baseprice'],4);
	  r.cell['plmrate'].setValue(a['pricelist_'+CUSTPLID+'_mrate'] ? a['pricelist_'+CUSTPLID+'_mrate'] : 0);
	  r.cell['pldiscperc'].setValue(a['pricelist_'+CUSTPLID+'_discount'] ? a['pricelist_'+CUSTPLID+'_discount'] : 0);*/
	  r.cell['vat'].setValue(a['vat']);
	  r.cell['price'].setValue(a['finalprice']);
	  r.cell['price'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(a['finalprice'],4);
	  /*r.cell['pricelist'].setValue(a['pricelist_name']);
	  r.cell['pricelist'].setAttribute("pricelistid",a['pricelist_id']);*/
	  
	  updatePriceByQty(r, r.cell['qty'].getValue());
	 }
 sh.sendCommand("commercialdocs getfullinfo -ap `"+ap+"` -id `"+id+"` -subjectid `"+subjectId+"`");
}

function InsertCustomRow(type)
{
 if(!type) type = "custom";
 var r = TB.AddRow();
 r.setAttribute('type',type);
 switch(type)
 {
  case 'note' : {
	 var colSpan = 9;
	 while(r.cells.length > 2)
	  r.deleteCell(1);
	 r.cells[0].colSpan=colSpan;
	} break;

 }

 r.edit();
}


function DeleteRow(r)
{
 r.remove();
 updateTotals();
}

function updateTotals(r)
{
 if(r)
 {
  var qty = parseFloat(r.cell['qty'].getValue());
  var unitprice = parseCurrency(r.cell['unitprice'].getValue());
  var discStr = r.cell['discount'].getValue();
  var discount = 0;
  var discount2 = 0;
  var discount3 = 0;

  if(discStr.indexOf("%") > 0)
  {
   var disc = parseFloat(discStr);
   discount = unitprice ? (unitprice/100)*disc : 0;
  }
  else
   discount = parseCurrency(discStr);

  if(!discount) 
   discount=0;

  /*var disc2Str = r.cell['discount2'].getValue();
  if(disc2Str && unitprice)
  {
   var disc = parseFloat(disc2Str);
   if(disc)
    discount2 = ((unitprice-discount)/100) * disc;
  }
  
  var disc3Str = r.cell['discount3'].getValue();
  if(disc2Str && disc3Str && unitprice)
  {
   var disc = parseFloat(disc3Str);
   if(disc)
    discount3 = (((unitprice-discount)-discount2)/100) * disc;
  }*/

  var vat = parseFloat(r.cell['vat'].getValue());

  if(discStr == "100%")
   var total = 0;
  else
   var total = (unitprice-discount-discount2-discount3) * qty;
  var totalPlusVat = total ? total + ((total/100)*vat) : 0;

  r.cell['price'].setValue("<em>&euro;</em>"+formatCurrency(total,DECIMALS),total);
  r.cell['price'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(total,4);
  r.cell['vatprice'].setValue("<em>&euro;</em>"+formatCurrency(totalPlusVat,DECIMALS),totalPlusVat);
  r.cell['vatprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(totalPlusVat,4);
 }

 var VAT_RATES = new Array();
 var VATS = new Object();
 TOT_AMOUNT = 0;
 TOT_VAT = 0;
 TOT_TOTAL = 0;

 for(var c=1; c < TB.O.rows.length; c++)
 {
  var r = TB.O.rows[c];
  if(r.getAttribute('type') == "note")
   continue;
  var qty = parseFloat(r.cell['qty'].getValue());

  var discount = 0;
  var discount2 = 0;
  var discount3 = 0;
  var unitprice = parseCurrency(r.cell['unitprice'].getValue());

  var discStr = r.cell['discount'].getValue();
  if(discStr.indexOf("%") > 0)
  {
   var disc = parseFloat(discStr);
   discount = unitprice ? (unitprice/100)*disc : 0;
  }
  else
   discount = parseCurrency(discStr);

  if(!discount) 
   discount=0;

  /*var disc2Str = r.cell['discount2'].getValue();
  if(disc2Str && unitprice)
  {
   var disc = parseFloat(disc2Str);
   if(disc)
    discount2 = ((unitprice-discount)/100) * disc;
  }
  
  var disc3Str = r.cell['discount3'].getValue();
  if(disc2Str && disc3Str && unitprice)
  {
   var disc = parseFloat(disc3Str);
   if(disc)
    discount3 = (((unitprice-discount)-discount2)/100) * disc;
  }*/

  discount = (discount+discount2+discount3) * qty;

  if(discStr == "100%")
   var amount = 0;
  else
   var amount = parseCurrency(r.cell['price'].getValue());

  var total = amount;
  var vatRate = parseFloat(r.cell['vat'].getValue());
  var vat = total ? (total/100)*vatRate : 0;

  TOT_AMOUNT+= total;
  TOT_VAT+= vat;
 }

 TOT_TOTAL = TOT_AMOUNT + TOT_VAT;

 document.getElementById("footer-total").innerHTML = "&euro; "+formatCurrency(TOT_AMOUNT + TOT_VAT);
}

function updatePriceByQty(r, value)
{
 var subjectId = document.getElementById("subject").getId();
 var ap = r.getAttribute('refap');
 var id = r.getAttribute('refid');
 var qty = value;
 var varType = "";
 var varName = "";
 if(r.cell['coltint'].getValue())
 {
  varType = "color";
  varName = r.cell['coltint'].getValue();
 }
 else if(r.cell['sizmis'].getValue())
 {
  varType = "size";
  varName = r.cell['sizmis'].getValue();
 }
 if(ap && id && qty)
 {
  var sh = new GShell();
  sh.OnError = function(){updateTotals(r);}
  sh.OnOutput = function(o,a){
	 if(!a) return updateTotals(r);
	 r.cell['unitprice'].setValue(a['finalprice']);
   	 r.cell['unitprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(a['finalprice'],4);
	 updateTotals(r);
	}
  var cmd = "commercialdocs get-price-by-qty -ap '"+ap+"' -id '"+id+"' -qty '"+qty+"' -vartype '"+varType+"' -varname `"+varName+"` -plid `"+CUSTPLID+"` -subjid '"+subjectId+"'";
  sh.sendCommand(cmd);
 }
 else
  updateTotals(r); 
}


function updateContactList()
{
 var ed = document.getElementById("subject");
 if(document.getElementById('address'))
 {
  document.getElementById('address').setAttribute('subjid',ed.data ? ed.data['id'] : 0);
  document.getElementById('address').setValue('',0);
 }
}

function OpenDocument(id)
{
 window.open(ABSOLUTE_URL+"GCommercialDocs/docinfo.php?id="+id, "GCD-"+id);
}

function PrintInvoice(docId,docName,exit)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnFinish = function(){if(exit) Template.Exit();}
 sh.sendCommand("dynarc item-info -ap `commercialdocs` -id `"+docId+"` || gframe -f print.preview -params `modelap=printmodels&modelct=invoices&parser=commercialdocs&id="+docId+"` -title `"+docName+"`");
}

function GeneratePreemptive(save)
{
 if(save)
  return Submit(function(){GeneratePreemptive();});

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 OpenDocument(a['id']);
	 document.location.reload();
	}
 sh.sendCommand("ticket generate-preemptive -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>`");
}

function GenerateInvoice(save)
{
 if(save)
  return Submit(function(){GenerateInvoice();});

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 OpenDocument(a['id']);
	 document.location.reload();
	}
 sh.sendCommand("ticket generate-invoice -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>`");
}

function Print(callback)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 var sh2 = new GShell();
	 sh2.OnError = function(err){alert(err);}
	 sh2.OnOutput = function(){if(callback) callback();}
	 sh2.sendCommand("dynarc edit-item -ap `"+AP+"` -id `"+TICKET_ID+"` -extset `ticketinfo.printdate='now',printfile='"+a['fullname']+"'`");
	}
 sh.sendCommand("dynarc item-info -ap `"+AP+"` -id `"+TICKET_ID+"` || gframe -f print.preview -params `modelap=printmodels&modelct=tickets&parser=ticket&id="+TICKET_ID+"` -title `"+PDF_FILENAME+"`");
}

function DeleteTicket()
{
 if(!confirm("Sei sicuro di voler eliminare questo intervento?"))
  return;
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){Template.Exit();}
 sh.sendCommand("dynarc delete-item -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>`");
}

function NewIntervention()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 a = a['last_element'];
	 var tb = document.getElementById("intervlist").gmutable;
	 var r = tb.AddRow();
	 r.data = a;
	 r.id = a['id'];
	 r.setAttribute('operatorid',a['operator_id']);
	 var date = new Date();
	 date.setFromISO(a['date']);
	 r.cell['date'].setValue(date.printf('d/m/Y'));
	 r.cell['title'].innerHTML = "<span class='graybold' style='color:blue;cursor:pointer' onclick='EditIntervention(this.parentNode.parentNode,"+a['id']+")'>"+a['name']+"</span>";
	 r.cell['description'].setValue(a['desc']);
	 r.cell['hours'].setValue(a['tot_hours']);
	 r.cell['extrahours'].setValue(a['tot_extra_hours']);
	 r.cell['starttime'].setValue(a['start_time']);
	 r.cell['endtime'].setValue(a['end_time']);
	 r.cell['starttime2'].setValue(a['start_time2']);
	 r.cell['endtime2'].setValue(a['end_time2']);
	 r.cell['operator'].setValue(a['operator_name']);
	 r.cell['tothours'].setValue(a['subtot_hours']);
	 r.cell['totamount'].setValue(a['tot_amount']);
	 r.cell['btninfo'].innerHTML = "<img src='"+ABSOLUTE_URL+"share/icons/16x16/information.gif' onclick='EditIntervention(this.parentNode.parentNode,"+a['id']+")' title='Mostra dettagli intervento' style='cursor:pointer'/"+">";
	 r.cell['btndel'].innerHTML = "<img src='"+ABSOLUTE_URL+"Tickets/img/delete-black.png' onclick='DeleteIntervention(this.parentNode.parentNode,"+a['id']+")' style='cursor:pointer' title='Elimina'/"+">";
	 updateIntervTotals();
	}
 sh.sendCommand("gframe -f intervention/new -params `ap="+AP+"&id="+TICKET_ID+"`");
}

function EditIntervention(r, id)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 if(a['removed'])
	 {
	  r.remove();
	  updateIntervTotals();
	  return;
	 }
	 a = a['last_element'];
	 r.data = a;
	 r.setAttribute('operatorid',a['operator_id']);
	 var date = new Date();
	 date.setFromISO(a['date']);
	 r.cell['date'].setValue(date.printf('d/m/Y'));
	 r.cell['title'].setValue(a['name']);
	 r.cell['description'].setValue(a['desc']);
	 r.cell['hours'].setValue(a['tot_hours']);
	 r.cell['extrahours'].setValue(a['tot_extra_hours']);
	 r.cell['starttime'].setValue(a['start_time']);
	 r.cell['endtime'].setValue(a['end_time']);
	 r.cell['starttime2'].setValue(a['start_time2']);
	 r.cell['endtime2'].setValue(a['end_time2']);
	 r.cell['operator'].setValue(a['operator_name']);
	 r.cell['tothours'].setValue(a['subtot_hours']);
	 r.cell['totamount'].setValue(a['tot_amount']);
	 updateIntervTotals();
	}

 sh.sendCommand("gframe -f intervention/edit -params `ap="+AP+"&id="+id+"&refid="+TICKET_ID+"`");
}

function DeleteIntervention(r, id)
{
 if(!confirm("Sei sicuro di voler rimuovere questo intervento dalla lista?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 r.remove();
	 updateIntervTotals();
	}
 sh.sendCommand("dynarc edit-item -ap `"+AP+"` -id `"+TICKET_ID+"` -extunset `interventions.id='"+id+"'`");
}

function updateIntervTotals()
{
 var minutes = 0;
 var amount = 0;

 var tb = document.getElementById("intervlist").gmutable;
 for(var c=1; c < tb.O.rows.length; c++)
 {
  var tl = tb.O.rows[c].cell['tothours'].getValue();
  if(tl)
   minutes+= parse_timelength(tl)/60;
  var am = parseCurrency(tb.O.rows[c].cell['totamount'].getValue());
  if(am)
   amount+= am;
 }
 document.getElementById("interv-tothours").innerHTML = timelength_to_str(minutes*60);
 document.getElementById("interv-totamount").innerHTML = formatCurrency(amount)+" &euro;";

 if(AUTOINSLABOR && !HIDE_ITEMLIST)
 {
  var tb = document.getElementById("doctable").gmutable;
  var ok = false;
  for(var c=1; c < tb.O.rows.length; c++)
  {
   var r = tb.O.rows[c];
   if(r.getAttribute('type') == "labor")
   {
	r.cell['unitprice'].setValue(formatCurrency(amount),amount);
	r.cell['unitprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(parseCurrency(amount),4);
	if(r.id && (UPDATED_ROWS.indexOf(r) < 0)) UPDATED_ROWS.push(r);
	updateTotals(r);
	ok = true;
	break;
   }
  }
  if(!ok)
  {
   var r = tb.AddRow();
   r.setAttribute('type','labor');
   r.setAttribute('vatid',LABOR_VAT_ID);
   r.setAttribute('vattype',LABOR_VAT_TYPE);
   r.cell['description'].setValue("Manodopera");
   r.cell['qty'].setValue(1);
   r.cell['unitprice'].setValue(formatCurrency(amount),amount);
   r.cell['unitprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(parseCurrency(amount),4);
   r.cell['vat'].setValue(LABOR_VAT);
   updateTotals(r);
  }
 }
}

function UnlockTicket()
{
 if(!confirm("Sei sicuro di voler sbloccare questo ticket?"))
  return;
 document.getElementById("unlock-btn").style.display = "none";
 document.getElementById("unlock-btn2").style.display = "none";
 document.getElementById("save-btn").style.display = "";
 document.getElementById("save-btn2").style.display = "";
}

function CloseTicket(status)
{
 if(!confirm("Il ticket sta per essere chiuso. Continuare?"))
  return;

 document.getElementById('status').setValue('Chiuso',status);
 Submit();
}

function ReOpenTicket()
{
 if(!confirm("Sei sicuro di voler riaprire questo ticket?"))
  return;
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){document.location.reload();}
 sh.sendCommand("dynarc edit-item -ap `"+AP+"` -id `"+TICKET_ID+"` -extset `ticketinfo.closed=0,finishtime=0,status=0`");
}

function setTaxDelivery(days)
{
 var date = new Date();
 //date.setFromISO(document.getElementById('taxdelivery').isodatetime);
 date.NextDate(1);
 document.getElementById('taxdelivery').setDateTime(date.printf('Y-m-d H:i'));
}

function NewAddress()
{
 var subjId = document.getElementById('subject').getId();
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 var address = "<?php echo $_ADDRESS_SCHEMA; ?>";
	 var keys = new Array('{CODE}','{TITLE}','{ADDRESS}','{CITY}','{ZIP}','{PROV}','{CC}','{NOTE}');
	 var values = new Array(a['code'], a['name'], a['address'], a['city'], a['zipcode'], a['province'], a['countrycode'], a['note']);
 	 for(var c=0; c < keys.length; c++)
 	 {
  	  var k = keys[c];
  	  var v = values[c];
  	  address = address.replace(k,v);
 	 }
	 document.getElementById('address').setValue(address, a['id']);
	 var img = document.getElementById('addressbtn');
	 img.src = ABSOLUTE_URL+"share/icons/16x16/pencil.gif";
	 img.title = "Modifica dettagli indirizzo";
	 img.onclick = function(){EditAddress();}
	}
 sh.sendCommand("gframe -f addresses/new -params `subjid="+subjId+"`");
}

function EditAddress()
{
 var id = document.getElementById('address').getValue();
 if(!id) return NewAddress();

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 if(a['removed'])
	  return document.getElementById('address').setValue("", 0);
	 var address = "<?php echo $_ADDRESS_SCHEMA; ?>";
	 var keys = new Array('{CODE}','{TITLE}','{ADDRESS}','{CITY}','{ZIP}','{PROV}','{CC}','{NOTE}');
	 var values = new Array(a['code'], a['name'], a['address'], a['city'], a['zipcode'], a['province'], a['countrycode'], a['note']);
 	 for(var c=0; c < keys.length; c++)
 	 {
  	  var k = keys[c];
  	  var v = values[c];
  	  address = address.replace(k,v);
 	 }
	 document.getElementById('address').setValue(address, id);
	}
 sh.sendCommand("gframe -f addresses/edit -params `refap="+AP+"&refid="+TICKET_ID+"&id="+id+"`");
}

function deleteTktRefFile()
{
 document.getElementById("tktreffile").value = "";
 document.getElementById("tktreffile").setAttribute('filename','');
 document.getElementById("tktreffiledelbtn").style.visibility = "hidden";
}

function checkTicketRef(ed)
{
 if(!ed.value) return;
 var sh = new GShell();
 sh.OnOutput = function(o,a){
	 if(a && a['id'])
	 {
	  alert("Attenzione! Esiste già un altro ticket che ha come Rif. ticket esterno '"+ed.value+"'.");
	  ed.select();
	  ed.focus();
	 }
	}
 sh.sendCommand("dynarc item-info -ap '"+AP+"' -where `ext_ticket_ref='"+ed.value+"' AND id!='"+TICKET_ID+"'`");
}

/* TICKET-CUSTHW-PLUGIN */
function addNewHardware()
{
 var subjectId = document.getElementById("subject").getId();
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 var ul = document.getElementById("hardware-list");
	 var liref = document.getElementById("hardware-list-separator");
	 var li = document.createElement('LI');
	 li.value = a['id'];
	 li.setAttribute('value',a['id']);
	 li.innerHTML = a['name'];
	 ul.insertBefore(li,liref);
	 document.getElementById("hardware").setValue(a['name'],a['id']);
	 document.getElementById("hardware-info-button").style.visibility = "visible";
	}
 sh.sendCommand("gframe -f tickets/new.custhw -params `subjid="+subjectId+"`");
}

function editHardware(id)
{
 if(!id)
 {
  var id = document.getElementById('hardware').getValue();
  var li = document.getElementById('hardware').selectedItem;
 }
 else
 {
  var ul = document.getElementById('hardware').popupmenu;
  var list = ul.getElementsByTagName('LI');
  for(var c=0; c < list.length; c++)
  {
   var li = list[c];
   var val = li.getAttribute('retval') ? li.getAttribute('retval') : li.getAttribute('value');
   if(val == id) 
	break;
  }
 }
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 li.innerHTML = a['name'];
	 document.getElementById("hardware").setValue(a['name'],id);
	}
 sh.sendCommand("gframe -f tickets/edit.custhw -params `id="+id+"`");
}

function updateHardwareList()
{
 var subjectId = document.getElementById("subject").getId();
 var ul = document.getElementById('hardware-list');
 if(!ul) return;
 var sep = document.getElementById('hardware-list-separator');
 // empty list //
 while(ul.getElementsByTagName('LI').length > 3)
 {
  var li = ul.getElementsByTagName('LI')[1];
  if(li == sep)
   break;
  ul.removeChild(li);
 }
 document.getElementById("hardware").setValue("",0);

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){ 	 
	 if(!a || !a['items']) return;
	 for(var c=0; c < a['items'].length; c++)
	 {
	  var li = document.createElement('LI');
	  li.value = a['items'][c]['id'];
	  li.setAttribute('value',a['items'][c]['id']);
	  li.innerHTML = a['items'][c]['name'];
	  ul.insertBefore(li,sep);
	 }
	}
 sh.sendCommand("dynarc item-list -ap `"+HWAP+"` -where `subject_id='"+subjectId+"'`");
}

function addNewOS()
{
 var tit = prompt("Digita il nome del nuovo sistema operativo");
 if(!tit) return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 var ul = document.getElementById("os-list");
	 var liref = document.getElementById("os-list-separator");
	 var li = document.createElement('LI');
	 li.value = a['name'];
	 li.setAttribute('value',a['name']);
	 li.innerHTML = a['name'];
	 ul.insertBefore(li,liref);
	 document.getElementById("os").setValue(a['name'],a['name']);
	}
 sh.sendCommand("dynarc new-item -ap tktoslist -name `"+tit+"`");
}

function addNewHDD()
{
 var tit = prompt("Digita il modello del nuovo hard-disk");
 if(!tit) return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 var ul = document.getElementById("hdd-list");
	 var liref = document.getElementById("hdd-list-separator");
	 var li = document.createElement('LI');
	 li.value = a['name'];
	 li.setAttribute('value',a['name']);
	 li.innerHTML = a['name'];
	 ul.insertBefore(li,liref);
	 document.getElementById("hdd").setValue(a['name'],a['name']);
	}
 sh.sendCommand("dynarc new-item -ap tkthddlist -name `"+tit+"`");
}

function saveHardwareInfo(callback)
{
 /* TODO: se il plugin ticket-custhw-plugin non è installato deve lanciare subito callback */
 if(!document.getElementById('hardware')) return callback();

 var hwid = document.getElementById('hardware').getValue();
 if(!hwid || (hwid == "0")) return callback();

 var osName = (document.getElementById("os") && document.getElementById("os").value) ? document.getElementById("os").value.E_QUOT() : "";
 var user1 = (document.getElementById("user") && document.getElementById("user").value) ? document.getElementById("user").value.E_QUOT() : "";
 var user2 = (document.getElementById("user2") && document.getElementById("user2").value) ? document.getElementById("user2").value.E_QUOT() : "";
 var user3 = (document.getElementById("user3") && document.getElementById("user3").value) ? document.getElementById("user3").value.E_QUOT() : "";
 var root = (document.getElementById("admin") && document.getElementById("admin").value) ? document.getElementById("admin").value.E_QUOT() : "";

 var passwd1 = (document.getElementById("password") && document.getElementById("password").value) ? document.getElementById("password").value.E_QUOT() : "";
 var passwd2 = (document.getElementById("password2") && document.getElementById("password2").value) ? document.getElementById("password2").value.E_QUOT() : "";
 var passwd3 = (document.getElementById("password3") && document.getElementById("password3").value) ? document.getElementById("password3").value.E_QUOT() : "";
 var rootPasswd = (document.getElementById("adminpassword") && document.getElementById("adminpassword").value) ? document.getElementById("adminpassword").value.E_QUOT() : "";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){callback();}
 sh.sendCommand("dynarc edit-item -ap `"+HWAP+"` -id '"+hwid+"' -extset `oslist."+(OSID ? "id='"+OSID+"'," : "")+"name=\""+osName+"\",user1=\""+user1+"\",user2=\""+user2+"\",user3=\""+user3+"\",root=\""+root+"\",passwd=\""+passwd1+"\",passwd2=\""+passwd2+"\",passwd3=\""+passwd3+"\",rootpwd=\""+rootPasswd+"\"`");
}

function calculateHours(r)
{
 var t = parse_timelength(r.cell['endtime'].getValue()) - parse_timelength(r.cell['starttime'].getValue());
 t+= parse_timelength(r.cell['endtime2'].getValue()) - parse_timelength(r.cell['starttime2'].getValue());
 r.cell['hours'].setValue( (t>0) ? timelength_to_str(t) : '' );
 r.cell['extrahours'].setValue("");
}
</script>
<?php

$template->End();

?>


