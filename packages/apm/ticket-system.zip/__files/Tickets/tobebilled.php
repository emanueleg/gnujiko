<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 26-09-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Official Gnujiko Ticket System
 #VERSION: 2.15beta
 #CHANGELOG: 26-09-2016 : esteso il numero di righe fino a 2000 risultati per pagina.
			 07-06-2016 : Bug fix su funzione sendMail.
			 30-11-2014 : Integrato hardware, scaffale, richieste, ecc...
			 14-11-2014 : Aggiunta funzione duplica ticket.
			 10-11-2014 : Aggiunto campo note.
			 01-11-2014 : Bug fix indirizzi.
			 27-10-2014 : Sostituito code_str con code_num ed aggiunto insegna su esportazione in excel.
			 23-10-2014 : Aggiustata funzione exportToExcel.
			 21-10-2014 : Aggiornato filtri per data.
			 18-10-2014 : Aggiornamenti vari.
			 13-10-2014 : Aggiunto filtri per città e provincia.
			 10-10-2014 : Aggiornata colonna indirizzo.
			 07-10-2014 : Sistemazioni varie.
			 06-10-2014 : Aggiornamenti vari
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS;

$_BASE_PATH = "../";
$_RESTRICTED_ACCESS = "tickets";
$_AP = "tickets";

$_EDIT_TICKET_FORM = "Tickets/ticketinfo.php";

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate();

if(is_array($template->config['display']))
{
 if($template->config['display']['edit-ticket-form'] && file_exists($_BASE_PATH.$template->config['display']['edit-ticket-form']))
  $_EDIT_TICKET_FORM = $template->config['display']['edit-ticket-form'];
}

$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeInternalObject("serp");
$template->includeInternalObject("contactsearch");
$template->includeInternalObject("addresssearch");
$template->includeObject("printmanager");
$template->includeCSS('ticketlist.css');

$template->Begin("Tickets");
//-------------------------------------------------------------------------------------------------------------------//
$dateFrom = $_REQUEST['from'] ? $_REQUEST['from'] : "";
$dateTo = $_REQUEST['to'] ? $_REQUEST['to'] : "";

$_STATUS = array();
reset($template->config['ticketstatus']);
while(list($k,$v)=each($template->config['ticketstatus']))
{
 $_STATUS[$k] = $v['name'];
}

$_DEF_RPP = 25;

$ret = GShell("dynarc item-list -ap tickettypes");
$_TICKET_TYPES = $ret['outarr']['items'];
$_TICKET_TYPE_BY_ID = array();
for($c=0; $c < count($_TICKET_TYPES); $c++)
 $_TICKET_TYPE_BY_ID[$_TICKET_TYPES[$c]['id']] = $_TICKET_TYPES[$c];


$_OPERATORS = _getGroupUserList(_getGID("tickets"));
if($_REQUEST['operator_id'])
{
 // get operator name
 for($c=0; $c < count($_OPERATORS); $c++){if($_OPERATORS[$c]['id'] == $_REQUEST['operator_id']){
   $_REQUEST['operator_name'] = $_OPERATORS[$c]['fullname'] ? $_OPERATORS[$c]['fullname'] : $_OPERATORS[$c]['name']; break;}}
}

$_COLUMNS = array(
 0 => array('title'=>'N. ticket', 		'field'=>'code_num', 		'width'=>70, 'sortable'=>true, 	'visibled'=>true),
 1 => array('title'=>'Rif. Ticket',		'field'=>'ext_ticket_ref',	'sortable'=>true, 'visibled'=>false),
 2 => array('title'=>'Data apertura',	'field'=>'ctime',			'width'=>100, 'sortable'=>true,	'visibled'=>true, 'format'=>'date'),
 3 => array('title'=>'Data scadenza',	'field'=>'tax_delivery',	'width'=>120, 'sortable'=>true,	'visibled'=>false, 'format'=>'date'),
 4 => array('title'=>'Data chiusura',	'field'=>'finish_datetime',	'width'=>100, 'sortable'=>true,	'visibled'=>true, 'format'=>'date'),
 5 => array('title'=>'Cliente',			'field'=>'subject_name',	'sortable'=>true,	'visibled'=>true),
 6 => array('title'=>'Tipologia',		'field'=>'ticket_type',		'sortable'=>true,	'visibled'=>false),
 7 => array('title'=>'Indirizzo',		'field'=>'contact_id',		'sortable'=>false,	'visibled'=>false),
 8 => array('title'=>'Zona',			'field'=>'zone',			'sortable'=>true,	'visibled'=>false),
 9 => array('title'=>'Operatore',		'field'=>'operator_id',		'sortable'=>true,	'visibled'=>false),
 10 => array('title'=>'Hardware',		'field'=>'hw_name',			'sortable'=>true,	'visibled'=>false),
 11 => array('title'=>'Scaffale',		'field'=>'shelf',			'sortable'=>true,	'visibled'=>false),
 12 => array('title'=>'Imponibile',		'field'=>'amount',			'sortable'=>true,	'visibled'=>true,	'format'=>'currency'),
 13 => array('title'=>'IVA',			'field'=>'vat',				'sortable'=>true,	'visibled'=>true,	'format'=>'currency'),
 14 => array('title'=>'Totale',			'field'=>'total',			'sortable'=>true,	'visibled'=>true,	'format'=>'currency'),
 15 => array('title'=>'Status',			'field'=>'status',			'sortable'=>true,	'visibled'=>true),
 16 => array('title'=>'Note',			'field'=>'note',			'width'=>200, 	'sortable'=>true,	'visibled'=>true)
);

/* GET SETTINGS */
$ret = GShell("aboutconfig get -app tickets -sec ticketlist");
if(!$ret['error'])
{
 $settings = $ret['outarr']['defaultsettings'];
 if(is_array($settings['ticketlist']))
 {
  $visibledColumns = explode(",",$settings['ticketlist']['visibledcolumns']);
  for($c=0; $c < count($_COLUMNS); $c++)
  {
   $col = $_COLUMNS[$c];
   if(in_array($col['field'], $visibledColumns))
	$_COLUMNS[$c]['visibled'] = true;
   else
	$_COLUMNS[$c]['visibled'] = false;
  }
  if($settings['ticketlist']['rpp'])
   $_DEF_RPP = $settings['ticketlist']['rpp'];
 }
}

/* GET CONFIG */
$config = array();
$ret = GShell("aboutconfig get-config -app tickets");
if(!$ret['error'])
 $config = $ret['outarr']['config'];

/* ADDRESS */
$_ADDRESS_SCHEMA = "{ADDRESS} - {CITY} ({PROV})";
$_ADDRESS_KEYS = array('{CODE}','{TITLE}','{ADDRESS}','{CITY}','{ZIP}','{PROV}','{CC}','{NOTE}');
if($config['interface']['ticketaddressschema'])
 $_ADDRESS_SCHEMA = $config['interface']['ticketaddressschema'];

/* PDF */
$_REF_KEYS = array('{NUM}','{DATE}','{TIME}','{TKTREF}','{TYPE}','{CUSTOMER}','{FULLADDRESS}','{ZONE}','{CLOSEDATE}','{CLOSETIME}'
	,'{OPERATOR}','{TECH1}','{TECH2}','{TAXDELIVERY}','{ADDR_CODE}','{ADDR_TITLE}','{ADDR_ADDRESS}','{ADDR_CITY}','{ADDR_ZIP}'
	,'{ADDR_PROV}','{ADDR_CC}','{ADDR_NOTE}');
$_PDF_SCHEMA = "Ticket-{NUM}";
if($config['options']['pdffileschema'])
 $_PDF_SCHEMA = $config['options']['pdffileschema'];


/* STYLE */
$style = "";
if($config['interface']['ticketlistfontsize'])
{
 $style.= "table.sortable-table td {font-size: ".$config['interface']['ticketlistfontsize']."px}\n";
}

if($style)
 echo "<style type='text/css'>".$style."</style>";

$centerContents = "<input type='text' class='edit' style='width:290px;float:left' placeholder='Ricerca per cliente' id='search' value=\""
	.htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\" modal='extended' fields='code_str,name' contactfields='phone,phone2,cell,email' ct='customers'/>";
$centerContents.= "<input type='button' class='button-search' id='searchbtn'/>";

$_DATE_FILTERS = array('ctime'=>'Filtra x data apertura', 'expiry'=>'Filtra x data scadenza', 'finish'=>'Filtra x data chiusura');
if(!$_REQUEST['datefilter'])
 $_REQUEST['datefilter'] = 'ctime';

$centerContents.= "<input type='edit' class='dropdown' id='datefilter' connect='datefilterlist' readonly='true' style='width:150px;margin-left:30px' value='".$_DATE_FILTERS[$_REQUEST['datefilter']]."' retval='".$_REQUEST['datefilter']."'/>";
$centerContents.= "<ul class='popupmenu' id='datefilterlist'>";
reset($_DATE_FILTERS);
while(list($k,$v)=each($_DATE_FILTERS)){ $centerContents.= "<li value='".$k."'>".$v."</li>"; }
$centerContents.= "</ul>";

$centerContents.= "<input type='text' class='calendar' value='".($dateFrom ? date('d/m/Y',strtotime($dateFrom)) : '')."' id='datefrom'/><span class='smalltext'> al </span><input type='text' class='calendar' value='".($dateTo ? date('d/m/Y',strtotime($dateTo)) : '')."' id='dateto'/>";

$template->Header("search", $centerContents, "BTN_EXIT", 800);
//-------------------------------------------------------------------------------------------------------------------//
if($_REQUEST['operator_id'])
{
 $_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "ctime";
 $_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "DESC";
}
else
{
 $_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "subject_name";
 $_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "ASC";
}
$_RPP = $_REQUEST['rpp'] ? $_REQUEST['rpp'] : $_DEF_RPP;
$_PG = $_REQUEST['pg'] ? $_REQUEST['pg'] : 1;

$_SERP = new SERP();
$_SERP->setOrderBy($_ORDER_BY);
$_SERP->setOrderMethod($_ORDER_METHOD);
$_SERP->setResultsPerPage($_RPP);
$_SERP->setCurrentPage($_PG);

$_SEARCH_BY_ADDRESS = false;
if($_REQUEST['city'] || $_REQUEST['province'] || $_REQUEST['address'])
{
 $_SEARCH_BY_ADDRESS = true;
 /* RICERCA PER CITTA' O PROVINCIA */
 $cmd = "dynarc cross-search -ap rubrica -ext addresses -ap2 '".$_AP."' -extget `ticketinfo` -j `id=contact_id` -get `code_num,code_str`";
 $where = "item.closed='1' AND item.invoice_id='0' AND item.status='100'";

 if($_REQUEST['from'] || $_REQUEST['to'])
 {
  switch($_REQUEST['datefilter'])
  {
   case 'ctime' : {	
	 if($_REQUEST['from'])	$where.= " AND item.ctime>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND item.ctime<'".$_REQUEST['to']." 23:59:59'";
	} break;

   case 'expiry' : {
	 if($_REQUEST['from'])	$where.= " AND item.tax_delivery>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND item.tax_delivery<'".$_REQUEST['to']." 23:59:59'";
	} break;

   case 'finish' : {
	 if($_REQUEST['from'])	$where.= " AND item.finish_datetime>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND item.finish_datetime<'".$_REQUEST['to']." 23:59:59'";
	} break;
  }
 }

 if($_REQUEST['city'])					$where.= " AND ext.city='".$_REQUEST['city']."'";
 if($_REQUEST['province'])				$where.= " AND ext.province='".$_REQUEST['province']."'";
 if(isset($_REQUEST['status']))			$where.= " AND item.status='".$_REQUEST['status']."'";
 if($_REQUEST['subjectid'])				$where.= " AND item.subject_id='".$_REQUEST['subjectid']."'";
 else if($_REQUEST['search'])			$where.= " AND item.subject_name='".$_REQUEST['search']."'";
 if($_REQUEST['ticket_type'])			$where.= " AND item.ticket_type='".$_REQUEST['ticket_type']."'";
 if($_REQUEST['ext_ticket_ref'])
 {
  if(strpos($_REQUEST['ext_ticket_ref'], "*") !== false)
   $where.= " AND item.ext_ticket_ref LIKE '".str_replace("*","%",$_REQUEST['ext_ticket_ref'])."'";
  else
   $where.= " AND (item.ext_ticket_ref='".$_REQUEST['ext_ticket_ref']."' OR item.ext_ticket_ref LIKE '"
	.$_REQUEST['ext_ticket_ref']."%' OR item.ext_ticket_ref LIKE '%".$_REQUEST['ext_ticket_ref']."%' OR item.ext_ticket_ref LIKE '%"
	.$_REQUEST['ext_ticket_ref']."')";
 }
 if($_REQUEST['operator_id'])			$where.= " AND item.operator_id='".$_REQUEST['operator_id']."'";
 if($_REQUEST['contact_id'])			$where.= " AND item.contact_id='".$_REQUEST['contact_id']."'";
 else if($_REQUEST['address'])
 {
  $where.= " AND (ext.code='".$_REQUEST['address']."' OR ext.code LIKE '".$_REQUEST['address']."%' OR ext.name='"
	.$_REQUEST['address']."' OR ext.name LIKE '".$_REQUEST['address']."%' OR ext.name LIKE '%"
	.$_REQUEST['address']."' OR ext.name LIKE '%".$_REQUEST['address']."%' OR ext.address='"
	.$_REQUEST['address']."' OR ext.address LIKE '".$_REQUEST['address']."%' OR ext.address LIKE '%"
	.$_REQUEST['address']."' OR ext.address LIKE '%".$_REQUEST['address']."%')";
 }
 if($_REQUEST['zoneid'])				$where.= " AND item.zone_id='".$_REQUEST['zoneid']."'";
 else if($_REQUEST['zone'])				$where.= " AND item.zone LIKE '".$_REQUEST['zone']."%'";
 if($_REQUEST['techid'])				$where.= " AND (item.tech_1='".$_REQUEST['techid']."' OR item.tech_2='".$_REQUEST['techid']."')";

 if($where)	$cmd.= " -where `".ltrim($where,' AND ')."`";
}
else
{
 /* RICERCA NORMALE */
 $cmd = "dynarc item-list -ap `".$_AP."` -extget `ticketinfo`";
 $where = "closed='1' AND invoice_id='0' AND status='100'";

 if($_REQUEST['from'] || $_REQUEST['to'])
 {
  switch($_REQUEST['datefilter'])
  {
   case 'ctime' : {	
	 if($_REQUEST['from'])	$where.= " AND ctime>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND ctime<'".$_REQUEST['to']." 23:59:59'";
	} break;

   case 'expiry' : {
	 if($_REQUEST['from'])	$where.= " AND tax_delivery>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND tax_delivery<'".$_REQUEST['to']." 23:59:59'";
	} break;

   case 'finish' : {
	 if($_REQUEST['from'])	$where.= " AND finish_datetime>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND finish_datetime<'".$_REQUEST['to']." 23:59:59'";
	} break;
  }
 }

 if(isset($_REQUEST['status']))			$where.= " AND status='".$_REQUEST['status']."'";
 if($_REQUEST['subjectid'])				$where.= " AND subject_id='".$_REQUEST['subjectid']."'";
 else if($_REQUEST['search'])			$where.= " AND subject_name='".$_REQUEST['search']."'";
 if($_REQUEST['ticket_type'])			$where.= " AND ticket_type='".$_REQUEST['ticket_type']."'";
 if($_REQUEST['ext_ticket_ref'])
 {
  if(strpos($_REQUEST['ext_ticket_ref'], "*") !== false)
   $where.= " AND ext_ticket_ref LIKE '".str_replace("*","%",$_REQUEST['ext_ticket_ref'])."'";
  else
   $where.= " AND (ext_ticket_ref='".$_REQUEST['ext_ticket_ref']."' OR ext_ticket_ref LIKE '"
	.$_REQUEST['ext_ticket_ref']."%' OR ext_ticket_ref LIKE '%".$_REQUEST['ext_ticket_ref']."%' OR ext_ticket_ref LIKE '%"
	.$_REQUEST['ext_ticket_ref']."')";
 }
 if($_REQUEST['operator_id'])			$where.= " AND operator_id='".$_REQUEST['operator_id']."'";
 if($_REQUEST['contact_id'])				$where.= " AND contact_id='".$_REQUEST['contact_id']."'";
 if($_REQUEST['zoneid'])					$where.= " AND zone_id='".$_REQUEST['zoneid']."'";
 else if($_REQUEST['zone'])				$where.= " AND zone LIKE '".$_REQUEST['zone']."%'";
 if($_REQUEST['techid'])					$where.= " AND (tech_1='".$_REQUEST['techid']."' OR tech_2='".$_REQUEST['techid']."')";

 $cmd.= " -where `".$where."`";
}

$_CMD = $cmd;
$ret = $_SERP->SendCommand($cmd);
$ticketlist = $ret['items'];
//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0);
?>
 <input type='button' class='button-blue' value="Fattura ticket selezionati" onclick="BillTickets()"/>
 </td>
 <td width='200'>
	<input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='mainmenubutton'/>
	<ul class='popupmenu' id='mainmenu'>
  	 <li onclick="BillTickets()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/new_file.png" height="16"/>Fattura ticket selezionati</li>
	 <li class='separator'>&nbsp;</li>
	 <li class='subitem'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Salva su Excel
	  <ul class='popupmenu'>
		<li onclick="ExportToExcel(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Esporta come lista</li>
		<li onclick="ExportRenderedServices(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Esporta resi servizi</li>
	  </ul>
	 </li>
	 <li onclick="Print(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/printer.gif"/>Stampa</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="CloneTicket()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/copy.png"/>Duplica ticket selezionati</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="DeleteSelected()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/trash.gif"/>Elimina ticket selezionati</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="gotoAboutConfig()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/cog.gif"/>Configurazione avanzata</li>
	</ul>

	<input type='button' class="button-gray menu" value="Visualizza" connect="viewmenu" id="viewmenubutton"/>
	<ul class='popupmenu' id='viewmenu'>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $checked = $col['visibled'] ? true : false;
	 echo "<li><input type='checkbox'".($checked ? " checked='true'" : "")." onchange=\"showColumn('".$col['field']."',this)\"/>".$col['title']."</li>";
	}
	?>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="saveGlobalSettings()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save.gif"/>Salva configurazione</li>
	</ul>
 </td>
 <td>&nbsp;</td>
 <td width='130'>
	<span class='smalltext'>Mostra</span>
	<input type='text' class='dropdown' id='rpp' value="<?php echo $_RPP; ?> righe" retval="<?php echo $_RPP; ?>" readonly='true' connect='rpplist' style='width:80px'/>
	<ul class='popupmenu' id='rpplist'>
	 <li value='10'>10 righe</li>
	 <li value='25'>25 righe</li>
	 <li value='50'>50 righe</li>
	 <li value='100'>100 righe</li>
	 <li value='250'>250 righe</li>
	 <li value='500'>500 righe</li>
	 <li value='1000'>1000 righe</li>
	 <li value='2000'>2000 righe</li>
	</ul>
 </td>
 <td width='223' align='right'>
	<?php $_SERP->DrawSerpButtons(true);
 
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
$leftContents.= "<div class='advanced-search-inner'>";
$leftContents.= "<table width='100%' cellspacing='5' cellpadding='0' border='0'>";
$leftContents.= "<tr><td>Tipo di interv.</td>";
$leftContents.= "<td><input type='text' class='dropdown' readonly='true' id='intervtype' connect='intervtypelist' style='width:140px' value='"
	.($_REQUEST['ticket_type'] ? $_TICKET_TYPE_BY_ID[$_REQUEST['ticket_type']]['name'] : 'Tutti')."' retval='".$_REQUEST['ticket_type']."'/>";
$leftContents.= "<ul class='popupmenu' id='intervtypelist'>";
$leftContents.= "<li value=''>Tutti</li>";

for($c=0; $c < count($_TICKET_TYPES); $c++)
 $leftContents.= "<li value='".$_TICKET_TYPES[$c]['id']."'>".$_TICKET_TYPES[$c]['name']."</li>";
$leftContents.= "</ul></td></tr>";

$leftContents.= "<tr><td>Status:</td>";
$leftContents.= "<td><input type='text' class='dropdown' id='show' connect='show-list' readonly='true' value='".(isset($_REQUEST['status']) ? $_STATUS[$_REQUEST['status']] : 'Tutti')."' style='width:140px'/>";
$leftContents.= "<ul class='popupmenu' id='show-list'>";
$leftContents.= "<li value=''>Tutti</li>";

reset($_STATUS);
while(list($k,$v)=each($_STATUS))
{
 $leftContents.= "<li value='".$k."'>".$v."</li>";
}
$leftContents.= "</ul></td></tr>";

$leftContents.= "<tr><td>Rif. Ticket:</td>";
$leftContents.= "<td><input type='text' class='edit' id='extticketref' style='width:140px' value=\"".$_REQUEST['ext_ticket_ref']."\"/></td></tr>";

$leftContents.= "<tr><td>Operatore:</td>";
$leftContents.= "<td><input type='text' class='dropdown' id='operator' connect='operatorlist' style='width:140px' readonly='true' value=\""
	.($_REQUEST['operator_id'] ? $_REQUEST['operator_name'] : 'Tutti')."\" retval='".$_REQUEST['operator_id']."'/>";
$leftContents.= "<ul class='popupmenu' id='operatorlist'>";
$leftContents.= "<li value=''>Tutti</li>";
for($c=0; $c < count($_OPERATORS); $c++)
 $leftContents.= "<li value='".$_OPERATORS[$c]['id']."'>".($_OPERATORS[$c]['fullname'] ? $_OPERATORS[$c]['fullname'] : $_OPERATORS[$c]['name'])."</li>";
$leftContents.= "</ul></td></tr>";

$leftContents.= "<tr><td>Tecnico:</td>";
$leftContents.= "<td><input type='text' class='contact' id='technician' style='width:140px' value=\"".$_REQUEST['techname']."\" refid=\"".$_REQUEST['techid']."\" ct='employees' limit='20'/></td></tr>";

$leftContents.= "<tr><td>Indirizzo:</td>";
if($_REQUEST['contact_id'])
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT name FROM dynarc_rubrica_addresses WHERE id='".$_REQUEST['contact_id']."'");
 $db->Read();
 $_REQUEST['address'] = $db->record['name'];
 $db->Close();
}
$leftContents.= "<td><input type='text' class='search' id='address' style='width:140px' value=\"".$_REQUEST['address']."\" refid=\"".$_REQUEST['contact_id']."\" subjid='".$_REQUEST['subjectid']."' limit='20'/></td></tr>";

$leftContents.= "<tr><td>Citt&agrave;</td>";
$leftContents.= "<td><input type='text' class='edit' id='city' style='width:140px' value=\"".$_REQUEST['city']."\"/></td></tr>";

$leftContents.= "<tr><td>Provincia</td>";
$leftContents.= "<td><input type='text' class='edit' id='province' style='width:140px' value=\"".$_REQUEST['province']."\"/></td></tr>";

$leftContents.= "<tr><td>Zona:</td>";
$leftContents.= "<td><input type='text' class='search' id='zone' style='width:140px' value=\"".$_REQUEST['zone']."\" refid=\"".$_REQUEST['zoneid']."\" ap='ticketzones' limit='20'/></td></tr>";

$leftContents.= "<tr><td>&nbsp;</td><td><input type='button' class='button-gray' value='Reset' onclick='ResetSearch()'/></td></tr>";

$leftContents.= "</table>";
$leftContents.= "</div>";
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("fullspace");
//-------------------------------------------------------------------------------------------------------------------//
?>
<table width="100%" height="80%" cellspacing="0" cellpadding="0" border="0" id="template-outer-mask">
 <tr><td class="bg-lightgray" style="width:270px;<?php if($_REQUEST['hideleftsection']) echo 'display:none'; ?>" valign="top" id="template-left-section">
	<div class='advanced-search-title'><img src="<?php echo $_ABSOLUTE_URL; ?>Tickets/img/search.png"/> RICERCA AVANZATA
	 <img src="<?php echo $_ABSOLUTE_URL; ?>Tickets/img/hidearrow.png" style="float:right;margin-top:12px;cursor:pointer" title="Nascondi barra laterale" onclick="HideLeftSection()"/>
	</div>
	<?php
	echo $leftContents;
	showMainMenu($template);
	?>
	</td>
	<td style="width:8px" valign="top"><div class="vertical-gray-separator" id="template-left-bar" <?php if($_REQUEST['hideleftsection']) echo "style='cursor:pointer' onclick='ShowLeftSection()' title='Mostra barra laterale'"; ?>></div></td>
	<td class="page-contents" valign="top">
	 <div class="page-contents-body">
	  <!-- START OF PAGE ------------------------------------------------------------------------->
	  <div class="titlebar blue-bar"><span class="titlebar blue-bar">TICKET DA FATTURARE</span></div>


<table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='ticketlist' noprinthidden='true'>
<tr><th width='16'><input type='checkbox'/></th>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $visibled = $col['visibled'] ? true : false;
	 echo "<th".(!$visibled ? " style='display:none'" : "");
	 if($col['width'])			echo " width='".$col['width']."'";
	 if($col['field'])			echo " field='".$col['field']."'";
	 if($col['format'])			echo " format='".$col['format']."'";
	 if($col['sortable'])		echo " sortable='true'";
	 echo ">".$col['title']."</th>";
	}
	?>
	<th width='22'>&nbsp;</th>
	<th width='22'>&nbsp;</th>
</tr>
<?php
$_TOT_AMOUNT = 0;
$_TOT_VAT = 0;
$_TOT_TOTAL = 0;
$row = 0;
for($c=0; $c < count($ticketlist); $c++)
{
 $item = $ticketlist[$c];
 $hint = $item['name']." - ".$item['subject_name'].($item['ext_ticket_ref'] ? " - Rif. ".$item['ext_ticket_ref'] : "");
 $_ADDRESS_VALUES = array(
	 $item['addr_code'],
	 $item['addr_title'],
	 $item['addr_address'],
	 $item['addr_city'],
	 $item['addr_zipcode'],
	 $item['addr_province'],
	 $item['addr_cc'],
	 $item['addr_note']
	);
 $address = str_replace($_ADDRESS_KEYS, $_ADDRESS_VALUES, $_ADDRESS_SCHEMA);
 $item['address'] = $address;

 $_PDF_VALUES = array(
	 $item['code_num'],
	 date('d/m/Y',$item['ctime']),
	 date('H:i',$item['ctime']),
	 $item['ext_ticket_ref'],
	 $item['type_name'],
	 $item['subject_name'],
	 $item['address'],
	 $item['zone'],
	 $item['finish_datetime'] ? date('d/m/Y',strtotime($item['finish_datetime'])) : "",
	 $item['finish_datetime'] ? date('H:i',strtotime($item['finish_datetime'])) : "",
	 $item['operator_name'],
	 $item['tech_1_name'],
	 $item['tech_2_name'],
	 $item['tax_delivery'] ? date('d/m/Y',strtotime($item['tax_delivery'])) : "",
	 $item['addr_code'],
	 $item['addr_title'],
	 $item['addr_address'],
	 $item['addr_city'],
	 $item['addr_zipcode'],
	 $item['addr_province'],
	 $item['addr_cc'],
	 $item['addr_note']
	);
 $_PDF_FILENAME = str_replace($_REF_KEYS, $_PDF_VALUES, $_PDF_SCHEMA);
 $_PDF_FILENAME = str_replace("/","-",$_PDF_FILENAME);


 echo "<tr class='row".$row."' id='".$item['id']."' title=\"".$hint."\"><td><input type='checkbox'/></td>";
 for($i=0; $i < count($_COLUMNS); $i++)
 {
  $col = $_COLUMNS[$i];
  $visibled = $col['visibled'] ? true : false;
  echo "<td".(!$visibled ? " style='display:none'>" : ">");
  switch($col['field'])
  {
   case 'code_num' : echo "<a class='link blue' href='".$_ABSOLUTE_URL.$_EDIT_TICKET_FORM."?id=".$item['id']."' target='TKT-".$item['id']."'>".$item['code_num']."</a>"; break;
   case 'ctime' : echo "<a class='link blue' href='".$_ABSOLUTE_URL.$_EDIT_TICKET_FORM."?id=".$item['id']."' target='TKT-".$item['id']."'>".date('d/m/Y',$_SEARCH_BY_ADDRESS ? strtotime($item['ctime']) : $item['ctime'])."</a>"; break;
   case 'tax_delivery' : echo $item['tax_delivery'] ? date('d/m/Y',strtotime($item['tax_delivery'])) : "&nbsp;"; break;
   case 'finish_datetime' : echo date('d/m/Y',strtotime($item['finish_datetime'])); break;
   case 'subject_name' : echo $item['subject_name'] ? $item['subject_name'] : "&nbsp;"; break;
   case 'ticket_type' : echo $item['type_name'] ? $item['type_name'] : "&nbsp;"; break;
   case 'contact_id' : echo $item['address'] ? $item['address'] : '&nbsp;'; break;
   case 'zone' : echo $item['zone'] ? $item['zone'] : "&nbsp;"; break;
   case 'ext_ticket_ref' : echo "<a class='link blue' href='".$_ABSOLUTE_URL.$_EDIT_TICKET_FORM."?id=".$item['id']."' target='TKT-".$item['id']."'>"
	.($item['ext_ticket_ref'] ? $item['ext_ticket_ref'] : '&nbsp;')."</a>"; break;
   case 'operator_id' : echo $item['operator_name'] ? $item['operator_name'] : "&nbsp;"; break;
   case 'hw_name' : echo $item['hw_name'] ? $item['hw_name'] : "&nbsp;"; break;
   case 'shelf' : echo $item['shelf'] ? $item['shelf'] : "&nbsp;"; break;
   case 'amount' : echo number_format($item['amount'],2,',','.'); break;
   case 'vat' : echo number_format($item['vat'],2,',','.'); break;
   case 'total' : echo number_format($item['total'],2,',','.'); break;
   case 'status' : echo $_STATUS[$item['status']]; break;
   case 'note' : echo $item['note'] ? $item['note'] : "&nbsp;"; break;
  }
  echo "</td>";
 }
 echo "<td><img src='".$_ABSOLUTE_URL."share/icons/16x16/printer.gif' onclick='PrintTicket(".$item['id'].",\""
	.$_PDF_FILENAME."\")' style='cursor:pointer' title='Stampa'/></td>";
 if($item['send_datetime'])
  echo "<td><img src='".$_ABSOLUTE_URL."Tickets/img/emailsent.png' onclick='SendMail(".$item['id'].",\"".$_PDF_FILENAME."\")' style='cursor:pointer' title='Ticket inviato il ".date('d/m/Y H:i')."'/></td>";
 else
  echo "<td><img src='".$_ABSOLUTE_URL."Tickets/img/sendmail.png' onclick='SendMail(".$item['id'].",\"".$_PDF_FILENAME."\")' style='cursor:pointer' title='Invia x email'/></td>";
 echo "</tr>";
 $_TOT_AMOUNT+= $item['amount'];
 $_TOT_VAT+= $item['vat'];
 $_TOT_TOTAL+= $item['total'];
 $row = $row ? 0 : 1;
}
?>
</table>

<div class="totals-footer">
 <table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr><td rowspan='2' valign='middle'><input type='button' class='button-blue' value="Stampa" onclick="Print()"/></td>
	  <td align='center'><span class='smalltext'>n. documenti</span></td>
	  <td align='center'><span class='smalltext'>Tot. Imonibile</span></td>
	  <td align='center'><span class='smalltext'>Tot. IVA</span></td>
	  <td align='right'><span class='smalltext'>Totale</span></td></tr>
  <tr><td align='center'><span class='smalltext' id='foot-ndocs'><?php echo count($ticketlist); ?></span></td>
	  <td align='center'><span class='smalltext' id='foot-totamount'><?php echo number_format($_TOT_AMOUNT,2,',','.'); ?> &euro;</span></td>
	  <td align='center'><span class='smalltext' id='foot-totvat'><?php echo number_format($_TOT_VAT,2,',','.'); ?> &euro;</span></td>
	  <td align='right'><span class='bigtext' id='foot-tottotal'><b><?php echo number_format($_TOT_TOTAL,2,',','.'); ?> &euro;</b></span></td></tr>
 </table>
</div>


	  <!-- END OF PAGE --------------------------------------------------------------------------->
	 </div>
	</td>
 </tr>
</table>

<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
/*-------------------------------------------------------------------------------------------------------------------*/
$excelExportStatusArgStr = "";
reset($_STATUS);
while(list($k,$v) = each($_STATUS))
 $excelExportStatusArgStr.= ";".$k."=".$v;
$excelExportStatusArgStr = ltrim($excelExportStatusArgStr, ";");

?>
<script>
var AP = "<?php echo $_AP; ?>";
var ON_PRINTING = false;
var ON_EXPORT = false;
var ATTACH_PDF = <?php echo $config['sendmail']['attachpdf'] ? 'true' : 'false'; ?>;

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL;
	return false;
}

Template.OnInit = function(){
 /* AUTORESIZE */
 var sH = this.getScreenHeight();
 var tb = document.getElementById("template-outer-mask");
 if(tb.offsetHeight < (sH-115))
  tb.style.height = (sH-115)+"px";
 /* EOF - AUTORESIZE */

	this.initEd(document.getElementById('rpp'), "dropdown").onchange = function(){
		 Template.SERP.RPP = this.getValue();
		 Template.SERP.reload(0);
		}


	this.initEd(document.getElementById("search"), "contactextended").OnSearch = function(){
			 Template.SERP.setVar("refap","");
			 Template.SERP.setVar("refid",0);
			 if(this.value && this.data)
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",this.data['id']);
			 }
			 else
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",0);
			 }
			 Template.SERP.reload(0);
			};
	this.initBtn(document.getElementById("searchbtn")).onclick = function(){document.getElementById("search").OnSearch();}

	this.initBtn(document.getElementById('mainmenubutton'), 'popupmenu');
	this.initBtn(document.getElementById('viewmenubutton'), 'popupmenu');

	this.initEd(document.getElementById('show'), "dropdown").onchange = function(){
		 if(this.getValue() == "")
		  Template.SERP.unsetVar("status");
		 else
		  Template.SERP.setVar("status",this.getValue());
		 Template.SERP.reload(0);
		};


	this.initEd(document.getElementById("datefrom"), "date");
	this.initEd(document.getElementById("dateto"), "date").OnDateChange = function(date){
		 Template.SERP.setVar("from",document.getElementById("datefrom").isodate);
		 Template.SERP.setVar("to",date);
		 Template.SERP.reload();
		};

	this.initEd(document.getElementById('datefilter'), 'dropdown').onchange = function(){
		 Template.SERP.setVar('datefilter',this.getValue());
		};

	this.initEd(document.getElementById('intervtype'), 'dropdown').onchange = function(){
		 Template.SERP.setVar("ticket_type", this.getValue());
		 Template.SERP.reload(0);
		};

	this.initEd(document.getElementById('operator'), 'dropdown').onchange = function(){
		 Template.SERP.setVar("operator_id", this.getValue());
		 Template.SERP.reload(0);
		};

	this.initEd(document.getElementById("technician"), "contact").onchange = function(){
		 Template.SERP.setVar("techid", this.getId());
		 Template.SERP.setVar("techname", this.value);
		 Template.SERP.reload(0);
		};

	document.getElementById('extticketref').onchange = function(){Template.SERP.setVar("ext_ticket_ref",this.value);Template.SERP.reload(0);}; 
	document.getElementById('city').onchange = function(){Template.SERP.setVar("city",this.value); Template.SERP.reload(0);}
	document.getElementById('province').onchange = function(){Template.SERP.setVar("province",this.value); Template.SERP.reload(0);}

	this.initEd(document.getElementById('address'), "address").OnSearch = function(){
		 Template.SERP.setVar("contact_id", this.getId());
		 Template.SERP.reload(0);
		};

	document.getElementById('address').OnFreeSearch = function(){
		 Template.SERP.unsetVar("contact_id");
		 Template.SERP.setVar("address",this.value);
		 Template.SERP.reload(0);
		}

	this.initEd(document.getElementById('zone'), 'itemfind').onchange = function(){
		 Template.SERP.setVar("zoneid", this.getId());
		 Template.SERP.setVar("zone", this.value);
		 Template.SERP.reload(0);
		};

	this.SERP = new SERP("<?php echo $_SERP->OrderBy; ?>", "<?php echo $_SERP->OrderMethod; ?>", "<?php echo $_SERP->RPP; ?>", "<?php echo $_SERP->PG; ?>");
	this.initSortableTable(document.getElementById("ticketlist"), this.SERP.OrderBy, this.SERP.OrderMethod).OnSort = function(field, method){
		Template.SERP.OrderBy = field;
	    Template.SERP.OrderMethod = method;
		Template.SERP.reload(0);
	}
}

function NewTicket()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 document.location.href = ABSOLUTE_URL+"Tickets/ticketinfo.php?id="+a['id'];
	}
 sh.sendCommand("dynarc new-item -ap tickets");
}

function PrintTicket(docId, pdfFileName, callback)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 var sh2 = new GShell();
	 sh2.OnError = function(err){alert(err);}
	 sh2.OnOutput = function(){ if(callback) callback(docId); }
	 sh2.sendCommand("dynarc edit-item -ap `"+AP+"` -id `"+docId+"` -extset `ticketinfo.printdate='now',printfile='"+a['fullname']+"'`");
	}
 sh.sendCommand("dynarc item-info -ap `"+AP+"` -id `"+docId+"` || gframe -f print.preview -params `modelap=printmodels&modelct=tickets&parser=ticket&id="+docId+"` -title `"+pdfFileName+"`");
}

function SendMail(docId, pdfFileName, bypassConfirm)
{
 if(!bypassConfirm)
 {
  if(!confirm("Desideri inviare questo ticket per email al cliente?"))
   return;
 }

 var tb = document.getElementById("ticketlist");
 var r = tb.getRowById(docId);
 var img = r.cells[r.cells.length-1].getElementsByTagName('IMG')[0];
 img.src = ABSOLUTE_URL+"Tickets/img/small-loading.gif";
 img.title = "Invio email in corso, attendere...";
 img.onclick = null;
 img.setAttribute('refid',docId);
 

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 var mtime = new Date(); mtime.setTime(parseFloat(a['mtime'])*1000);
	 var printTime = new Date(); printTime.setFromISO(a['print_datetime']);
	 if(ATTACH_PDF && (printTime.getTime() < mtime.getTime()))
	  return PrintTicket(docId, pdfFileName, function(){SendMail(docId, pdfFileName, true);});
	 
	 var sh2 = new GShell();
	 sh2.OnError = function(err){alert(err);}
	 sh2.OnOutput = function(){
		 // ripristina icona
		 img.src = ABSOLUTE_URL+"Tickets/img/emailsent.png";
		 img.title = "Email inviata!";
		 img.onclick = function(){SendMail(this.getAttribute('refid'), pdfFileName);}
		}
	 sh2.sendCommand("ticket sendmail -id '"+docId+"' --only-preview || gframe -f tickets/sendmail -c *.message --use-cache-contents -params 'refap="+AP+"&refid="+docId+"&sender='+*.sender+'&sendername='+*.sendername+'&recp='+*.recp+'&subject='+*.subject+'&attach1='+*.attachments[0]+'&attach2='+*.attachments[1]");
	}
 sh.sendCommand("dynarc item-info -ap '"+AP+"' -id '"+docId+"' -get `print_datetime,print_filename`");
}

function setFilter(filter)
{
 Template.SERP.setVar("filter",filter);
 Template.SERP.reload();
}

function showColumn(field,cb)
{
 var tb = document.getElementById("ticketlist");
 if(cb.checked == true)
  tb.showColumn(field);
 else
  tb.hideColumn(field);
}

function ExportToExcel(btn)
{
 document.getElementById('mainmenubutton').popupmenu.hide();
 var cmd = "<?php echo $_CMD; ?> --order-by `<?php echo $_SERP->OrderBy.' '.$_SERP->OrderMethod; ?>`";
 cmd+= " || tableize *.items";
 cmd+= " -k `type_name,code_num,ext_ticket_ref,ctime,tax_delivery,app_datetime,finish_datetime,subject_code,subject_name";
 cmd+= ",address,addr_code,addr_title,addr_address,addr_city,addr_province,zone,operator_name";
 cmd+= ",tech_1_name,tech_2_name,hw_name,shelf,request,datatosave,accessories,status,amount,vat,total,note`";

 cmd+= " -n `TIPOLOGIA|COD. TICKET|RIF. TICKET|DATA APERT.|SCADENZA|APPUNTAMENTO|DATA CHISURA|COD. CLIENTE|CLIENTE|INDIRIZZO COMPLETO|COD. INDIRIZZO|INSEGNA|INDIRIZZO|CITTA|PROVINCIA|ZONA|OPERATORE|TECNICO 1|TECNICO 2|HARDWARE|SCAFFALE|RICHIESTA|DATI DA SALVARE|ACCESSORI RITIRATI|STATUS|IMPONIBILE|IVA|TOTALE|NOTE`";

 cmd+= " -f `string|string|string|date|date|date|date|string|string|string|string|string|string|string|string|string|string|string|string|string|string|string|string|string|option{<?php echo $excelExportStatusArgStr; ?>}|currency|currency|currency|string`";

 cmd+= " | gframe -f excel/export -params `file=lista_ticket` -c";

 var sh = new GShell();
 sh.showProcessMessage("Esportazione dei tickets in Excel", "Attendere prego, è in corso l'esportazione dei tickets su file Excel.");
 sh.OnError = function(err){this.processMessage.error(err);}
 sh.OnOutput = function(o,a){
	 this.hideProcessMessage();
	 if(!a) return;
	 var fileName = a['filename'];
	 document.location.href = ABSOLUTE_URL+"getfile.php?file="+fileName;
	}
 sh.sendCommand(cmd);
}

function ExportRenderedServices(btn)
{
 document.getElementById('mainmenubutton').popupmenu.hide();
 var tb = document.getElementById("ticketlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun ticket selezionato");

 var ids = "";
 if(sel.length) // esporta solo i selezionati
 {
  for(var c=0; c < sel.length; c++)
   ids+= ","+sel[c].id;
  ids = ids.substr(1);
 }

 var sh = new GShell();
 sh.showProcessMessage("Esportazione dei tickets in Excel", "Attendere prego, è in corso l'esportazione dei tickets su file Excel.");
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 this.hideProcessMessage();
	 if(!a) return;
	 var fileName = a['filename'];
	 document.location.href = ABSOLUTE_URL+"getfile.php?file="+fileName;
	}
 sh.sendCommand("ticket export-exploded -f resi_servizi.xlsx -ids `"+ids+"`");
}

function Print(btn)
{
 var doc = new GnujikoPrintableDocument("TICKET DA FATTURARE", "A4");

 var dateFrom = new Date();
 var dateTo = new Date();
 dateFrom.setFromISO(document.getElementById("datefrom").isodate);
 dateTo.setFromISO(document.getElementById("dateto").isodate);

 var header = "<div style='width:190mm' class='defaultheader'><h3>TICKET DA FATTURARE - dal "+dateFrom.printf('d/m/Y')+" al "+dateTo.printf('d/m/Y')+"</h3></div>";
 doc.setDefaultPageHeader(header);

 var footer = "<div style='width:190mm;margin-top:10mm' class='defaultfooter'>";
 footer+= "<table width='100%' cellspacing='0' cellpadding='0' border='0' class='footertable'>";
 footer+= "<tr><td style='width:60mm'>Pag.</td>";
 footer+= "<td style='width:30mm;text-align:center'>n. documenti</td>";
 footer+= "<td style='width:30mm;text-align:center'>Tot. imponibile</td>";
 footer+= "<td style='width:30mm;text-align:center'>Tot. IVA</td>";
 footer+= "<td style='width:30mm;text-align:center'>Totale</td></tr>";

 footer+= "<tr><td>{PGC}</td>";
 footer+= "<td style='text-align:center'>"+document.getElementById('foot-ndocs').innerHTML+"</td>";
 footer+= "<td style='text-align:center'>"+document.getElementById('foot-totamount').innerHTML+"</td>";
 footer+= "<td style='text-align:center'>"+document.getElementById('foot-totvat').innerHTML+"</td>";
 footer+= "<td style='text-align:center'>"+document.getElementById('foot-tottotal').innerHTML+"</td></tr>";

 footer+= "</table></div>";

 doc.setDefaultPageFooter(footer);
 doc.includeCSS("var/objects/printmanager/printabletable.css");

 var gpt = new GnujikoPrintableTable(document.getElementById('ticketlist'),true,true);
 var ppc = gpt.generatePrintPreview(190);
 for(var c=0; c < ppc.length; c++)
 {
  var page = doc.addPage();
  page.footer = page.footer.replace("{PGC}", (c+1)+"/"+ppc.length);
  page.setContents(ppc[c]);
 }

 doc.printAsPDF();
 document.location.href = "#search";
}

function DeleteSelected()
{
 var tb = document.getElementById("ticketlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun ticket selezionato");
 if(!confirm("Sei sicuro di voler eliminare i ticket selezionati?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload(0);}
 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= " -id '"+sel[c].id+"'";
 sh.sendCommand("dynarc delete-item -ap tickets -r"+q);
}

function saveGlobalSettings()
{
 var xml = "<ticketlist";
 var visibledColumns = "";
 var rpp = document.getElementById('rpp').getValue();

 var tb = document.getElementById("ticketlist");
 for(var c=0; c < tb.fields.length; c++)
 {
  var th = tb.fields[c];
  if(th.style.display != "none")
   visibledColumns+= ","+th.getAttribute('field');
 }
 if(visibledColumns)
  xml+= " visibledcolumns='"+visibledColumns.substr(1)+"'";

 xml+= " rpp='"+rpp+"'";
 xml+= "/"+">";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){alert("Configurazione salvata");}
 sh.sendSudoCommand("aboutconfig set-config -app tickets -sec ticketlist -xml-settings `"+xml+"`");
}

function BillTickets()
{
 var tb = document.getElementById("ticketlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun ticket selezionato");

 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= ","+sel[c].id;
 
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(a['invoices'])
	 {
	  alert("Sono state generate "+a['invoices'].length+" fatture.");
	  document.location.reload();
	 }
	 else
	 {
	  OpenDocument(a['id']);
	  document.location.reload();
	 }
	}
 sh.sendCommand("ticket generate-invoice -ap `<?php echo $_AP; ?>` -ids "+q.substr(1));

}

function OpenDocument(id)
{
 window.open(ABSOLUTE_URL+"GCommercialDocs/docinfo.php?id="+id, "GCD-"+id);
}

function HideLeftSection()
{
 document.getElementById("template-left-section").style.display = "none";
 var tlb = document.getElementById('template-left-bar');
 tlb.style.cursor = "pointer";
 tlb.title = "Mostra barra laterale";
 tlb.onclick = function(){ShowLeftSection();}
 Template.SERP.setVar("hideleftsection",'true');
}

function ShowLeftSection()
{
 document.getElementById("template-left-section").style.display = "";
 var tlb = document.getElementById('template-left-bar');
 tlb.style.cursor = "default";
 tlb.title = "";
 tlb.onclick = null;
 Template.SERP.unsetVar("hideleftsection");
}

function ResetSearch()
{
 document.getElementById('intervtype').setValue("Tutti","");
 Template.SERP.unsetVar("ticket_type");

 document.getElementById('show').setValue("Tutti","");
 Template.SERP.unsetVar("status");

 document.getElementById('extticketref').value = "";
 Template.SERP.unsetVar("ext_ticket_ref");

 document.getElementById('operator').setValue("Tutti","");
 Template.SERP.unsetVar("operator_id");

 document.getElementById("technician").value = "";
 Template.SERP.unsetVar("techid");
 Template.SERP.unsetVar("techname");

 document.getElementById('address').value = "";
 Template.SERP.unsetVar("contact_id");
 Template.SERP.unsetVar("address");

 document.getElementById('city').value = "";
 Template.SERP.unsetVar("city");

 document.getElementById('province').value = "";
 Template.SERP.unsetVar("province");

 document.getElementById('zone').value = "";
 Template.SERP.unsetVar("zone");
 Template.SERP.unsetVar("zoneid");

}

function CloneTicket()
{
 var tb = document.getElementById("ticketlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun ticket selezionato");
 if(!confirm("Sei sicuro di voler duplicare i ticket selezionati?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload(0);}
 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= " -id '"+sel[c].id+"'";
 sh.sendCommand("ticket clone"+q);
}

function gotoAboutConfig()
{
 window.open(ABSOLUTE_URL+"aboutconfig/tickets/");
}
</script>
<?php
$template->End();

