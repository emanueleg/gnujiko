<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 11-11-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Official Gnujiko Ticket System
 #VERSION: 2.6beta
 #CHANGELOG: 12-11-2016 : Aggiunto campo priority.
			 11-06-2016 : Aggiunto variabile globale ABOUT_CONFIG.
			 17-05-2016 : Integrazione con config-custom.
			 07-01-2015 : Aggiunto richieste di assistenza.
			 15-10-2014 : Aggiornato sistema di status.
			 07-10-2014 : Aggiunto status 9 - Annullato.
 #TODO:
 
*/

global $_BASE_PATH, $_SHELL_CMD_PATH, $_ABOUT_CONFIG;
include_once($_BASE_PATH."include/userfunc.php");

/* GET CONFIG */
$ret = GShell("aboutconfig get-config -app tickets");
if(!$ret['error'])
 $_ABOUT_CONFIG = $ret['outarr']['config'];

$ret = GShell("dynarc item-count -ap tickets -where `closed='1' AND invoice_id='0' AND status='100'`");
$toBeBilledCount = $ret['outarr']['count'];

$_APPLICATION_CONFIG = array(
	"appname"=>"Tickets",
	"basepath"=>"Tickets/",
	"mainmenu"=>array(
	 0 => array('title'=>'Elenco ticket', 'url'=>'index.php', 'icon'=>'icons/open-tickets.png'),
	 1 => array('title'=>'Ticket da fatturare', 'url'=>'tobebilled.php', 'icon'=>'icons/tobebilled.png', 'counter'=>$toBeBilledCount),
	 2 => array('title'=>'Calendario appuntamenti', 'url'=>'appointments.php', 'icon'=>'icons/appointments.png')
	)
);

if($_ABOUT_CONFIG['extrequest']['enabled'])
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT COUNT(*) FROM extreqtickets WHERE ticket_id='0'");
 $db->Read();
 $extReqCount = $db->record[0];
 $db->Close();

 $_APPLICATION_CONFIG['mainmenu'][] = array('title'=>'Richieste di assistenza', 'url'=>'requests.php', 'icon'=>'icons/open-tickets.png', 'counter'=>$extReqCount);
}

/* TICKET STATUS */
$_APPLICATION_CONFIG['ticketstatus'] = array(
 /* INCEPTION PHASE - from 0 to 31 */
 0  => array("code"=>"OPEN", "name"=>"Aperto"),
 10 => array("code"=>"DAPIAN", "name"=>"Da pianificare"),
 20 => array("code"=>"ANN", "name"=>"Annullato"),

 /* ELABORATION PHASE - from 32 to 63 */
 32 => array("code"=>"PIAN", "name"=>"Pianificato"),

 /* CONTRUCTION PHASE - from 64 to 95 */
 64 => array("code"=>"ATTP", "name"=>"In attesa parti"),
 70 => array("code"=>"LAV", "name"=>"In lavorazione"),
 80 => array("code"=>"CTRL", "name"=>"Da controllare"),
 90 => array("code"=>"SOSP", "name"=>"Sospeso"),

 /* TRANSITION PHASE - from 96 to 127 */
 96 => array("code"=>"OK", "name"=>"Chiuso non fatturabile"),
 100 => array("code"=>"DAFAT", "name"=>"Chiuso da fatturare"),
 110 => array("code"=>"FAT", "name"=>"Chiuso - fatturato")

);

/* TICKET PRIORITY */
$_APPLICATION_CONFIG['ticketpriority'] = array(
 0 => array("name"=>"Bassa"),
 128 => array("name"=>"Media"),
 255 => array("name"=>"Alta")
);

/* INCLUDE CUSTOM CONFIG FILE */
if(file_exists($_BASE_PATH."Tickets/config-custom.php"))
 include($_BASE_PATH."Tickets/config-custom.php");

function showMainMenu($template)
{
 global $_ABSOLUTE_URL;
 echo "<ul class='glight-main-menu'>";
 for($c=0; $c < count($template->config['mainmenu']); $c++)
 {
  $itm = $template->config['mainmenu'][$c];
  if(!$itm['url'] || !$itm['title'])
  {
   // is separator
   echo "<li class='separator'>&nbsp;</li>";
   continue;
  }

  $url = $template->config['basepath'].$itm['url'];
  $active = ($template->cache['mainmenuselidx'] == $c) ? true : false;
  echo "<a href='".$_ABSOLUTE_URL.$url."'><li class='item".($active ? " selected" : "")."'>";
  echo "<img src='".$_ABSOLUTE_URL.$template->config['basepath'].$itm['icon']."'/>";
  echo "<span class='item-title-singleline'>".$itm['title']."</span>";
  if($itm['counter'])
   echo "<em>".$itm['counter']."</em>";
  echo "</li></a>";
 }
 echo "</ul>";
}

