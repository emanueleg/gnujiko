<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 17-06-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Anteprima Email.
 #VERSION: 2.2beta
 #CHANGELOG: 17-06-2016 : Esteso fino a 5 allegati.
			 07-06-2016 : Bug fix usecachecontents.
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate("widget");
$template->includeObject("editsearch");
$template->includeObject("fckeditor");
$template->includeInternalObject("contactsearch");
$template->includeInternalObject("attachments");

$template->Begin("Anteprima dell&lsquo;email");
//-------------------------------------------------------------------------------------------------------------------//
$_SENDER = $_REQUEST['sendername'] ? $_REQUEST['sendername'].($_REQUEST['sender'] ? " <".$_REQUEST['sender'].">" : "") : $_REQUEST['sender'];
$_RECP = $_REQUEST['recp'];
$_SUBJECT = $_REQUEST['subject'];
$_MESSAGE = $_REQUEST['contents'];
$_REF_AP = $_REQUEST['refap'];
$_REF_ID = $_REQUEST['refid'];

//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-header bg-blue"><h3>Invia email</h3></div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",800);

//-------------------------------------------------------------------------------------------------------------------//
?>
<style type="text/css">
div.attachments-container {
	background: #ffffff;
	border: 1px solid #d8d8d8;
	padding: 5px;
}
</style>

<div class="glight-widget-body" style="width:784px;height:470px">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td width='300'><label>MITTENTE</label><br/>
	 <input type="text" class="edit" id="sender" style="width:280px" value="<?php echo $_SENDER; ?>"/>
	</td>
	<td><label>DESTINATARIO</label><br/>
	 <input type='text' class='edit' id="recp" style='width:280px' id='recp' value="<?php echo $_RECP; ?>"/>
	</td>
	<td rowspan='5' valign='top' style='vertical-align:top;padding-left:10px'>
	 <label>ALLEGATI</label><br/>
	 <?php
	 $Attachments = new GLAttachments();
	 $Attachments->height = "415px";
	 if($_REQUEST['attachment'])	$Attachments->AddFile($_REQUEST['attachment']);
	 if($_REQUEST['attach1'])		$Attachments->AddFile($_REQUEST['attach1']);
	 if($_REQUEST['attach2'])		$Attachments->AddFile($_REQUEST['attach2']);
	 if($_REQUEST['attach3'])		$Attachments->AddFile($_REQUEST['attach3']);
	 if($_REQUEST['attach4'])		$Attachments->AddFile($_REQUEST['attach4']);
	 if($_REQUEST['attach5'])		$Attachments->AddFile($_REQUEST['attach5']);
	 echo "<div class='attachments-container' id='attachments' style='height:415px;margin-bottom:10px'>";
	 $Attachments->Paint();
	 echo "</div>";
	 ?>
	<input type='button' class='button-blue' value="Carica un allegato" id="attachbtn" connect='attachments'/>
	</td>
</tr>
<tr><td colspan='2'><label>OGGETTO</label><br/>
	 <input type='text' class='edit' id='subject' style='width:580px' value="<?php echo $_SUBJECT; ?>"/>
	</td>
</tr>

<tr class='separator'><td colspan="2"><hr style="width:620px"/></td></tr>

<tr><td colspan='2' valign='top'><label>MESSAGGIO</label><br/>
	 <textarea class="textarea" id="message" style="width:580px;height:200px"><?php echo $_MESSAGE; ?></textarea>
    </td>
</tr>

<tr><td colspan='2' valign='top'><label>FIRMA</label><br/>
	 <textarea class="textarea" id="firm" style="width:580px;height:100px">
	 <?php
	 $ret = GShell("aboutconfig get-config -app sendmail",$_REQUEST['sessid'],$_REQUEST['shellid']);
	 if(!$ret['error'])
	 {
	  $config = $ret['outarr']['config'];
	  if($config['firm'] && $config['firm']['ap'] && $config['firm']['id'])
	  {
	   $ret = GShell("dynarc item-info -ap '".$config['firm']['ap']."' -id '".$config['firm']['id']."'",$_REQUEST['sessid'],$_REQUEST['shellid']);
	   if(!$ret['error']) echo $ret['outarr']['desc'];
	  }
	 }
	 ?>
	 </textarea>
    </td>
</tr>

</table>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$footer = "<input type='button' class='button-gray' value='Annulla' style='float:left;' onclick='Template.Exit()'/>";
$footer.= "<input type='button' class='button-blue' value='Invia &raquo;' style='float:right' onclick='SendMail(this)'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_REF_AP; ?>";
var ID = "<?php echo $_REF_ID; ?>";
var ONSEND = false;

Template.OnInit = function(){
	this.initEd(document.getElementById("firm"), "fckeditor", "Basic");
	this.initBtn(document.getElementById("attachbtn"), "attachupld").OnUpload = function(){};
}

function gframe_cachecontentsload(cnts)
{
 document.getElementById('message').innerHTML = cnts;
 Template.initEd(document.getElementById("message"), "fckeditor", "Basic");
}

function SendMail(btn)
{
 if(ONSEND)
  return alert("Invio in corso, attendere...");
 if(btn)
  btn.value = "Invio in corso...";
 ONSEND = true;

 var subject = document.getElementById('subject').value;
 var sender = document.getElementById('sender').value;
 var recp = document.getElementById('recp').value;
 var senderName = "";
 var senderEmail = "";
 if(sender && (sender.indexOf('<') > -1) && (sender.indexOf('>') > -1))
 {
  var s = sender.indexOf('<');
  var e = sender.indexOf('>');
  var l = e-s;
  senderName = sender.substr(0,s).trim();
  senderEmail = sender.substr(s+1, l-1).trim();
 }
 else
  senderEmail = sender;

 var msg = document.getElementById("message").getValue();
 var firm = document.getElementById("firm").getValue();
 if(firm) msg+= "<br/"+"><br/"+">"+firm;

 var attlist = document.getElementById("attachbtn").getAttachments();
 var attachQ = "";
 for(var c=0; c < attlist.length; c++)
  attachQ+= " -attachment `"+attlist[c]+"`";
  
 var sh = new GShell();
 sh.OnError = function(err){alert(err); ONSEND = false; if(btn) btn.value = "Invia &raquo;";}
 sh.OnOutput = function(o,a){gframe_close(o,a);}
 sh.sendCommand("ticket sendmail -ap '"+AP+"' -id '"+ID+"' -from `"+senderEmail+"` -fromname `"+senderName+"` -recp `"+recp+"` -subject `"+subject+"` -message `"+msg+"`"+attachQ);
}
</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

