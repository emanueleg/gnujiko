<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Excel parser for Tickets.
 #VERSION: 2.3beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.
			 30-11-2014 : Aggiunte le nuove chiavi. Manca da completare la funzione import.
			 10-11-2014
 #TODO: Sono state inserite le nuove chiavi (hardware,os,shelf,request,datatosave,accessories) ma è da completare la funzione import.
 
*/

function gnujikoexcelparser_tickets_info()
{
 $info = array('name' => "Tickets");
 $keys = array(
	/* BASIC INFO */
	"num"=>"N. Ticket",
	"type"=>"Tipologia ticket",
	"extref"=>"Rif. ticket esterno",
	"date"=>"Data apertura",
	"taxdelivery"=>"Data scadenza",
	"appdatetime"=>"Data appuntamento",
	"finishdatetime"=>"Data chiusura",
	"subjcode"=>"Cod. Cliente",
	"subject"=>"Nome Cliente",
	"loccode"=>"Codice domicilio/cantiere",
	"locname"=>"Titolo domicilio/cantiere",
	"locaddr"=>"Indirizzo domicilio/cantiere",
	"loccity"=>"Citt&agrave; domicilio/cantiere",
	"loczip"=>"C.A.P. domicilio/cantiere",
	"locprov"=>"Provincia domicilio/cantiere",
	"loccc"=>"Sigla paese domicilio/cantiere",
	"zone"=>"Zona",
	"status"=>"Status",
	"operator"=>"Operatore",
	"tech1"=>"Tecnico 1",
	"tech2"=>"Tecnico 2",
	"hardware"=>"Hardware",
	"os"=>"Sistema Operativo",
	"shelf"=>"Scaffale",
	"request"=>"Richiesta",
	"datatosave"=>"Dati da salvare",
	"accessories"=>"Accessori ritirati",
	"description"=>"Dettagli intervento",
	"amount"=>"Imponibile",
	"vat"=>"IVA",
	"total"=>"Totale",
	"note"=>"Note"
	);

 $keydict = array(
	/* BASIC INFO */
	"num"=> 			array("n.","num"),
	"type"=>			array('type','tipo'),
	"extref"=>			array('rif','riferimento'),
	"date"=>			array('data','apertura'),
	"taxdelivery"=>		array('scadenza'),
	"appdatetime"=>		array('app','appuntamento'),
	"finishdatetime"=>	array('chiusura'),
	"subjcode"=>		array('cod. cliente','cod. cli'),
	"subject"=>			array('cliente'),
	"loccode"=>			array('termid','cod. indirizzo'),
	"locname"=>			array('insegna','citofono'),
	"locaddr"=>			array('indirizzo'),
	"loccity"=>			array('citta','città'),
	"loczip"=>			array('cap','c.a.p'),
	"locprov"=>			array('prov','provincia'),
	"loccc"=>			array('paese'),
	"zone"=>			array('zona'),
	"status"=>			array('stato','status'),
	"operator"=>		array('operatore'),
	"tech1"=>			array('tech','tecnico','tech1','tecnico 1'),
	"tech2"=>			array('tech2','tecnico 2'),
	"hardware"=>		array('hw','hardware'),
	"os"=>				array('sistema operativo','o.s','s.o','os','so'),
	"shelf"=>			array('scaffale','ubicazione','posizione'),
	"request"=>			array('richiesta','rich.','req'),
	"datatosave"=>		array('dati da salvare','cartelle da salvare','da salvare'),
	"accessories"=>		array('accessori','acc. ritirati'),
	"description"=>		array('dettagli','descrizione','note'),
	"amount"=>			array('imponibile','imp'),
	"vat"=>				array('iva','i.v.a'),
	"total"=>			array('tot','totale'),
	"note"=>			array('note','notes','annotazioni')
	);

 return array('info'=>$info, 'keys'=>$keys, 'keydict'=>$keydict);
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoexcelparser_tickets_import($_DATA, $sessid, $shellid, $_AP="tickets", $catId=0, $catTag="", $id=0)
{
 global $_BASE_PATH;
 include_once($_BASE_PATH."include/extendedfunc.php");

 $mtime = date('Y-m-d H:i:s');

 $interface = array("name"=>"progressbar","steps"=>count($_DATA['items']));
 gshPreOutput($shellid,"Import tickets", "ESTIMATION", "", "PASSTHRU", $interface);

 for($c=0; $c < count($_DATA['items']); $c++)
 {
  $itm = $_DATA['items'][$c];
  $extset = "";
  $subjId = 0;
  $db = new AlpaDatabase();

  $cmd = "dynarc new-item -ap '".$_AP."'";
  if($itm['num'])
  {
   if(is_numeric($itm['num']))
	$cmd.= " -code-num '".$itm['num']."'";
   else
   {
	$x = null;
	if(strpos($itm['num'],'/'))			$x = explode("/",$itm['num']);
	else if(strpos($itm['num'],'-'))	$x = explode("-",$itm['num']);
	if($x && is_numeric(trim($x[0])))	$cmd.= " -code-num '".trim($x[0])."' -code-ext '".trim($x[1])."'";
   }
  }

  if($itm['date'])						$cmd.= " -ctime `".strdatetime_to_iso($itm['date'])."`";
  if($itm['description'])				$cmd.= " -desc `".$itm['description']."`";
  if($itm['type'])
  {
   $db->RunQuery("SELECT id FROM dynarc_tickettypes_items WHERE (code_str='".$itm['type']."' OR name='".$db->Purify($itm['type'])."' OR name LIKE '"
	.$db->Purify($itm['type'])."%' OR name LIKE '%".$db->Purify($itm['type'])."') AND trash='0' LIMIT 1");
   if($db->Read())
	$extset.= ",type='".$db->record['id']."'";
  }
  if($itm['extref'])					$extset.= ",extticketref='''".$itm['extref']."'''";
  if($itm['taxdelivery'])				$extset.= ",taxdelivery='".strdatetime_to_iso($itm['taxdelivery'])."'";
  if($itm['appdatetime'])				$extset.= ",apptime='".strdatetime_to_iso($itm['appdatetime'])."'";
  if($itm['finishdatetime'])			$extset.= ",finishtime='".strdatetime_to_iso($itm['finishdatetime'])."',closed='1'";
  if($itm['status'])					$extset.= ",status='".$itm['status']."'";
  if($itm['amount'])					$extset.= ",amount='".$itm['amount']."'";
  if($itm['vat'])						$extset.= ",vat='".$itm['vat']."'";
  if($itm['total'])						$extset.= ",total='".$itm['total']."'";
  if($itm['note'])						$extset.= ",note='''".$itm['note']."'''";
  if($itm['subjcode'] || $itm['subject'])
  {
   if($itm['subjcode'])
   {
    $db->RunQuery("SELECT id,name FROM dynarc_rubrica_items WHERE code_str='".$itm['subjcode']."' AND trash='0' LIMIT 1");
    if($db->Read())
	{
 	 $extset.= ",subjid='".$db->record['id']."',subjname='''".$db->record['name']."'''";
	 $subjId = $db->record['id'];
	}
	else
	{
	 $db->Close();
	 $ret = GShell("dynarc new-item -ap rubrica -ct customers -code-str '".$itm['subjcode']."' -name `".$itm['subject']."`",$sessid,$shellid);
	 if(!$ret['error']) $extset.= ",subjid='".$ret['outarr']['id']."',subjname='''".$ret['outarr']['name']."'''";
	 $subjId = $ret['outarr']['id'];
	 $db = new AlpaDatabase();
	}
   }
   else if($itm['subject'])
   {
    $db->RunQuery("SELECT id,name,code_str FROM dynarc_rubrica_items WHERE (name='".$db->Purify($itm['subject'])."' OR name LIKE '"
		.$db->Purify($itm['subject'])."' OR name LIKE '".$db->Purify($itm['subject'])."%') AND trash='0' LIMIT 1");
    if($db->Read())
	{
 	 $extset.= ",subjid='".$db->record['id']."',subjname='''".$db->record['name']."'''";
	 $subjId = $db->record['id'];
	}
	else
	{
	 $db->Close();
	 $ret = GShell("dynarc new-item -ap rubrica -ct customers -name `".$itm['subject']."`",$sessid,$shellid);
	 if(!$ret['error']) $extset.= ",subjid='".$ret['outarr']['id']."',subjname='''".$ret['outarr']['name']."'''";
	 $subjId = $ret['outarr']['id'];
	 $db = new AlpaDatabase();
	}
   }
  }
  if($itm['loccode'] || $itm['locname'] || $itm['locaddr'] || $itm['loccity'] || $itm['loczip'] || $itm['locprov'] || $itm['loccc'])
  {
   $q = "";
   if($itm['loccode'])
	$q.= " AND code='".$itm['loccode']."'";
   else if($itm['locaddr'] && $itm['loccity'])
	$q.= " AND address='".$db->Purify($itm['locaddr'])."' AND city='".$db->Purify($itm['loccity'])."'";
   else if($itm['locname'])
	$q.= " AND name='".$db->Purify($itm['locname'])."'";
   if($q)
   {
	$db->RunQuery("SELECT id FROM dynarc_rubrica_addresses WHERE item_id='".$subjId."'".$q." LIMIT 1");
	if($db->Read())
	 $extset.= ",contactid='".$db->record['id']."',address='''".$db->record['name']."'''";
	else
	{
	 $db->RunQuery("INSERT INTO dynarc_rubrica_addresses(item_id,name,code,address,city,zipcode,province,countrycode) VALUES('"
		.$subjId."','".$db->Purify($itm['locname'])."','".$itm['loccode']."','".$db->Purify($itm['locaddr'])."','"
		.$db->Purify($itm['loccity'])."','".$itm['loczip']."','".$itm['locprov']."','".$itm['loccc']."')");
	 $extset.= ",contactid='".$db->GetInsertId()."',address='''".$itm['locname']."'''";
	}
   }
  }
  if($itm['zone'])
  {
   $db->RunQuery("SELECT id FROM dynarc_ticketzones_items WHERE (name='".$db->Purify($itm['zone'])."' OR name LIKE '"
	.$db->Purify($itm['zone'])."') AND trash='0' LIMIT 1");
   if($db->Read())
	$extset.= ",zoneid='".$db->record['id']."',zone='''".$itm['zone']."'''"; 
  }
  else
   $extset.= ",zone='''".$itm['zone']."'''";
  if($itm['operator'])
  {
   $db->RunQuery("SELECT id FROM gnujiko_users WHERE username='".$db->Purify($itm['operator'])."' OR fullname='"
	.$db->Purify($itm['operator'])."' LIMIT 1");
   if($db->Read())
	$extset.= ",opid='".$db->record['id']."'";
  }
  if($itm['tech1'])
  {
   $db->RunQuery("SELECT id FROM dynarc_rubrica_items WHERE name='".$itm['tech1']."' AND trash='0' LIMIT 1");
   if($db->Read()) $extset.= ",tech1='".$db->record['id']."'";
  }
  if($itm['tech2'])
  {
   $db->RunQuery("SELECT id FROM dynarc_rubrica_items WHERE name='".$itm['tech2']."' AND trash='0' LIMIT 1");
   if($db->Read()) $extset.= ",tech2='".$db->record['id']."'";
  }
  
  $db->Close();
  if($extset)
   $cmd.= " -extset `ticketinfo.".ltrim($extset,",")."`";

  $ret = GShell($cmd,$sessid,$shellid);
  if($ret['error']) return $ret;
  gshPreOutput($shellid,$ret['outarr']['name']." has been created.","PROGRESS", $ret['outarr']['id']);
 }

 return array('message'=>"done!");
}
//-------------------------------------------------------------------------------------------------------------------//
function gnujikoexcelparser_tickets_fastimport($_KEYS, $_DATA, $sessid, $shellid, $_AP="", $catId=0, $catTag="", $id=0, $sessInfo)
{


 return array('message'=>"done!");
}
//-------------------------------------------------------------------------------------------------------------------//

