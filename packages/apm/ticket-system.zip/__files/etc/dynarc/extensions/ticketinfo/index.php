<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2016 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 12-11-2016
#PACKAGE: ticket-system
#DESCRIPTION: 
#VERSION: 2.15beta
#CHANGELOG: 12-11-2016 : Aggiunto campo priority e phone.
			24-10-2016 : MySQLi integration.
			11-09-2016 : Aggiunto parametro bypassupdatecontact
			13-07-2016 : Bug fix edit contact info.
			25-05-2016 : Aggiunto campo ext-contract-ref e vat_id.
			10-05-2016 : Aggiunto campi customer e commiss.
			29-11-2014 : Aggiunto campi.
			10-11-2014 : Bug fix campo note.
			01-11-2014 : Aggiunto campo name su indirizzo completo.
			27-10-2014 : Aggiunto add_title su funzione get.
			23-10-2014 : Aggiunto vari campi su funzione get per integrazione con tableize.
			17-10-2014 : Aggiunto file ticket di riferimento.
			14-10-2014 : Aggiunto data stampa, file stampa, data invio e email invio.
			10-10-2014 : Aggiornata funzione get
			27-09-2014 : Aggiunto zone_id
#TODO: 
*/

global $_BASE_PATH;

function dynarcextension_ticketinfo_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` ADD `ticket_type` INT(11) NOT NULL ,
 ADD `subject_id` INT(11) NOT NULL ,
 ADD `subject_name` VARCHAR(32) NOT NULL ,
 ADD `contact_id` INT(11) NOT NULL ,
 ADD `zone` VARCHAR(255) NOT NULL ,
 ADD `zone_id` INT(11) NOT NULL ,
 ADD `note` TEXT NOT NULL ,
 ADD `tax_delivery` DATETIME NOT NULL ,
 ADD `status` TINYINT(1) NOT NULL ,
 ADD `operator_id` INT(11) NOT NULL ,
 ADD `ext_ticket_ref` VARCHAR(32) NOT NULL,
 ADD `ext_contract_ref` VARCHAR(32) NOT NULL,
 ADD `closure_modal` VARCHAR(32) NOT NULL ,
 ADD `payment_mode` VARCHAR(32) NOT NULL ,
 ADD `closure_note` TEXT NOT NULL,
 ADD `amount` DECIMAL(10,5) NOT NULL,
 ADD `vat` DECIMAL(10,5) NOT NULL ,
 ADD `total` DECIMAL(10,5) NOT NULL ,
 ADD `preemptive_id` INT(11) NOT NULL ,
 ADD `invoice_id` INT(11) NOT NULL ,
 ADD `finish_datetime` DATETIME NOT NULL,
 ADD `app_datetime` DATETIME NOT NULL,
 ADD `closed` TINYINT(1) NOT NULL,
 ADD `tech_1` INT(11) NOT NULL,
 ADD `tech_2` INT(11) NOT NULL,
 ADD `print_datetime` DATETIME NOT NULL ,
 ADD `print_filename` VARCHAR(255) NOT NULL ,
 ADD `send_datetime` DATETIME NOT NULL ,
 ADD `send_email` VARCHAR(255) NOT NULL,
 ADD `ticket_ref_file` VARCHAR(255) NOT NULL,
 ADD `hw_id` INT(11) NOT NULL ,
 ADD `hw_name` VARCHAR(32) NOT NULL ,
 ADD `shelf` VARCHAR(32) NOT NULL ,
 ADD `request` TEXT NOT NULL ,
 ADD `datatosave` TEXT NOT NULL ,
 ADD `accessories` TEXT NOT NULL ,
 ADD `customer_id` INT(11) NOT NULL ,
 ADD `customer_name` VARCHAR(48) NOT NULL ,
 ADD `commiss_id` INT(11) NOT NULL ,
 ADD `commiss_name` VARCHAR(48) NOT NULL ,
 ADD `vat_id` INT(11) NOT NULL,
 ADD `priority` TINYINT(1) UNSIGNED NOT NULL,
 ADD `phone` VARCHAR(14) NOT NULL,
 ADD INDEX (`ticket_type`,`subject_id`,`status`,`ext_ticket_ref`,`closure_modal`,`payment_mode`,`closed`,`zone_id`,`tech_1`,`tech_2`,`hw_id`,`shelf`,`customer_id`,`commiss_id`,`priority`)");
 $db->Close();

 return array("message"=>"TicketInfo extension has been installed into archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items DROP `ticket_type`, DROP `subject_id`,
  DROP `subject_name`, DROP `contact_id`, DROP `zone`, DROP `note`, DROP `tax_delivery`, DROP `status`, DROP `operator_id`, 
  DROP `ext_ticket_ref`, DROP `closure_modal`, DROP `payment_mode`, DROP `closure_note`, DROP `amount`, DROP `vat`, DROP `total`,
  DROP `preemptive_id`, DROP `invoice_id`, DROP `finish_datetime`, DROP `app_datetime`, DROP `closed`, DROP `zone_id`, 
  DROP `tech_1`, DROP `tech_2`, DROP `print_datetime`, DROP `print_filename`, DROP `send_datetime`, DROP `send_email`, 
  DROP `ticket_ref_file`, DROP `hw_id`, DROP `hw_name`, DROP `shelf`, DROP `request`, DROP `datatosave`, DROP `accessories`, DROP `customer_id`,
  DROP `customer_name`, DROP `commiss_id`, DROP `commiss_name`, DROP `ext_contract_ref`, DROP `vat_id`, DROP `priority`, DROP `phone`");
 $db->Close();

 return array("message"=>"TicketInfo extension has been removed from archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_catset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_catunset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_catget($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_ticketinfo_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 $bypassUpdateContact = false;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'type' : {$type=$args[$c+1]; $c++;} break;
   case 'subjid' : case 'subjectid' : {$subjectId=$args[$c+1]; $c++;} break;
   case 'subjname' : case 'subjectname' : {$subjectName=$args[$c+1]; $c++;} break;

   case 'contactid' : {$contactId=$args[$c+1]; $c++;} break;
   case 'address' : {$address=$args[$c+1]; $c++;} break;
   case 'addrname' : {$addrName=$args[$c+1]; $c++;} break;
   case 'city' : {$city=$args[$c+1]; $c++;} break;
   case 'prov' : case 'province' : {$province=$args[$c+1]; $c++;} break;
   case 'phone' : {$phone=$args[$c+1]; $c++;} break;
   case 'bypassupdatecontact' : {$bypassUpdateContact=$args[$c+1]; $c++;} break;

   case 'zone' : {$zone=$args[$c+1]; $c++;} break;
   case 'zoneid' : {$zoneId=$args[$c+1]; $c++;} break;
   case 'note' : case 'notes' : {$note=$args[$c+1]; $c++;} break;
   case 'taxdelivery' : {$taxDelivery=$args[$c+1]; $c++;} break;
   case 'status' : {$status=$args[$c+1]; $c++;} break;
   case 'priority' : {$priority=$args[$c+1]; $c++;} break;
   case 'operatorid' : case 'opid' : {$operatorId=$args[$c+1]; $c++;} break;
   case 'extticketref' : case 'ticketref' : {$extTicketRef=$args[$c+1]; $c++;} break;
   case 'extcontractref' : {$extContractRef=$args[$c+1]; $c++;} break;
   case 'ticketreffile' : case 'tktreffile' : {$ticketRefFile=$args[$c+1]; $c++;} break;
   case 'closuremodal' : {$closureModal=$args[$c+1]; $c++;} break;
   case 'paymentmode' : {$paymentMode=$args[$c+1]; $c++;} break;
   case 'closurenote' : {$closureNote=$args[$c+1]; $c++;} break;
   case 'amount' : {$amount=$args[$c+1]; $c++;} break;
   case 'vat' : {$vat=$args[$c+1]; $c++;} break;
   case 'vatid' : {$vatId=$args[$c+1]; $c++;} break;
   case 'total' : {$total=$args[$c+1]; $c++;} break;
   case 'preemptiveid' : {$preemptiveId=$args[$c+1]; $c++;} break;
   case 'invoiceid' : {$invoiceId=$args[$c+1]; $c++;} break;
   case 'finishtime' : {$finishDateTime=$args[$c+1]; $c++;} break;
   case 'apptime' : {$appDateTime=$args[$c+1]; $c++;} break;
   case 'closed' : {$closed=$args[$c+1]; $c++;} break;
   case 'tech1' : {$tech1id=$args[$c+1]; $c++;} break;
   case 'tech2' : {$tech2id=$args[$c+1]; $c++;} break;
   case 'printdate' : case 'printtime' : case 'printdatetime' : {$printDateTime=$args[$c+1]; $c++;} break;
   case 'printfile' : case 'pdfname' : case 'pdffilename' : {$printFileName=$args[$c+1]; $c++;} break;
   case 'senddate' : case 'sendtime' : case 'senddatetime' : {$sendDateTime=$args[$c+1]; $c++;} break;
   case 'sendemail' : {$sendEmail=$args[$c+1]; $c++;} break;
  
   case 'hwid' : {$hwID=$args[$c+1]; $c++;} break;
   case 'hwname' : case 'hardware' : case 'hardwarename' : {$hwName=$args[$c+1]; $c++;} break;
   case 'shelf' : {$shelf=$args[$c+1]; $c++;} break;
   case 'request' : {$request=$args[$c+1]; $c++;} break;
   case 'datatosave' : {$dataToSave=$args[$c+1]; $c++;} break;
   case 'accessories' : {$accessories=$args[$c+1]; $c++;} break;
   
   case 'custid' : case 'customerid' : {$customerId=$args[$c+1]; $c++;} break;
   case 'custname' : case 'customername' : {$customerName=$args[$c+1]; $c++;} break;
   case 'commissid' : {$commissId=$args[$c+1]; $c++;} break;
   case 'commissname' : {$commissName=$args[$c+1]; $c++;} break;
  }

 if(($address || $addrName) && $subjectId && !$contactId)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("INSERT INTO dynarc_rubrica_addresses(item_id,name,address,city,province) VALUES('".$subjectId."','"
	.$db->Purify($addrName ? $addrName : $address)."','".$db->Purify($address)."','".$db->Purify($city)."','".$province."')");
  if($db->Error) return array('message'=>'MySQL error: '.$db->Error, 'error'=>'MYSQL_ERROR');
  $contactId = $db->GetInsertId();
  $db->Close();
 }
 else if($contactId && !$bypassUpdateContact)
 {
  $q = "";
  $db = new AlpaDatabase();
  if(isset($addrName)) 	$q.= ",name='".$db->Purify($addrName)."'";
  if(isset($address))	$q.= ",address='".$db->Purify($address)."'";
  if(isset($city))		$q.= ",city='".$db->Purify($city)."'";
  if(isset($province))	$q.= ",province='".$province."'";

  if($q)
   $db->RunQuery("UPDATE dynarc_rubrica_addresses SET ".ltrim($q,",")." WHERE id='".$contactId."'");

  $db->Close();
 }

 if($zone && !$zoneId)
 {
  // add zone
  $ret = GShell("dynarc new-item -ap ticketzones -name `".$zone."`",$sessid,$shellid);
  if(!$ret['error'])
   $zoneId = $ret['outarr']['id'];
 }

 if($printDateTime == "now")	$printDateTime = date('Y-m-d H:i:s');
 if($sendDateTime == "now")		$sendDateTime = date('Y-m-d H:i:s');

 $db = new AlpaDatabase();
 $q = "";
 if(isset($type))			$q.= ",ticket_type='".$type."'";
 if($subjectId)				$q.= ",subject_id='".$subjectId."'";
 if($subjectName)			$q.= ",subject_name='".$db->Purify($subjectName)."'";
 if($contactId)				$q.= ",contact_id='".$contactId."'";
 if(isset($zone))			$q.= ",zone='".$db->Purify($zone)."'";
 if(isset($zoneId))			$q.= ",zone_id='".$zoneId."'";
 if(isset($note))			$q.= ",note='".$db->Purify($note)."'";
 if(isset($phone))			$q.= ",phone='".$db->Purify($phone)."'";
 if(isset($taxDelivery))	$q.= ",tax_delivery='".$taxDelivery."'";
 if(isset($status))			$q.= ",status='".$status."'";
 if(isset($priority))		$q.= ",priority='".$priority."'";
 if(isset($operatorId))		$q.= ",operator_id='".$operatorId."'";
 if(isset($extTicketRef))	$q.= ",ext_ticket_ref='".$extTicketRef."'";
 if(isset($extContractRef))	$q.= ",ext_contract_ref='".$extContractRef."'";
 if(isset($ticketRefFile))	$q.= ",ticket_ref_file='".$ticketRefFile."'";
 if(isset($closureModal))	$q.= ",closure_modal='".$closureModal."'";
 if(isset($paymentMode))	$q.= ",payment_mode='".$paymentMode."'";
 if(isset($closureNote))	$q.= ",closure_note='".$db->Purify($closureNote)."'";
 if(isset($amount))			$q.= ",amount='".$amount."'";
 if(isset($vat))			$q.= ",vat='".$vat."'";
 if(isset($vatId))			$q.= ",vat_id='".$vatId."'";
 if(isset($total))			$q.= ",total='".$total."'";
 if(isset($preemptiveId))	$q.= ",preemptive_id='".$preemptiveId."'";
 if(isset($invoiceId))		$q.= ",invoice_id='".$invoiceId."'";
 if(isset($finishDateTime))	$q.= ",finish_datetime='".$finishDateTime."'";
 if(isset($appDateTime))	$q.= ",app_datetime='".$appDateTime."'";
 if(isset($closed))			$q.= ",closed='".$closed."'";
 if(isset($tech1id))		$q.= ",tech_1='".$tech1id."'";
 if(isset($tech2id))		$q.= ",tech_2='".$tech2id."'";
 if(isset($printDateTime))	$q.= ",print_datetime='".$printDateTime."'";
 if(isset($printFileName))	$q.= ",print_filename='".$printFileName."'";
 if(isset($sendDateTime))	$q.= ",send_datetime='".$sendDateTime."'";
 if(isset($sendEmail))		$q.= ",send_email='".$sendEmail."'";

 if(isset($hwID))			$q.= ",hw_id='".$hwID."'";
 if(isset($hwName))			$q.= ",hw_name='".$db->Purify($hwName)."'";
 if(isset($shelf))			$q.= ",shelf='".$db->Purify($shelf)."'";
 if(isset($request))		$q.= ",request='".$db->Purify($request)."'";
 if(isset($dataToSave))		$q.= ",datatosave='".$db->Purify($dataToSave)."'";
 if(isset($accessories))	$q.= ",accessories='".$db->Purify($accessories)."'";

 if(isset($customerId))		$q.= ",customer_id='".$customerId."'";
 if(isset($customerName))	$q.= ",customer_name='".$db->Purify($customerName)."'";
 if(isset($commissId))		$q.= ",commiss_id='".$commissId."'";
 if(isset($commissName))	$q.= ",commiss_name='".$db->Purify($commissName)."'";

 if(isset($appDateTime))	
 {
  $q.= ",app_datetime='".$appDateTime."'";
  if(!$appDateTime)
   $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_cronevents WHERE item_id='".$itemInfo['id']."'");
 }

 if($q)
 {
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET ".ltrim($q,",")." WHERE id='".$itemInfo['id']."'");
  if($db->Error) return array('message'=>'MySQL error: '.$db->Error, 'error'=>'MYSQL_ERROR');
 }
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_ticketinfo_catunset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_ticketinfo_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 /*for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }*/

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();

 $itemInfo['type'] = $db->record['ticket_type'];
 $itemInfo['subject_id'] = $db->record['subject_id'];
 $itemInfo['subject_name'] = $db->record['subject_name'];
 $itemInfo['contact_id'] = $db->record['contact_id'];
 $itemInfo['zone'] = $db->record['zone'];
 $itemInfo['zone_id'] = $db->record['zone_id'];
 $itemInfo['note'] = $db->record['note'];
 $itemInfo['phone'] = $db->record['phone'];
 $itemInfo['tax_delivery'] = ($db->record['tax_delivery'] != "0000-00-00 00:00:00") ? $db->record['tax_delivery'] : 0;
 $itemInfo['status'] = $db->record['status'];
 $itemInfo['priority'] = $db->record['priority'];
 $itemInfo['operator_id'] = $db->record['operator_id'] ? $db->record['operator_id'] : $itemInfo['modinfo']['uid'];
 $itemInfo['ext_ticket_ref'] = $db->record['ext_ticket_ref'];
 $itemInfo['ext_contract_ref'] = $db->record['ext_contract_ref'];
 $itemInfo['ticket_ref_file'] = $db->record['ticket_ref_file'];
 $itemInfo['closure_modal'] = $db->record['closure_modal'];
 $itemInfo['payment_mode'] = $db->record['payment_mode'];
 $itemInfo['closure_note'] = $db->record['closure_note'];
 $itemInfo['amount'] = $db->record['amount'];
 $itemInfo['vat'] = $db->record['vat'];
 $itemInfo['vat_id'] = $db->record['vat_id'];
 $itemInfo['total'] = $db->record['total'];
 $itemInfo['preemptive_id'] = $db->record['preemptive_id'];
 $itemInfo['invoice_id'] = $db->record['invoice_id'];
 $itemInfo['finish_datetime'] = ($db->record['finish_datetime'] != "0000-00-00 00:00:00") ? $db->record['finish_datetime'] : 0;
 $itemInfo['app_datetime'] = ($db->record['app_datetime'] != "0000-00-00 00:00:00") ? $db->record['app_datetime'] : 0;
 $itemInfo['closed'] = $db->record['closed'];
 $itemInfo['tech_1_id'] = $db->record['tech_1'];
 $itemInfo['tech_2_id'] = $db->record['tech_2'];
 $itemInfo['print_datetime'] = ($db->record['print_datetime'] != "0000-00-00 00:00:00") ? $db->record['print_datetime'] : 0;
 $itemInfo['print_filename'] = $db->record['print_filename'];
 $itemInfo['send_datetime'] = ($db->record['send_datetime'] != "0000-00-00 00:00:00") ? $db->record['send_datetime'] : 0;
 $itemInfo['send_email'] = $db->record['send_email'];

 $itemInfo['hw_id'] = $db->record['hw_id'];
 $itemInfo['hw_name'] = $db->record['hw_name'];
 $itemInfo['shelf'] = $db->record['shelf'];
 $itemInfo['request'] = $db->record['request'];
 $itemInfo['datatosave'] = $db->record['datatosave'];
 $itemInfo['accessories'] = $db->record['accessories'];

 $itemInfo['customer_id'] = $db->record['customer_id'];
 $itemInfo['customer_name'] = $db->record['customer_name'];
 $itemInfo['commiss_id'] = $db->record['commiss_id'];
 $itemInfo['commiss_name'] = $db->record['commiss_name'];

 // get subject code
 if($itemInfo['subject_id'])
 {
  $db->RunQuery("SELECT code_str FROM dynarc_rubrica_items WHERE id='".$itemInfo['subject_id']."'");
  $db->Read();
  $itemInfo['subject_code'] = $db->record['code_str'];
 } 

 // get ticket type name
 if($itemInfo['type'])
 {
  $db->RunQuery("SELECT code_str,name FROM dynarc_tickettypes_items WHERE id='".$itemInfo['type']."'");
  $db->Read();
  $itemInfo['type_code'] = $db->record['code_str'];
  $itemInfo['type_name'] = $db->record['name'];
 }

 // get operator name
 if($itemInfo['operator_id'])
 {
  $db->RunQuery("SELECT username,fullname FROM gnujiko_users WHERE id='".$itemInfo['operator_id']."'");
  $db->Read();
  $itemInfo['operator_name'] = $db->record['fullname'] ? $db->record['fullname'] : $db->record['username'];
 }

 // get address
 if($itemInfo['contact_id'])
 {
  $db->RunQuery("SELECT name,code,address,city,zipcode,province,countrycode,note FROM dynarc_rubrica_addresses WHERE id='".$itemInfo['contact_id']."'");
  $db->Read();
  $itemInfo['address'] = $db->record['name'];
  /*$itemInfo['addressinfo'] = array('code'=>$db->record['code'], 'name'=>$db->record['name'], 'address'=>$db->record['address'], 
	'city'=>$db->record['city'], 'zipcode'=>$db->record['zipcode'], 'province'=>$db->record['province'], 
	'countrycode'=>$db->record['countrycode'], 'note'=>$db->record['note']);*/
  $address = "";
  if($db->record['code']) 		$address.= " - ".$db->record['code'];
  if($db->record['name'])		$address.= " - ".$db->record['name'];
  if($db->record['address']) 	$address.= " - ".$db->record['address'];
  if($db->record['city'])		$address.= " - ".$db->record['city'];
  if($db->record['province'])	$address.= " (".$db->record['province'].")";
  if($address) $itemInfo['address'] = ltrim($address, " - ");
  $itemInfo['addr_code'] = $db->record['code'];
  $itemInfo['addr_title'] = $db->record['name'];
  $itemInfo['addr_address'] = $db->record['address'];
  $itemInfo['addr_city'] = $db->record['city'];
  $itemInfo['addr_province'] = $db->record['province'];
  $itemInfo['addr_zipcode'] = $db->record['zipcode'];
  $itemInfo['addr_cc'] = $db->record['countrycode'];
  $itemInfo['addr_note'] = $db->record['note'];
 }

 // get technicians
 if($itemInfo['tech_1_id'])
 {
  $db->RunQuery("SELECT name FROM dynarc_rubrica_items WHERE id='".$itemInfo['tech_1_id']."'");
  $db->Read();
  $itemInfo['tech_1_name'] = $db->record['name'];
 }

 if($itemInfo['tech_2_id'])
 {
  $db->RunQuery("SELECT name FROM dynarc_rubrica_items WHERE id='".$itemInfo['tech_2_id']."'");
  $db->Read();
  $itemInfo['tech_2_name'] = $db->record['name'];
 }

 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 $xml = "<ticketinfo />";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 if(!$node)
  return ;

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_ticketinfo_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
