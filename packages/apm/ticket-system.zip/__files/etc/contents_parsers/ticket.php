<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 05-01-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Ticket parser
 #VERSION: 2.4beta
 #CHANGELOG: 05-01-2016 : Aggiunta data e ora appuntamento.
			 24-03-2015 : Bug fix su subject_name.
			 17-12-2014 : Aggiunto altre chiavi per hardware.
			 16-12-2014 : Aggiunto chiavi: hw,richiesta,dati da salvare,accessori.
 #TODO:
 
*/

function gnujikocontentparser_ticket_info($sessid, $shellid)
{
 $info = array('name' => "Ticket");
 $keys = array(
	 "SUBJECT_NAME" => "Cliente - nome e cognome",
	 "SUBJECT_CODE" => "Codice cliente",
	 "SUBJECT_ADDRESS" => "Cliente - indirizzo",
	 "SUBJECT_CITY" => "Cliente - città",
	 "SUBJECT_ZIPCODE" => "Cliente - C.A.P.",
	 "SUBJECT_TAXCODE" => "Cliente - cod. fisc.",
	 "SUBJECT_VATNUMBER" => "Cliente - partita IVA",
	 "SUBJECT_TCAOVN" => "Cliente - p.IVA e/o cod. fisc.",
	 "SUBJECT_PHONE" => "Cliente - telefono",
	 "SUBJECT_PHONE2" => "Cliente - telefono2",
	 "SUBJECT_FAX" => "Cliente - fax",
	 "SUBJECT_CELL" => "Cliente - cellulare",
	 "SUBJECT_EMAIL" => "Cliente - email",

	 "TKT_NUM" => "N. ticket",
	 "TKT_REF" => "Riferimento ticket",
	 "TKT_DATETIME" => "Data e ora apertura",
	 "CLOSURE_DATETIME" => "Data e ora chiusura",
	 "APP_DATETIME" => "Data e ora appuntamento",
	 "INTERV_TYPE" => "Cod. tipo intervento",
	 "DETAILS" => "Dettagli intervento",
	 "NOTES" => "Note",
	 "OPERATOR_NAME" => "Operatore",
	 "HW_NAME" => "Hardware - Marca e modello",
	 "HW_PN" => "Hardware - Product Number",
	 "HW_SN" => "Hardware - Serial Number",
	 "HW_PURCHDT" => "Hardware - data acquisto",
	 "HW_YGUAR" => "Hardware - anni di garanzia",
	 "HW_NOTE" => "Hardware - note",
	 "SHELF" => "Scaffale",
	 "REQUEST" => "Richiesta",
	 "DATATOSAVE" => "Dati da salvare",
	 "ACCESSORIES" => "Accessori",

	 "DOC_AMOUNT" => "Tot. imponibile",
	 "DOC_VAT" => "Tot. IVA",
	 "DOC_TOT" => "Tot. IVA inclusa",

	 "COMPANY-NAME" => "Denominazione azienda (la vostra)",
	 "CO_ADDR" => "Indirizzo (della vs azienda)",
	 "CO_ZIP" => "C.A.P. (della vs azienda)",
	 "CO_CITY" => "Città (della vs azienda)",
	 "CO_PROV" => "Provincia (della vs azienda)",
	 "CO_CC" => "Paese (della vs azienda)",
	 "CO_VATNUMBER" => "Numero della Partita IVA (della vs azienda)",
	 "CO_TAXCODE" => "Codice Fiscale (della vs azienda)",
	 "CO_PHONE" => "Telefono principale (della vs azienda)",
	 "CO_PHONE2" => "Telefono secondario (della vs azienda)",
	 "CO_FAX" => "Fax principale (della vs azienda)",
	 "CO_FAX2" => "Fax secondario (della vs azienda)",
	 "CO_CELL" => "Cellulare principale (della vs azienda)",
	 "CO_CELL2" => "Cellulare secondario (della vs azienda)",
	 "CO_EMAIL" => "Email principale (della vs azienda)",
	 "CO_EMAIL2" => "Email secondaria (della vs azienda)",
	 "CO_WEBSITE" => "Sito web (della vs azienda)",

	 "COBNK_NAME" => "Ns. Banca: Nome della banca ",
	 "COBNK_IBAN" => "Ns. Banca: IBAN",
	 "CB_ABI" => "Ns. Banca: ABI",
	 "CB_CAB" => "Ns. Banca: CAB",
	 "CB_CIN" => "Ns. Banca: CIN",
	 "CB_CC" => "Ns. Banca: Conto Corrente",


	);
 return array('info'=>$info, 'keys'=>$keys);
}

function gnujikocontentparser_ticket_parse($_CONTENTS, $_PARAMS, $sessid, $shellid)
{
 global $_BASE_PATH, $_ABSOLUTE_URL, $_COMPANY_PROFILE;
 include_once($_BASE_PATH."include/company-profile.php");
 $_BANKS = $_COMPANY_PROFILE['banks'];
 $_DECIMALS = $_COMPANY_PROFILE['accounting']['decimals_pricing'];


 $contents = $_CONTENTS;

 // DOC INFO //
 $ret = GShell("dynarc item-info -ap tickets -id '".$_PARAMS['id']."' -extget `ticketinfo,cdelements`",$sessid,$shellid);
 if(!$ret['error'])
 {
  $docInfo = $ret['outarr'];
  // get subject info //
  if($docInfo['subject_id'])
  {
   $ret = GShell("dynarc item-info -ap rubrica -id '".$docInfo['subject_id']."' -extget `rubricainfo,contacts`",$sessid,$shellid);
   if(!$ret['error'])
	$subjectInfo = $ret['outarr'];
  }
  // get intervention type //
  $ret = GShell("dynarc item-info -ap tickettypes -id '".$docInfo['type']."'",$sessid,$shellid);
  if(!$ret['error'])
   $intervType = $ret['outarr'];
  // get hardware info //
  if($docInfo['hw_id'])
  {
   $db = new AlpaDatabase();
   $db->RunQuery("SELECT description,product_number,serial_number,purchase_date,years_guarantee FROM dynarc_tktcusthw_items WHERE id='".$docInfo['hw_id']."'");
   if($db->Read())
   {
	$docInfo['hw_pn'] = $db->record['product_number'];
	$docInfo['hw_sn'] = $db->record['serial_number'];
	$docInfo['hw_purchdt'] = ($db->record['purchase_date'] && ($db->record['purchase_date'] != "0000-00-00") && ($db->record['purchase_date'] != "1970-01-01")) ? date('d/m/Y',strtotime($db->record['purchase_date'])) : "";
	$docInfo['hw_yguar'] = $db->record['years_guarantee'];
	$docInfo['hw_note'] = $db->record['description'];
   }
   $db->Close();
  }
 }

 $keys = array(
	 "{SUBJECT_NAME}", 
	 "{SUBJECT_CODE}", 
	 "{SUBJECT_ADDRESS}", 
	 "{SUBJECT_CITY}", 
	 "{SUBJECT_ZIPCODE}", 
	 "{SUBJECT_TAXCODE}", 
	 "{SUBJECT_VATNUMBER}", 
	 "{SUBJECT_TCAOVN}",
	 "{SUBJECT_PHONE}",
	 "{SUBJECT_PHONE2}",
	 "{SUBJECT_FAX}",
	 "{SUBJECT_CELL}",
	 "{SUBJECT_EMAIL}",
	 
	 "{TKT_NUM}",
	 "{TKT_REF}",
	 "{TKT_DATETIME}",
	 "{CLOSURE_DATETIME}", 
	 "{APP_DATETIME}", 
	 "{INTERV_TYPE}", 
	 "{DETAILS}",
	 "{NOTES}",
	 "{OPERATOR_NAME}",
	 "{HW_NAME}",
	 "{HW_PN}",
	 "{HW_SN}",
	 "{HW_PURCHDT}",
	 "{HW_YGUAR}",
	 "{HW_NOTE}",
	 "{SHELF}",
	 "{REQUEST}",
	 "{DATATOSAVE}",
	 "{ACCESSORIES}",

	 "{DOC_AMOUNT}",
	 "{DOC_VAT}",
	 "{DOC_TOT}",

	 "{COMPANY-NAME}", "{CO_ADDR}", "{CO_ZIP}", "{CO_CITY}", "{CO_PROV}", "{CO_CC}", "{CO_VATNUMBER}", "{CO_TAXCODE}", "{CO_PHONE}", "{CO_PHONE2}", 
	 "{CO_FAX}", "{CO_FAX2}", "{CO_CELL}", "{CO_CELL2}", "{CO_EMAIL}", "{CO_EMAIL2}", "{CO_WEBSITE}",

	 "{COBNK_NAME}", "{COBNK_IBAN}", "{CB_ABI}", "{CB_CAB}", "{CB_CIN}", "{CB_CC}",

	);

 $tcaovn = "";
 if($subjectInfo['vatnumber'] && $subjectInfo['taxcode'])
  $tcaovn = "P.IVA: ".$subjectInfo['vatnumber']."<br/>C.F.: ".$subjectInfo['taxcode'];
 else if($subjectInfo['vatnumber'])
  $tcaovn = "P.IVA: ".$subjectInfo['vatnumber'];
 else if($subjectInfo['taxcode'])
  $tcaovn = "C.F.: ".$subjectInfo['taxcode'];

 /* Get company bank info */
 $CObankName = $_BANKS[0] ? $_BANKS[0]['name'] : "&nbsp;";
 $CObankIBAN = $_BANKS[0] ? $_BANKS[0]['iban'] : "&nbsp;";
 $CObankABI = $_BANKS[0] ? $_BANKS[0]['abi'] : "&nbsp;";
 $CObankCAB = $_BANKS[0] ? $_BANKS[0]['cab'] : "&nbsp;";
 $CObankCIN = $_BANKS[0] ? $_BANKS[0]['cin'] : "&nbsp;";
 $CObankCC = $_BANKS[0] ? $_BANKS[0]['cc'] : "&nbsp;";

 if($CObankIBAN && (strlen($CObankIBAN) >= 27))
  $CObankIBAN = substr($CObankIBAN,0,4)." ".substr($CObankIBAN,4,4)." ".substr($CObankIBAN,8,4)." ".substr($CObankIBAN,12,4)." ".substr($CObankIBAN,16,4)." ".substr($CObankIBAN,20,4)." ".substr($CObankIBAN,24);


 $vals = array(
	 $docInfo['subject_name'],
	 $subjectInfo['code_str'],
	 $subjectInfo['contacts'][0]['address'],
	 $subjectInfo['contacts'][0]['city'],
	 $subjectInfo['contacts'][0]['zipcode'],
	 $subjectInfo['taxcode'],
	 $subjectInfo['vatnumber'],
	 $tcaovn,
	 $subjectInfo['contacts'][0]['phone'],
	 $subjectInfo['contacts'][0]['phone2'],
	 $subjectInfo['contacts'][0]['fax'],
	 $subjectInfo['contacts'][0]['cell'],
	 $subjectInfo['contacts'][0]['email'],

	 $docInfo['code_num'].($docInfo['code_ext'] ? "/".$docInfo['code_ext'] : ""),
	 $docInfo['ext_ticket_ref'],
	 date('d/m/Y H:i',$docInfo['ctime']),
	 $docInfo['finish_datetime'] ? date('d/m/Y H:i',strtotime($docInfo['finish_datetime'])) : "",
	 $docInfo['app_datetime'] ? date('d/m/Y H:i',strtotime($docInfo['app_datetime'])) : "",
	 $docInfo['type_name'],
	 $docInfo['desc'],
	 $docInfo['closure_note'],
	 $docInfo['operator_name'],
	 $docInfo['hw_name'],
	 $docInfo['hw_pn'],
	 $docInfo['hw_sn'],
	 $docInfo['hw_purchdt'],
	 $docInfo['hw_yguar'],
	 $docInfo['hw_note'],
	 $docInfo['shelf'],
	 $docInfo['request'],
	 $docInfo['datatosave'],
	 $docInfo['accessories'],

	 number_format($docInfo['amount'],2,",","."),
	 number_format($docInfo['vat'],2,",","."),
	 number_format($docInfo['total'],2,",","."),

	 /* COMPANY INFO */
	 $_COMPANY_PROFILE['name'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['address'] ? $_COMPANY_PROFILE['addresses']['headquarters']['address'] : $_COMPANY_PROFILE['addresses']['registered_office']['address'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['zip'] ? $_COMPANY_PROFILE['addresses']['headquarters']['zip'] : $_COMPANY_PROFILE['addresses']['registered_office']['zip'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['city'] ? $_COMPANY_PROFILE['addresses']['headquarters']['city'] : $_COMPANY_PROFILE['addresses']['registered_office']['city'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['prov'] ? $_COMPANY_PROFILE['addresses']['headquarters']['prov'] : $_COMPANY_PROFILE['addresses']['registered_office']['prov'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['country'] ? $_COMPANY_PROFILE['addresses']['headquarters']['country'] : $_COMPANY_PROFILE['addresses']['registered_office']['country'],

	 $_COMPANY_PROFILE['vatnumber'], $_COMPANY_PROFILE['taxcode'], 

	 $_COMPANY_PROFILE['addresses']['headquarters']['phones'][0]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['phones'][0]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['phones'][0]['number'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['phones'][1]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['phones'][1]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['phones'][1]['number'],

	 $_COMPANY_PROFILE['addresses']['headquarters']['fax'][0]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['fax'][0]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['fax'][0]['number'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['fax'][1]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['fax'][1]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['fax'][1]['number'],

	 $_COMPANY_PROFILE['addresses']['headquarters']['cells'][0]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['cells'][0]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['cells'][0]['number'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['cells'][1]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['cells'][1]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['cells'][1]['number'],

	 $_COMPANY_PROFILE['addresses']['headquarters']['emails'][0]['email'] ? $_COMPANY_PROFILE['addresses']['headquarters']['emails'][0]['email'] : $_COMPANY_PROFILE['addresses']['registered_office']['emails'][0]['email'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['emails'][1]['email'] ? $_COMPANY_PROFILE['addresses']['headquarters']['emails'][1]['email'] : $_COMPANY_PROFILE['addresses']['registered_office']['emails'][1]['email'],

	 $_COMPANY_PROFILE['website'],

 	 $CObankName, $CObankIBAN, $CObankABI, $CObankCAB, $CObankCIN, $CObankCC
	);

 for($c=0; $c < count($keys); $c++)
 {
  $key = $keys[$c];
  $val = $vals[$c];

  while($p = stripos($contents,$key,$p))
  {
   $chunk = strtoupper(substr($contents,$p-4,4));
   if(($chunk == "ID='") || ($chunk == 'ID="'))
   {// is inside on html tag //
    $endTag = stripos($contents,">",$p+strlen($key));
    $contents = substr($contents,0,$endTag+1).$val.substr($contents,$endTag+1);
    $p = $endTag+strlen($val);
   }
   else
   {
    $contents = substr($contents,0,$p).$val.substr($contents,$p+strlen($key));
    $p+= strlen($val);
   }
  }
 }

 $_CONTENTS = $contents;
 return $contents;
}


