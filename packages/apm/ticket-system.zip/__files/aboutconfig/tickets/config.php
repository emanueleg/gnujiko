<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 27-05-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Ticket configuration panel
 #VERSION: 2.2beta
 #CHANGELOG: 27-05-2016 : Aggiunto parametro continue.
			 17-05-2016 : Aggiunto le notifiche.
 #TODO:
 
*/

$_APPLICATION_CONFIG = array(
	"appname"=>"Configurazione Tickets",
	"basepath"=>"aboutconfig/tickets/",
	"pathway"=>array("title"=>"Tickets", "url"=>"index.php"),
	"restrictedaccess" => true,
	"mainmenu"=>array(
	 0 => array("title"=>"Settaggi", "url"=>"index.php?continue=".$_REQUEST['continue']),
	 1 => array("title"=>"Notifiche", "url"=>"alerts.php?continue=".$_REQUEST['continue']),
	)
);
