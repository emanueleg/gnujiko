<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 16-06-2016
 #PACKAGE: ticket-system
 #DESCRIPTION: Ticket alerts configuration panel
 #VERSION: 2.2beta
 #CHANGELOG: 16-06-2016 : Aggiunto chiavi intervtimefrom ed intervtimeto.
			 27-05-2016 : Aggiunto parametro continue al salvataggio.
 #TODO: 
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SMTP_USERNAME;

$_BASE_PATH = "../../";

include($_BASE_PATH."var/templates/glight/index.php");

global $_APPLICATION_CONFIG;
require_once($_BASE_PATH."Tickets/config.php");
$_TICKET_STATUS_LIST = $_APPLICATION_CONFIG['ticketstatus'];
$_APPLICATION_CONFIG = null;


$template = new GLightTemplate();
$template->includeObject("fckeditor");
$template->includeCSS("../aboutconfig.css");

$template->Begin("Notifiche via email");

$centerContents = "<span class='glight-template-hdrtitle'>PANNELLO DI CONFIGURAZIONE - TICKETS</span>";

$template->Header("search", $centerContents, "BTN_EXIT", 800);

$template->Pathway();

$template->Body("default",800);


/* GET CONFIG */
$ret = GShell("aboutconfig get-config -app tickets -sec alerts");
if(!$ret['error'])
 $config = $ret['outarr']['config'];
else
 $configErr = $ret['message'];



/*-------------------------------------------------------------------------------------------------------------------*/
?>
<style type="text/css">
table.keylist {
 background: #fafafa;
 border: 1px solid #d8d8d8;
}

table.keylist th {
 font-family: arial, sans-serif;
 font-size: 10px;
 color: #777;
 border-bottom: 1px solid #d8d8d8;
}

table.keylist td.key {
 font-family: arial, sans-serif;
 font-size: 10px;
 color: #444;
 font-weight: bold;
}

table.keylist td.desc {
 font-family: arial, sans-serif;
 font-size: 10px;
 color: #333;
}

table.gmutable th {
 background: #999;
}

div.gmutable {
 border: 0px;
}

</style>

<h1>Configurazione notifiche tickets</h1>
<hr/>

<h2>Notifiche via email</h2>
<p><input type='checkbox' id='enable-statusalerts' <?php if($config['statusalert']['enabled']) echo "checked='true'"; ?>/> <b>Abilita notifiche via email</b><br/><br/>Quando un tecnico (collaboratore/dipendente) cambia lo status di un ticket &egrave; possibile farsi recapitare una notifica al proprio indirizzo email (quello dell&lsquo;amministratore o l&lsquo;addetto alla gestione dei ticket)</p>

 <?php
 if($config['statusalert']['sendername'] && $config['statusalert']['senderemail'])
  $alertsender = $config['statusalert']['sendername']." <".$config['statusalert']['senderemail'].">";
 else if($config['statusalert']['senderemail'])
  $alertsender = $config['statusalert']['senderemail'];
 ?>


<p style='padding-top:0px'>
 <table cellspacing='0' cellpadding='3' border='0'>
  <tr><td>Destinatario: </td>
	<td><input type='text' class='edit' style='width:200px' id="statusalert-recp" value="<?php echo $config['statusalert']['recp']; ?>"/></td>
	<td><small>Indica l&lsquo;indirizzo email dove recapitare le notifiche.</small></td></tr>

  <tr><td>Mittente: </td>
	<td><input type='text' class='edit' style='width:200px' id="statusalert-sender" value="<?php echo $alertsender; ?>" placeholder="<?php echo $_SMTP_USERNAME; ?>"/></td>
	<td><small>Indica l&lsquo;indirizzo email del mittente. Se omesso verr&agrave; utilizzato quello predefinito da sendmail.</small></td></tr>

 </table>
</p>

<p style='margin-bottom:0px'><b>ABILITA NOTIFICHE PER I SEGUENTI STATUS</b></p>
<div id='statusalert-statuslist' style="margin:0px 0px 20px 20px;padding:0px">
 <?php
 $statuslist = $config['statusalert']['statuslist'] ? explode(",",$config['statusalert']['statuslist']) : array();
 reset($_TICKET_STATUS_LIST);
 while(list($k,$v) = each($_TICKET_STATUS_LIST))
 {
  $checked = in_array($k, $statuslist);
  echo "<input type='checkbox' data-value='".$k."'".($checked ? " checked='true'/> " : "/> ").$v['name']."<br/>";
 }
 ?>
</div>


<p><b>OGGETTO</b><br/><br/>
 Definisci, utilizzando le chiavi disponibili, l&lsquo;oggetto del messaggio.<br/>
 <input type='text' class='edit' id='statusalert-subject' style='width:600px;margin-bottom:0px;background:#feffcb;' value="<?php echo $config['statusalert']['subject']; ?>" placeholder="Es: Il ticket n. {NUM} &egrave; stato modificato"/>
 <br/>
 <br/>
 <small>Elenco delle chiavi disponibili</small>
 <table class='keylist' style='width:600px;margin-top0px' border='0' cellspacing='0' cellpadding='3'>
 <tr><th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th>
	<th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th></tr>

 <tr><td class='key'>{NUM}</td>					<td class='desc'>Numero ticket</td>
	 <td class='key'>{STATUS}</td>				<td class='desc'>Status</td></tr>

 <tr><td class='key'>{DATE}</td>				<td class='desc'>Data apertura ticket</td>
	 <td class='key'>{CLOSEDATE}</td>			<td class='desc'>Data chiusura ticket</td></tr>

 <tr><td class='key'>{TIME}</td>				<td class='desc'>Ora apertura ticket</td>
	 <td class='key'>{CLOSETIME}</td>			<td class='desc'>Ora chiusura ticket</td></tr>

 <tr><td class='key'>{TKTREF}</td>				<td class='desc'>N. ticket di riferimento</td>
	 <td class='key'>{OPERATOR}</td>			<td class='desc'>Operatore</td></tr>

 <tr><td class='key'>{TYPE}</td>				<td class='desc'>Tipologia ticket</td>
	 <td class='key'>{INTERVDATE}</td>			<td class='desc'>Data intervento</td></tr>

 <tr><td class='key'>{CUSTOMER}</td>			<td class='desc'>Cliente</td>
	 <td class='key'>{INTERVDESC}</td>			<td class='desc'>Descrizione intervento</td></tr>

 <tr><td class='key'>{FULLADDRESS}</td>			<td class='desc'>Indirizzo completo</td>
	 <td class='key'>{TAXDELIVERY}</td>			<td class='desc'>Data scadenza ticket</td></tr>

 <tr><td class='key'>{ADDR_CODE}</td>			<td class='desc'>Cod. indirizzo</td>
	 <td class='key'>{ADDR_ZIP}</td>			<td class='desc'>C.A.P.</td></tr>

 <tr><td class='key'>{ADDR_TITLE}</td>			<td class='desc'>Utente / Insegna / Citofono</td>
	 <td class='key'>{ADDR_PROV}</td>			<td class='desc'>Provincia</td></tr>

 <tr><td class='key'>{ADDR_ADDRESS}</td>		<td class='desc'>Indirizzo</td>
	 <td class='key'>{ADDR_CC}</td>				<td class='desc'>Paese (sigla)</td></tr>

 <tr><td class='key'>{ADDR_CITY}</td>			<td class='desc'>Citt&agrave;</td>
	 <td class='key'>{ADDR_NOTE}</td>			<td class='desc'>Note indirizzo</td></tr>

 <tr><td class='key'>{INTERVTIMEFROM}</td>		<td class='desc'>Ora inizio intervento</td>
	 <td class='key'>{INTERVTIMETO}</td>		<td class='desc'>Ora fine intervento</td></tr>

 <?php
 if(file_exists($_BASE_PATH."Tickets/config-custom.php"))
 {
  ?>
  <tr><td class='key'>{NC_CLIENTE}</td>			<td class='desc'>NC Cliente</td>
	  <td class='key'>{TECH_1}</td>				<td class='desc'>Tecnico 1</td></tr>
  <tr><td class='key'>{NC_COMMITTENTE}</td>		<td class='desc'>NC Committente</td>
	  <td class='key'>{TECH_2}</td>				<td class='desc'>Tecnico 2</td></tr>
  <tr><td class='key'>{EXT_CONTRACT_REF}</td>	<td class='desc'>Rif. Contratto</td>
	  <td class='key'>{APP_DATETIME}</td>		<td class='desc'>Data pianifica</td></tr>
  <?php
 }
 ?>

 </table>
</p>

<p><b>MESSAGGIO</b><br/><br/>Definisci il messaggio che deve apparire sull&lsquo; email di notifica. Anche qui puoi utilizzare le stesse chiavi cha hai usato per definire l&lsquo;oggetto del messaggio riportate qui sopra.<br/>
<?php
if($config['statusalert']['messageap'] && $config['statusalert']['messageid'])
{
 $ret = GShell("dynarc item-info -ap '".$config['statusalert']['messageap']."' -id '".$config['statusalert']['messageid']."'");
 if(!$ret['error'])
 {
  $statusAlertRefAP = $config['statusalert']['messageap'];
  $statusAlertRefID = $config['statusalert']['messageid'];
  $statusAlertMessage = $ret['outarr']['desc'];
 }
}
else
{
 // default message //
 $statusAlertMessage = "Il ticket n. {NUM} &egrave; appena stato modificato.<br/><br/>";
 $statusAlertMessage.= "Status: {STATUS}<br/>";
 $statusAlertMessage.= "Tecnico: <b>{TECH_1}</b><br/>";
 $statusAlertMessage.= "Descrizione dell&lsquo;intervento: <br/>{INTERVDESC}<br/>";
}
?>
 <textarea id='statusalert-message' style='width:600px;height:300px' refap="<?php echo $statusAlertRefAP; ?>" refid="<?php echo $statusAlertRefID; ?>"><?php echo $statusAlertMessage; ?></textarea>
</p>

<hr/>
<input type='button' class='button-blue' value="Applica" onclick="saveConfig()"/>
<input type='button' class='button-blue' value="Salva e chiudi" onclick="saveConfig(true)"/>
<br/>
<br/>
<br/>
<br/>
<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();

?>
<script>

var EXIT_AFTER_SAVE = false;

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL+"accounts/Logout.php?continue="+this.getVar('continue');
	return false;
}

Template.OnInit = function(){
	 this.initEd(document.getElementById("statusalert-message"),"fckeditor","Optimized");
}

function saveConfig(exit)
{
 EXIT_AFTER_SAVE = exit ? true : false;
 var xml = "";
 
 saveStatusAlerts(xml, function(xml){saveFinish(xml);});

}

function saveStatusAlerts(xml, callback)
{
 var enabled = (document.getElementById("enable-statusalerts").checked == true) ? '1' : '0';

 var div = document.getElementById('statusalert-statuslist');
 var list = div.getElementsByTagName('INPUT');
 var statuslist = new Array();
 for(var c=0; c < list.length; c++)
 {
  var cb = list[c];
  if(cb.checked == true)
   statuslist.push(cb.getAttribute('data-value'));
 }

 var ed = document.getElementById('statusalert-message');
 var Subject = document.getElementById('statusalert-subject').value;
 var Sender = document.getElementById('statusalert-sender').value;
 var Recp = document.getElementById('statusalert-recp').value;
 var SenderName = "";
 var SenderEmail = "";
 if(Sender && (Sender.indexOf('<') > -1) && (Sender.indexOf('>') > -1))
 {
  var s = Sender.indexOf('<');
  var e = Sender.indexOf('>');
  var l = e-s;
  SenderName = Sender.substr(0,s).trim();
  SenderEmail = Sender.substr(s+1, l-1).trim();
 }
 else
  SenderEmail = Sender;
 
 var refAP = ed.getAttribute('refap') ? ed.getAttribute('refap') : "aboutconfig_htmlparms";
 var refID = ed.getAttribute('refid') ? ed.getAttribute('refid') : 0;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 xml+= "<statusalert enabled=\""+enabled+"\" statuslist=\""+implode(',',statuslist)+"\" subject=\""+Subject.E_QUOT()+"\" messageap=\""+refAP+"\" messageid=\""+a['id']+"\" sendername=\""+SenderName.E_QUOT()+"\" senderemail=\""+SenderEmail+"\" recp=\""+Recp+"\"/"+">";
	 callback(xml);
	}

 var content = ed.getValue();

 if(!refID)
  sh.sendCommand("dynarc new-cat -ap aboutconfig_htmlparms -name `Tickets` -tag tickets --if-not-exists && dynarc new-item -ap aboutconfig_htmlparms -ct tickets -name 'Email di notifica cambio status' -desc `"+content+"`");
 else
  sh.sendCommand("dynarc edit-item -ap '"+refAP+"' -id '"+refID+"' -desc `"+content+"`");

}

function saveFinish(xml)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){
	 alert("Salvataggio completato!");
	 if(EXIT_AFTER_SAVE)
	  Template.Exit();
	}
 sh.sendCommand("aboutconfig set-config -app tickets -sec alerts -xml-config `"+xml+"`");
}

</script>
<?php

$template->End();

?>
