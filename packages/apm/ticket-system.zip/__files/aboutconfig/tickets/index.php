<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2017 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 28-01-2017
 #PACKAGE: ticket-system
 #DESCRIPTION: Ticket configuration panel
 #VERSION: 2.18beta
 #CHANGELOG: 28-01-2017 : Aggiunto colonne sn,marca,colore e misura su lista servizi/manodopera/materiali.
			 12-11-2016 : Aggiunto campo priorita e telefono
			 17-06-2016 : Aggiunto inclusione allegati interni alle email.
			 16-06-2016 : Aggiunto chiavi su invio email al cliente e al tecnico collaboratore.
			 11-06-2016 : Aggiunto chiavi invio email e personalizzazione colonne lista ticket.
			 28-05-2016 : Aggiunto campi ricerca avanzata configurabili da aboutconfig.
			 18-05-2016 : Aggiunto chiavi INTERVDESC ed INTERVDATE su Riferimenti ai ticket sulle fatture
			 04-04-2016 : Bug fix gmutable orderable.
			 09-01-2015 : Aggiunto richieste di assistenza.
			 01-11-2014 : Aggiunto chiavi indirizzo su oggetto e messaggio email.
			 18-10-2014 : Aggiornamenti vari.
			 14-10-2014 : Aggiunto opzioni per invio ticket tramite email.
			 11-10-2014 : Aggiunto elenco tipologie di intervento.
			 10-10-2014 : Aggiunto schema indirizzo.
			 08-10-2014 : Aggiunta opzione nascondi bottone ticket annullati e calendario.
			 07-10-2014 : Aggiunto opzioni per data chiusura.
			 06-10-2014 : Aggiunto voci

 #TODO: Ripristinare le colonne tariffa oraria, costo al km, e chiamata su Tipi di Intervento.
		Ripristinare Sistema Operativo 2 (su campi da mostrare) una volta trovato il sistema nei ticket di selezionare più s.o.
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SMTP_USERNAME;

$_BASE_PATH = "../../";

include($_BASE_PATH."var/templates/glight/index.php");

global $_APPLICATION_CONFIG;
require_once($_BASE_PATH."Tickets/config.php");
$_TICKET_STATUS_LIST = $_APPLICATION_CONFIG['ticketstatus'];
$_APPLICATION_CONFIG = null;


$template = new GLightTemplate();
$template->includeObject("editsearch");
$template->includeObject("gmutable");
$template->includeObject("fckeditor");
$template->includeCSS("../aboutconfig.css");

$template->Begin("Settaggi principali");

/*$centerContents = "<input type='text' class='search' style='width:400px;float:left' placeholder='Cerca nella configurazione...' id='search' value=\"".htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\"/><input type='button' class='button-search' id='searchbtn'/>";*/
$centerContents = "<span class='glight-template-hdrtitle'>PANNELLO DI CONFIGURAZIONE - TICKETS</span>";

$template->Header("search", $centerContents, "BTN_EXIT", 800);

$template->Pathway();

$template->Body("default",800);

$_TICKETLIST_COLUMNS = array(
 'code_num' => array('title'=>'N. ticket', 	'width'=>70),
 'ext_ticket_ref' => array('title'=>'Rif. Ticket'),
 'ctime' => array('title'=>'Data apertura', 'width'=>100),
 'tax_delivery' => array('title'=>'Data scadenza',	'width'=>120),
 'finish_datetime' => array('title'=>'Data chiusura', 'width'=>120),
 'subject_name' => array('title'=>'Cliente'),
 'ticket_type' => array('title'=>'Tipologia'),
 'contact_id' => array('title'=>'Indirizzo'),
 'zone' => array('title'=>'Zona'),
 'operator_id' => array('title'=>'Operatore'),
 'tech_1' => array('title'=>'Tecnico'),
 'hw_name' => array('title'=>'Hardware'),
 'shelf' => array('title'=>'Scaffale'),
 'amount' => array('title'=>'Imponibile'),
 'vat' => array('title'=>'IVA'),
 'total' => array('title'=>'Totale'),
 'status' => array('title'=>'Status'),
 'priority' => array('title'=>'Priorita'),
 'phone' => array('title'=>'Telefono'),
 'note' => array('title'=>'Note')
);

$_INTERVLIST_COLUMNS = array(
	 'date'=> array('title'=>"Data", 'width'=>80),
	 'title'=> array('title'=>"Descrizione"),
	 'description'=> array('title'=>"Dettagli"),
	 'operator'=> array('title'=>"Tecnico", 'width'=>150),
	 'hours'=> array('title'=>"Ore ord.", 'width'=>60),
	 'extrahours'=> array('title'=>"Ore straord.", 'width'=>60),
	 'tothours'=> array('title'=>'Tot. ore', 'width'=>60),
	 'starttime'=> array('title'=>'Ora inizio', 'width'=>60),
	 'endtime'=> array('title'=>'Ora fine', 'width'=>60),
	 'starttime2'=> array('title'=>'Ora inizio 2', 'width'=>60),
	 'endtime2'=> array('title'=>'Ora fine 2', 'width'=>60),
	 'totamount'=> array('title'=>"Importo", 'width'=>60)
	);


$_ITEMLIST_COLUMNS = array(
	 'code'=> array('title'=>'Codice', 'width'=>60),
	 "sn"=>array("title"=>"S.N.", "width"=>100),
	 "brand"=>array("title"=>"Marca", "width"=>100),
	 'description'=> array('title'=>'Descrizione'),
	 'qty'=> array('title'=>'Qta', 'width'=>40),
	 'units'=> array('title'=>'U.M.', 'width'=>40),
	 "coltint"=>array("title"=>"Colore/Tinta", "width"=>100),
	 "sizmis"=>array("title"=>"Taglia/Misura", "width"=>100),
	 'unitprice'=> array('title'=>'PR. Unit', 'width'=>60),
	 'discount'=> array('title'=>'Sconto', 'width'=>60),
	 'vat'=> array('title'=>'I.V.A.', 'width'=>40),
	 'price'=> array('title'=>'Totale', 'width'=>120),
	 'vatprice'=> array('title'=>'Tot. + IVA', 'width'=>120),
	);

$_EXEX_COLUMNS = array(
	 'num'=> array('title'=>'Num.'),
	 'type'=> array('title'=>'Tipologia'),
	 'tktref'=> array('title'=>'N. ticket di rif.'),
	 'date'=> array('title'=>'Data apertura'),
	 'appdate'=> array('title'=>'Data appuntamento'),
	 'taxdelivery'=> array('title'=>'Data scadenza'),
	 'closedate'=> array('title'=>'Data chiusura'),
	 'customer'=> array('title'=>'Cliente'),
	 'fulladdress'=> array('title'=>'Indirizzo completo'),
	 'addrcode'=> array('title'=>'Cod. indirizzo'),
	 'addrtitle'=> array('title'=>'Insegna / Citofono'),
	 'addraddress'=> array('title'=>'Indirizzo'),
	 'addrcity'=> array('title'=>'Citta'),
	 'addrzipcode'=> array('title'=>'C.A.P.'),
	 'addrprov'=> array('title'=>'Provincia'),
	 'addrcc'=> array('title'=>'Paese'),
	 'addrnote'=> array('title'=>'Note indirizzo'),
	 'zone'=> array('title'=>'Zona'),
	 'operator'=> array('title'=>'Operatore'),
	 'tech1'=> array('title'=>'Tecnico 1'),
	 'tech2'=> array('title'=>'Tecnico 2'),
	 'hardware'=> array('title'=>'Hardware'),
	 'shelf'=> array('title'=>'Scaffale'),
	 'request'=> array('title'=>'Richiesta'),
	 'datatosave'=> array('title'=>'Dati da salvare'),
	 'accessories'=> array('title'=>'Accessori ritirati'),
	 'note'=> array('title'=>'Annotazioni'),
	 'description'=> array('title'=>'Descrizione dettagliata'),
	 'element'=> array('title'=>'Voce da fatturare'),
	 'qty'=> array('title'=>'Qta'),
	 'amount'=> array('title'=>'Imponibile'),
	 'vat'=> array('title'=>'I.V.A.'),
	 'total'=> array('title'=>'Totale'),
	);

$_ADVSEARCH_COLUMNS = array(
	 'intervtype' => array('title'=>"Tipo di interv.", 'desc'=>"Tipologia di intervento", 'visibled'=>true),
	 'status' => array('title'=>"Status", 'desc'=>"Ticket status", 'visibled'=>true),
	 'extticketref' => array('title'=>"Rif. Ticket", 'desc'=>"Riferimento ticket esterno", 'visibled'=>true),
	 'operator' => array('title'=>"Operatore", 'desc'=>"Operatore (colui che ha creato il ticket)", 'visibled'=>true),
	 'technician' => array('title'=>"Tecnico", 'desc'=>"Tecnico a cui &egrave; stato assegnato il ticket", 'visibled'=>true),
	 'collaborator' => array('title'=>"Collaboratore", 'desc'=>"Collaboratore a cui &egrave; stato assegnato il ticket", 'visibled'=>true),
	 'address' => array('title'=>"Indirizzo", 'desc'=>"Indirizzo", 'visibled'=>true),
	 'city' => array('title'=>"Citt&agrave;", 'desc'=>"Citt&agrave;", 'visibled'=>true),
	 'province' => array('title'=>"Provincia", 'desc'=>"Provincia", 'visibled'=>true),
	 'zone' => array('title'=>"Zona", 'desc'=>"Zona", 'visibled'=>true)
	);

$_EXCERT_COLUMNS = array(
	 'num'=> array('title'=>'Num.'),
	 'type'=> array('title'=>'Tipologia'),
	 'tktref'=> array('title'=>'N. ticket di rif.'),
	 'date'=> array('title'=>'Data apertura'),
	 'appdate'=> array('title'=>'Data appuntamento'),
	 'intervdate'=> array('title'=>'Data intervento'),
	 'intervtimefrom'=> array('title'=>'Ora inizio intervento'),
	 'intervtimeto'=> array('title'=>'Ora fine intervento'),
	 'taxdelivery'=> array('title'=>'Data scadenza'),
	 'closedate'=> array('title'=>'Data chiusura'),
	 'customer'=> array('title'=>'Cliente'),
	 'fulladdress'=> array('title'=>'Indirizzo completo'),
	 'addrcode'=> array('title'=>'Cod. indirizzo'),
	 'addrtitle'=> array('title'=>'Utente / Insegna / Citofono'),
	 'addraddress'=> array('title'=>'Indirizzo'),
	 'addrcity'=> array('title'=>'Citta'),
	 'addrzipcode'=> array('title'=>'C.A.P.'),
	 'addrprov'=> array('title'=>'Provincia'),
	 'addrcc'=> array('title'=>'Paese'),
	 'addrnote'=> array('title'=>'Note indirizzo'),
	 'zone'=> array('title'=>'Zona'),
	 'tech'=> array('title'=>'Tecnico / Collaboratore'),
	 'request'=> array('title'=>'Richiesta'),
	 'description'=> array('title'=>'Descrizione intervento'),
	 'note'=> array('title'=>'Annotazioni'),
	 'element'=> array('title'=>'Voce da fatturare'),
	 'qty'=> array('title'=>'Qta'),
	 'amount'=> array('title'=>'Imponibile'),
	 'vat'=> array('title'=>'I.V.A.'),
	 'total'=> array('title'=>'Totale'),
	 'intervamount' => array('title'=>'Tot. comp. tecnico')
	);

if(file_exists($_BASE_PATH."Tickets/config-custom.php"))
{
 $_TICKETLIST_COLUMNS['customer_name'] = array('title'=>"NC Cliente");
 $_TICKETLIST_COLUMNS['commiss_name'] = array('title'=>"NC Committente");
 $_TICKETLIST_COLUMNS['ext_contract_ref'] = array('title'=>"Rif. Contratto");

 $_ADVSEARCH_COLUMNS['custname'] = array('title'=>"NC Cliente", 'desc'=>"NC Cliente", 'visibled'=>true);
 $_ADVSEARCH_COLUMNS['commissname'] = array('title'=>"NC Committente", 'desc'=>"NC Committente", 'visibled'=>true);
 $_ADVSEARCH_COLUMNS['extcontractref'] = array('title'=>"Rif. Contratto", 'desc'=>"Riferimento contratto", 'visibled'=>true);

 $_EXCERT_COLUMNS['customer_name'] = array('title'=>"NC Cliente");
 $_EXCERT_COLUMNS['commiss_name'] = array('title'=>"NC Committente");
 $_EXCERT_COLUMNS['ext_contract_ref'] = array('title'=>"Rif. Contratto");
 /*$_EXCERT_COLUMNS['intervamount'] = array('title'=>"Imponibile intervento");
 $_EXCERT_COLUMNS['intervvat'] = array('title'=>"IVA intervento");
 $_EXCERT_COLUMNS['intervtotal'] = array('title'=>"Totale intervento");*/
}

/* GET LIST OF VAT RATES */
$ret = GShell("dynarc item-list -ap vatrates");
$_VAT_LIST = $ret['outarr']['items'];
$_VAT_BY_ID = array();
for($c=0; $c < count($_VAT_LIST); $c++)
 $_VAT_BY_ID[$_VAT_LIST[$c]['id']] = $_VAT_LIST[$c];


/* GET CONFIG */
$ret = GShell("aboutconfig get-config -app tickets");
if(!$ret['error'])
 $config = $ret['outarr']['config'];
else
 $configErr = $ret['message'];

if(is_array($config['advsearchfields']))
{
 reset($config['advsearchfields']);
 while(list($k,$v) = each($config['advsearchfields']))
 {
  if($_ADVSEARCH_COLUMNS[$v['name']])
  {
   $_ADVSEARCH_COLUMNS[$v['name']]['title'] = $v['title'];
   $_ADVSEARCH_COLUMNS[$v['name']]['visibled'] = $v['visibled'];
  }
 }
}


/* GET LIST OF OPERATORS */
$_OPERATORS = array();
$operators = _getGroupUserList(_getGID("tickets"));
for($c=0; $c < count($operators); $c++)
 $_OPERATORS[$operators[$c]['id']] = ($operators[$c]['fullname'] ? $operators[$c]['fullname'] : $operators[$c]['name']);

/* GET LIST OF TICKET TYPES */
$_TKTTYPES = array();
$ret = GShell("dynarc item-list -ap tickettypes");
$list = $ret['outarr']['items'];
for($c=0; $c < count($list); $c++)
 $_TKTTYPES[$list[$c]['id']] = $list[$c]['name'];


$_REQFORASSIST_INSTALLED = false;
$_REQFORASSIST_ENABLED = false;
$_EXTREQNOTIFY_ENABLED = false;

if(file_exists($_BASE_PATH."Tickets/externalrequest.php")) $_REQFORASSIST_INSTALLED = true;
if($config['extrequest']['enabled']) $_REQFORASSIST_ENABLED = true;
if($config['extrequest']['enablenotify']) $_EXTREQNOTIFY_ENABLED = true;
 

/*-------------------------------------------------------------------------------------------------------------------*/
?>
<style type="text/css">
table.keylist {
 background: #fafafa;
 border: 1px solid #d8d8d8;
}

table.keylist th {
 font-family: arial, sans-serif;
 font-size: 10px;
 color: #777;
 border-bottom: 1px solid #d8d8d8;
}

table.keylist td.key {
 font-family: arial, sans-serif;
 font-size: 10px;
 color: #444;
 font-weight: bold;
}

table.keylist td.desc {
 font-family: arial, sans-serif;
 font-size: 10px;
 color: #333;
}

table.gmutable th {
 background: #999;
}

div.gmutable {
 border: 0px;
}

</style>

<h1>Configurazione Tickets</h1>
<hr/>
<h2>INTERFACCIA</h2>

<!-- ALTEZZE EDITOR -->
<h3>Altezze editor</h3>
<p>
<table border='0' cellspacing='0' cellpadding='3'>
<tr><td>Altezza editor 'Descrizione dettagliata': </td>
	<td> <input type='text' class='edit' style='width:50px' id='ticketdesceditor-height' value="<?php echo $config['interface']['ticketdesceditorheight'] ? $config['interface']['ticketdesceditorheight'] : '200'; ?>"/> px</td></tr>
<tr><td>Altezza lista 'Interventi effettuati': </td>
	<td> <input type='text' class='edit' style='width:50px' id='intervlist-height' value="<?php echo $config['interface']['intervlistheight'] ? $config['interface']['intervlistheight'] : '150'; ?>"/> px</td></tr>
<tr><td>Altezza lista 'Servizi, manodopera e materiali': </td>
	<td> <input type='text' class='edit' style='width:50px' id='itemlist-height' value="<?php echo $config['interface']['itemlistheight'] ? $config['interface']['itemlistheight'] : '150'; ?>"/> px</td></tr>
<tr><td>Dimensione caratteri lista ticket: </td>
	<td> <input type='text' class='edit' style='width:50px' id='ticketlist-fontsize' value="<?php echo $config['interface']['ticketlistfontsize'] ? $config['interface']['ticketlistfontsize'] : '12'; ?>"/> px</td></tr>

</table>
</p>

<h3>Titolo scheda ticket</h3>
<p>
Quando clicchi su una voce della lista tickets verr&agrave; aperto il link di quel ticket in una nuova scheda del browser.
<br/>
<br/>Definisci qui sotto lo schema che deve avere il titolo di quella scheda.<br/>
<input type='text' class='edit' id='tickettitleschema' style='width:600px;margin-bottom:0px;background:#feffcb;' placeholder="Es: Ticket n.{NUM} del {DATE}" value="<?php echo $config['interface']['tickettitleschema']; ?>"/><br/><br/>
<small>Elenco delle chiavi disponibili</small>
<table class='keylist' style='width:600px;margin-top0px' border='0' cellspacing='0' cellpadding='3'>
<tr><th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th>
	<th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th></tr>

<tr><td class='key'>{NUM}</td>					<td class='desc'>Numero ticket</td>
	<td class='key'>{ZONE}</td>					<td class='desc'>Zona</td></tr>

<tr><td class='key'>{DATE}</td>					<td class='desc'>Data apertura ticket</td>
	<td class='key'>{CLOSEDATE}</td>			<td class='desc'>Data chiusura ticket</td></tr>

<tr><td class='key'>{TIME}</td>					<td class='desc'>Ora apertura ticket</td>
	<td class='key'>{CLOSETIME}</td>			<td class='desc'>Ora chiusura ticket</td></tr>

<tr><td class='key'>{TKTREF}</td>				<td class='desc'>N. ticket di riferimento</td>
	<td class='key'>{OPERATOR}</td>				<td class='desc'>Operatore</td></tr>

<tr><td class='key'>{TYPE}</td>					<td class='desc'>Tipologia ticket</td>
	<td class='key'>{TECH1}</td>				<td class='desc'>Tecnico 1</td></tr>

<tr><td class='key'>{CUSTOMER}</td>				<td class='desc'>Cliente</td>
	<td class='key'>{TECH2}</td>				<td class='desc'>Tecnico 2</td></tr>

 <tr><td class='key'>{FULLADDRESS}</td>			<td class='desc'>Indirizzo completo</td>
	 <td class='key'>{TAXDELIVERY}</td>			<td class='desc'>Data scadenza ticket</td></tr>

 <tr><td class='key'>{ADDR_CODE}</td>			<td class='desc'>Cod. indirizzo</td>
	 <td class='key'>{ADDR_ZIP}</td>			<td class='desc'>C.A.P.</td></tr>

 <tr><td class='key'>{ADDR_TITLE}</td>			<td class='desc'>Insegna / Citofono</td>
	 <td class='key'>{ADDR_PROV}</td>			<td class='desc'>Provincia</td></tr>

 <tr><td class='key'>{ADDR_ADDRESS}</td>		<td class='desc'>Indirizzo</td>
	 <td class='key'>{ADDR_CC}</td>				<td class='desc'>Paese (sigla)</td></tr>

 <tr><td class='key'>{ADDR_CITY}</td>			<td class='desc'>Citt&agrave;</td>
	 <td class='key'>{ADDR_NOTE}</td>			<td class='desc'>Note indirizzo</td></tr>

</table>
</p>

<h3>Nome del file PDF nelle stampe</h3>
<p>Utilizzando le stesse chiavi riportate qui sopra per il titolo della scheda ticket, definisci lo schema che deve avere il nome del file PDF quando viene generata la stampa di un ticket.<br/><br/>
 <input type='text' class='edit' id='pdffileschema' style='width:600px;margin-bottom:0px;background:#feffcb;' value="<?php echo $config['options']['pdffileschema']; ?>" placeholder="Es: ticket-{NUM}-{DATE}"/><br/><br/>
 <i>Attenzione! , eventuali spazi e caratteri speciali verranno automaticamente sostituiti con un "_" (underscore).<br/>
 Evitate di utilizzare le chiavi come {CLOSEDATE} e {CLOSETIME} perch&egrave; se stampate un ticket aperto quella data non verr&agrave; mostrata.</i>
</p>

<h3>Indirizzo</h3>
<p>
E&lsquo;possibile definire lo schema di visualizzazione degli indirizzi che appaiono sia nella scheda ticket che nell&lsquo;elenco ticket.
<br/>
<br/>Definisci qui sotto lo schema che devono avere gli indirizzi.<br/>
<input type='text' class='edit' id='ticketaddressschema' style='width:600px;margin-bottom:0px;background:#feffcb;' placeholder="Es: {ADDRESS} - {CITY} ({PROV})" value="<?php echo $config['interface']['ticketaddressschema']; ?>"/><br/><br/>
<small>Elenco delle chiavi disponibili</small>
<table class='keylist' style='width:600px;margin-top0px' border='0' cellspacing='0' cellpadding='3'>
<tr><th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th>
	<th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th></tr>

<tr><td class='key'>{CODE}</td>					<td class='desc'>Codice</td>
	<td class='key'>{ZIP}</td>					<td class='desc'>C.A.P.</td></tr>

<tr><td class='key'>{TITLE}</td>				<td class='desc'>Titolo</td>
	<td class='key'>{PROV}</td>					<td class='desc'>Provincia (sigla)</td></tr>

<tr><td class='key'>{ADDRESS}</td>				<td class='desc'>Indirizzo</td>
	<td class='key'>{CC}</td>					<td class='desc'>Paese (sigla)</td></tr>

<tr><td class='key'>{CITY}</td>					<td class='desc'>Citt&agrave;</td>
	<td class='key'>{NOTE}</td>					<td class='desc'>Annotazioni</td></tr>

</table>
</p>
<!-- SEZIONI DA MOSTRARE -->
<h3>Sezioni da mostrare nella scheda ticket</h3>
<small>Seleziona le sezioni che desideri avere all&lsquo;interno della scheda ticket in base alle tue esigienze e necessit&agrave;.</small>
<p>
 <table border='0' cellspacing='0' cellpadding='3'>
  <tr><td width='250'><input type='checkbox' id='hide-intervlist' <?php if(!$config['interface']['hideintervlist']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='intervlisttitle'><?php echo $config['interface']['intervlisttitle'] ? $config['interface']['intervlisttitle'] : "Lista interventi effettuati"; ?></span></td>
	  <td><span class="tinytext linkblue" onclick='renameIntervList()'>rinomina questa sezione</span></td></tr>

  <tr><td><input type='checkbox' id='hide-itemlist' <?php if(!$config['interface']['hideitemlist']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='itemlisttitle'><?php echo $config['interface']['itemlisttitle'] ? $config['interface']['itemlisttitle'] : "Lista servizi, manodopera e materiali"; ?></span></td>
	  <td><span class="tinytext linkblue" onclick='renameItemList()'>rinomina questa sezione</span></td></tr>

 </table>
</p>
<!-- CAMPI DA MOSTRARE -->
<h3>Campi da mostrare nella scheda ticket</h3>
<small>Seleziona i campi che desideri avere all&lsquo;interno della scheda ticket in base alle tue esigienze e necessit&agrave;.</small>
<p>
 <table border='0' cellspacing='0' cellpadding='3'>
  <tr><td width='150'><input type='checkbox' id='hide-field-address' <?php if(!$config['interface']['hidefieldaddress']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='field-address'><?php echo $config['interface']['fieldaddresstitle'] ? $config['interface']['fieldaddresstitle'] : "Indirizzo"; ?></span></td>
	  <td><small><i>(indirizzo / cantiere su cui si &egrave; svolto il lavoro per conto del cliente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-address')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='hide-field-zone' <?php if(!$config['interface']['hidefieldzone']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='field-zone'><?php echo $config['interface']['fieldzonetitle'] ? $config['interface']['fieldzonetitle'] : "Zona"; ?></span></td>
	  <td><small><i>(zona di intervento. Potete specificare regioni, quartieri, ecc...)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-zone')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='hide-field-note' <?php if(!$config['interface']['hidefieldnote']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='field-note'><?php echo $config['interface']['fieldnotetitle'] ? $config['interface']['fieldnotetitle'] : "Note"; ?></span></td>
	  <td><small><i>(note di apertura)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-note')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='hide-field-appointment' <?php if(!$config['interface']['hidefieldappointment']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='field-appointment'><?php echo $config['interface']['fieldappointmenttitle'] ? $config['interface']['fieldappointmenttitle'] : "Appuntamento"; ?></span></td>
	  <td><small><i>(data e ora appuntamento)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-appointment')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='hide-field-operator' <?php if(!$config['interface']['hidefieldoperator']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='field-operator'><?php echo $config['interface']['fieldoperatortitle'] ? $config['interface']['fieldoperatortitle'] : "Operatore"; ?></span></td>
	  <td><small><i>(operatore/responsabile, colui che apre il ticket)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-operator')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='hide-field-priority' <?php if(!$config['interface']['hidefieldpriority']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='field-priority'><?php echo $config['interface']['fieldprioritytitle'] ? $config['interface']['fieldprioritytitle'] : "Priorita"; ?></span></td>
	  <td><small><i>(priorit&agrave;)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-priority')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='hide-field-phone' <?php if(!$config['interface']['hidefieldphone']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='field-phone'><?php echo $config['interface']['fieldphonetitle'] ? $config['interface']['fieldphonetitle'] : "Telefono"; ?></span></td>
	  <td><small><i>(contatto telefonico del cliente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-phone')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='hide-field-tktreffile' <?php if(!$config['interface']['hidefieldtktreffile']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='field-tktreffile'><?php echo $config['interface']['fieldtktreffiletitle'] ? $config['interface']['fieldtktreffiletitle'] : "File ticket di riferimento"; ?></span></td>
	  <td><small><i>(&egrave; possibile allegare un file che pu&ograve; essere trattato come ticket di riferimento o altro)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-tktreffile')">rinomina questo campo</span></td></tr>

  <!------------------------------------------------------------------------------------------------------------------>

  <tr><td><input type='checkbox' id='show-field-request' <?php if($config['interface']['showfieldrequest']) echo "checked='true'"; ?>/> 
	<span class='smalltext' id='field-request'><?php echo $config['interface']['fieldrequesttitle'] ? $config['interface']['fieldrequesttitle'] : "Richiesta"; ?></span></td>
	  <td><small><i>(problema o richiesta segnalato dal cliente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-request')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-hardware' <?php if($config['interface']['showfieldhardware']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-hardware'><?php echo $config['interface']['fieldhardwaretitle'] ? $config['interface']['fieldhardwaretitle'] : "Hardware"; ?></span></td>
	  <td><small><i>(articolo,dispositivo,materiale ritirato dal cliente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-hardware')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-shelf' <?php if($config['interface']['showfieldshelf']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-shelf'><?php echo $config['interface']['fieldshelftitle'] ? $config['interface']['fieldshelftitle'] : "Scaffale"; ?></span></td>
	  <td><small><i>(scaffale, ubicazione materiale cliente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-shelf')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-accessories' <?php if($config['interface']['showfieldaccessories']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-accessories'><?php echo $config['interface']['fieldaccessoriestitle'] ? $config['interface']['fieldaccessoriestitle'] : "Accessori ritirati"; ?></span></td>
	  <td><small><i>(elenco degli accessori ritirati oltre al materiale del cliente in questione)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-accessories')">rinomina questo campo</span></td></tr>

  <!-- UTENTI E PASSWORD  -->

  <tr><td><input type='checkbox' id='show-field-datatosave' <?php if($config['interface']['showfielddatatosave']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-datatosave'><?php echo $config['interface']['fielddatatosavetitle'] ? $config['interface']['fielddatatosavetitle'] : "Dati da salvare"; ?></span></td>
	  <td><small><i>(elenco di files e cartelle da salvare)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-datatosave')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-os' <?php if($config['interface']['showfieldos']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-os'><?php echo $config['interface']['fieldostitle'] ? $config['interface']['fieldostitle'] : "Sistema Operativo"; ?></span></td>
	  <td><small><i>(Sistema Operativo installato nel dispositivo del cliente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-os')">rinomina questo campo</span></td></tr>

  <!-- <tr><td><input type='checkbox' id='show-field-os2' <?php if($config['interface']['showfieldos2']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-os2'><?php echo $config['interface']['fieldos2title'] ? $config['interface']['fieldos2title'] : "Sistema Operativo 2"; ?></span></td>
	  <td><small><i>(Sistema Operativo secondario installato nel dispositivo del cliente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-os2')">rinomina questo campo</span></td></tr> -->

  <!-- TODO: riattivare se necessario
  <tr><td><input type='checkbox' id='show-field-disksize' <?php if($config['interface']['showfielddisksize']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-disksize'><?php echo $config['interface']['fielddisksizetitle'] ? $config['interface']['fielddisksizetitle'] : "Dimensioni disco"; ?></span></td>
	  <td><small><i>(Capacit&agrave; e informazioni sul disco fisso)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-disksize')">rinomina questo campo</span></td></tr> -->

  <tr><td><input type='checkbox' id='show-field-user1' <?php if($config['interface']['showfielduser1']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-user1'><?php echo $config['interface']['fielduser1title'] ? $config['interface']['fielduser1title'] : "Utente 1"; ?></span></td>
	  <td><small><i>(login del primo utente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-user1')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-passwd1' <?php if($config['interface']['showfieldpasswd1']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-passwd1'><?php echo $config['interface']['fieldpasswd1title'] ? $config['interface']['fieldpasswd1title'] : "Password 1"; ?></span></td>
	  <td><small><i>(password del primo utente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-passwd1')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-user2' <?php if($config['interface']['showfielduser2']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-user2'><?php echo $config['interface']['fielduser2title'] ? $config['interface']['fielduser2title'] : "Utente 2"; ?></span></td>
	  <td><small><i>(login del secondo utente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-user2')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-passwd2' <?php if($config['interface']['showfieldpasswd2']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-passwd2'><?php echo $config['interface']['fieldpasswd2title'] ? $config['interface']['fieldpasswd2title'] : "Password 2"; ?></span></td>
	  <td><small><i>(password del secondo utente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-passwd2')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-user3' <?php if($config['interface']['showfielduser3']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-user3'><?php echo $config['interface']['fielduser3title'] ? $config['interface']['fielduser3title'] : "Utente 3"; ?></span></td>
	  <td><small><i>(login del terzo utente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-user3')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-passwd3' <?php if($config['interface']['showfieldpasswd3']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-passwd3'><?php echo $config['interface']['fieldpasswd3title'] ? $config['interface']['fieldpasswd3title'] : "Password 3"; ?></span></td>
	  <td><small><i>(password del terzo utente)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-passwd3')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-admin' <?php if($config['interface']['showfieldadmin']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-admin'><?php echo $config['interface']['fieldadmintitle'] ? $config['interface']['fieldadmintitle'] : "Login Amministratore"; ?></span></td>
	  <td><small><i>(login dell&lsquo;utente amministratore)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-admin')">rinomina questo campo</span></td></tr>

  <tr><td><input type='checkbox' id='show-field-adminpasswd' <?php if($config['interface']['showfieldadminpasswd']) echo "checked='true'"; ?>/> <span class='smalltext' id='field-adminpasswd'><?php echo $config['interface']['fieldadminpasswdtitle'] ? $config['interface']['fieldadminpasswdtitle'] : "Password Amministratore"; ?></span></td>
	  <td><small><i>(password amministratore)</i></small></td>
	  <td><span class="tinytext linkblue" onclick="renameField('field-adminpasswd')">rinomina questo campo</span></td></tr>


 </table>
</p>

<!-- PERSONALIZZAZIONE COLONNE LISTA TICKET -->
<h3>Disposizione colonne della lista ticket</h3>
<small>Seleziona le colonne che desideri mostrare. Puoi anche rinominarle, modificare le dimensioni e l&lsquo;ordinamento semplicemente trascinandole su e giu.</small>
<div class="gmutable" style="height:300px;margin-top:10px;padding:0px">
 <table id='ticketlist' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
   <tr><th width='32'><input type='checkbox'/></th>
	   <th id='tag' width='100'>TAG</th>
	   <th id='title' editable='true'>TITOLO</th>
	   <th id='width' width='80' editable='true' format='number'>DIMENSIONE</th>
   </tr>
   <?php
   $_USER_COLUMNS = array();
   if(is_array($config['ticketlistcolumns']))
   {
	for($c=0; $c < count($config['ticketlistcolumns']); $c++)
	{
	 $col = $config['ticketlistcolumns'][$c];
	 echo "<tr class='selected'><td><input type='checkbox' checked='true'/></td><td>".$col['tag']."</td><td><span class='graybold'>".$col['title']."</span></td><td><span class='graybold'>".$col['width']."</span></td></tr>";
	 $_USER_COLUMNS[$col['tag']] = true;
	}
   }
   else
   {
	$ret = GShell("aboutconfig get -app tickets -sec ticketlist");
	if(!$ret['error'])
	{
	 $settings = $ret['outarr']['defaultsettings'];
	 if(is_array($settings['ticketlist']))
	 {
	  $visibledColumns = explode(",",$settings['ticketlist']['visibledcolumns']);
	  reset($_TICKETLIST_COLUMNS);
	  while(list($k,$col) = each($_TICKETLIST_COLUMNS))
	  {
	   if(in_array($k, $visibledColumns))
	   {
		echo "<tr class='selected'><td><input type='checkbox' checked='true'/></td><td>".$k."</td><td><span class='graybold'>".$col['title']."</span></td><td><span class='graybold'>".$col['width']."</span></td></tr>";
		$_USER_COLUMNS[$k] = true;
	   }
	  }
	 }
	}
   }
   reset($_TICKETLIST_COLUMNS);
   while(list($k,$v)=each($_TICKETLIST_COLUMNS))
   {
	if($_USER_COLUMNS[$k]) continue;
	echo "<tr><td><input type='checkbox'/></td><td>".$k."</td><td><span class='graybold'>".$v['title']."</span></td><td><span class='graybold'>"
		.$v['width']."</span></td></tr>";
   }
   ?>
 </table>
</div>
<br/><br/>

<!-- INTERVENTI EFFETTUATI -->
<h3>Disposizione colonne della lista &quot;Interventi effettuati&quot;</h3>
<small>Seleziona le colonne che desideri mostrare. Puoi anche rinominarle, modificare le dimensioni e l&lsquo;ordinamento semplicemente trascinandole su e giu.</small>
<div class="gmutable" style="height:300px;margin-top:10px;padding:0px">
 <table id='intervlist' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
   <tr><th width='32'><input type='checkbox'/></th>
	   <th id='tag' width='100'>TAG</th>
	   <th id='title' editable='true'>TITOLO</th>
	   <th id='width' width='80' editable='true' format='number'>DIMENSIONE</th>
   </tr>
   <?php
   $_USER_COLUMNS = array();
   if(is_array($config['intervcolumns']))
   {
	for($c=0; $c < count($config['intervcolumns']); $c++)
	{
	 $col = $config['intervcolumns'][$c];
	 echo "<tr class='selected'><td><input type='checkbox' checked='true'/></td><td>".$col['tag']."</td><td><span class='graybold'>".$col['title']."</span></td><td><span class='graybold'>".$col['width']."</span></td></tr>";
	 $_USER_COLUMNS[$col['tag']] = true;
	}
   }
   reset($_INTERVLIST_COLUMNS);
   while(list($k,$v)=each($_INTERVLIST_COLUMNS))
   {
	if($_USER_COLUMNS[$k]) continue;
	echo "<tr><td><input type='checkbox'/></td><td>".$k."</td><td><span class='graybold'>".$v['title']."</span></td><td><span class='graybold'>"
		.$v['width']."</span></td></tr>";
   }
   ?>
 </table>
</div>
<br/><br/>
<!-- SERVIZI,MANODOPERA E MATERIALI -->
<h3>Disposizione colonne della lista &quot;Servizi, manodopera e materiali&quot;</h3>
<small>Seleziona le colonne che desideri mostrare. Puoi anche rinominarle, modificare le dimensioni e l&lsquo;ordinamento semplicemente trascinandole su e giu.</small>
<div class="gmutable" style="height:320px;margin-top:10px;padding:0px">
 <table id='itemlist' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
   <tr><th width='32'><input type='checkbox'/></th>
	   <th id='tag' width='100'>TAG</th>
	   <th id='title' editable='true'>TITOLO</th>
	   <th id='width' width='80' editable='true' format='number'>DIMENSIONE</th>
   </tr>
   <?php
   $_USER_COLUMNS = array();
   if(is_array($config['itemscolumns']))
   {
	for($c=0; $c < count($config['itemscolumns']); $c++)
	{
	 $col = $config['itemscolumns'][$c];
	 echo "<tr class='selected'><td><input type='checkbox' checked='true'/></td><td>".$col['tag']."</td><td><span class='graybold'>".$col['title']."</span></td><td><span class='graybold'>".$col['width']."</span></td></tr>";
	 $_USER_COLUMNS[$col['tag']] = true;
	}
   }
   reset($_ITEMLIST_COLUMNS);
   while(list($k,$v)=each($_ITEMLIST_COLUMNS))
   {
	if($_USER_COLUMNS[$k]) continue;
	echo "<tr><td><input type='checkbox'/></td><td>".$k."</td><td><span class='graybold'>".$v['title']."</span></td><td><span class='graybold'>"
		.$v['width']."</span></td></tr>";
   }
   ?>
 </table>
</div>
<br/><br/>
<!-- CAMPI DA MOSTRARE SU RICERCA AVANZATA -->
<h3>Campi da mostrare su ricerca avanzata</h3>
<small>Seleziona i campi che desideri visualizzare nella ricerca avanzata (che &egrave; presente sulla sx nella lista dei ticket).</small>
<p>
 <table border='0' cellspacing='0' cellpadding='3' id='advsearchfieldstable'>
 <?php
  reset($_ADVSEARCH_COLUMNS);
  while(list($k,$v) = each($_ADVSEARCH_COLUMNS))
  {
   echo "<tr data-ref='".$k."'><td width='150'><input type='checkbox'".($v['visibled'] ? " checked='true'/>" : "/>");
   echo "<span class='smalltext' id='advsearch_".$k."_title'>".$v['title']."</span></td>";
   echo "<td><small><i>".$v['desc']."</i></small></td>";
   echo "<td><span class='tinytext linkblue' onclick=\"renameAdvSearchField('advsearch_".$k."_title')\">rinomina questo campo</span></td></tr>";
  }
 ?>
 </table>
</p>
<br/><br/>

<!-- OPZIONI -->
<h2>OPZIONI</h2>
<h3>Opzioni principali</h3>
<p>
 <table cellspacing='0' cellpadding='3' border='0'>
 <tr><td width='300'><input type='checkbox' id='hidecanceledbtn' <?php if($config['options']['hidecanceledbtn']) echo "checked='true'"; ?>/> Nascondi ticket annullati</td>
	 <td><small>Nasconde il bottone per mostrare i ticket annullati. E&lsquo;possibile comunque visualizzarli agendo tramite il filtro status sulla ricerca avanzata.</small></td></tr>
 <tr><td><input type='checkbox' id='autoinslabor' <?php if($config['options']['autoinslabor']) echo "checked='true'"; ?>/> Inserimento automatico manodopera</td>
	 <td><small>Inserisce automaticamente l&lsquo;importo totale della manodopera nella tabella &quot;Servizi, manodopera e materiali&quot;</small></td></tr>
 <tr><td>Aliq. IVA predefinita sulla manodopera:</td>
	 <td><input type='text' class='dropdown' id='laborvat' connect='laborvatlist' style='width:200px' value="<?php echo $config['options']['laborvatid'] ? $_VAT_BY_ID[$config['options']['laborvatid']]['name'] : ''; ?>" retval="<?php echo $config['options']['laborvatid']; ?>"/>
	  <ul class='popupmenu' id='laborvatlist'>
	   <?php
		for($c=0; $c < count($_VAT_LIST); $c++)
		 echo "<li value='".$_VAT_LIST[$c]['id']."'>".$_VAT_LIST[$c]['name']."</li>";
	   ?>
	  </ul>
	 </td></tr>
 </table>
</p>
<h3>Duplicazione ticket</h3>
<p>Seleziona i campi da mantenere, o impostare, quando si duplica un ticket.<br/>
 <table cellspacing='0' cellpadding='3' border='0'>
  <tr><td width='200'><input type='checkbox' id='tktclone-customer' <?php if($config['options']['clonecustomer']) echo "checked='true'"; ?>/> Cliente</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-address' <?php if($config['options']['cloneaddress']) echo "checked='true'"; ?>/> Indirizzo</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-ctime' <?php if($config['options']['clonectime']) echo "checked='true'"; ?>/> Data e ora apertura</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-expiry' <?php if($config['options']['cloneexpiry']) echo "checked='true'"; ?>/> Data e ora scadenza</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-type' <?php if($config['options']['clonetype']) echo "checked='true'"; ?>/> Tipologia</td>
	  <td><input type='radio' name='tktclonetype' <?php if($config['options']['clonetype'] == 'clone') echo "checked='true'"; ?>/> copia &nbsp;
		  <input type='radio' name='tktclonetype' <?php if($config['options']['clonetype'] && ($config['options']['clonetype'] != 'clone')) echo "checked='true'"; ?>/> imposta a: <input type='text' class='dropdown' readonly='true' id='tktclone-type-dropdown' connect='tktclone-type-list' style='width:200px' retval="<?php if($config['options']['clonetype'] && ($config['options']['clonetype'] != 'clone')) echo $config['options']['clonetype']; ?>" value="<?php if($config['options']['clonetype'] && ($config['options']['clonetype'] != 'clone')) echo $_TKTTYPES[$config['options']['clonetype']]; ?>"/>
	   <ul class='popupmenu' id='tktclone-type-list'>
		<li value='0'>&nbsp;</li>
		<?php
		 reset($_TKTTYPES);
		 while(list($k,$v)=each($_TKTTYPES))
		 {
		  echo "<li value='".$k."'>".$v."</li>";
		 }
		?>
	   </ul>
	  </td></tr>
  <tr><td><input type='checkbox' id='tktclone-operator' <?php if($config['options']['cloneoperator']) echo "checked='true'"; ?>/> Operatore</td>
	  <td><input type='radio' name='tktcloneoperator' <?php if($config['options']['cloneoperator'] == 'clone') echo "checked='true'"; ?>/> copia &nbsp;
		  <input type='radio' name='tktcloneoperator' <?php if($config['options']['cloneoperator'] && ($config['options']['cloneoperator'] != 'clone')) echo "checked='true'"; ?>/> imposta a: <input type='text' class='dropdown' readonly='true' id='tktclone-operator-dropdown' connect='tktclone-operator-list' style='width:200px' retval="<?php if($config['options']['cloneoperator'] && ($config['options']['cloneoperator'] != 'clone')) echo $config['options']['cloneoperator']; ?>" value="<?php if($config['options']['cloneoperator'] && ($config['options']['cloneoperator'] != 'clone')) echo $_OPERATORS[$config['options']['cloneoperator']]; ?>"/>
	   <ul class='popupmenu' id='tktclone-operator-list'>
		<?php
		 reset($_OPERATORS);
		 while(list($k,$v)=each($_OPERATORS))
		 {
		  echo "<li value='".$k."'>".$v."</li>";
		 }
		?>
	   </ul>
	  </td></tr>
  <tr><td><input type='checkbox' id='tktclone-zone' <?php if($config['options']['clonezone']) echo "checked='true'"; ?>/> Zona</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-exttktref' <?php if($config['options']['cloneexttktref']) echo "checked='true'"; ?>/> Riferimento ticket esterno</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-tktreffile' <?php if($config['options']['clonetktreffile']) echo "checked='true'"; ?>/> File ticket di riferimento</td>
	  <td>&nbsp;</td></tr>

  <tr><td><input type='checkbox' id='tktclone-hardware' <?php if($config['options']['clonehardware']) echo "checked='true'"; ?>/> Hardware</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-shelf' <?php if($config['options']['cloneshelf']) echo "checked='true'"; ?>/> Scaffale</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-request' <?php if($config['options']['clonerequest']) echo "checked='true'"; ?>/> Richieste cliente</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-datatosave' <?php if($config['options']['clonedatatosave']) echo "checked='true'"; ?>/> Dati da salvare</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-accessories' <?php if($config['options']['cloneaccessories']) echo "checked='true'"; ?>/> Accessori ritirati</td>
	  <td>&nbsp;</td></tr>


  <tr><td><input type='checkbox' id='tktclone-note' <?php if($config['options']['clonenote']) echo "checked='true'"; ?>/> Note di apertura</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-description' <?php if($config['options']['clonedescription']) echo "checked='true'"; ?>/> Descrizione dettagliata</td>
	  <td>&nbsp;</td></tr>
  <tr><td><input type='checkbox' id='tktclone-status' <?php if($config['options']['clonestatus']) echo "checked='true'"; ?>/> Status</td>
	  <td><input type='radio' name='tktclonestatus' <?php if($config['options']['clonestatus'] == 'clone') echo "checked='true'"; ?>/> copia &nbsp;
		  <input type='radio' name='tktclonestatus' <?php if($config['options']['clonestatus'] && ($config['options']['clonestatus'] != 'clone')) echo "checked='true'"; ?>/> imposta a: <input type='text' class='dropdown' readonly='true' id='tktclone-status-dropdown' connect='tktclone-status-list' style='width:200px' retval="<?php if($config['options']['clonestatus'] && ($config['options']['clonestatus'] != 'clone')) echo $config['options']['clonestatus']; ?>" value="<?php if($config['options']['clonestatus'] && ($config['options']['clonestatus'] != 'clone')) echo $_TICKET_STATUS_LIST[$config['options']['clonestatus']]['name']; ?>"/>
	   <ul class='popupmenu' id='tktclone-status-list'>
		<?php
		while(list($k,$v)=each($_TICKET_STATUS_LIST))
		 echo "<li value='".$k."'>".$v['name']."</li>";
		?>
	   </ul>
	  </td></tr>
 </table>
</p>
<br/><br/>
<!-- ESPORTAZIONI -->
<h2>ESPORTAZIONI</h2>
<h3>Elenco campi da esportare in Excel come &quot;resi servizi&quot;</h3>
<small>Seleziona le colonne che desideri esportare sul file Excel. Puoi anche rinominarle e modificare l&lsquo;ordinamento semplicemente trascinandole su e giu.</small>
<div class="gmutable" style="height:300px;margin-top:10px;padding:0px">
 <table id='exportexplodedlist' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
   <tr><th width='32'><input type='checkbox' onchange="EXEXTB.selectAll(this.checked)"/></th>
	   <th id='tag' width='100'>TAG</th>
	   <th id='title' editable='true'>TITOLO</th>
   </tr>
   <?php
   $_EXEXUSER_COLUMNS = array();
   if(is_array($config['exexcolumns']))
   {
	for($c=0; $c < count($config['exexcolumns']); $c++)
	{
	 $col = $config['exexcolumns'][$c];
	 echo "<tr class='selected'><td><input type='checkbox' checked='true'/></td><td>".$col['tag']."</td><td><span class='graybold'>".$col['title']."</span></td></tr>";
	 $_EXEXUSER_COLUMNS[$col['tag']] = true;
	}
   }
   reset($_EXEX_COLUMNS);
   while(list($k,$v)=each($_EXEX_COLUMNS))
   {
	if($_EXEXUSER_COLUMNS[$k]) continue;
	echo "<tr><td><input type='checkbox'/></td><td>".$k."</td><td><span class='graybold'>".$v['title']."</span></td></tr>";
   }
   ?>
 </table>
</div>
<br/><br/>

<!-- CERTIFICAZIONE TECNICO/COLLABORATORE -->
<h2>CERTIFICAZIONE TECNICO/COLLABORATORE</h2>
<h3>Elenco campi da esportare in Excel come certificazione tecnico/collaboratore.</h3>
<small>Seleziona le colonne che desideri esportare sul file Excel. Puoi anche rinominarle e modificare l&lsquo;ordinamento semplicemente trascinandole su e giu.</small>
<div class="gmutable" style="height:300px;margin-top:10px;padding:0px">
 <table id='exportcert' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
   <tr><th width='32'><input type='checkbox' onchange="EXCERTTB.selectAll(this.checked)"/></th>
	   <th id='tag' width='100'>TAG</th>
	   <th id='title' editable='true'>TITOLO</th>
   </tr>
   <?php
   $_EXCERTUSER_COLUMNS = array();
   if(is_array($config['excertcolumns']))
   {
	for($c=0; $c < count($config['excertcolumns']); $c++)
	{
	 $col = $config['excertcolumns'][$c];
	 echo "<tr class='selected'><td><input type='checkbox' checked='true'/></td><td>".$col['tag']."</td><td><span class='graybold'>".$col['title']."</span></td></tr>";
	 $_EXCERTUSER_COLUMNS[$col['tag']] = true;
	}
   }
   reset($_EXCERT_COLUMNS);
   while(list($k,$v)=each($_EXCERT_COLUMNS))
   {
	if($_EXCERTUSER_COLUMNS[$k]) continue;
	echo "<tr><td><input type='checkbox'/></td><td>".$k."</td><td><span class='graybold'>".$v['title']."</span></td></tr>";
   }
   ?>
 </table>
</div>
<br/><br/>

<!-- CONSUNTIVO CLIENTE -->
<h2>CONSUNTIVO CLIENTE</h2>
<h3>Elenco campi da esportare in Excel come consuntivo cliente.</h3>
<small>Seleziona le colonne che desideri esportare sul file Excel. Puoi anche rinominarle e modificare l&lsquo;ordinamento semplicemente trascinandole su e giu.</small>
<div class="gmutable" style="height:300px;margin-top:10px;padding:0px">
 <table id='exportcons' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
   <tr><th width='32'><input type='checkbox' onchange="EXCONSTB.selectAll(this.checked)"/></th>
	   <th id='tag' width='100'>TAG</th>
	   <th id='title' editable='true'>TITOLO</th>
   </tr>
   <?php
   $_EXCONSUSER_COLUMNS = array();
   if(is_array($config['exconscolumns']))
   {
	for($c=0; $c < count($config['exconscolumns']); $c++)
	{
	 $col = $config['exconscolumns'][$c];
	 echo "<tr class='selected'><td><input type='checkbox' checked='true'/></td><td>".$col['tag']."</td><td><span class='graybold'>".$col['title']."</span></td></tr>";
	 $_EXCONSUSER_COLUMNS[$col['tag']] = true;
	}
   }
   reset($_EXCERT_COLUMNS);
   while(list($k,$v)=each($_EXCERT_COLUMNS))
   {
	if($_EXCONSUSER_COLUMNS[$k]) continue;
	echo "<tr><td><input type='checkbox'/></td><td>".$k."</td><td><span class='graybold'>".$v['title']."</span></td></tr>";
   }
   ?>
 </table>
</div>
<br/><br/>

<!-- CHIUSURA -->
<h2>CHIUSURA</h2>
<h3>Modalit&agrave; di chiusura</h3>
<p>
 <table cellspacing='0' cellpadding='3' border='0'>
 <tr><td width='100'><input type='radio' name='closuremodal' <?php if($config['closure']['modal'] != 'simply') echo "checked='true'"; ?>/>Avanzata</td>
	 <td><small>Permette di emettere fattura direttamente dal ticket, con la possibilit&agrave; di scegliere la modalit&agrave; di chiusura (scontrino o fattura), la modalit&agrave; di pagamento (bonifico, contanti, carta di credito, ...) e le note di chiusura.</small></td></tr>
 <tr><td><input type='radio' name='closuremodal' <?php if($config['closure']['modal'] == 'simply') echo "checked='true'"; ?>/>Semplice</td>
	 <td><small>La fatturazione avviene automaticamente mediante la procedura di raggruppamento ticket.</small></td></tr>
 </table>
</p>

<h3>Data chiusura</h3>
<p>
 <table cellspacing='0' cellpadding='3' border='0'>
 <tr><td width='200'><input type='radio' name='finishdatemodal' <?php if($config['closure']['finishdatemodal'] == 'lastworktime') echo "checked='true'"; ?>/>Termine lavori</td>
	 <td><small>Imposta come data e ora chiusura quella dell&lsquo;ultimo lavoro fatto.</small></td></tr>
 <tr><td><input type='radio' name='finishdatemodal' <?php if(!$config['closure']['finishdatemodal'] || ($config['closure']['finishdatemodal'] == 'auto')) echo "checked='true'"; ?>/>Automatica</td>
	 <td><small>Imposta la chiusura con la data e l&lsquo;ora corrente.</small></td></tr>
 <tr><td><input type='radio' name='finishdatemodal' <?php if($config['closure']['finishdatemodal'] == 'manual') echo "checked='true'"; ?>/>Manuale</td>
	 <td><small>Imposta manualmente la data e &lsquo;ora di chiusura ticket.</small></td></tr>
 </table>
</p>

<h3>Riferimenti ai ticket sulle fatture</h3>
<p>
Quando raggruppi i ticket in una fattura all&lsquo;interno del corpo di quella fattura verranno automaticamente inserite le diciture con i riferimenti di quei ticket assieme ai loro importi. <i>Es: Rif. Rapp. d&lsquo;intervento n.XXX del gg/mm/aaaa.....</i>
<br/>
<br/>Definisci qui sotto lo schema che devono avere tali diciture utilizzando le chiavi appropriate.<br/>
<input type='text' class='edit' id='ticketrefschema' style='width:600px;margin-bottom:0px;background:#feffcb;' placeholder="Es: Rif. Ticket n.{NUM} del {DATE}" value="<?php echo $config['closure']['ticketrefschema']; ?>"/><br/><br/>
<input type='text' class='edit' id='ticketrefschemanote' style='width:600px;margin-bottom:0px;background:#feffcb;' placeholder="Se la dicitura &egrave; troppo lunga ti consiglio di troncarla in due ed inserire qui la porzione di testo pi&ugrave; grande." value="<?php echo $config['closure']['ticketrefschemanote']; ?>"/><br/><br/>

<small>Elenco delle chiavi disponibili</small>
<table class='keylist' style='width:600px;margin-top0px' border='0' cellspacing='0' cellpadding='3'>
<tr><th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th>
	<th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th></tr>

<tr><td class='key'>{NUM}</td>					<td class='desc'>Numero ticket</td>
	<td class='key'>{ZONE}</td>					<td class='desc'>Zona</td></tr>

<tr><td class='key'>{DATE}</td>					<td class='desc'>Data apertura ticket</td>
	<td class='key'>{CLOSEDATE}</td>			<td class='desc'>Data chiusura ticket</td></tr>

<tr><td class='key'>{TIME}</td>					<td class='desc'>Ora apertura ticket</td>
	<td class='key'>{CLOSETIME}</td>			<td class='desc'>Ora chiusura ticket</td></tr>

<tr><td class='key'>{TKTREF}</td>				<td class='desc'>N. ticket di riferimento</td>
	<td class='key'>{OPERATOR}</td>				<td class='desc'>Operatore</td></tr>

<tr><td class='key'>{TYPE}</td>					<td class='desc'>Tipologia ticket</td>
	<td class='key'>{TECH1}</td>				<td class='desc'>Tecnico 1</td></tr>

<tr><td class='key'>{CUSTOMER}</td>				<td class='desc'>Cliente</td>
	<td class='key'>{TECH2}</td>				<td class='desc'>Tecnico 2</td></tr>

 <tr><td class='key'>{INTERVDATE}</td>			<td class='desc'>Data intervento</td>
	<td class='key'>{INTERVDESC}</td>			<td class='desc'>Descrizione intervento</td></tr>

 <tr><td class='key'>{FULLADDRESS}</td>			<td class='desc'>Indirizzo completo</td>
	 <td class='key'>{TAXDELIVERY}</td>			<td class='desc'>Data scadenza ticket</td></tr>

 <tr><td class='key'>{ADDR_CODE}</td>			<td class='desc'>Cod. indirizzo</td>
	 <td class='key'>{ADDR_ZIP}</td>			<td class='desc'>C.A.P.</td></tr>

 <tr><td class='key'>{ADDR_TITLE}</td>			<td class='desc'>Insegna / Citofono</td>
	 <td class='key'>{ADDR_PROV}</td>			<td class='desc'>Provincia</td></tr>

 <tr><td class='key'>{ADDR_ADDRESS}</td>		<td class='desc'>Indirizzo</td>
	 <td class='key'>{ADDR_CC}</td>				<td class='desc'>Paese (sigla)</td></tr>

 <tr><td class='key'>{ADDR_CITY}</td>			<td class='desc'>Citt&agrave;</td>
	 <td class='key'>{ADDR_NOTE}</td>			<td class='desc'>Note indirizzo</td></tr>

</table>
</p>

<!-- CALENDARIO -->
<h2>CALENDARIO</h2>
<h3>Lista appuntamenti</h3>
<p>
 <table cellspacing='0' cellpadding='3' border='0'>
 <tr><td><input type='radio' name='applistview-modal' <?php if($config['calendar']['listviewmodal'] != 'onlyopen') echo "checked='true'"; ?>/>mostra tutti gli appuntamenti</td></tr>
 <tr><td><input type='radio' name='applistview-modal' <?php if($config['calendar']['listviewmodal'] == 'onlyopen') echo "checked='true'"; ?>/>mostra solo quelli aperti</td></tr>
 </table>
</p>

<!-- TIPOLOGIE DI INTERVENTO -->
<h2>TIPI DI INTERVENTO</h2>
<h3>Elenco tipologie di intervento <img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/button.png" title="Aggiungi" style="cursor:pointer" onclick="AddTicketType()"/></h3>
<div class="gmutable" style="height:300px;margin-top:10px;padding:0px">
 <table id='tickettypelist' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
   <tr>
	   <th id='code' width='100' editable='true'>COD</th>
	   <th id='title' editable='true'>TITOLO</th>
	   <!-- <th id='hourlyrate' width='80' editable='true' format='currency' style='font-size:8px'>TARIFFA ORARIA</th>
	   <th id='kmrate' width='80' editable='true' format='currency' style='font-size:8px'>COSTO AL KM</th>
	   <th id='callcosts' width='80' editable='true' format='currency' style='font-size:8px'>CHIAMATA</th> -->
	   <th width='22'>&nbsp;</th>
   </tr>
   <?php
	$ret = GShell("dynarc item-list -ap tickettypes --all-cat -get 'hourly_rate,km_rate,call_costs'");
	$list = $ret['outarr']['items'];
	for($c=0; $c < count($list); $c++)
	{
	 $itm = $list[$c];
	 echo "<tr id='".$itm['id']."'>";
	 echo "<td><span class='graybold'>".$itm['code_str']."</span></td>";
	 echo "<td><span class='graybold'>".$itm['name']."</span></td>";
	 /*echo "<td><span class='graybold'>".number_format($itm['hourly_rate'],2,',','.')."</span></td>";
	 echo "<td><span class='graybold'>".number_format($itm['km_rate'],2,',','.')."</span></td>";
	 echo "<td><span class='graybold'>".number_format($itm['call_costs'],2,',','.')."</span></td>";*/
	 echo "<td align='center'><img src='".$_ABSOLUTE_URL."share/icons/16x16/delete.gif' style='cursor:pointer' title='Elimina' onclick='DeleteTicketType(this.parentNode.parentNode)'/></td>";
	 echo "</tr>";
	}
   ?>
 </table>
</div>

<!-- INVIO EMAIL AL CLIENTE -->
<h2>INVIO EMAIL AL CLIENTE</h2>
<h3>Mittente</h3>
<p>Indica il mittente del messaggio. Se omesso verr&agrave; utilizzata l&lsquo;email dell&lsquo;utente collegato oppure quella predefinita da sendmail.<br/>
 <?php
 if($config['sendmail']['sendername'] && $config['sendmail']['senderemail'])
  $sender = $config['sendmail']['sendername']." <".$config['sendmail']['senderemail'].">";
 else if($config['sendmail']['senderemail'])
  $sender = $config['sendmail']['senderemail'];
 ?>
 <input type='text' class='edit' id='sendmail-sender' style='width:300px' value="<?php echo $sender; ?>" placeholder="Digita l&lsquo;email predefinita per l&lsquo;invio dei messaggi."/>
</p>

<h3>Oggetto</h3>
<p>Definisci, utilizzando le chiavi disponibili, l&lsquo;oggetto del messaggio.<br/>
 <input type='text' class='edit' id='sendmail-subject' style='width:600px;margin-bottom:0px;background:#feffcb;' value="<?php echo $config['sendmail']['subject']; ?>"/>
 <br/>
 <br/>
 <small>Elenco delle chiavi disponibili</small>
 <table class='keylist' style='width:600px;margin-top0px' border='0' cellspacing='0' cellpadding='3'>
 <tr><th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th>
	<th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th></tr>

 <tr><td class='key'>{NUM}</td>					<td class='desc'>Numero ticket</td>
	 <td class='key'>{ZONE}</td>				<td class='desc'>Zona</td></tr>

 <tr><td class='key'>{DATE}</td>				<td class='desc'>Data apertura ticket</td>
	 <td class='key'>{CLOSEDATE}</td>			<td class='desc'>Data chiusura ticket</td></tr>

 <tr><td class='key'>{TIME}</td>				<td class='desc'>Ora apertura ticket</td>
	 <td class='key'>{CLOSETIME}</td>			<td class='desc'>Ora chiusura ticket</td></tr>

 <tr><td class='key'>{TKTREF}</td>				<td class='desc'>N. ticket di riferimento</td>
	 <td class='key'>{OPERATOR}</td>			<td class='desc'>Operatore</td></tr>

 <tr><td class='key'>{TYPE}</td>				<td class='desc'>Tipologia ticket</td>
	 <td class='key'>{TECH1}</td>				<td class='desc'>Tecnico 1</td></tr>

 <tr><td class='key'>{CUSTOMER}</td>			<td class='desc'>Cliente</td>
	 <td class='key'>{TECH2}</td>				<td class='desc'>Tecnico 2</td></tr>

 <tr><td class='key'>{FULLADDRESS}</td>			<td class='desc'>Indirizzo completo</td>
	 <td class='key'>{TAXDELIVERY}</td>			<td class='desc'>Data scadenza ticket</td></tr>

 <tr><td class='key'>{ADDR_CODE}</td>			<td class='desc'>Cod. indirizzo</td>
	 <td class='key'>{ADDR_ZIP}</td>			<td class='desc'>C.A.P.</td></tr>

 <tr><td class='key'>{ADDR_TITLE}</td>			<td class='desc'>Utente / Insegna / Citofono</td>
	 <td class='key'>{ADDR_PROV}</td>			<td class='desc'>Provincia</td></tr>

 <tr><td class='key'>{ADDR_ADDRESS}</td>		<td class='desc'>Indirizzo</td>
	 <td class='key'>{ADDR_CC}</td>				<td class='desc'>Paese (sigla)</td></tr>

 <tr><td class='key'>{ADDR_CITY}</td>			<td class='desc'>Citt&agrave;</td>
	 <td class='key'>{ADDR_NOTE}</td>			<td class='desc'>Note indirizzo</td></tr>

 <tr><td class='key'>{INTERVDATE}</td>			<td class='desc'>Data intervento</td>
	 <td class='key'>{INTERVTIMEFROM}</td>		<td class='desc'>Ora inizio intervento</td></tr>

 <tr><td class='key'>{INTERVDESC}</td>			<td class='desc'>Descrizione intervento</td>
	 <td class='key'>{INTERVTIMETO}</td>		<td class='desc'>Ora fine intervento</td></tr>

 <tr><td class='key'>{STATUS}</td>				<td class='desc'>Stato ticket</td>
	 <td class='key'>{EXT_CONTRACT_REF}</td>	<td class='desc'>Rif. Contratto</td></tr>

 </table>
</p>

<h3>Messaggio</h3>
<p>Definisci il messaggio che deve apparire sulla email. Anche qui puoi utilizzare le stesse chiavi cha hai usato per definire l&lsquo;oggetto del messaggio riportate qui sopra.<br/>
<?php
if($config['sendmail']['messageap'] && $config['sendmail']['messageid'])
{
 $ret = GShell("dynarc item-info -ap '".$config['sendmail']['messageap']."' -id '".$config['sendmail']['messageid']."'");
 if(!$ret['error'])
 {
  $sendmailRefAP = $config['sendmail']['messageap'];
  $sendmailRefID = $config['sendmail']['messageid'];
  $sendmailMessage = $ret['outarr']['desc'];
 }
}
?>
 <textarea id='sendmail-message' style='width:600px;height:300px' refap="<?php echo $sendmailRefAP; ?>" refid="<?php echo $sendmailRefID; ?>"><?php
  echo $sendmailMessage;
 ?></textarea>
</p>

<h3>Allegati</h3>
<p>
<table cellspacing='0' cellpadding='3' border='0'>
<tr><td><input type='checkbox' id='attachpdf' <?php if($config['sendmail']['attachpdf']) echo "checked='true'"; ?>/> Allega l&lsquo;ultima stampa PDF del ticket.</td></tr>
<tr><td><input type='checkbox' id='attachtktref' <?php if($config['sendmail']['attachtktref']) echo "checked='true'"; ?>/> Allega il file del ticket di riferimento. (se caricato)</td></tr>
<tr><td><input type='checkbox' id='attachint' <?php if($config['sendmail']['attachint']) echo "checked='true'"; ?>/> Includi allegati interni</td></tr>
</table>
</p>

<!-- INVIO EMAIL AL TECNICO / COLLABORATORE -->
<h2>INVIO EMAIL AL TECNICO / COLLABORATORE</h2>
<h3>Mittente</h3>
<p>Indica il mittente del messaggio. Se omesso verr&agrave; utilizzata l&lsquo;email dell&lsquo;utente collegato oppure quella predefinita da sendmail.<br/>
 <?php
 if($config['sendtechmail']['sendername'] && $config['sendtechmail']['senderemail'])
  $sender = $config['sendtechmail']['sendername']." <".$config['sendtechmail']['senderemail'].">";
 else if($config['sendtechmail']['senderemail'])
  $sender = $config['sendtechmail']['senderemail'];
 ?>
 <input type='text' class='edit' id='sendtechmail-sender' style='width:300px' value="<?php echo $sender; ?>" placeholder="Digita l&lsquo;email predefinita per l&lsquo;invio dei messaggi."/>
</p>

<h3>Oggetto</h3>
<p>Definisci, utilizzando le chiavi disponibili, l&lsquo;oggetto del messaggio.<br/>
 <input type='text' class='edit' id='sendtechmail-subject' style='width:600px;margin-bottom:0px;background:#feffcb;' value="<?php echo $config['sendtechmail']['subject']; ?>"/>
 <br/>
 <br/>
 <small>Elenco delle chiavi disponibili</small>
 <table class='keylist' style='width:600px;margin-top0px' border='0' cellspacing='0' cellpadding='3'>
 <tr><th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th>
	<th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th></tr>

 <tr><td class='key'>{NUM}</td>					<td class='desc'>Numero ticket</td>
	 <td class='key'>{ZONE}</td>				<td class='desc'>Zona</td></tr>

 <tr><td class='key'>{DATE}</td>				<td class='desc'>Data apertura ticket</td>
	 <td class='key'>{CLOSEDATE}</td>			<td class='desc'>Data chiusura ticket</td></tr>

 <tr><td class='key'>{TIME}</td>				<td class='desc'>Ora apertura ticket</td>
	 <td class='key'>{CLOSETIME}</td>			<td class='desc'>Ora chiusura ticket</td></tr>

 <tr><td class='key'>{TKTREF}</td>				<td class='desc'>N. ticket di riferimento</td>
	 <td class='key'>{OPERATOR}</td>			<td class='desc'>Operatore</td></tr>

 <tr><td class='key'>{TYPE}</td>				<td class='desc'>Tipologia ticket</td>
	 <td class='key'>{TECH1}</td>				<td class='desc'>Tecnico 1</td></tr>

 <tr><td class='key'>{CUSTOMER}</td>			<td class='desc'>Cliente</td>
	 <td class='key'>{TECH2}</td>				<td class='desc'>Tecnico 2</td></tr>

 <tr><td class='key'>{FULLADDRESS}</td>			<td class='desc'>Indirizzo completo</td>
	 <td class='key'>{TAXDELIVERY}</td>			<td class='desc'>Data scadenza ticket</td></tr>

 <tr><td class='key'>{ADDR_CODE}</td>			<td class='desc'>Cod. indirizzo</td>
	 <td class='key'>{ADDR_ZIP}</td>			<td class='desc'>C.A.P.</td></tr>

 <tr><td class='key'>{ADDR_TITLE}</td>			<td class='desc'>Utente / Insegna / Citofono</td>
	 <td class='key'>{ADDR_PROV}</td>			<td class='desc'>Provincia</td></tr>

 <tr><td class='key'>{ADDR_ADDRESS}</td>		<td class='desc'>Indirizzo</td>
	 <td class='key'>{ADDR_CC}</td>				<td class='desc'>Paese (sigla)</td></tr>

 <tr><td class='key'>{ADDR_CITY}</td>			<td class='desc'>Citt&agrave;</td>
	 <td class='key'>{ADDR_NOTE}</td>			<td class='desc'>Note indirizzo</td></tr>


 <?php
 if(file_exists($_BASE_PATH."Tickets/config-custom.php"))
 {
  ?>
  <tr><td class='key'>{NC_CLIENTE}</td>			<td class='desc'>NC Cliente</td>
	  <td class='key'>{EXT_CONTRACT_REF}</td>	<td class='desc'>Rif. Contratto</td></tr>
  <tr><td class='key'>{NC_COMMITTENTE}</td>		<td class='desc'>NC Committente</td>
	  <td class='key'>{APP_DATETIME}</td>		<td class='desc'>Data pianifica</td></tr>
  <?php
 }
 ?>

 <tr><td class='key'>{INTERVDATE}</td>			<td class='desc'>Data intervento</td>
	 <td class='key'>{INTERVTIMEFROM}</td>		<td class='desc'>Ora inizio intervento</td></tr>

 <tr><td class='key'>{INTERVDESC}</td>			<td class='desc'>Descrizione intervento</td>
	 <td class='key'>{INTERVTIMETO}</td>		<td class='desc'>Ora fine intervento</td></tr>

 <tr><td class='key'>{STATUS}</td>				<td class='desc'>Stato ticket</td>
	 <td class='key'>&nbsp;</td>				<td class='desc'>&nbsp;</td></tr>

 </table>
</p>

<h3>Messaggio</h3>
<p>Definisci il messaggio che deve apparire sulla email. Anche qui puoi utilizzare le stesse chiavi cha hai usato per definire l&lsquo;oggetto del messaggio riportate qui sopra.<br/>
<?php
if($config['sendtechmail']['messageap'] && $config['sendtechmail']['messageid'])
{
 $ret = GShell("dynarc item-info -ap '".$config['sendtechmail']['messageap']."' -id '".$config['sendtechmail']['messageid']."'");
 if(!$ret['error'])
 {
  $sendtechmailRefAP = $config['sendtechmail']['messageap'];
  $sendtechmailRefID = $config['sendtechmail']['messageid'];
  $sendtechmailMessage = $ret['outarr']['desc'];
 }
}
?>
 <textarea id='sendtechmail-message' style='width:600px;height:300px' refap="<?php echo $sendtechmailRefAP; ?>" refid="<?php echo $sendtechmailRefID; ?>"><?php  echo $sendtechmailMessage; ?></textarea>
</p>

<h3>Allegati</h3>
<p>
<table cellspacing='0' cellpadding='3' border='0'>
<tr><td><input type='checkbox' id='sendtechmail-attachpdf' <?php if($config['sendtechmail']['attachpdf']) echo "checked='true'"; ?>/> Allega l&lsquo;ultima stampa PDF del ticket.</td></tr>
<tr><td><input type='checkbox' id='sendtechmail-attachtktref' <?php if($config['sendtechmail']['attachtktref']) echo "checked='true'"; ?>/> Allega il file del ticket di riferimento. (se caricato)</td></tr>
<tr><td><input type='checkbox' id='sendtechmail-attachint' <?php if($config['sendtechmail']['attachint']) echo "checked='true'"; ?>/> Includi allegati interni</td></tr>
</table>
</p>

<!-- RICHIESTE DI ASSISTENZA -->
<h2>RICHIESTE DI ASSISTENZA/INTERVENTO DAL WEB</h2>
<p><input type='checkbox' id='extreq-enable' onclick='enableDisableExtReq(this)' <?php if($config['extrequest']['enabled']) echo "checked='true'"; if(!$_REQFORASSIST_INSTALLED) echo " disabled='true'"; ?>/> <b>Abilita richieste di assistenza via web</b>
	<?php
	 if(!$_REQFORASSIST_INSTALLED)
	  echo "&nbsp;&nbsp;<span style='color:#f31903'>&egrave; necessario installare il pacchetto <b>ticket-system-reqforassist</b></span>";
	?>
<br/><br/>
E&lsquo;possibile gestire richieste di assistenza (o di intervento) dal vostro sito web tramite una form compilabile dal cliente.</p>

<div id='external-request-container' <?php if(!$config['extrequest']['enabled']) echo "style='display:none'"; ?>>
 <h3>URL alle pagine</h3>
 <?php
  $_EXTREQ_URL_FORM = $config['extrequest']['requrl'] ? $config['extrequest']['requrl'] : $_ABSOLUTE_URL."requestforassistance.php";
  $_EXTREQ_URL_SUCCESS = $config['extrequest']['successurl'] ? $config['extrequest']['successurl'] : $_ABSOLUTE_URL."requestforassistancesuccess.php";
  $_EXTREQ_URL_ERROR = $config['extrequest']['errorurl'] ? $config['extrequest']['errorurl'] : $_ABSOLUTE_URL."requestforassistance.php";
 ?>
 <p>
  <table cellspacing='0' cellpadding='3' border='0'>
  <tr><td>URL form richiesta: </td>
	<td><input type='text' class='edit' style='width:400px'  id="extreq-form-request-url" value="<?php echo $_EXTREQ_URL_FORM; ?>"/></td>
	<td><small>Indica l&lsquo;indirizzo (URL) della pagina del tuo sito internet contentente la form della richiesta compilabile dal cliente.</small></td></tr>

  <tr><td>URL pagina successo: </td>
	<td><input type='text' class='edit' style='width:400px' id="extreq-successpage-url" value="<?php echo $_EXTREQ_URL_SUCCESS; ?>"/></td>
	<td><small>Indica l&lsquo;indirizzo (URL) della pagina contentente il messaggio che indica che l&lsquo;operazione &egrave; avvenuta con successo.</small></td></tr>

  <tr><td>URL pagina errore: </td>
	<td><input type='text' class='edit' style='width:400px' id="extreq-errorpage-url" value="<?php echo $_EXTREQ_URL_ERROR; ?>"/></td>
	<td><small>Indica l&lsquo;indirizzo (URL) della pagina contentente il messaggio che indica che l&lsquo;operazione non &egrave; andata a buon fine causa errore.</small></td></tr>

  </table>
 </p>

 <h3>Campi obbligatori</h3>
 <p>Indica i campi obbligatori che l&lsquo;utente dovr&agrave; compilare nella form di richiesta.<br/><br/>
  <table cellspacing='0' cellpadding='3' border='0'>
   <tr><td><input type='checkbox' id='extreq-reqfield-customer' <?php if($config['extrequest']['reqfield_customer']) echo "checked='true'"; ?>/> Nome e Cognome / Ragione sociale</td></tr>
   <tr><td><input type='checkbox' id='extreq-reqfield-phone' <?php if($config['extrequest']['reqfield_phone']) echo "checked='true'"; ?>/> Numero di telefono</td></tr>
   <tr><td><input type='checkbox' id='extreq-reqfield-email' <?php if($config['extrequest']['reqfield_email']) echo "checked='true'"; ?>/> Email</td></tr>
   <tr><td><input type='checkbox' id='extreq-reqfield-hwname' <?php if($config['extrequest']['reqfield_hwname']) echo "checked='true'"; ?>/> Hardware</td></tr>

  </table>
 </p>

 <h3>Notifiche via email</h3>
 <p><input type='checkbox' id='extreq-enable-notify' onclick='enableDisableExtReqNotify(this)' <?php if($config['extrequest']['enablenotify']) echo "checked='true'"; ?>/> <b>Abilita notifiche via email</b><br/><br/>Quando un cliente compila una form di assistenza tramite il vostro sito &egrave; possibile farsi recapitare una notifica al proprio indirizzo email (o quello dell&lsquo;operatore che dovr&agrave; vagliare la richiesta per poi generare il ticket.)</p>

 <?php
 if($config['extrequest']['sendername'] && $config['extrequest']['senderemail'])
  $extreqsender = $config['extrequest']['sendername']." <".$config['extrequest']['senderemail'].">";
 else if($config['extrequest']['senderemail'])
  $extreqsender = $config['extrequest']['senderemail'];
 ?>


 <div id='external-request-notify-container' <?php if(!$config['extrequest']['enablenotify']) echo "style='display:none'"; ?>>
  <p style='padding-top:0px'>
  <table cellspacing='0' cellpadding='3' border='0'>
  <tr><td>Destinatario: </td>
	<td><input type='text' class='edit' style='width:200px' id="extreqnotify-recp" value="<?php echo $config['extrequest']['recp']; ?>"/></td>
	<td><small>Indica l&lsquo;indirizzo email dove recapitare le notifiche.</small></td></tr>

  <tr><td>Mittente: </td>
	<td><input type='text' class='edit' style='width:200px' id="extreqnotify-sender" value="<?php echo $extreqsender; ?>" placeholder="<?php echo $_SMTP_USERNAME; ?>"/></td>
	<td><small>Indica l&lsquo;indirizzo email del mittente. Se omesso verr&agrave; utilizzato quello predefinito da sendmail.</small></td></tr>

  </table>
  </p>

 <p><b>OGGETTO</b><br/><br/>
 Definisci, utilizzando le chiavi disponibili, l&lsquo;oggetto del messaggio.<br/>
 <input type='text' class='edit' id='extreqnotify-subject' style='width:600px;margin-bottom:0px;background:#feffcb;' value="<?php echo $config['extrequest']['subject']; ?>" placeholder="Es: Richiesta di assistenza n. {CODE} da {CUSTOMER}"/>
 <br/>
 <br/>
 <small>Elenco delle chiavi disponibili</small>
 <table class='keylist' style='width:600px;margin-top0px' border='0' cellspacing='0' cellpadding='3'>
 <tr><th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th>
	<th style='text-align:left;width:100px'>CHIAVE</th>
	<th style='text-align:left'>DESCRIZIONE</th></tr>

 <tr><td class='key'>{CODE}</td>				<td class='desc'>Codice richiesta</td>
	 <td class='key'>{CUSTOMER}</td>			<td class='desc'>Cliente</td></tr>

 <tr><td class='key'>{DATE}</td>				<td class='desc'>Data richiesta (gg/mm/aaaa)</td>
	 <td class='key'>{PHONE}</td>				<td class='desc'>Telefono</td></tr>

 <tr><td class='key'>{TIME}</td>				<td class='desc'>Ora richiesta (hh:mm)</td>
	 <td class='key'>{EMAIL}</td>				<td class='desc'>Email</td></tr>

 <tr><td class='key'>{DATETIME}</td>			<td class='desc'>Data e ora richiesta {gg/mm/aaaa hh:mm)</td>
	 <td class='key'>{HWNAME}</td>				<td class='desc'>Hardware</td></tr>

 <tr><td class='key'>{MESSAGE}</td>				<td class='desc'>Messaggio</td>
	 <td class='key'>&nbsp;</td>				<td class='desc'>&nbsp;</td></tr>

 </table>
</p>

<p><b>MESSAGGIO</b><br/><br/>Definisci il messaggio che deve apparire sul&lsquo; email di notifica. Anche qui puoi utilizzare le stesse chiavi cha hai usato per definire l&lsquo;oggetto del messaggio riportate qui sopra.<br/>
<?php
if($config['extrequest']['messageap'] && $config['extrequest']['messageid'])
{
 $ret = GShell("dynarc item-info -ap '".$config['extrequest']['messageap']."' -id '".$config['extrequest']['messageid']."'");
 if(!$ret['error'])
 {
  $extreqNotifyRefAP = $config['extrequest']['messageap'];
  $extreqNotifyRefID = $config['extrequest']['messageid'];
  $extreqNotifyMessage = $ret['outarr']['desc'];
 }
}
else
{
 // default message //
 $extreqNotifyMessage = "Il cliente <b>{CUSTOMER}</b> ha appena effettuato una richiesta di assistenza in data {DATE} alle ore {TIME}.<br/><br/>";
 $extreqNotifyMessage.= "Dati cliente: <br/>";
 $extreqNotifyMessage.= "Nome e Cognome: <b>{CUSTOMER}</b><br/>";
 $extreqNotifyMessage.= "Telefono: <b>{PHONE}</b><br/>";
 $extreqNotifyMessage.= "Email: <b>{EMAIL}</b><br/><br/>";
 $extreqNotifyMessage.= "Testo del messaggio:<br/><hr/>";
 $extreqNotifyMessage.= "{MESSAGE}<br/><hr/>";
}
?>
 <textarea id='extreqnotify-message' style='width:600px;height:300px' refap="<?php echo $extreqNotifyRefAP; ?>" refid="<?php echo $extreqNotifyRefID; ?>"><?php echo $extreqNotifyMessage; ?></textarea>
</p>


 </div>


<!-- eof - external-request-container -->
</div>
<!-- EOF RICHIESTE DI ASSISTENZA -->





<hr/>
<input type='button' class='button-blue' value="Applica" onclick="saveConfig()"/>
<input type='button' class='button-blue' value="Salva e chiudi" onclick="saveConfig(true)"/>
<br/>
<br/>
<br/>
<br/>
<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();

?>
<script>
var EXIT_AFTER_SAVE = false;
var INTERVTB = null;
var TICKETLISTTB = null;
var ITEMSTB = null;
var EXEXTB = null;
var EXCERTTB = null;
var EXCONSTB = null;

var EXTREQ_ENABLED = <?php echo $_REQFORASSIST_ENABLED ? "true" : "false"; ?>;
var EXTREQ_NOTIFYENABLED = <?php echo $_EXTREQNOTIFY_ENABLED ? "true" : "false"; ?>;

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL+"accounts/Logout.php?continue="+this.getVar('continue');
	return false;
}

Template.OnInit = function(){
	this.initEd(document.getElementById("laborvat"),"dropdown");
	this.initEd(document.getElementById("sendmail-message"),"fckeditor","Optimized");
	this.initEd(document.getElementById("sendtechmail-message"),"fckeditor","Optimized");
	this.initEd(document.getElementById('tktclone-type-dropdown'), "dropdown").onchange = function(){};
	this.initEd(document.getElementById('tktclone-operator-dropdown'), "dropdown").onchange = function(){};
	this.initEd(document.getElementById('tktclone-status-dropdown'), "dropdown").onchange = function(){};
	INTERVTB = new GMUTable(document.getElementById("intervlist"), {autoresize:true, autoaddrows:false, orderable:true});
	TICKETLISTTB = new GMUTable(document.getElementById("ticketlist"), {autoresize:true, autoaddrows:false, orderable:true});
	ITEMSTB = new GMUTable(document.getElementById("itemlist"), {autoresize:true, autoaddrows:false, orderable:true});
	EXEXTB = new GMUTable(document.getElementById("exportexplodedlist"), {autoresize:true, autoaddrows:false, orderable:true});
	EXCERTTB = new GMUTable(document.getElementById("exportcert"), {autoresize:true, autoaddrows:false, orderable:true});
	EXCONSTB = new GMUTable(document.getElementById("exportcons"), {autoresize:true, autoaddrows:false, orderable:true});
	TICKETTYPETB = new GMUTable(document.getElementById("tickettypelist"), {autoresize:true, autoaddrows:false});
	TICKETTYPETB.OnBeforeAddRow = function(r){
		 r.cells[0].innerHTML = "<span class='graybold'></span>";
		 r.cells[1].innerHTML = "<span class='graybold'></span>";
		 r.cells[2].innerHTML = "<img src='"+ABSOLUTE_URL+"share/icons/16x16/delete.gif' style='cursor:pointer' title='Elimina' onclick='DeleteTicketType(this.parentNode.parentNode)'/"+">";
		}
	TICKETTYPETB.OnCellEdit = function(r, cell, value, data){
		 var sh = new GShell();
		 sh.OnError = function(err){alert(err);}
		 sh.OnOutput = function(o,a){r.id=a['id'];}
		 sh.sendCommand("dynarc "+(r.id ? "edit-item -id '"+r.id+"'" : "new-item -group tickets")+" -ap tickettypes -code-str `"+r.cell['code'].getValue()+"` -name `"+r.cell['title'].getValue()+"`");
		}
	TICKETTYPETB.OnRowMove = function(r){
		 var ser = "";
		 for(var c=1; c < TICKETTYPETB.O.rows.length; c++)
		  ser+= ","+TICKETTYPETB.O.rows[c].id;
		 var sh = new GShell();
		 sh.OnError = function(err){alert(err);}
		 sh.sendCommand("dynarc item-sort -ap tickettypes -serialize `"+ser.substr(1)+"`");
		}

	if(EXTREQ_NOTIFYENABLED)
	 this.initEd(document.getElementById("extreqnotify-message"),"fckeditor","Optimized");
}

function saveConfig(exit)
{
 EXIT_AFTER_SAVE = exit ? true : false;
 var xml = "";
 
 /* Interfaccia */
 var ticketDescEditorHeight = document.getElementById('ticketdesceditor-height').value;
 var intervListHeight = document.getElementById('intervlist-height').value;
 var itemListHeight = document.getElementById('itemlist-height').value;
 var ticketlistfontsize = document.getElementById('ticketlist-fontsize').value;
 var tickettitleschema = document.getElementById('tickettitleschema').value.E_QUOT().replace(/&/g, '&amp;');
 var ticketaddressschema = document.getElementById('ticketaddressschema').value.E_QUOT().replace(/&/g, '&amp;');
 var hideIntervList = document.getElementById('hide-intervlist').checked ? '0' : '1';
 var hideItemList = document.getElementById('hide-itemlist').checked ? '0' : '1';
 var intervlistTitle = document.getElementById('intervlisttitle').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var itemlistTitle = document.getElementById('itemlisttitle').innerHTML.E_QUOT().replace(/&/g, '&amp;');

 var hideFieldAddress = document.getElementById('hide-field-address').checked ? '0' : '1';
 var hideFieldZone = document.getElementById('hide-field-zone').checked ? '0' : '1';
 var hideFieldNote = document.getElementById('hide-field-note').checked ? '0' : '1';
 var hideFieldAppointment = document.getElementById('hide-field-appointment').checked ? '0' : '1';
 var hideFieldOperator = document.getElementById('hide-field-operator').checked ? '0' : '1';
 var hideFieldPriority = document.getElementById('hide-field-priority').checked ? '0' : '1';
 var hideFieldPhone = document.getElementById('hide-field-phone').checked ? '0' : '1';
 var hideFieldTktRefFile = document.getElementById('hide-field-tktreffile').checked ? '0' : '1';

 var fieldAddressTitle = document.getElementById('field-address').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldZoneTitle = document.getElementById('field-zone').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldNoteTitle = document.getElementById('field-note').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldAppointmentTitle = document.getElementById('field-appointment').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldOperatorTitle = document.getElementById('field-operator').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldPriorityTitle = document.getElementById('field-priority').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldPhoneTitle = document.getElementById('field-phone').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldTktRefFileTitle = document.getElementById('field-tktreffile').innerHTML.E_QUOT().replace(/&/g, '&amp;');

 var showFieldRequest = document.getElementById('show-field-request').checked ? '1' : '0';
 var showFieldHardware = document.getElementById('show-field-hardware').checked ? '1' : '0';
 var showFieldShelf = document.getElementById('show-field-shelf').checked ? '1' : '0';
 var showFieldAccessories = document.getElementById('show-field-accessories').checked ? '1' : '0';
 var showFieldDataToSave = document.getElementById('show-field-datatosave').checked ? '1' : '0';
 var showFieldOS = document.getElementById('show-field-os').checked ? '1' : '0';
 //var showFieldOS2 = document.getElementById('show-field-os2').checked ? '1' : '0';
 /* TODO: riattivare se necessario
 var showFieldDiskSize = document.getElementById('show-field-disksize').checked ? '1' : '0'; */

 var fieldRequestTitle = document.getElementById('field-request').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldHardwareTitle = document.getElementById('field-hardware').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldShelfTitle = document.getElementById('field-shelf').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldAccessoriesTitle = document.getElementById('field-accessories').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldDataToSaveTitle = document.getElementById('field-datatosave').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldOSTitle = document.getElementById('field-os').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 //var fieldOS2Title = document.getElementById('field-os2').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 /* TODO: riattivare se necessario
 var fieldDiskSizeTitle = document.getElementById('field-disksize').innerHTML.E_QUOT().replace(/&/g, '&amp;'); */

 var showFieldUser1 = document.getElementById('show-field-user1').checked ? '1' : '0';
 var showFieldPasswd1 = document.getElementById('show-field-passwd1').checked ? '1' : '0';
 var showFieldUser2 = document.getElementById('show-field-user2').checked ? '1' : '0';
 var showFieldPasswd2 = document.getElementById('show-field-passwd2').checked ? '1' : '0';
 var showFieldUser3 = document.getElementById('show-field-user3').checked ? '1' : '0';
 var showFieldPasswd3 = document.getElementById('show-field-passwd3').checked ? '1' : '0';
 var showFieldAdmin = document.getElementById('show-field-admin').checked ? '1' : '0';
 var showFieldAdminPasswd = document.getElementById('show-field-adminpasswd').checked ? '1' : '0';

 var fieldUser1Title = document.getElementById('field-user1').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldPasswd1Title = document.getElementById('field-passwd1').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldUser2Title = document.getElementById('field-user2').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldPasswd2Title = document.getElementById('field-passwd2').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldUser3Title = document.getElementById('field-user3').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldPasswd3Title = document.getElementById('field-passwd3').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldAdminTitle = document.getElementById('field-admin').innerHTML.E_QUOT().replace(/&/g, '&amp;');
 var fieldAdminPasswdTitle = document.getElementById('field-adminpasswd').innerHTML.E_QUOT().replace(/&/g, '&amp;');



 xml+= "<interface ticketdesceditorheight='"+ticketDescEditorHeight+"' intervlistheight='"+intervListHeight+"' itemlistheight='"+itemListHeight+"' tickettitleschema=\""+tickettitleschema+"\" ticketaddressschema=\""+ticketaddressschema+"\" ticketlistfontsize='"+ticketlistfontsize+"' hideintervlist='"+hideIntervList+"' intervlisttitle=\""+intervlistTitle+"\" hideitemlist='"+hideItemList+"' itemlisttitle=\""+itemlistTitle+"\"";

 xml+= " hidefieldaddress='"+hideFieldAddress+"' fieldaddresstitle=\""+fieldAddressTitle+"\"";
 xml+= " hidefieldzone='"+hideFieldZone+"' fieldzonetitle=\""+fieldZoneTitle+"\"";
 xml+= " hidefieldnote='"+hideFieldNote+"' fieldnotetitle=\""+fieldNoteTitle+"\"";
 xml+= " hidefieldappointment='"+hideFieldAppointment+"' fieldappointmenttitle=\""+fieldAppointmentTitle+"\"";
 xml+= " hidefieldoperator='"+hideFieldOperator+"' fieldoperatortitle=\""+fieldOperatorTitle+"\"";
 xml+= " hidefieldpriority='"+hideFieldPriority+"' fieldprioritytitle=\""+fieldPriorityTitle+"\"";
 xml+= " hidefieldphone='"+hideFieldPhone+"' fieldphonetitle=\""+fieldPhoneTitle+"\"";
 xml+= " hidefieldtktreffile='"+hideFieldTktRefFile+"' fieldtktreffiletitle=\""+fieldTktRefFileTitle+"\"";

 xml+= " showfieldrequest='"+showFieldRequest+"' fieldrequesttitle=\""+fieldRequestTitle+"\"";
 xml+= " showfieldhardware='"+showFieldHardware+"' fieldhardwaretitle=\""+fieldHardwareTitle+"\"";
 xml+= " showfieldshelf='"+showFieldShelf+"' fieldshelftitle=\""+fieldShelfTitle+"\"";
 xml+= " showfieldaccessories='"+showFieldAccessories+"' fieldaccessoriestitle=\""+fieldAccessoriesTitle+"\"";
 xml+= " showfielddatatosave='"+showFieldDataToSave+"' fielddatatosavetitle=\""+fieldDataToSaveTitle+"\"";
 xml+= " showfieldos='"+showFieldOS+"' fieldostitle=\""+fieldOSTitle+"\"";

 /* TODO: riattivare se necessario
 xml+= " showfieldos2='"+showFieldOS2+"' fieldos2title=\""+fieldOS2Title+"\"";
 xml+= " showfielddisksize='"+showFieldDiskSize+"' fielddisksizetitle=\""+fieldDiskSizeTitle+"\""; */

 xml+= " showfielduser1='"+showFieldUser1+"' fielduser1title=\""+fieldUser1Title+"\"";
 xml+= " showfieldpasswd1='"+showFieldPasswd1+"' fieldpasswd1title=\""+fieldPasswd1Title+"\"";
 xml+= " showfielduser2='"+showFieldUser2+"' fielduser2title=\""+fieldUser2Title+"\"";
 xml+= " showfieldpasswd2='"+showFieldPasswd2+"' fieldpasswd2title=\""+fieldPasswd2Title+"\"";
 xml+= " showfielduser3='"+showFieldUser3+"' fielduser3title=\""+fieldUser3Title+"\"";
 xml+= " showfieldpasswd3='"+showFieldPasswd3+"' fieldpasswd3title=\""+fieldPasswd3Title+"\"";
 xml+= " showfieldadmin='"+showFieldAdmin+"' fieldadmintitle=\""+fieldAdminTitle+"\"";
 xml+= " showfieldadminpasswd='"+showFieldAdminPasswd+"' fieldadminpasswdtitle=\""+fieldAdminPasswdTitle+"\"";

 xml+= "/"+">";

 xml+= "<advsearchfields>";
 var tb = document.getElementById('advsearchfieldstable');
 for(var c=0; c < tb.rows.length; c++)
 {
  var r = tb.rows[c];
  var cb = r.cells[0].getElementsByTagName('INPUT')[0];
  var tit = r.cells[0].getElementsByTagName('SPAN')[0].innerHTML;
  xml+= "<field name=\""+r.getAttribute('data-ref')+"\" title=\""+tit.E_QUOT()+"\" visibled=\""+(cb.checked==true ? '1' : '0')+"\"/"+">";
 }
 xml+= "</advsearchfields>";
 
 xml+= "<intervcolumns>";
 var sel = INTERVTB.GetSelectedRows();
 for(var c=0; c < sel.length; c++)
  xml+= "<column tag=\""+sel[c].cell['tag'].getValue()+"\" title=\""+sel[c].cell['title'].getValue()+"\" width=\""+sel[c].cell['width'].getValue()+"\"/"+">";
 xml+= "</intervcolumns>";

 xml+= "<ticketlistcolumns>";
 var sel = TICKETLISTTB.GetSelectedRows();
 for(var c=0; c < sel.length; c++)
  xml+= "<column tag=\""+sel[c].cell['tag'].getValue()+"\" title=\""+sel[c].cell['title'].getValue()+"\" width=\""+sel[c].cell['width'].getValue()+"\"/"+">";
 xml+= "</ticketlistcolumns>";

 xml+= "<itemscolumns>";
 var sel = ITEMSTB.GetSelectedRows();
 for(var c=0; c < sel.length; c++)
  xml+= "<column tag=\""+sel[c].cell['tag'].getValue()+"\" title=\""+sel[c].cell['title'].getValue()+"\" width=\""+sel[c].cell['width'].getValue()+"\"/"+">";
 xml+= "</itemscolumns>";

 xml+= "<exexcolumns>";
 var sel = EXEXTB.GetSelectedRows();
 for(var c=0; c < sel.length; c++)
  xml+= "<column tag=\""+sel[c].cell['tag'].getValue()+"\" title=\""+sel[c].cell['title'].getValue()+"\"/"+">";
 xml+= "</exexcolumns>";

 xml+= "<excertcolumns>";
 var sel = EXCERTTB.GetSelectedRows();
 for(var c=0; c < sel.length; c++)
  xml+= "<column tag=\""+sel[c].cell['tag'].getValue()+"\" title=\""+sel[c].cell['title'].getValue()+"\"/"+">";
 xml+= "</excertcolumns>";

 xml+= "<exconscolumns>";
 var sel = EXCONSTB.GetSelectedRows();
 for(var c=0; c < sel.length; c++)
  xml+= "<column tag=\""+sel[c].cell['tag'].getValue()+"\" title=\""+sel[c].cell['title'].getValue()+"\"/"+">";
 xml+= "</exconscolumns>";

 /* Opzioni */
 var autoInsLabor = document.getElementById('autoinslabor').checked ? '1' : '0';
 var laborVatId = document.getElementById('laborvat').getValue();
 var hideCanceledBtn = document.getElementById('hidecanceledbtn').checked ? '1' : '0';
 var pdfFileSchema = document.getElementById('pdffileschema').value;

 var cloneCustomer = document.getElementById('tktclone-customer').checked ? '1' : '0';
 var cloneAddress = document.getElementById('tktclone-address').checked ? '1' : '0';
 var cloneCTime = document.getElementById('tktclone-ctime').checked ? '1' : '0';
 var cloneExpiry = document.getElementById('tktclone-expiry').checked ? '1' : '0';
 var cloneType = document.getElementById('tktclone-type').checked ? ( document.getElementsByName('tktclonetype')[0].checked ? 'clone' : document.getElementById('tktclone-type-dropdown').getValue() ) : '0';
 var cloneOperator = document.getElementById('tktclone-operator').checked ? ( document.getElementsByName('tktcloneoperator')[0].checked ? 'clone' : document.getElementById('tktclone-operator-dropdown').getValue() ) : '0';
 var cloneZone = document.getElementById('tktclone-zone').checked ? '1' : '0';
 var cloneExtTktRef = document.getElementById('tktclone-exttktref').checked ? '1' : '0';
 var cloneTktRefFile = document.getElementById('tktclone-tktreffile').checked ? '1' : '0';

 var cloneHardware = document.getElementById('tktclone-hardware').checked ? '1' : '0';
 var cloneShelf = document.getElementById('tktclone-shelf').checked ? '1' : '0';
 var cloneRequest = document.getElementById('tktclone-request').checked ? '1' : '0';
 var cloneData2Save = document.getElementById('tktclone-datatosave').checked ? '1' : '0';
 var cloneAccessories = document.getElementById('tktclone-accessories').checked ? '1' : '0';

 var cloneNote = document.getElementById('tktclone-note').checked ? '1' : '0';
 var cloneDescription = document.getElementById('tktclone-description').checked ? '1' : '0';
 var cloneStatus = document.getElementById('tktclone-status').checked ? ( document.getElementsByName('tktclonestatus')[0].checked ? 'clone' : document.getElementById('tktclone-status-dropdown').getValue() ) : '0';

 xml+= "<options autoinslabor='"+autoInsLabor+"' laborvatid='"+laborVatId+"' hidecanceledbtn='"+hideCanceledBtn+"' pdffileschema=\""+pdfFileSchema.E_QUOT().replace(/&/g, '&amp;')+"\" clonecustomer='"+cloneCustomer+"' cloneaddress='"+cloneAddress+"' clonectime='"+cloneCTime+"' cloneexpiry='"+cloneExpiry+"' clonetype='"+cloneType+"' cloneoperator='"+cloneOperator+"' clonezone='"+cloneZone+"' cloneexttktref='"+cloneExtTktRef+"' clonetktreffile='"+cloneTktRefFile+"' clonenote='"+cloneNote+"' clonedescription='"+cloneDescription+"' clonestatus='"+cloneStatus+"' clonehardware='"+cloneHardware+"' cloneshelf='"+cloneShelf+"' clonerequest='"+cloneRequest+"' clonedatatosave='"+cloneData2Save+"' cloneaccessories='"+cloneAccessories+"'/"+">";

 /* Chiusura */
 var modal = document.getElementsByName('closuremodal')[0].checked ? 'advanced' : 'simply';
 var schema = document.getElementById('ticketrefschema').value;
 var schemanote = document.getElementById('ticketrefschemanote').value;
 var finishDateModal = "auto";
 if(document.getElementsByName('finishdatemodal')[0].checked == true)		finishDateModal = "lastworktime";
 else if(document.getElementsByName('finishdatemodal')[2].checked == true)	finishDateModal = "manual";
 xml+= "<closure modal=\""+modal+"\" ticketrefschema=\""+schema.E_QUOT().replace(/&/g, '&amp;')+"\" ticketrefschemanote=\""+schemanote.E_QUOT().replace(/&/g, '&amp;')+"\" finishdatemodal=\""+finishDateModal+"\"/"+">";

 /* Calendario */
 var listViewModal = document.getElementsByName('applistview-modal')[0].checked ? 'all' : 'onlyopen';
 xml+= "<calendar listviewmodal='"+listViewModal+"'/"+">";

 /* Sendmail */
 saveSendmail(xml, function(xml){
	saveSendTechMail(xml, function(xml){
		 saveExtRequest(xml, function(xml){
		 	 saveFinish(xml);
			});
		});
	});
}

function saveSendmail(xml, callback)
{
 var ed = document.getElementById('sendmail-message');
 var sendmailSubject = document.getElementById('sendmail-subject').value;
 var sendmailSender = document.getElementById('sendmail-sender').value;
 var sendmailSenderName = "";
 var sendmailSenderEmail = "";
 if(sendmailSender && (sendmailSender.indexOf('<') > -1) && (sendmailSender.indexOf('>') > -1))
 {
  var s = sendmailSender.indexOf('<');
  var e = sendmailSender.indexOf('>');
  var l = e-s;
  sendmailSenderName = sendmailSender.substr(0,s).trim();
  sendmailSenderEmail = sendmailSender.substr(s+1, l-1).trim();
 }
 else
  sendmailSenderEmail = sendmailSender;
 
 var refAP = ed.getAttribute('refap') ? ed.getAttribute('refap') : "aboutconfig_htmlparms";
 var refID = ed.getAttribute('refid') ? ed.getAttribute('refid') : 0;

 var attachPDF = (document.getElementById('attachpdf').checked == true) ? "1" : "0";
 var attachTR = (document.getElementById('attachtktref').checked == true) ? "1" : "0";
 var attachINT = (document.getElementById('attachint').checked == true) ? "1" : "0";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 xml+= "<sendmail subject=\""+sendmailSubject.E_QUOT()+"\" messageap=\""+refAP+"\" messageid=\""+a['id']+"\" sendername=\""+sendmailSenderName.E_QUOT()+"\" senderemail=\""+sendmailSenderEmail+"\" attachpdf='"+attachPDF+"' attachtktref='"+attachTR+"' attachint='"+attachINT+"'/"+">";
	 callback(xml);
	}
 if(!refID)
  sh.sendCommand("dynarc new-cat -ap aboutconfig_htmlparms -name `Tickets` -tag tickets --if-not-exists && dynarc new-item -ap aboutconfig_htmlparms -ct tickets -name 'Messaggio email' -desc `"+ed.getValue()+"`");
 else
  sh.sendCommand("dynarc edit-item -ap '"+refAP+"' -id '"+refID+"' -desc `"+ed.getValue()+"`");
}

function saveSendTechMail(xml, callback)
{
 var ed = document.getElementById('sendtechmail-message');
 var sendmailSubject = document.getElementById('sendtechmail-subject').value;
 var sendmailSender = document.getElementById('sendtechmail-sender').value;
 var sendmailSenderName = "";
 var sendmailSenderEmail = "";
 if(sendmailSender && (sendmailSender.indexOf('<') > -1) && (sendmailSender.indexOf('>') > -1))
 {
  var s = sendmailSender.indexOf('<');
  var e = sendmailSender.indexOf('>');
  var l = e-s;
  sendmailSenderName = sendmailSender.substr(0,s).trim();
  sendmailSenderEmail = sendmailSender.substr(s+1, l-1).trim();
 }
 else
  sendmailSenderEmail = sendmailSender;
 
 var refAP = ed.getAttribute('refap') ? ed.getAttribute('refap') : "aboutconfig_htmlparms";
 var refID = ed.getAttribute('refid') ? ed.getAttribute('refid') : 0;

 var attachPDF = (document.getElementById('sendtechmail-attachpdf').checked == true) ? "1" : "0";
 var attachTR = (document.getElementById('sendtechmail-attachtktref').checked == true) ? "1" : "0";
 var attachINT = (document.getElementById('sendtechmail-attachint').checked == true) ? "1" : "0";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 xml+= "<sendtechmail subject=\""+sendmailSubject.E_QUOT()+"\" messageap=\""+refAP+"\" messageid=\""+a['id']+"\" sendername=\""+sendmailSenderName.E_QUOT()+"\" senderemail=\""+sendmailSenderEmail+"\" attachpdf='"+attachPDF+"' attachtktref='"+attachTR+"' attachint='"+attachINT+"'/"+">";
	 callback(xml);
	}
 if(!refID)
  sh.sendCommand("dynarc new-cat -ap aboutconfig_htmlparms -name `Tickets` -tag tickets --if-not-exists && dynarc new-item -ap aboutconfig_htmlparms -ct tickets -name 'Messaggio email al tecnico/collaboratore' -desc `"+ed.getValue()+"`");
 else
  sh.sendCommand("dynarc edit-item -ap '"+refAP+"' -id '"+refID+"' -desc `"+ed.getValue()+"`");
}

function saveExtRequest(xml, callback)
{
 var enableRequest = (document.getElementById("extreq-enable").checked == true) ? '1' : '0';
 var enableNotify = (document.getElementById("extreq-enable-notify").checked == true) ? '1' : '0';

 var URLrequest = document.getElementById("extreq-form-request-url").value;
 var URLsuccess = document.getElementById("extreq-successpage-url").value;
 var URLerror = document.getElementById("extreq-errorpage-url").value;

 // required fields //
 var rfCustomer = (document.getElementById('extreq-reqfield-customer').checked == true) ? '1' : '0';
 var rfPhone = (document.getElementById('extreq-reqfield-phone').checked == true) ? '1' : '0';
 var rfEmail = (document.getElementById('extreq-reqfield-email').checked == true) ? '1' : '0';
 var rfHW = (document.getElementById('extreq-reqfield-hwname').checked == true) ? '1' : '0';

 var ed = document.getElementById('extreqnotify-message');
 var extreqSubject = document.getElementById('extreqnotify-subject').value;
 var extreqSender = document.getElementById('extreqnotify-sender').value;
 var extreqRecp = document.getElementById('extreqnotify-recp').value;
 var extreqSenderName = "";
 var extreqSenderEmail = "";
 if(extreqSender && (extreqSender.indexOf('<') > -1) && (extreqSender.indexOf('>') > -1))
 {
  var s = extreqSender.indexOf('<');
  var e = extreqSender.indexOf('>');
  var l = e-s;
  extreqSenderName = extreqSender.substr(0,s).trim();
  extreqSenderEmail = extreqSender.substr(s+1, l-1).trim();
 }
 else
  extreqSenderEmail = extreqSender;
 
 var refAP = ed.getAttribute('refap') ? ed.getAttribute('refap') : "aboutconfig_htmlparms";
 var refID = ed.getAttribute('refid') ? ed.getAttribute('refid') : 0;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 xml+= "<extrequest enabled=\""+enableRequest+"\" enablenotify=\""+enableNotify+"\" subject=\""+extreqSubject.E_QUOT()+"\" messageap=\""+refAP+"\" messageid=\""+a['id']+"\" sendername=\""+extreqSenderName.E_QUOT()+"\" senderemail=\""+extreqSenderEmail+"\" recp=\""+extreqRecp+"\" requrl=\""+URLrequest+"\" successurl=\""+URLsuccess+"\" errorurl=\""+URLerror+"\" reqfield_customer=\""+rfCustomer+"\"  reqfield_phone=\""+rfPhone+"\"  reqfield_email=\""+rfEmail+"\" reqfield_hwname=\""+rfHW+"\"/"+">";
	 callback(xml);
	}

 var content = "";
 if(EXTREQ_NOTIFYENABLED)
  content = ed.getValue();

 if(!refID)
  sh.sendCommand("dynarc new-cat -ap aboutconfig_htmlparms -name `Tickets` -tag tickets --if-not-exists && dynarc new-item -ap aboutconfig_htmlparms -ct tickets -name 'Messaggio email di notifica richiesta assistenza' -desc `"+content+"`");
 else
  sh.sendCommand("dynarc edit-item -ap '"+refAP+"' -id '"+refID+"' -desc `"+content+"`");

}

function saveFinish(xml)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){
	 alert("Salvataggio completato!");
	 if(EXIT_AFTER_SAVE)
	  Template.Exit();
	}
 sh.sendCommand("aboutconfig set-config -app tickets -xml-config `"+xml+"`");
}

function AddTicketType()
{
 var r = TICKETTYPETB.AddRow();
 r.edit();
}

function DeleteTicketType(r)
{
 if(!confirm("Sei sicuro di voler eliminare questo tipo di intervento?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){r.remove();}
 sh.sendCommand("dynarc delete-item -ap tickettypes -id '"+r.id+"' -r");
}

function renameIntervList()
{
 var title = prompt("Rinomina sezione interventi effettuati",document.getElementById('intervlisttitle').innerHTML);
 if(!title) return;
 document.getElementById('intervlisttitle').innerHTML = title;
}

function renameItemList()
{
 var title = prompt("Rinomina sezione servizi,manodopera e materiali",document.getElementById('itemlisttitle').innerHTML);
 if(!title) return;
 document.getElementById('itemlisttitle').innerHTML = title;
}

function renameField(id)
{
 var title = prompt("Rinomina campo", document.getElementById(id).innerHTML);
 if(!title) return;
 document.getElementById(id).innerHTML = title;
}

function renameAdvSearchField(id)
{
 var title = prompt("Rinomina campo", document.getElementById(id).innerHTML);
 if(!title) return;
 document.getElementById(id).innerHTML = title;
}

function enableDisableExtReq(cb)
{
 var div = document.getElementById('external-request-container');
 if(cb.checked == true)
  div.style.display = "";
 else
  div.style.display = "none";
}

function enableDisableExtReqNotify(cb)
{
 var div = document.getElementById('external-request-notify-container');
 if(cb.checked == true)
 {
  div.style.display = "";
  if(!EXTREQ_NOTIFYENABLED)
  {
   Template.initEd(document.getElementById("extreqnotify-message"),"fckeditor","Optimized");
   EXTREQ_NOTIFYENABLED = true;
  }
 }
 else
  div.style.display = "none";
}
</script>
<?php

$template->End();

?>
