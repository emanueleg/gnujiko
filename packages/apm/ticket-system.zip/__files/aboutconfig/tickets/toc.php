<?php

global $_APPLICATION_CONFIG;

$_APPLICATION_CONFIG['mainmenu'][] = array("title"=>"Tickets", "url"=>"tickets/index.php");
