<?php 

global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_COMPANY_PROFILE, $_BASE_PATH, $_INSTALLED_VER;

if(version_compare($_INSTALLED_VER,"2.1beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT id FROM dynarc_vatrates_items WHERE 1 ORDER BY id DESC LIMIT 1");
 $db->Read();
 $vatId = $db->record['id'];
 $db->Close();

 $ret = GShell("vatregister register-list",$_SESSION_ID,$_SHELL_ID);
 $db = new AlpaDatabase();
 for($c=0; $c < count($ret['outarr']); $c++)
  $db->RunQuery("ALTER TABLE `vat_register_".$ret['outarr'][$c]['year']."` ADD `vr_".$vatId."_amount` FLOAT NOT NULL , ADD `vr_".$vatId."_vat` FLOAT NOT NULL");
 $db->Close();

 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `totvatreg_purchases` ADD `vr_".$vatId."_amount` FLOAT NOT NULL , ADD `vr_".$vatId."_vat` FLOAT NOT NULL");
 $db->RunQuery("ALTER TABLE `totvatreg_sales` ADD `vr_".$vatId."_amount` FLOAT NOT NULL , ADD `vr_".$vatId."_vat` FLOAT NOT NULL");
 $db->Close();
}

if(version_compare($_INSTALLED_VER,"2.31beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `pricelists` ADD `discount` FLOAT NOT NULL");
 $db->Close();
}