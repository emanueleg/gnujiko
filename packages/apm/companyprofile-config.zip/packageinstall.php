<?php 

global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new archive */
$_SHELL_OUT.= "Create new archive Aliquote IVA...";
$ret = GShell("dynarc new-archive -name `Aliquote IVA` -prefix vatrates -type document -prems 644 --default-cat-perms 644 --default-item-perms 644 --hidden",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];

$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_vatrates_items` ADD `vat_type` VARCHAR( 32 ) NOT NULL , ADD `percentage` FLOAT NOT NULL");
$db->Close();

/* Insert basic Italian VAT rates */
GShell("dynarc new-item -ap vatrates -name `IVA al 22%` -code-str `22` -set `vat_type='TAXABLE',percentage='22'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `IVA al 10%` -code-str `10` -set `vat_type='TAXABLE',percentage='10'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `IVA al 4%` -code-str `4` -set `vat_type='TAXABLE',percentage='4'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `Esclusa art. 15` -code-str `ESC art.15` -set `vat_type='EXCLUDING',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `Non imponibile art. 8 c.2` -code-str `NI art.8,2` -set `vat_type='NOT_TAXABLE',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `IVA al 22% INDETRAIBILE` -code-str `22IND` -set `vat_type='NOT_DEDUCTIBLE',percentage='22'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `IVA al 10% INDETRAIBILE` -code-str `10IND` -set `vat_type='NOT_DEDUCTIBLE',percentage='10'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `IVA al 4% INDETRAIBILE` -code-str `4IND` -set `vat_type='NOT_DEDUCTIBLE',percentage='4'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `ESENTE art.10` -code-str `ES art.10` -set `vat_type='FREE',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `FUORI CAMPO IVA art.2 c.3` -code-str `FCI art.2,3` -set `vat_type='NOT_SUBJECT',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `FUORI CAMPO IVA art.3 c.4` -code-str `FCI art.3,4` -set `vat_type='NOT_SUBJECT',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `FUORI CAMPO IVA art.4` -code-str `FCI art.4` -set `vat_type='NOT_SUBJECT',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `FUORI CAMPO IVA art.5` -code-str `FCI art.5` -set `vat_type='NOT_SUBJECT',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `NON IMPONIBILE art.41` -code-str `NI art.41` -set `vat_type='NOT_TAXABLE',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `NON IMPONIBILE art.8` -code-str `NI art.8` -set `vat_type='NOT_TAXABLE',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `NON IMPONIBILE art.8bis` -code-str `NI art.8bis` -set `vat_type='NOT_TAXABLE',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `NON IMPONIBILE art.9` -code-str `NI art.9` -set `vat_type='NOT_TAXABLE',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `NON SOGGETTA art.7` -code-str `NI art.7` -set `vat_type='NOT_SUBJECT',percentage='0'`",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-item -ap vatrates -name `NON SOGGETTA art.26` -code-str `NS art.26` -set `vat_type='NOT_SUBJECT',percentage='0'`",$_SESSION_ID,$_SHELL_ID);


/* Create table pricelists by MySQL */
$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `pricelists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `markuprate` float NOT NULL,
  `discount` float NOT NULL,
  `vat` float NOT NULL,
  `isdefault` tinyint(1) NOT NULL,
  `isextra` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `isdefault` (`isdefault`)
)");
/* ... and insert example data */
$db->RunQuery("INSERT INTO `pricelists` (`id`, `name`, `markuprate`, `discount`, `vat`, `isdefault`, `isextra`) VALUES
(1, 'Listino Generale', 0, 0, 22, 1, 0),
(2, 'Listino convenzionati', 0, 0, 22, 0, 0)");
$db->Close();


/* Create configuration file company-profile.php */
if(!file_exists($_BASE_PATH."include/company-profile.php"))
 GShell("mv include/company-profile-dist.php include/company-profile.php",$_SESSION_ID,$_SHELL_ID);

/* Insert into config menu */
GShell("system cfg-add-element -name `Profilo aziendale` -sec managerial -perms 444 -icon /share/widgets/config/icons/company-profile.png -file /share/widgets/config/managerial/companyprofile.php",$_SESSION_ID, $_SHELL_ID);