<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

GShell("dynarc delete-cat -ap commercialdocs -tag MEMBERINVOICES",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc delete-cat -ap printmodels -tag MEMBERINVOICES",$_SESSION_ID, $_SHELL_ID);