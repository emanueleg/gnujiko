<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `commdocs-memberinvoices` --first-user",$_SESSION_ID,$_SHELL_ID);
/* Create new category */
$_SHELL_OUT.= "Create category Fatture Soci...";
$ret = GShell("dynarc new-cat -ap 'commercialdocs' -name `Fatture Soci` -tag `MEMBERINVOICES` -group 'commdocs-memberinvoices' -perms '660' --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Create category Soci...";
$ret = GShell("dynarc new-cat -ap 'rubrica' -name `Soci` -tag `members` -group 'rubrica' -perms '664' --if-not-exists --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Create category Fatture Soci...";
$ret = GShell("dynarc new-cat -ap 'printmodels' -name `Fatture Soci` -tag `MEMBERINVOICES` -pt commercialdocs -group 'commdocs-memberinvoices' -perms '660' --if-not-exists",$_SESSION_ID,$_SHELL_ID);
if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-memberinvoice.xml -ap `printmodels` -ct MEMBERINVOICES",$_SESSION_ID,$_SHELL_ID);