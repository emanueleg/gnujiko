<?php global $_BASE_PATH, $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

if(version_compare($_INSTALLED_VER, "2.22beta", "<"))
{
 /* Sistema il gruppo ed i permessi */
 include_once($_BASE_PATH."include/userfunc.php");
 $gid = _getGID("backoffice");
 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE gnujiko_applications SET gid='".$gid."',_mod='640' WHERE url='BackOffice2/'");
 $db->Close();
}