<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `backoffice` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='BackOffice2/'");
if($db->Read())
$db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application BackOffice2...";
 $ret = GShell("system register-app -name `BackOffice2` -desc `Strumenti per la gestione del back office aziendale.` -url 'BackOffice2/' -icon 'BackOffice2/icon.png' -group backoffice -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new archive */
$ret = GShell("dynarc new-archive -name `Ri.Ba.` -prefix riba -group `commdocs-invoices` --default-cat-perms 664 --default-item-perms 664",$_SESSION_ID,$_SHELL_ID);

/* Create new archive */
$ret = GShell("dynarc new-archive -name `Lotti di produzione` -prefix lots -group `backoffice` --default-cat-perms 664 --default-item-perms 664",$_SESSION_ID,$_SHELL_ID);


/* RIBA: */
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_riba_items` ADD `availdate` DATE NOT NULL ,
ADD `bank_id` INT(11) NOT NULL ,
ADD `bank_name` VARCHAR(32) NOT NULL ,
ADD `bank_sia` VARCHAR(5) NOT NULL ,
ADD `bank_abi` VARCHAR(5) NOT NULL ,
ADD `bank_cab` VARCHAR(5) NOT NULL ,
ADD `bank_cc` VARCHAR(12) NOT NULL ,
ADD `elements_count` INT(4) NOT NULL ,
ADD `tot_amount` DECIMAL(10, 4) NOT NULL ,
ADD INDEX (`bank_id`)");
$db->Close();

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE `dynarc_riba_elements` (
`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`riba_id` INT(11) NOT NULL ,
`mmr_id` INT(11) NOT NULL ,
`amount` DECIMAL(10, 4) NOT NULL ,
`expire_date` DATE NOT NULL ,
`docref_id` INT(11) NOT NULL ,
`docref_name` VARCHAR(32) NOT NULL ,
`subject_id` INT(11) NOT NULL ,
`subject_name` VARCHAR(32) NOT NULL ,
`subject_taxcode` VARCHAR(16) NOT NULL ,
`subject_vatnumber` VARCHAR(11) NOT NULL ,
`cobnk_id` INT(11) NOT NULL ,
`bank_id` INT(11) NOT NULL ,
`bank_name` VARCHAR(32) NOT NULL ,
`bank_abi` VARCHAR(5) NOT NULL ,
`bank_cab` VARCHAR(5) NOT NULL ,
`bank_cc` VARCHAR(12) NOT NULL ,
INDEX (`riba_id`,`docref_id`,`subject_id`,`cobnk_id`,`bank_id`)
)");
$db->Close();

/* LOTTI: */
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_lots_items` ADD `ref_ap` VARCHAR(32) NOT NULL ,
ADD `ref_id` INT(11) NOT NULL ,
ADD `qty` FLOAT NOT NULL ,
ADD `prod_date` DATE NOT NULL ,
ADD `expiry_date` DATE NOT NULL ,
ADD `finished` TINYINT(1) NOT NULL ,
ADD INDEX (`ref_ap`,`ref_id`,`finished`)");
$db->Close();