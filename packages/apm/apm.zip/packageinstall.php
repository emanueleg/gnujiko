<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `gnujiko_apm_cache` (`var` VARCHAR(32) NOT NULL, `val` VARCHAR(255) NOT NULL, PRIMARY KEY (`var`))");
$db->Close();