<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2017 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 12-09-2017
 #PACKAGE: htmlparsehelper
 #DESCRIPTION: HTML parse helper.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

class HTMLParseHelper
{
 var $content, $pointer;

 function HTMLParseHelper($htmlContent="")
 {
  $this->content = $htmlContent;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function GetElementsByTagName($tagName, $content="")
 {
  if(!$content) $content = $this->content;
  $elements = array();
  $this->pointer = 0;
  $len = strlen($content);
  while($this->pointer < $len)
  {
   $EL = $this->parseTag($tagName, $content);
   if(!$EL) return $elements;
   $elements[] = $EL;
  }
  return $elements;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function parseTag($tagName, $content="")
 {
  if(!$content) $content = $this->content;
  $spstr = "<".$tagName;
  $p = stripos($content, $spstr, $this->pointer);
  if($p === false) return false;
  $sop = $p;	// start outer point

  if(($content[$p+strlen($spstr)] == ">") || ($content[$p+strlen($spstr)] == " "))
  {
   $sp = $p+strlen($spstr)+1;
   $epstr = "</".$tagName.">";
   $p = stripos($content, $epstr, $sp);
   if($p === false)
   {
    switch(strtoupper($tagName))
	{
	 case 'IMG' : case 'BR' : case 'HR' : case 'INPUT' : case 'LINK' : case 'META' : case 'SOURCE' : case 'TRACK' : {
		 $epstr = ">";
		 $p = stripos($content, $epstr, $sp-1);
		 if($p === false) return false;
		} break;

	 default : return false; break;
	}
   }
   $ep = $p;
   $eop = $ep+strlen($epstr);	// end outer point
   $EL = new HTMLParseHelperElement($this, $tagName, substr($content, $sop, $eop-$sop), $sop, $eop);
   $this->pointer = $eop;
   return $EL;
  }
  else
  {
   // ... is not the matched tag
   $this->pointer = strlen($content);
  }


 }
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
}


class HTMLParseHelperElement
{
 var $tagName, $innerHTML, $property, $style, $startPointer, $endPointer;

 function HTMLParseHelperElement($helper, $tagName, $content="", $startPointer=0, $endPointer=0)
 {
  $this->helper = $helper;
  $this->tagName = strtoupper($tagName);
  $this->innerHTML = "";
  $this->outerHTML = $content;
  $this->property = array();
  $this->style = array();
  $this->startPointer = $startPointer;
  $this->endPointer = $endPointer;

  $this->data = array();

  $this->init($content);
 }
 //------------------------------------------------------------------------------------------------------------------//
 function init($content="")
 {
  if(!$content) return;
  
  $sp = strlen($this->tagName)+1;
  $ep = stripos($content, ">");
  if($ep > $sp)
  {
   // get properties
   $tmp = substr($content, $sp, $ep-$sp);
   $x = $this->explodeProperties(ltrim($tmp));
   for($c=0; $c < count($x); $c++)
   {
	$xx = explode("=",$x[$c]);
	$k = $xx[0];
	$v = $xx[1];
	if(substr($v,0,1) == '"')		$v = str_replace('"', '', $v);
	else if(substr($v,0,1) == "'")	$v = str_replace("'", "", $v);

	if(strtoupper($k) == "STYLE")
	{
	 // get style
	 $xs = explode(";", $v);
	 for($i=0; $i < count($xs); $i++)
	 {
	  $xxs = explode(":",$xs[$i]);
	  $this->style[trim($xxs[0])] = trim($xxs[1]);
	 }
	}
	else
	 $this->property[$k] = $v;
   }
  }
  $sp = $ep+1;
  $ep = stripos($content, "</".$this->tagName.">");
  if($ep !== false)
   $this->innerHTML = substr($content, $sp, $ep-$sp);
 }
 //------------------------------------------------------------------------------------------------------------------//
 function GetElementsByTagName($tagName)
 {
  return $this->helper->GetElementsByTagName($tagName, $this->innerHTML);
 }
 //------------------------------------------------------------------------------------------------------------------//
 function Paint($leaveOpen=false)
 {
  $out = "<".strtolower($this->tagName);
  reset($this->property);
  while(list($k,$v) = each($this->property))
  {
   $out.= " ".$k."=\"".$v."\"";
  }
  reset($this->style);
  $style = "";
  while(list($k,$v) = each($this->style))
  {
   $style.= $k.":".$v.";";
  }
  if($style) $out.= " style=\"".$style."\"";
  $out.= ">";

  if($leaveOpen) return $out;

  if($this->innerHTML)
   $out.= $this->innerHTML."</".strtolower($this->tagName).">";
  else
  {
   switch($this->tagName)
   {
	case 'IMG' : case 'BR' : case 'HR' : case 'INPUT' : case 'LINK' : case 'META' : case 'SOURCE' : case 'TRACK' : $out.= "/>"; break;
	default : $out.= "</".strtolower($this->tagName).">"; break;
   }
  }
 
  return $out;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function explodeProperties($string)
 {
  $property = array();
  $len = strlen($string);
  $s = "";
  $oq = "";		// open quot
  $chunks = array();
  for($c=0; $c < $len; $c++)
  {
   switch($string[$c])
   {
	case " " : {
		 if($oq) $s.= " ";
		 else 
		 {
		  $chunks[] = $s;
		  $s = "";
		 }
		} break;

	case "'" : case '"' : {
		 if($oq == $string[$c]) $oq = "";
		 else $oq = $string[$c];
		 $s.= $string[$c];
		} break;

	default : $s.= $string[$c]; break;
   }
  }
  if($s) $chunks[] = $s;
  return $chunks;
 }
 //------------------------------------------------------------------------------------------------------------------//
 function parseHTML($variable,$value)
 {
  $contents = $this->Paint();
  $_KEYS = array(); $_VALS = array();
  if(is_array($variable)) 	$_KEYS = $variable; else $_KEYS[] = $variable;
  if(is_array($value))		$_VALS = $value; else $_VALS[] = $value;

  for($c=0; $c < count($_KEYS); $c++)
  {
   $key = $_KEYS[$c];
   $val = $_VALS[$c];

   while($p = stripos($contents,$key,$p))
   {
    $chunk = strtolower(substr($contents,$p-16,16));
    if(($chunk == "data-parserkey='") || ($chunk == 'data-parserkey="'))
    {// is inside on html tag //
     $endTag = stripos($contents,">",$p+strlen($key));
     $contents = substr($contents,0,$endTag+1).$val.substr($contents,$endTag+1);
     $p = $endTag+strlen($val);
    }
    else
    {
     $contents = substr($contents,0,$p).$val.substr($contents,$p+strlen($key));
     $p+= strlen($val);
    }
   }
  }
  return $contents;
 }
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
 //------------------------------------------------------------------------------------------------------------------//
}

