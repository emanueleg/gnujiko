<?php global $_BASE_PATH, $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

include_once($_BASE_PATH."include/userfunc.php");

/* Create new group */
GShell("groupadd `bookkeeping` --first-user",$_SESSION_ID,$_SHELL_ID);
GShell("groupadd `pettycashbook` --first-user",$_SESSION_ID,$_SHELL_ID);

$gid = _getGID("bookkeeping");

/* Sistema il gruppo ed i permessi */
$db = new AlpaDatabase();
$db->RunQuery("UPDATE gnujiko_applications SET gid='".$gid."',_mod='640' WHERE url='BookKeeping/'");
$db->Close();