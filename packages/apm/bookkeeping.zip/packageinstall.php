<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `bookkeeping` --first-user",$_SESSION_ID,$_SHELL_ID);
GShell("groupadd `pettycashbook` --first-user",$_SESSION_ID,$_SHELL_ID);


/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='BookKeeping/'");
if($db->Read())
$db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Contabilita...";
 $ret = GShell("system register-app -name `Contabilita` -desc `Gestione della contabilità. Prima Nota e Registro IVA.` -url 'BookKeeping/' -icon 'BookKeeping/icon.gif' -group bookkeeping -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new archive */
$_SHELL_OUT.= "Create new archive Prima Nota...";
$ret = GShell("dynarc new-archive -name `Prima Nota` -prefix pettycashbook -group `pettycashbook` -perms 660 --default-cat-perms 660 --default-item-perms 660",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension pettycashbook...";
$ret = GShell("dynarc install-extension pettycashbook -ap pettycashbook",$_SESSION_ID,$_SHELL_ID);

/* Create new category */
$ret = GShell("dynarc new-cat -ap pettycashbook -name `Entrate` -tag INCOMES -group `pettycashbook`",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap pettycashbook -name `Uscite` -tag EXPENSES -group `pettycashbook`",$_SESSION_ID,$_SHELL_ID);

/* Create print models categories */
$ret = GShell("dynarc cat-info -ap `printmodels` -tag bookkeeping",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Contabilita` -tag `bookkeeping` -group printmodels",$_SESSION_ID, $_SHELL_ID);

// pettycashbook //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag pettycashbook",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Prima Nota` -tag `pettycashbook` -pt bookkeeping -group printmodels",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-pettycashbook.xml -ap `printmodels` -ct pettycashbook",$_SESSION_ID,$_SHELL_ID);
}

// vatbook //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag vatbook",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Registro IVA` -tag `vatbook` -pt bookkeeping -group printmodels",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-vatbook.xml -ap `printmodels` -ct vatbook",$_SESSION_ID,$_SHELL_ID);
}