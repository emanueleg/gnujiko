<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new archive */
$_SHELL_OUT.= "Create new archive Operazioni pianificate...";
$ret = GShell("dynarc new-archive -name `Operazioni pianificate` -prefix 'scheduledtasks' -perms '644' --def-cat-perms '644' --def-item-perms '644'",$_SESSION_ID,$_SHELL_ID);
if(!$ret['error'])
{
 /* Installing extension */
 $_SHELL_OUT.= "Install extension coding...";
 $ret = GShell("dynarc install-extension 'coding' -ap 'scheduledtasks'",$_SESSION_ID,$_SHELL_ID);

 $_SHELL_OUT.= "Install extension cronevents...";
 $ret = GShell("dynarc install-extension 'cronevents' -ap 'scheduledtasks'",$_SESSION_ID,$_SHELL_ID);

 $_SHELL_OUT.= "Install extension cronrecurrence...";
 $ret = GShell("dynarc install-extension 'cronrecurrence' -ap 'scheduledtasks'",$_SESSION_ID,$_SHELL_ID);

 $_SHELL_OUT.= "Install extension scheduledtask...";
 $ret = GShell("dynarc install-extension 'scheduledtask' -ap 'scheduledtasks'",$_SESSION_ID,$_SHELL_ID);
}


