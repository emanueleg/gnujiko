<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2016 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 24-10-2016
#PACKAGE: dynarc-addresses-extension
#DESCRIPTION: Addresses extension for Dynarc archives.
#VERSION: 2.3beta
#CHANGELOG: 24-10-2016 : MySQLi integration.
			28-05-2016 : Aggiunto campi phone,phone2,fax,cell,email.
			10-10-2014 : Aggiunta colonna note.
#TODO: 
*/

global $_BASE_PATH;

function dynarcextension_addresses_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_".$archiveInfo['prefix']."_addresses` (
 `id` INT (11) NOT NULL AUTO_INCREMENT ,
 `item_id` INT (11) NOT NULL,
 `name` VARCHAR(80) NOT NULL,
 `code` VARCHAR(32) NOT NULL,
 `address` VARCHAR(80) NOT NULL,
 `city` VARCHAR(40) NOT NULL,
 `zipcode` VARCHAR(10) NOT NULL,
 `province` VARCHAR(2) NOT NULL,
 `countrycode` VARCHAR(3) NOT NULL,
 `note` TEXT NOT NULL,
 `phone` VARCHAR(20) NOT NULL ,
 `phone2` VARCHAR(20) NOT NULL ,
 `fax` VARCHAR(20) NOT NULL ,
 `cell` VARCHAR(20) NOT NULL ,
 `email` VARCHAR(40) NOT NULL,
 PRIMARY KEY(`id`), 
 INDEX(`item_id`,`code`,`city`,`province`,`countrycode`)
 )");
 $db->Close();

 return array("message"=>"Addresses extension has been installed into archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DROP TABLE IF EXISTS `dynarc_".$archiveInfo['prefix']."_addresses`");
 $db->Close();

 return array("message"=>"Addresses extension has been removed from archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_catset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_catunset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_catget($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_addresses_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'name' : {$name=$args[$c+1]; $c++;} break;
   case 'code' : {$code=$args[$c+1]; $c++;} break;
   case 'address' : {$address=$args[$c+1]; $c++;} break;
   case 'city' : {$city=$args[$c+1]; $c++;} break;
   case 'zipcode' : {$zipcode=$args[$c+1]; $c++;} break;
   case 'province' : {$province=$args[$c+1]; $c++;} break;
   case 'countrycode' : {$countrycode=$args[$c+1]; $c++;} break;
   case 'phone' : {$phone=$args[$c+1]; $c++;} break;
   case 'phone2' : {$phone2=$args[$c+1]; $c++;} break;
   case 'fax' : {$fax=$args[$c+1]; $c++;} break;
   case 'cell' : {$cell=$args[$c+1]; $c++;} break;
   case 'email' : {$email=$args[$c+1]; $c++;} break;
   case 'note' : {$note=$args[$c+1]; $c++;} break;
  }

 if($id)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT code,name,address,city,zipcode,province,countrycode,note,phone,phone2,fax,cell,email FROM dynarc_".$archiveInfo['prefix']."_addresses WHERE id='".$id."'");
  $db->Read();
  $itemInfo['last_address'] = $db->record;

  $q = "";
  if($name) 				{$q.=",name='".$db->Purify($name)."'";			$itemInfo['last_address']['name'] = $name;}
  if(isset($code)) 			{$q.=",code='".$db->Purify($code)."'";			$itemInfo['last_address']['code'] = $code;}
  if(isset($address))		{$q.=",address='".$db->Purify($address)."'";	$itemInfo['last_address']['address'] = $address;}
  if(isset($city))			{$q.=",city='".$db->Purify($city)."'";			$itemInfo['last_address']['city'] = $city;}
  if(isset($zipcode))		{$q.=",zipcode='".$zipcode."'";					$itemInfo['last_address']['zipcode'] = $zipcode;}
  if(isset($province))		{$q.=",province='".$province."'";				$itemInfo['last_address']['province'] = $province;}
  if(isset($countrycode))	{$q.=",countrycode='".$countrycode."'";			$itemInfo['last_address']['countrycode'] = $countrycode;}
  if(isset($note)) 			{$q.=",note='".$db->Purify($note)."'";			$itemInfo['last_address']['note'] = $note;}
  if(isset($phone))			{$q.=",phone='".$phone."'";						$itemInfo['last_address']['phone'] = $phone;}
  if(isset($phone2))		{$q.=",phone2='".$phone2."'";					$itemInfo['last_address']['phone2'] = $phone2;}
  if(isset($fax))			{$q.=",fax='".$fax."'";							$itemInfo['last_address']['fax'] = $fax;}
  if(isset($cell))			{$q.=",cell='".$cell."'";						$itemInfo['last_address']['cell'] = $cell;}
  if(isset($email))			{$q.=",email='".$email."'";						$itemInfo['last_address']['email'] = $email;}

  if($q)
   $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_addresses SET ".ltrim($q,",")." WHERE id='".$id."'");
  $db->Close();
  return $itemInfo;
 }

 $db = new AlpaDatabase();
 $fields = "item_id,name,code,address,city,zipcode,province,countrycode,note,phone,phone2,fax,cell,email";
 $db->RunQuery("INSERT INTO dynarc_".$archiveInfo['prefix']."_addresses(".$fields.") VALUES('"
	.$itemInfo['id']."','".$db->Purify($name)."','".$db->Purify($code)."','".$db->Purify($address)."','"
	.$db->Purify($city)."','".$zipcode."','".$province."','".$countrycode."','".$db->Purify($note)."','"
	.$phone."','".$phone2."','".$fax."','".$cell."','".$email."')");
 $recid = $db->GetInsertId();
 $itemInfo['last_address'] = array('id'=>$recid,'name'=>$name, 'code'=>$code, 'address'=>$address, 'city'=>$city, 'zipcode'=>$zipcode, 
	'province'=>$province, 'countrycode'=>$countrycode, 'note'=>$note, 'phone'=>$phone, 'phone2'=>$phone2, 'fax'=>$fax, 'cell'=>$cell, 'email'=>$email);
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_addresses_catunset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'all' : $all=true; break;
  }
 
 $db = new AlpaDatabase();
 if($id)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_addresses WHERE id='".$id."'");
 else
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_addresses WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_addresses_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 $limit = 100;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'limit' : {$limit=$args[$c+1]; $c++;} break;
  }

 $itemInfo['addresses'] = array();
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$archiveInfo['prefix']."_addresses WHERE item_id='".$itemInfo['id']."' ORDER BY name ASC LIMIT ".$limit);
 while($db->Read())
 {
  $a = array('id'=>$db->record['id']);
  $a['name'] = $db->record['name'];
  $a['code'] = $db->record['code'];
  $a['address'] = $db->record['address'];
  $a['city'] = $db->record['city'];
  $a['zipcode'] = $db->record['zipcode'];
  $a['province'] = $db->record['province'];
  $a['countrycode'] = $db->record['countrycode'];
  $a['note'] = $db->record['note'];
  $a['phone'] = $db->record['phone'];
  $a['phone2'] = $db->record['phone2'];
  $a['fax'] = $db->record['fax'];
  $a['cell'] = $db->record['cell'];
  $a['email'] = $db->record['email'];

  $itemInfo['addresses'][] = $a;
 }
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 $xml = "<addresses />";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 if(!$node)
  return ;

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_addresses_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
