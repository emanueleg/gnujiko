/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 18-10-2014
 #PACKAGE: dynarc-addresses-extension
 #DESCRIPTION: Address search object for GLight Template.
 #VERSION: 2.2beta
 #CHANGELOG: 18-10-2014 : Aggiornamenti vari.
			 10-10-2014 : Bug fix vari.
 #TODO: 
 
*/

function GLAddressSearch(ed, schema)
{
 var oThis = this;
 this.ed = ed;
 this.ed.defaultValue = this.ed.value;
 this.ap = ed.getAttribute('ap') ? ed.getAttribute('ap') : "rubrica";
 this.qryTimer = null;
 this.scrollTimer = null;
 this.limit = 10;
 this.qryInProgress = false;
 this.schema = schema ? schema : "{ADDRESS} - {CITY} ({PROV})";
 this.schemaKeys = new Array('{CODE}','{TITLE}','{ADDRESS}','{CITY}','{ZIP}','{PROV}','{CC}','{NOTE}');

 this.results = new Array();
 this.liElements = new Array();
 this.lastLIhinted = null;
 this.selectedIndex = -1;

 this.O = document.createElement('DIV');
 this.O.className = "gladdresssearch-container";

 this.ULDIV = document.createElement('DIV');
 this.ULDIV.className = "gladdresssearch-menu-div"
 this.UL = document.createElement('UL');
 this.UL.className = "gladdresssearch-menu";


 this.ULDIV.appendChild(this.UL);
 this.O.appendChild(this.ULDIV);

 this.O.style.width = this.ed.offsetWidth+"px";
 document.body.appendChild(this.O);
 
 this.ed.onkeydown = function(evt){oThis.onKeyDown(evt,this);}
 this.ed.onkeyup = function(evt){oThis.onKeyUp(evt,this);}
 this.ed.onkeypress = function(evt){oThis.onKeyPress(evt,this);}
 this.ed.onclick = function(){
	 if(this.getAttribute('emptyonclick'))
	  this.value = "";
	 //else
	 // oThis.execQry(true);
	}
 this.ed.OnFreeSearch = function(){}

 this.init();
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.init = function()
{

}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.execQry = function(autoselect)
{
 if(!this.ed.value)
 {
  if((this.ed.value != this.ed.defaultValue) && this.ed.OnSearch)
   this.ed.OnSearch();
  return this.hide();
 }

 if(this.qryTimer)
  clearInterval(this.qryTimer);

 var oThis = this;
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 oThis.qryInProgress = false;
	 if(!a || !a['results'])
	 {
	  oThis.empty("nessun indirizzo trovato");
	  oThis.results = new Array();
	  //oThis.ed.setAttribute('refid',0);
	  //oThis.ed.OnSearch();
	  if(autoselect) // significa che ha premuto enter
	   oThis.ed.OnFreeSearch();
	  return;
	 }
	 oThis.empty();
	 oThis.results = a['results'];
	 var lastLI = null;
	 for(var c=0; c < a['results'].length; c++)
	  lastLI = oThis.addResult(a['results'][c]);
	 /*if((a['results'].length == 1) && autoselect)
	  oThis.select(lastLI);
	 else
	 {*/
	  if(autoselect) // significa che ha premuto enter
	   oThis.ed.OnFreeSearch();
	  oThis.show();
	 //}
	}
 this.qryInProgress = true;
 
 var cmd = "fastfind addresses";
 if(this.ap)	cmd+= " -ap '"+this.ap+"'";
 if(this.ed.getAttribute('subjid'))	cmd+= " -subjid '"+this.ed.getAttribute('subjid')+"'";
 sh.sendCommand(cmd+" `"+this.ed.value+"` -limit "+this.limit);
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.repeatQry = function()
{
 this.fields = "";

 for(var c=0; c < this.optboxCBList.length; c++)
 {
  var inp = this.optboxCBList[c];
  if(!inp.checked) continue;
  if(inp.getAttribute('fields'))
   this.fields+= ","+inp.getAttribute('fields');
 }
 if(this.fields) this.fields = this.fields.substr(1);
 this.execQry();
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.empty = function(msg)
{
 this.UL.innerHTML = "";
 this.liElements = new Array();
 if(msg)
  this.UL.innerHTML = "<li class='emptymessage'><i>"+msg+"</i></li>";
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.addResult = function(data)
{
 var oThis = this;
 var li = document.createElement('LI');
 li.className = "extended";
 li.data = data;
 li.glcsHinst = this;
 li.onclick = function(){this.glcsHinst.select(this);}

 var address = this.schema;
 var values = new Array(data['code'], data['name'], data['address'], data['city'], data['zipcode'], data['province'], data['countrycode'], data['note']);
 for(var c=0; c < this.schemaKeys.length; c++)
 {
  var k = this.schemaKeys[c];
  var v = values[c];
  address = address.replace(k,v);
 }
 li.setAttribute('address',address);

 var html = "<div class='gladdressinfo' style='width:"+(this.O.offsetWidth-20)+"px'>";
  html+= "<div class='gladdress-name'><span class='gladdress-code'>"+address+"</div>";
 html+= "</div>";

 li.innerHTML = html;
 this.UL.appendChild(li);
 this.liElements.push(li);
 return li;
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.select = function(li)
{
 this.ed.value = li.getAttribute('address');
 this.ed.data = li.data;
 this.hide();
 if(this.ed.OnSearch)
  this.ed.OnSearch();
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.hint = function(li)
{
 if(this.lastLIhinted)
  this.lastLIhinted.className = this.lastLIhinted.className.replace(' selected','');
 li.className = li.className+" selected";
 this.lastLIhinted = li;
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.show = function()
{
 ACTIVE_GLADDRESSSEARCH = this;
 var pos = this.getObjectPosition(this.ed);
 this.O.style.left = pos.x+"px";
 this.O.style.top = (pos.y+this.ed.offsetHeight)+"px";
 this.O.style.visibility = "visible";
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.hide = function()
{
 this.O.style.visibility = "hidden";
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.getObjectPosition = function(e)
{
 var left = e.offsetLeft;
 var top  = e.offsetTop;
 var obj = e;
 while(e = e.offsetParent)
 {
  left+= e.offsetLeft-e.scrollLeft;
  top+= e.offsetTop-e.scrollTop;
 }

 while(obj = obj.parentNode)
 {
  left+= obj.scrollLeft ? obj.scrollLeft : 0;
  top+= obj.scrollTop ? obj.scrollTop : 0;
 }

 return {x:left, y:top};
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.onKeyDown = function(evt,ed)
{
 var oThis = this;
 if(this.qryTimer)
  clearInterval(this.qryTimer);
 if(this.scrollTimer)
  clearInterval(this.scrollTimer);

 var keyNum = window.event ? evt.keyCode : evt.which;
 if(keyNum == 9) evt.preventDefault();
 switch(keyNum)
 {
  case 38 : { // UP //
	 if(!this.results.length)
	  return;
	 this.lastMoveIndex = -1;
	} break;

  case 40 : { // DOWN //
	 if(!this.results.length)
	  return;
	 this.lastMoveIndex = 1;
	} break;

  case 13 : { // ENTER //
	 if((this.O.style.visibility == "visible") && this.lastLIhinted)
	  this.select(this.lastLIhinted);
	 else
	  this.execQry(true);
	} break;

  default : {
	 var isprintable=/[^ -~]/;
	 var ok = false;
	 if((keyNum == 8) || (keyNum == 46)) // canc and backspace //
	  ok = true;
     if((!isprintable.test(String.fromCharCode(keyNum))) || ok)
	  this.qryTimer = window.setTimeout(function(){oThis.execQry();},250);
	} break;
 }
 this.lastKeyNum = keyNum;
 if((keyNum == 9) || (keyNum == 27))
 {
  if(keyNum == 27)
   ed.value = ed.defaultValue;
  this.hide();
 }
 else
 {
  if(typeof(evt.stopPropagation) != "undefined")
   evt.stopPropagation();
  else
   evt.cancelBubble=true;
 }
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.onKeyUp = function(evt,ed)
{
 if(this.scrollTimer)
  clearInterval(this.scrollTimer);
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.onKeyPress = function(evt,ed)
{
 if((this.lastKeyNum==38) || (this.lastKeyNum==40))
  this.moveIndex(this.lastMoveIndex, ed);
 if(typeof(evt.stopPropagation) != "undefined")
  evt.stopPropagation();
 else
  evt.cancelBubble=true;
}
//--------------------------------------------------------------------------------------------------------------------//
GLAddressSearch.prototype.moveIndex = function(pos,ed)
{
 this.selectedIndex+=pos;
 if(this.selectedIndex < 0)
  this.selectedIndex = this.results.length-1;
 else if(this.selectedIndex >= this.results.length)
  this.selectedIndex = 0;
 this.hint(this.liElements[this.selectedIndex]);
}
//--------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------------------------------------//
var ACTIVE_GLADDRESSSEARCH = null;
function hideActiveGLAddressSearch()
{
 if(ACTIVE_GLADDRESSSEARCH)
  ACTIVE_GLADDRESSSEARCH.hide();
}
document.addEventListener ? document.addEventListener("mouseup",hideActiveGLAddressSearch,false) : document.attachEvent("onmouseup",hideActiveGLAddressSearch);

