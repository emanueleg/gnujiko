<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 28-05-2016
 #PACKAGE: dynarc-addresses-extension
 #DESCRIPTION: Modifica indirizzo
 #VERSION: 2.1beta
 #CHANGELOG: 28-05-2016 : Aggiunto campi tel,cell,email.
 #DEPENDS:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate("widget");
$template->includeObject("editsearch");
$template->includeObject("fckeditor");

$template->Begin("Dettagli indirizzo");
//-------------------------------------------------------------------------------------------------------------------//

$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : "rubrica";
$_ID = $_REQUEST['id'];

//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-header bg-green"><h3>Dettagli indirizzo</h3></div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",700);

$db = new AlpaDatabase();
$db->RunQuery("SELECT id,item_id,name,code,address,city,zipcode,province,countrycode,note,phone,phone2,fax,cell,email FROM dynarc_".$_AP."_addresses WHERE id='".$_ID."'");
$db->Read();
$itemInfo = $db->record;
$db->Close();

if($itemInfo['countrycode'])
{
 $ret = GShell("dynarc cat-info -ap countries -code '".$itemInfo['countrycode']."'",$_REQUEST['sessid'],$_REQUEST['shellid']);
 $itemInfo['country'] = $ret['outarr']['name'];
}


//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-body" style="width:684px;height:450px">
<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td width='120'><label>CODICE</label><br/>
	<input type='text' class='edit' style='width:100px' id='code' value="<?php echo $itemInfo['code']; ?>"/></td>

	<td><label>TITOLO</label><br/>
	<input type='text' class='edit' style='width:500px' id='title' value="<?php echo $itemInfo['name']; ?>"/></td></tr>
</table>
<br/>
<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td width='320'><label>INDIRIZZO</label><br/>
	<input type='text' class='edit' style='width:300px' id='address' value="<?php echo $itemInfo['address']; ?>"/></td>

	<td><label>CITTA&lsquo;</label><br/>
	<input type='text' class='edit' style='width:300px' id='city' value="<?php echo $itemInfo['city']; ?>"/></td></tr>
</table>
<br/>
<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td width='160'><label>CAP</label><br/>
	<input type='text' class='edit' style='width:100px' id='zipcode' value="<?php echo $itemInfo['zipcode']; ?>"/></td>

	<td width='160'><label>PROV</label><br/>
	<input type='text' class='edit' style='width:100px' id='province' value="<?php echo $itemInfo['province']; ?>"/></td>

	<td><label>STATO</label><br/>
	<input type='text' class='search' style='width:200px' id='countrycode' value="<?php echo $itemInfo['country']; ?>" retval="<?php echo $itemInfo['countrycode']; ?>"/></td></tr>
</table>
<br/>
<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td width='160'><label>TEL</label><br/>
	<input type='text' class='edit' style='width:140px' id='phone' value="<?php echo $itemInfo['phone']; ?>" maxlength='20'/></td>

	<td width='160'><label>CELL</label><br/>
	<input type='text' class='edit' style='width:140px' id='cell' value="<?php echo $itemInfo['cell']; ?>" maxlength='20'/></td>

	<td><label>EMAIL</label><br/>
	<input type='text' class='edit' style='width:300px' id='email' value="<?php echo $itemInfo['email']; ?>" maxlength='40'/></td></tr>
</table>
<br/>
<table width="676" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr class='separator'><td><hr style="width:670px"/></td></tr>
<tr><td><label>NOTE</label><br/>
	 <textarea class="textarea" id="note" style="width:676px;height:150px"><?php echo $itemInfo['note']; ?></textarea>
    </td></tr>
</table>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$footer = "<input type='button' class='button-blue' value='Salva' style='float:left' onclick='SubmitAction()'/>";
$footer.= "<input type='button' class='button-gray' value='Chiudi' style='float:left;margin-left:10px' onclick='abort()'/>";
$footer.= "<input type='button' class='button-red' value='Elimina' style='float:right' onclick='DeleteAddress()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";
var ID = "<?php echo $_ID; ?>";
var ITEMID = "<?php echo $itemInfo['item_id']; ?>";

function abort(){Template.Exit();}

Template.OnInit = function(){
 EditSearch.init(document.getElementById('countrycode'),
	"dynarc cat-find -ap countries -field name `","` -limit 10",
	"id","name","",true);
 document.getElementById('countrycode').onchange = function(){
	 if(this.value && this.data)
	  this.setAttribute('retval',this.data['code']);
	}
 document.getElementById('countrycode').setValue = function(code){
	 var oThis = this;
	 if(!code)
	 {
	  this.setAttribute('retval','');
	  this.value = "";
	  return;
	 }
	 this.setAttribute('retval',code);
	 var sh = new GShell();
	 sh.OnOutput = function(o,a){oThis.value = a['name'];}
	 sh.sendCommand("dynarc cat-info -ap countries -code '"+code+"'");
	}
 document.getElementById('countrycode').getValue = function(){return this.getAttribute('retval');}

 this.initEd(document.getElementById("note"), "fckeditor", "Basic");
}

function SubmitAction()
{
 var code = document.getElementById("code").value;
 var title = document.getElementById("title").value;
 var addr = document.getElementById("address").value;
 var city = document.getElementById("city").value;
 var zip = document.getElementById("zipcode").value;
 var prov = document.getElementById("province").value;
 var cc = document.getElementById("countrycode").getValue();
 var note = document.getElementById("note").getValue();
 var phone = document.getElementById("phone").value;
 var cell = document.getElementById("cell").value;
 var email = document.getElementById("email").value;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){gframe_close(o,a['last_address']);}

 var cmd = "dynarc edit-item -ap '"+AP+"' -id `"+ITEMID+"` -extset `addresses.id="+ID+",code='"+code+"',name='''"+title.E_QUOT()+"''',address='''"+addr.E_QUOT()+"''',city='''"+city.E_QUOT()+"''',zipcode='"+zip+"',province='"+prov+"',countrycode='"+cc+"',note='''"+note+"''',phone='"+phone+"',cell='"+cell+"',email='"+email+"'`";
 sh.sendCommand(cmd);
}

function DeleteAddress()
{
 if(!confirm("Sei sicuro di voler eliminare questo indirizzo?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 var a = new Array();
	 a['id'] = ID;
	 a['removed'] = true;
	 gframe_close(o,a);
	}
 sh.sendCommand("dynarc edit-item -ap '"+AP+"' -id '"+ITEMID+"' -extunset `addresses.id="+ID+"`");
}
</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

