<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

GShell("dynarc install-extension 'addresses' -ap 'rubrica'",$_SESSION_ID,$_SHELL_ID);