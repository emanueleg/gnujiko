<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

/* 10-10-2014 : Rev. 2.2beta */
if(version_compare($_INSTALLED_VER, "2.2beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_rubrica_addresses` ADD `note` TEXT NOT NULL");
 $db->Close();
}

/* 28-05-2016 : Rev. 2.4beta */
if(version_compare($_INSTALLED_VER, "2.4beta", "<"))
{
 /* Aggiunto campi phone,phone2,fax,cell,email. */
 $ret = GShell("dynarc extension-info addresses",$_SESSION_ID,$_SHELL_ID);
 if($ret['error']) { $_SHELL_OUT.= $ret['message']; $_SHELL_ERR=$ret['error']; return; }
 if(!$ret['error'] && count($ret['outarr']['archives']))
 {
  for($c=0; $c < count($ret['outarr']['archives']); $c++)
  {
   $ap = $ret['outarr']['archives'][$c]['ap'];
   $db = new AlpaDatabase();
   $_SHELL_OUT.= "Insert new fields into archive dynarc_".$ap."_addresses ...";
   $db->RunQuery("ALTER TABLE `dynarc_".$ap."_addresses` ADD `phone` VARCHAR(20) NOT NULL, ADD `phone2` VARCHAR(20) NOT NULL, ADD `fax` VARCHAR(20) NOT NULL, ADD `cell` VARCHAR(20) NOT NULL, ADD `email` VARCHAR(40) NOT NULL");
   if($db->Error) $_SHELL_OUT.= "failed!\nMySQL Error:".$db->Error;
   else $_SHELL_OUT.= "done!\n";
   $db->Close();
  }
 }
}