<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 22-11-2013
 #PACKAGE: backoffice-vendorcontracts
 #DESCRIPTION: BackOffice - Vendor contracts schedule parser for print preview.
 #VERSION: 2.4beta
 #CHANGELOG: 
 #TODO:
 
*/

?>
<script>
var VIEW = "<?php echo $_REQUEST['view']; ?>";

function loadPreview()
{
 var query = "<?php echo $_REQUEST['cmd']; ?>";
 query = query.replace(/\ '''/g, " `");
 query = query.replace(/\''' /g, "` ");

 var date = new Date();
 var sh = new GShell();
 sh.OnOutput = function(o,a){
	 scheduleInsertRows(a);
	}
 sh.sendCommand(query);
}

function scheduleInsertRows(a)
{
 var tb = document.getElementById('itemlist');
 if(!tb)
  return;

 if(!a || (!a['results'] && !['items']))
  return;

 if(!a['results'])
  a['results'] = a['items'];

 // use last row as footer //
 var fR = tb.rows[tb.rows.length-1];
 var cR = null;
 var startAt = 0;
 if(tb.rows[0].cells[0].tagName.toUpperCase() == "TH")
 {
  var fRH = tb.rows[1].offsetHeight;
  startAt++;
  if(fR.rowIndex >= 2)
   fRH+= tb.rows[2].offsetHeight;
  if(tb.rows[1] != fR)
   cR = tb.rows[1];
 }
 else
 {
  var fRH = tb.rows[0].offsetHeight;
  if(fR.rowIndex >= 1)
   fRH+= tb.rows[1].offsetHeight;
  if(tb.rows[0] != fR)
   cR = tb.rows[0];
 }

 var fRHstart = fRH;
 var start = <?php echo $_START ? $_START : "0"; ?>;
 var elidx = 0;

 for(var c=start; c < a['results'].length; c++)
 {
  var r = tb.insertRow(startAt+c-start);
  for(var i=0; i < tb.rows[0].cells.length; i++)
  {
   value = a['results'][c][tb.rows[0].cells[i].id] ? a['results'][c][tb.rows[0].cells[i].id] : "";
   var cell = r.insertCell(-1);
   if(cR)
   {
	cell.className = cR.cells[i].className;
    switch(cR.cells[i].getAttribute('format'))
	{
	  case 'currency' : cell.innerHTML = value ? formatCurrency(value,cR.cells[i].getAttribute('decimals') ? parseInt(cR.cells[i].getAttribute('decimals')) : DECIMALS) : "&nbsp;"; break;
	  case 'percentage' : cell.innerHTML = value ? parseFloat(value)+"%" : "&nbsp;"; break;
	  case 'percentage currency' : {
		 if(!parseFloat(value))
		  cell.innerHTML = "&nbsp;";
		 else if(value.indexOf("%") > 0)
		  cell.innerHTML = value;
		 else
		  cell.innerHTML = formatCurrency(value,cR.cells[i].getAttribute('decimals') ? parseInt(cR.cells[i].getAttribute('decimals')) : DECIMALS);
		} break;
	  case 'date' : {
		 var tmpDate = new Date();
		 tmpDate.setFromISO(value);
		 cell.innerHTML = tmpDate.printf('d/m/Y');
		} break;
	  default : {
		 cell.innerHTML = value ? value : "&nbsp;"; 
		} break;
	
	}
   }
   else
    cell.innerHTML = value ? value : "&nbsp;";
   if(tb.rows[0].cells[i].style.display == "none")
	cell.style.display = "none";
  }

  fRH-= r.offsetHeight;

  if(px2mm(fRH) < 5)
  {
    // mette la scritta **SEGUE** nel totale //
    var follows = document.getElementsByName("follow");
	for(var j=0; j < follows.length; j++)
	 follows[j].innerHTML = "**SEGUE**";

   fRH+= r.offsetHeight;
   tb.deleteRow(r.rowIndex);
   var page = {start:start, elements:elidx, freespace:px2mm(fRH)};
   if(window.parent && (typeof(window.parent.previewMessage) == "function"))
	window.parent.previewMessage("PAGEBREAK",page);
   break;
  }
  elidx++;
 }

 for(var c=0; c < fR.cells.length; c++)
  fR.cells[c].style.height = px2mm(fRH)+"mm";

 /* Rimuove le colonne nascoste perchè altrimenti escono fuori quando si esporta in PDF */
 for(var i=0; i < tb.rows[0].cells.length; i++)
 {
  if(tb.rows[0].cells[i].style.display == "none")
  {
   for(var c=0; c < tb.rows.length; c++)
    tb.rows[c].deleteCell(i);
   if(tb.getElementsByTagName('COLGROUP').length)
   {
    var col = tb.getElementsByTagName('COLGROUP')[0].getElementsByTagName('COL')[i];
    col.parentNode.removeChild(col);
   }
   i--;
  }
 }

 /* EOF - FIRST (or unique) TABLE */


 var contents = "<style type='text/css'>"+document.body.getElementsByTagName('STYLE')[1].innerHTML+"</style>" + document.getElementById("___printpreviewpagecontents").innerHTML;
 var page = {start:start, elements:elidx, freespace:px2mm(fRH), contents:contents};
 if(window.parent && (typeof(window.parent.previewMessage) == "function"))
  window.parent.previewMessage("PAGEINFO",page);
}

function px2mm(px)
{
 return (px*25.4)/72;
}

function getCellWidth(cell)
{
 return Math.floor(px2mm(parseFloat(getStyle(cell,"width"))));
}

function getStyle(el,styleProp)
{
 var x = el;
  if (x.currentStyle)
 var y = x.currentStyle[styleProp];
  else if (window.getComputedStyle)
 var y = document.defaultView.getComputedStyle(x,null).getPropertyValue(styleProp);
 return y;
}

</script>
<?php
