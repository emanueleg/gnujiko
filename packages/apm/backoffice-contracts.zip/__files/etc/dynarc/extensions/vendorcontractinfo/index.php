<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 19-11-2013
 #PACKAGE: backoffice-contracts
 #DESCRIPTION: Vendor Contract extended informations.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH;

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` 
 ADD `vendor_id` INT(11) NOT NULL,
 ADD `vendor_name` VARCHAR(32) NOT NULL,
 ADD `subject_id` INT(11) NOT NULL,
 ADD `subject_name` VARCHAR(32) NOT NULL,
 ADD `amount` DECIMAL(10,4) NOT NULL,
 ADD `payment_mode` INT(11) NOT NULL,
 ADD INDEX (`vendor_id`,`subject_id`)");
 $db->Close();

 return array("message"=>"Vendor contract main-info extension has been installed into archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` 
 DROP `vendor_id`,
 DROP `vendor_name`,
 DROP `subject_id`,
 DROP `subject_name`,
 DROP `amount`,
 DROP `payment_mode`");
 $db->Close();

 return array("message"=>"Vendor contract main-info extension has been removed from archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_set($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'subject' : case 'subject-name' : {$subjectName=$args[$c+1]; $c++;} break;
   case 'subjectid' : case 'subject-id' : {$subjectId=$args[$c+1]; $c++;} break;
   case 'vendor' : case 'vendor-name' : {$vendorName=$args[$c+1]; $c++;} break;
   case 'vendorid' : case 'vendor-id' : {$vendorId=$args[$c+1]; $c++;} break;
   case 'amount' : {$amount=$args[$c+1]; $c++;} break;
   case 'paymentmode' : {$paymentMode=$args[$c+1]; $c++;} break; 
  }

 $db = new AlpaDatabase();

 $q = "";
 if($subjectName)
  $q.= ",subject_name='".$db->Purify($subjectName)."'";
 if(isset($subjectId))
  $q.= ",subject_id='".$subjectId."'";
 if($vendorName)
  $q.= ",vendor_name='".$db->Purify($vendorName)."'";
 if(isset($vendorId))
  $q.= ",vendor_id='".$vendorId."'";
 if(isset($amount))
  $q.= ",amount='".$amount."'";
 if(isset($paymentMode))
  $q.= ",payment_mode='".$paymentMode."'";

 $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET ".substr($q,1)." WHERE id='".$itemInfo['id']."'");
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_get($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 $itemInfo['subject_id'] = $db->record['subject_id'];
 $itemInfo['subject_name'] = $db->record['subject_name'];
 $itemInfo['vendor_id'] = $db->record['vendor_id'];
 $itemInfo['vendor_name'] = $db->record['vendor_name'];
 $itemInfo['paymentmode'] = $db->record['payment_mode'];
 $itemInfo['amount'] = $db->record['amount'];

 $db->Close();
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_export($sessid, $shellid, $archiveInfo, $itemInfo)
{
 $xml = "";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_import($sessid, $shellid, $archiveInfo, $itemInfo, $node)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_syncexport($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_USERS_HOMES;
 $xml = "";
 $attachments = array();

 return array('xml'=>$xml,'attachments'=>$attachments);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_vendorcontractinfo_syncimport($sessid, $shellid, $archiveInfo, $itemInfo, $xmlNode, $isCategory=false)
{
 global $_USER_PATH;
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

