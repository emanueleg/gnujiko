<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 22-11-2013
 #PACKAGE: backoffice-vendorcontracts
 #DESCRIPTION: BackOffice - Vendor contracts schedule parser
 #VERSION: 2.24beta
 #CHANGELOG: 
 #TODO:
 
*/

function gnujikocontentparser_allvendorcontracts_info($sessid, $shellid)
{
 $info = array('name' => "Lista contratti vs fornitori");
 $keys = array(
	 "DOC_PG" => "Numero di pagina",
	 "DATE_FROM" => "Dal (data)", 
	 "DATE_TO" => "Al (data)", 

	 "COMPANY-NAME" => "Denominazione azienda (la vostra)",
	 "CO_ADDR" => "Indirizzo (della vs azienda)",
	 "CO_ZIP" => "C.A.P. (della vs azienda)",
	 "CO_CITY" => "Città (della vs azienda)",
	 "CO_PROV" => "Provincia (della vs azienda)",
	 "CO_CC" => "Paese (della vs azienda)",
	 "CO_VATNUMBER" => "Numero della Partita IVA (della vs azienda)",
	 "CO_TAXCODE" => "Codice Fiscale (della vs azienda)",
	 "CO_PHONE" => "Telefono principale (della vs azienda)",
	 "CO_PHONE2" => "Telefono secondario (della vs azienda)",
	 "CO_FAX" => "Fax principale (della vs azienda)",
	 "CO_FAX2" => "Fax secondario (della vs azienda)",
	 "CO_CELL" => "Cellulare principale (della vs azienda)",
	 "CO_CELL2" => "Cellulare secondario (della vs azienda)",
	 "CO_EMAIL" => "Email principale (della vs azienda)",
	 "CO_EMAIL2" => "Email secondaria (della vs azienda)",
	 "CO_WEBSITE" => "Sito web (della vs azienda)",

	 "TOT_AMOUNT" => "Totale importi"
	);
 return array('info'=>$info, 'keys'=>$keys);
}

function gnujikocontentparser_allvendorcontracts_parse($_CONTENTS, $_PARAMS, $sessid, $shellid)
{
 global $_BASE_PATH, $_ABSOLUTE_URL, $_COMPANY_PROFILE;
 include_once($_BASE_PATH."include/company-profile.php");
 $_BANKS = $_COMPANY_PROFILE['banks'];
 $_DECIMALS = $_COMPANY_PROFILE['accounting']['decimals_pricing'];

 $contents = $_CONTENTS;

 $keys = array(
	 "{DOC_PG}",
	 "{DATE_FROM}",
	 "{DATE_TO}",
	 
	 "{COBNK_NAME}",
	 "{COBNK_IBAN}",
	 "{CB_ABI}",
	 "{CB_CAB}",
	 "{CB_CIN}",
	 "{CB_CC}",

	 "{COMPANY-NAME}", "{CO_ADDR}", "{CO_ZIP}", "{CO_CITY}", "{CO_PROV}", "{CO_CC}", "{CO_VATNUMBER}", "{CO_TAXCODE}", "{CO_PHONE}", "{CO_PHONE2}", 
	 "{CO_FAX}", "{CO_FAX2}", "{CO_CELL}", "{CO_CELL2}", "{CO_EMAIL}", "{CO_EMAIL2}", "{CO_WEBSITE}",

	 "{TOT_AMOUNT}"
	);

/* MAKE QUERY */
$today = time();
$cmd = $_PARAMS['cmd'];

$_DATE_FROM = ($_PARAMS['from'] && ($_PARAMS['from'] != "0000-00-00") && ($_PARAMS['from'] != "1970-01-01")) ? date('d/m/Y',strtotime($_PARAMS['from'])) : "sempre";
$_DATE_TO = ($_PARAMS['to'] && ($_PARAMS['to'] != "0000-00-00") && ($_PARAMS['to'] != "1970-01-01")) ? date('d/m/Y',strtotime($_PARAMS['to'])) : "";

$_RET = GShell($cmd,$sessid,$shellid);

/*$_TOT_AMOUNT = 0;
for($c=0; $c < count($_RET['outarr']['items']); $c++)
 $_TOT_AMOUNT+= $_RET['outarr']['items'][$c]['amount'];*/

$_TOT_AMOUNT = $_PARAMS['amount']; 

/* Get company bank info */
$CObankName = $_BANKS[0] ? $_BANKS[0]['name'] : "&nbsp;";
$CObankIBAN = $_BANKS[0] ? $_BANKS[0]['iban'] : "&nbsp;";
$CObankABI = $_BANKS[0] ? $_BANKS[0]['abi'] : "&nbsp;";
$CObankCAB = $_BANKS[0] ? $_BANKS[0]['cab'] : "&nbsp;";
$CObankCIN = $_BANKS[0] ? $_BANKS[0]['cin'] : "&nbsp;";
$CObankCC = $_BANKS[0] ? $_BANKS[0]['cc'] : "&nbsp;";

if($CObankIBAN && (strlen($CObankIBAN) >= 27))
 $CObankIBAN = substr($CObankIBAN,0,4)." ".substr($CObankIBAN,4,4)." ".substr($CObankIBAN,8,4)." ".substr($CObankIBAN,12,4)." ".substr($CObankIBAN,16,4)." ".substr($CObankIBAN,20,4)." ".substr($CObankIBAN,24);


$vals = array(
	 $_REQUEST['page'] ? $_REQUEST['page'] : 1,
	 $_DATE_FROM,
	 $_DATE_TO,

	 $CObankName, $CObankIBAN, $CObankABI, $CObankCAB, $CObankCIN, $CObankCC,
	 
	 /* COMPANY INFO */
	 $_COMPANY_PROFILE['name'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['address'] ? $_COMPANY_PROFILE['addresses']['headquarters']['address'] : $_COMPANY_PROFILE['addresses']['registered_office']['address'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['zip'] ? $_COMPANY_PROFILE['addresses']['headquarters']['zip'] : $_COMPANY_PROFILE['addresses']['registered_office']['zip'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['city'] ? $_COMPANY_PROFILE['addresses']['headquarters']['city'] : $_COMPANY_PROFILE['addresses']['registered_office']['city'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['prov'] ? $_COMPANY_PROFILE['addresses']['headquarters']['prov'] : $_COMPANY_PROFILE['addresses']['registered_office']['prov'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['country'] ? $_COMPANY_PROFILE['addresses']['headquarters']['country'] : $_COMPANY_PROFILE['addresses']['registered_office']['country'],

	 $_COMPANY_PROFILE['vatnumber'], $_COMPANY_PROFILE['taxcode'], 

	 $_COMPANY_PROFILE['addresses']['headquarters']['phones'][0]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['phones'][0]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['phones'][0]['number'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['phones'][1]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['phones'][1]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['phones'][1]['number'],

	 $_COMPANY_PROFILE['addresses']['headquarters']['fax'][0]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['fax'][0]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['fax'][0]['number'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['fax'][1]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['fax'][1]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['fax'][1]['number'],

	 $_COMPANY_PROFILE['addresses']['headquarters']['cells'][0]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['cells'][0]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['cells'][0]['number'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['cells'][1]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['cells'][1]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['cells'][1]['number'],

	 $_COMPANY_PROFILE['addresses']['headquarters']['emails'][0]['email'] ? $_COMPANY_PROFILE['addresses']['headquarters']['emails'][0]['email'] : $_COMPANY_PROFILE['addresses']['registered_office']['emails'][0]['email'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['emails'][1]['email'] ? $_COMPANY_PROFILE['addresses']['headquarters']['emails'][1]['email'] : $_COMPANY_PROFILE['addresses']['registered_office']['emails'][1]['email'],

	 $_COMPANY_PROFILE['website'],

	 number_format($_TOT_AMOUNT,2,",",".")
	);

for($c=0; $c < count($keys); $c++)
{
 $key = $keys[$c];
 $val = $vals[$c];

 while($p = stripos($contents,$key,$p))
 {
  $chunk = strtoupper(substr($contents,$p-4,4));
  if(($chunk == "ID='") || ($chunk == 'ID="'))
  {// is inside on html tag //
   $endTag = stripos($contents,">",$p+strlen($key));
   $contents = substr($contents,0,$endTag+1).$val.substr($contents,$endTag+1);
   $p = $endTag+strlen($val);
  }
  else
  {
   $contents = substr($contents,0,$p).$val.substr($contents,$p+strlen($key));
   $p+= strlen($val);
  }
 }

}

$_CONTENTS = $contents;
return $contents;
}


