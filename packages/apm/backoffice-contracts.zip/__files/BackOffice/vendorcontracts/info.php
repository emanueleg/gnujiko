<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 19-11-2013
 #PACKAGE: backoffice-contracts 
 #DESCRIPTION: Vendor contract info
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CONTRACT_INFO, $_TITLE;
$_BASE_PATH = "../../";
include_once($_BASE_PATH."var/templates/standardapp/index.php");
//-------------------------------------------------------------------------------------------------------------------//
$app = new StandardApp();
//-------------------------------------------------------------------------------------------------------------------//
include_once($_BASE_PATH."var/objects/htmlgutility/menu.php");
include_once($_BASE_PATH."var/objects/gcal/index.php");
include_once($_BASE_PATH."var/objects/editsearch/index.php");
include_once($_BASE_PATH."var/objects/fckeditor/index.php");
include_once($_BASE_PATH."var/objects/gmutable/index.php");
include_once($_BASE_PATH."var/objects/dynrubricaedit/index.php");
include_once($_BASE_PATH."include/i18n.php");
LoadLanguage("calendar");
?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL.$app->Config['basepath']; ?>common.css" type="text/css" />
<?php
//-------------------------------------------------------------------------------------------------------------------//
$app->StartPage();
$_AP = "vendorcontracts";
//-------------------------------------------------------------------------------------------------------------------//
$ret = GShell("dynarc item-info -ap `".$_AP."` -id `".$_REQUEST['id']."` -extget `vendorcontractinfo,schedule`");
if(!$ret['error'])
{
 $_CONTRACT_INFO = $ret['outarr'];
}
//-------------------------------------------------------------------------------------------------------------------//
$app->StartHeader();
$_TITLE = $_CONTRACT_INFO['name'] ? $_CONTRACT_INFO['name'] : "Nuovo contratto";
?>
<span class='gray24'><?php echo $_TITLE; ?></span></td>

<td align='right' width='150'>
	<input type='button' class='button-blue' value="Salva" onclick="SaveContract()"/>
	<input type='button' class='button-gray' value="Chiudi" onclick="abort()"/>
<?php
$app->EndHeader();
//-------------------------------------------------------------------------------------------------------------------//
$app->StartContent();
//-------------------------------------------------------------------------------------------------------------------//
// controlla se ci sono dei rinnovi scaduti non pagati //
if($_CONTRACT_INFO['freq'])
{
 $ret = GShell("schedule list -from always -to today --only-expired -ap ".$_AP." -id ".$_CONTRACT_INFO['id']);
 if(!$ret['error'] && isset($ret['outarr']['results']) && count($ret['outarr']['results']))
 {
  $list = $ret['outarr']['results'];
  $app->showAlert("Ci sono delle fatture scadute non pagate","","margin-bottom:0px");
  echo "<table width='100%' class='orangetable' width='100' cellspacing='0' cellpadding='0' border='0'>";
  for($c=0; $c < count($list); $c++)
  {
   echo "<tr><td style='height:40px'>Scadenza: ".date('d/m/Y',strtotime($list[$c]['expiry_date']))."</td>";
   echo "<td>Importo: ".number_format($list[$c]['amount'],2,",",".")."</td>";
   echo "<td align='right'><input type='button' class='button-blue' value='Salda' onclick='Pay(\"".$list[$c]['expiry_date']."\",\"".$list[$c]['amount']."\")'/></td></tr>";
  }
  echo "</table>";
 //echo "<br/><input type='button' class='button-red' value='Invia sollecito di pagamento'/><br/><br/>";
 }
}
?>
<br/>
<br/>
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="formtable">
<tr><th colspan='3'>Dettagli contratto</th></tr>
<tr><td align='right'>Cliente</td>	<td><input type="text" class="flatedit" style="width:380px" placeholder="Digita il nome di un cliente" id="subject" value="<?php echo $_CONTRACT_INFO['subject_name']; ?>"/></td>
	<td align='right'>Data registrazione <input type='text' class='flatedit' id='ctime' style='width:70px' placeholder="dd/mm/yyyy" value="<?php echo date('d/m/Y',$_CONTRACT_INFO['ctime']); ?>"/></td></tr>
<tr><td align='right'>Riferimento</td> <td><input type='text' class='flatedit' style='width:380px' placeholder="Digita un titolo" id='refer' value="<?php echo $_CONTRACT_INFO['name']; ?>"/></td>
	<td align='right'>Cadenza <select id='freq' style='width:140px'><?php
	 $options = array("12"=>"annuale", "6"=>"semestrale", "4"=>"quadrimestrale", "3"=>"trimestrale", "2"=>"bimestrale", "1"=>"mensile");
	 while(list($k,$v)=each($options))
	 {
	  echo "<option value='".$k."'".($k == $_CONTRACT_INFO['freq'] ? " selected='selected'>" : ">").$v."</option>";
	 }
	?></select></td></tr>
<tr><td align='right'>Fornitore</td>	<td><input type='text' class='flatedit' style='width:380px' placeholder="Digita il nome del fornitore" id="vendor" value="<?php echo $_CONTRACT_INFO['vendor_name']; ?>"/></td>
	<td align='right'>Importo <input type='text' class='flatedit' id='amount' style='width:70px' value="<?php echo number_format($_CONTRACT_INFO['amount'],2,',','.'); ?>" onchange="this.value=formatCurrency(parseCurrency(this.value))"/></td></tr>

<tr><td align='right'>Categoria</td>
	<td><select id='catid' style='width:190px'><?php
		$ret = GShell("dynarc cat-list -ap `".$_AP."`",$_REQUEST['sessid'],$_REQUEST['shellid']);
		$list = $ret['outarr'];
		$intoTree = false;
		for($c=0; $c < count($list); $c++)
		 echo "<option value='".$list[$c]['id']."'".(($list[$c]['id'] == $_CONTRACT_INFO['cat_id']) ? " selected='selected'>" : ">")
			.$list[$c]['name']."</option>";
		?></select> <img src="<?php echo $_ABSOLUTE_URL.$app->Config['basepath']; ?>../img/select-cat.png" style="cursor:pointer" onclick="selectCat()"/> &nbsp;&nbsp;
		Data termine <input type='text' class='flatedit' id='finish_date' style='width:70px' value="<?php echo ($_CONTRACT_INFO['finish_date'] != '0000-00-00') ? date('d/m/Y',strtotime($_CONTRACT_INFO['finish_date'])) : ''; ?>"/></td>
	<td align='right'>Prossima scadenza <input type='text' class='flatedit' id='next_expiry' style='width:70px' placeholder="dd/mm/yyyy" value="<?php echo ($_CONTRACT_INFO['next_expiry'] != '0000-00-00') ? date('d/m/Y',strtotime($_CONTRACT_INFO['next_expiry'])) : ''; ?>"/></td></tr>
<tr><td colspan='3'>Descrizione del contratto / Annotazioni</td></tr>
<tr><td colspan='3'><textarea id="description" style="width:100%;height:350px"><?php echo $_CONTRACT_INFO['desc']; ?></textarea></td></tr>
</table>

<div style="border-top:1px solid #d8d8d8;padding-top:20px;padding-bottom:20px;">
 <input type="button" class="button-blue" value="Salva e chiudi" onclick="SaveContract(true)"/>
 <input type="button" class="button-red" value="Elimina ordine" style="float:right" onclick="DeleteContract()"/>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$app->EndContent();
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var oFCKeditor = null;
var AP = "<?php echo $_AP; ?>";
var ID = "<?php echo $_CONTRACT_INFO['id']; ?>";

function desktopOnLoad()
{
 var sSkinPath = "<?php echo $_BASE_PATH; ?>../../var/objects/fckeditor/editor/skins/office2003/";
 /* FCKEDITOR 1 */
 oFCKeditor = new FCKeditor('description') ;
 oFCKeditor.ToolbarSet = "Optimized";
 oFCKeditor.BasePath	= "<?php echo $_BASE_PATH; ?>var/objects/fckeditor/";
 oFCKeditor.Config['SkinPath'] = sSkinPath ;
 oFCKeditor.Config['PreloadImages'] =
				sSkinPath + 'images/toolbar.start.gif' + ';' +
				sSkinPath + 'images/toolbar.end.gif' + ';' +
				sSkinPath + 'images/toolbar.bg.gif' + ';' +
				sSkinPath + 'images/toolbar.buttonarrow.gif' ;
 oFCKeditor.Height = 350;
 oFCKeditor.ReplaceTextarea();

 /* SUBJECT */ 
 RubricaEdit = new DynRubricaEdit(document.getElementById('subject'), "", "rubrica");

 /* VENDOR */
 RubricaEdit = new DynRubricaEdit(document.getElementById('vendor'), "VENDORS", "rubrica");

}

function SaveContract(saveAndClose, saveAndReload, setStatus)
{
 var subjectId = document.getElementById('subject').data ? document.getElementById('subject').data['id'] : 0;
 var subjectName = document.getElementById('subject').value;

 var vendorId = document.getElementById('vendor').data ? document.getElementById('vendor').data['id'] : 0;
 var vendorName = document.getElementById('vendor').value;

 var ctime = strdatetime_to_iso(document.getElementById('ctime').value).substr(0,10);
 var nextExpiry = document.getElementById('next_expiry').value ? strdatetime_to_iso(document.getElementById('next_expiry').value).substr(0,10) : "";
 var finishDate = document.getElementById('finish_date').value ? strdatetime_to_iso(document.getElementById('finish_date').value).substr(0,10) : "";
 var amount = parseCurrency(document.getElementById('amount').value);
 var freq = document.getElementById('freq').value;
 var catId = document.getElementById('catid').value;

 var title = document.getElementById('refer').value;
 var oEditor = FCKeditorAPI.GetInstance('description');
 var description = oEditor.GetXHTML();

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(saveAndClose)
	  document.location.href = "../vendorcontracts.php";
	 else if(saveAndReload)
	  document.location.reload();
	 else
	  alert("Il contratto è stato salvato correttamente.");
	}

 /* SAVE CONTRACT */
 sh.sendCommand("dynarc edit-item -ap `"+AP+"` -id `"+ID+"` -name `"+title+"` -cat `"+catId+"` -desc `"+description+"` -ctime `"+ctime+"` -extset `vendorcontractinfo.subjectid='"+subjectId+"',subject='''"+subjectName+"''',vendorid='"+vendorId+"',vendor='''"+vendorName+"''',amount='"+amount+"',schedule.finish-date='"+finishDate+"',next-expiry='"+nextExpiry+"',freq='"+freq+"'`");
}

function abort()
{
 document.location.href = "../vendorcontracts.php";
}

function DeleteContract()
{
 if(!confirm("Sei sicuro di voler eliminare questo contratto?"))
  return;
 var sh = new GShell();
 sh.OnError = function(msg){alert(msg);}
 sh.OnOutput = function(){document.location.href = "../vendorcontracts.php";}
 sh.sendCommand("dynarc delete-item -ap `"+AP+"` -id `"+ID+"`");
}

function selectCat()
{
 var sel = document.getElementById('catid');

 var sh = new GShell();
 sh.OnOutput = function(o,catId){
	 if(!catId) return;
	 while(sel.options.length)
	  sel.removeChild(sel.options[0]);

	 var sh2 = new GShell();
	 sh2.OnOutput = function(o,a){
		 if(!a) return;
		 for(var c=0; c < a.length; c++)
		 {
		  var opt = document.createElement('OPTION');
		  opt.value = a[c]['id'];
		  opt.innerHTML = a[c]['name'];
		  sel.appendChild(opt);
		 }
		 sel.value = catId;
		}

	 sh2.sendCommand("dynarc cat-list -ap `"+AP+"`");
	}

 sh.sendCommand("gframe -f dynarc.categorySelect -params `ap="+AP+"`");
}

function Pay(expiry, amount)
{
 var amount = amount ? parseFloat(amount) : 0;
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(a)
	  document.location.reload();
	}
 sh.sendCommand("gframe -f schedule/add -title `Salda fattura` -params `ap="+AP+"&id="+ID+"&expiry="+expiry+"&amount="+amount+"`");
}
</script>

<?php
//-------------------------------------------------------------------------------------------------------------------//
$app->Finish();
//-------------------------------------------------------------------------------------------------------------------//

