<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 19-11-2013
 #PACKAGE: backoffice-contracts
 #DESCRIPTION: Vendor contracts configuration file
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

$_APPLICATION_CONFIG = array(
	"appname"=>"BackOffice",
	"basepath"=>"BackOffice/vendorcontracts/",
	"mainmenu"=>array(
		 0 => array("title"=>"Dettagli", "url"=>"info.php?id=".$_REQUEST['id']),
		 1 => array("title"=>"Storico pagamenti", "url"=>"history.php?id=".$_REQUEST['id']),
		),
);
