<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 21-11-2013
 #PACKAGE: backoffice-contracts 
 #DESCRIPTION: Vendor contract payment history
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CONTRACT_INFO, $_TITLE;
$_BASE_PATH = "../../";
include_once($_BASE_PATH."var/templates/standardapp/index.php");
//-------------------------------------------------------------------------------------------------------------------//
$app = new StandardApp();
//-------------------------------------------------------------------------------------------------------------------//
include_once($_BASE_PATH."var/objects/htmlgutility/menu.php");
include_once($_BASE_PATH."var/objects/gcal/index.php");
include_once($_BASE_PATH."var/objects/editsearch/index.php");
include_once($_BASE_PATH."var/objects/gmutable/index.php");
include_once($_BASE_PATH."var/objects/dynrubricaedit/index.php");
include_once($_BASE_PATH."include/i18n.php");
LoadLanguage("calendar");
?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL.$app->Config['basepath']; ?>common.css" type="text/css" />
<?php
//-------------------------------------------------------------------------------------------------------------------//
$app->StartPage();
$_AP = "vendorcontracts";
//-------------------------------------------------------------------------------------------------------------------//
$ret = GShell("dynarc item-info -ap `".$_AP."` -id `".$_REQUEST['id']."` -extget `vendorcontractinfo,schedule`");
if(!$ret['error'])
{
 $_CONTRACT_INFO = $ret['outarr'];
}
//-------------------------------------------------------------------------------------------------------------------//
$app->StartHeader();
$_TITLE = $_CONTRACT_INFO['name'];
?>
<span class='gray24'><?php echo $_TITLE; ?></span></td>

<td align='right' width='150'>
	<input type='button' class='button-blue' value="Salva" onclick="SaveContract()"/>
	<input type='button' class='button-gray' value="Chiudi" onclick="abort()"/>
<?php
$app->EndHeader();
//-------------------------------------------------------------------------------------------------------------------//
$app->StartContent();
//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="bluepanel" style="margin-top:20px;margin-bottom:20px">
 <div class="title">Storico pagamenti</div>
 <div class="contents">
  <div class="gmutable" style="height:350px;border:0px;padding:0px;margin:0px">
   <table id='doctable' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
    <tr><th width='40' style='text-align:center'><input type="checkbox" onchange="tb.selectAll(this.checked)"/></th>
     <th width='100' id='expiry_date' editable='true' format='date'><small>Data scadenza</small></th>
	 <th width='150' id='payment_date' editable='true' format='date'><small>Data pagamento</small></th>
	 <th width='150' id='refer' editable='true'>Rif. ordine</th>
	 <th id='notes' editable='true'>Note</th>
	 <th style='text-align:right;padding-right:10px;' width='70' id='amount' editable='true' format='currency'>Importo</th></tr>
	<?php
	$ret = GShell("schedule history -ap vendorcontracts -id ".$_CONTRACT_INFO['id']);
	$list = $ret['outarr']['results'];
	$db = new AlpaDatabase();
	for($c=0; $c < count($list); $c++)
	{
	 $itm = $list[$c];
	 echo "<tr id='".$itm['id']."' paymentmethod='".$itm['payment_method']."'><td align='center'><input type='checkbox'/></td>";
	 echo "<td><span class='graybold'>".date('d/m/Y',strtotime($itm['expiry_date']))."</span></td>";
	 echo "<td><span class='graybold'>".date('d/m/Y',strtotime($itm['payment_date']))."</span></td>";
	 /*if($itm['payment_method'])
	 {
	  $db->RunQuery("SELECT name FROM dynarc_paymentmode_items WHERE id='".$itm['payment_method']."'");
	  $db->Read();
	 }
	 echo "<td><span class='graybold'>".($itm['payment_method'] ? $db->record['name'] : "")."</span></td>";*/
	 echo "<td><span class='graybold'>".$itm['refer']."</span></td>";
	 echo "<td><span class='graybold'>".$itm['notes']."</span></td>";
	 echo "<td align='right' style='padding-right:10px'><span class='graybold'>".number_format($itm['amount'],2,",",".")."</span></td></tr>";
	}
	$db->Close();
	?>
   </table>
  </div>
 </div>
</div>
<input type='button' class='button-blue' value='Aggiungi' onclick="NewRow()"/> 
<input type='button' class='button-red' value="Elimina selezionate" onclick="DeleteSelectedRows()"/>


<?php
//-------------------------------------------------------------------------------------------------------------------//
$app->EndContent();
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";
var ID = "<?php echo $_CONTRACT_INFO['id']; ?>";
var tb = null;

function desktopOnLoad()
{
/* GMUTABLE */
 tb = new GMUTable(document.getElementById('doctable'));
 /*tb.FieldByName['payment_method'].enableSearch("dynarc search -ap paymentmode -field name `", "` -limit 5 --order-by `name ASC`", "name","name","items",true);*/
 tb.OnBeforeAddRow = function(r){
	 r.setAttribute('paymentmethod','0');
	 r.cells[0].innerHTML = "<input type='checkbox'/ >";
	 r.cells[1].innerHTML = "<span class='graybold'></span>";
	 r.cells[2].innerHTML = "<span class='graybold'></span>";
	 r.cells[3].innerHTML = "<span class='graybold'></span>";
	 r.cells[4].innerHTML = "<span class='graybold'></span>";
	 r.cells[5].innerHTML = "<span class='graybold'><?php echo number_format($_CONTRACT_INFO['amount'],2,',','.'); ?></span>";
	 r.cells[5].style.textAlign='right';
	 r.cells[5].style.fontWeight='bold';
	 r.cells[5].style.paddingRight='10px';
	 this.NEW_ROWS.push(r);
	}

 tb.OnCellEdit = function(r,cell,value,data){
	 switch(cell.tag)
	 {
	  case 'payment_method' : r.setAttribute('paymentmethod', (value && data) ? data['id'] : '0'); break;
	 }

	 if(r.id && (this.UPDATED_ROWS.indexOf(r) < 0))
	  this.UPDATED_ROWS.push(r);
	}

 tb.OnDeleteRow = function(r){
	 if(r.id)
	 {
	  if(this.UPDATED_ROWS.indexOf(r) >= 0)
	   this.UPDATED_ROWS.splice(this.UPDATED_ROWS.indexOf(r),1);
	  this.DELETED_ROWS.push(r);
	 }
	 else
	  this.NEW_ROWS.splice(this.NEW_ROWS.indexOf(r),1);
	}


 tb.NEW_ROWS = new Array();
 tb.UPDATED_ROWS = new Array();
 tb.DELETED_ROWS = new Array();
}

function NewRow()
{
 r = tb.AddRow();
 r.edit();
}

function DeleteSelectedRows()
{
 var list = tb.GetSelectedRows();
 if(!list.length)
  return alert("Nessuna riga è stata selezionata");

 for(var c=0; c < list.length; c++)
  list[c].remove();
}


function SaveContract(saveAndClose, saveAndReload)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnFinish = function(o,a){
	 if(saveAndClose)
	  document.location.href = "../orders.php";
	 else if(saveAndReload)
	  document.location.reload();
	 else
	  alert("Il documento è stato salvato correttamente.");
	}

 for(var c=0; c < tb.NEW_ROWS.length; c++)
 {
  var r = tb.NEW_ROWS[c];
  sh.sendCommand("schedule new -ap "+AP+" -id "+ID+" -expiry '"+strdatetime_to_iso(r.cell['expiry_date'].getValue()).substr(0,10)+"' -payment '"+strdatetime_to_iso(r.cell['payment_date'].getValue()).substr(0,10)+"' -refer `"+r.cell['refer'].getValue()+"` -notes `"+r.cell['notes'].getValue()+"` -amount '"+parseCurrency(r.cell['amount'].getValue())+"'");
 }
 for(var c=0; c < tb.UPDATED_ROWS.length; c++)
 {
  var r = tb.UPDATED_ROWS[c];
  sh.sendCommand("schedule edit -ap "+AP+" -id "+r.id+" -expiry '"+strdatetime_to_iso(r.cell['expiry_date'].getValue()).substr(0,10)+"' -payment '"+strdatetime_to_iso(r.cell['payment_date'].getValue()).substr(0,10)+"' -refer `"+r.cell['refer'].getValue()+"` -notes `"+r.cell['notes'].getValue()+"` -amount '"+parseCurrency(r.cell['amount'].getValue())+"'");
 }
 for(var c=0; c < tb.DELETED_ROWS.length; c++)
 {
  var r = tb.DELETED_ROWS[c];
  sh.sendCommand("schedule delete -ap "+AP+" -id "+r.id);
 }
}

function abort()
{
 document.location.href = "../vendorcontracts.php";
}
</script>

<?php
//-------------------------------------------------------------------------------------------------------------------//
$app->Finish();
//-------------------------------------------------------------------------------------------------------------------//

