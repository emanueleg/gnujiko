<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 19-11-2013
 #PACKAGE: backoffice-contracts
 #DESCRIPTION: BackOffice - Contracts
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_AP;
$_BASE_PATH = "../";
include_once($_BASE_PATH."var/templates/standardapp/index.php");
//-------------------------------------------------------------------------------------------------------------------//
$app = new StandardApp();
//-------------------------------------------------------------------------------------------------------------------//
include_once($_BASE_PATH."var/objects/htmlgutility/menu.php");
include_once($_BASE_PATH."var/objects/gcal/index.php");
include_once($_BASE_PATH."var/objects/editsearch/index.php");
include_once($_BASE_PATH."include/i18n.php");
LoadLanguage("calendar");
?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL.$app->Config['basepath']; ?>common.css" type="text/css" />
<?php
//-------------------------------------------------------------------------------------------------------------------//
$app->StartPage();
//-------------------------------------------------------------------------------------------------------------------//
$_AP = "vendorcontracts";
if(!$_REQUEST['show'])
 $_REQUEST['show'] = "all";

switch($_REQUEST['show'])
{
 case 'expired' : include($_BASE_PATH.$app->Config['basepath']."vendorcontracts-expired.php"); break;
 case 'expiring' : include($_BASE_PATH.$app->Config['basepath']."vendorcontracts-expiring.php"); break;
 case 'finish' : include($_BASE_PATH.$app->Config['basepath']."vendorcontracts-finish.php"); break;
 default : include($_BASE_PATH.$app->Config['basepath']."vendorcontracts-all.php"); break;
}
//-------------------------------------------------------------------------------------------------------------------//
$app->Finish();
//-------------------------------------------------------------------------------------------------------------------//

