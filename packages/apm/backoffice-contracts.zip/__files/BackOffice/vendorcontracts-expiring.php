<?php

if(!$_REQUEST['view'])
 $_REQUEST['view'] = "default";
if(!$_REQUEST['from'] || ($_REQUEST['from'] == "0000-00-00"))
{
 // this month
 $_REQUEST['from'] = date("Y-m")."-01";
 $_REQUEST['to'] = date("Y-m-d",strtotime("+1 month",strtotime($_REQUEST['from'])));
}
if(!$_REQUEST['rpp']) $_REQUEST['rpp'] = 10;
if(!$_REQUEST['pg']) $_REQUEST['pg'] = 1;

$dateFrom = strtotime($_REQUEST['from']);
$dateTo = strtotime($_REQUEST['to']);

if(!$dateFrom)
 $dateFromStr = "da sempre";
else
 $dateFromStr = date('d',$dateFrom).'/'.strtolower(i18n('MONTHABB-'.date('n',$dateFrom))).'/'.date('Y',$dateFrom);
$dateToStr = date('d',$dateTo).'/'.strtolower(i18n('MONTHABB-'.date('n',$dateTo))).'/'.date('Y',$dateTo);

$_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "next_expiry";
$_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "ASC";

$cmd = "schedule list -ap vendorcontracts -from '".date('Y-m-d',$dateFrom)."' -to '".date('Y-m-d',$dateTo)."' -where 'finish_date=0000-00-00'";
if($_REQUEST['search'])
{
 if($_REQUEST['subjid'])
  $cmd.= " -subjectid '".$_REQUEST['subjid']."'";
 else
  $cmd.= " -subject '".$_REQUEST['search']."'";
}
$cmd.= " --order-by '".$_ORDER_BY." ".$_ORDER_METHOD."'";

$ret = GShell($cmd);
$resCount = $ret['outarr']['count'];
$list = $ret['outarr']['results'];

$resultsFrom = $_REQUEST['rpp']*($_REQUEST['pg']-1); /* pg.1=0, pg.2=10, pg.3=20, ... */
$resultsTo = $resultsFrom+$_REQUEST['rpp'];
if($resultsTo > $resCount) $resultsTo = $resCount;
//-------------------------------------------------------------------------------------------------------------------//
$app->StartHeader();
?>
<span class='gray24'>Contratti fornitore</span></td>
<td><span class="smalltext">Filtra per cliente:</span> <input type='text' class='edit' id='search' style='width:200px' value="<?php echo $_REQUEST['search']; ?>" subjid="<?php echo $_REQUEST['subjid']; ?>"/></td>
<td align='right'>&nbsp;
	<input type="button" id="datefrom" class="dropdown-gray" value="<?php echo $dateFromStr; ?>" date="<?php echo $dateFrom ? date('Y-m-d',$dateFrom) : '0000-00-00'; ?>" onclick="showCal(this)"/> 
	<span class='at12'>al</span> 
	<input type="button" id="dateto" class="dropdown-gray" value="<?php echo $dateToStr; ?>" date="<?php echo date('Y-m-d',$dateTo); ?>" onclick="showCal(this,true)"/>

<?php
$app->EndHeader();
//-------------------------------------------------------------------------------------------------------------------//
$app->StartContent();

$show = array("all"=>"Tutti i contratti", "expired"=>"Contratti scaduti", "expiring"=>"In scadenza", "finish"=>"Terminati");

?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
<tr>
	<td><ul class='toggles'>
		 <?php
		  $idx = 0;
		  while(list($k,$v)=each($show))
		  {
		   $class = "";
		   if($idx == 0)
			$class = "first";
		   else if($idx == (count($show)-1))
			$class = "last";
		   if($k == $_REQUEST['show'])
			$class.= " selected";
		   echo "<li".($class ? " class='".$class."'" : "")." onclick=\"setShow('".$k."')\">".$v."</li>";
		   $idx++;
		  }
		 ?>
		 <!--<li class="first ">Mostra Tutto</li>
		 <li>Fatture scadute</li>
		 <li class="last">In scadenza</li> -->
		</ul></td>
	<td align="right"><span class="smalltext">Vista:</span>
		<input type="button" id="view-button" class="dropdown-gray" value="<?php echo ($_REQUEST['view'] == 'group') ? 'Raggruppata' : 'Predefinita'; ?>"/>
		<ul class="submenu" id="view-menu">
		 <li onclick="setView('default')">Predefinita</li>
		 <li onclick="setView('group')">Raggruppa per cliente</li>
		</ul>
	</td>
	<!--<td>&nbsp;&nbsp; <span class='at12'><?php echo ($resultsFrom+1)."-".$resultsTo." di ".$resCount; ?></span> &nbsp;&nbsp;</td>
	<td width='90'>
	 <ul class="toggles">
	  <li class="first disabled"><strong><</strong></li>
	  <li class="last selected"><strong>></strong></li>
	 </ul>
	</td> -->
</tr>
</table>

<table width="100%" cellspacing="0" cellpadding="0" border="0" class="flat-table" style="margin-top:20px" id="contractlist">
<tr><th sortable='true' field='subject_name'>Cliente</th>
	<!-- <th style='width:20px'>&nbsp;</th> -->
	<th sortable='true' field='name'>Riferimento</th>
	<th sortable='true' field='next_expiry'>Scadenza</th>
	<th sortable='true' field='amount' style='text-align:right'>Importo</th></tr>
<?php
$totPaid=0;
$totUnpaid=0;
$totExpired=0;
$totAmount = 0;
$totCustomers = 0;
$itemsBySubject = array();
if($_REQUEST['view'] == "group") // GROUPED VIEW
{
 for($c=0; $c < count($list); $c++)
 {
  $item = $list[$c];
  if(!$itemsBySubject[$item['subject_id']])
  {
   $itemsBySubject[$item['subject_id']] = array();
   $totCustomers++;
  }
  $itemsBySubject[$item['subject_id']][] = $list[$c];
  if($item['amount'])
   $totAmount+= $item['amount'];
  if($item['paid'])
   $totPaid+= $item['amount'];
  else
   $totUnpaid+= $item['amount'];
  if($item['expired'] && !$item['paid'])
   $totExpired+= $item['amount'];
 }
 reset($itemsBySubject);
 while(list($subjId,$res)=each($itemsBySubject))
 {
  if(count($res) == 1)
  {
   $item = $res[0];
   $expire = strtotime($item['expiry_date']);
   $color = $item['paid'] ? "green" : ($expire < time() ? "#b50000" : "#222222");
   $alt = $item['paid'] ? "pagata il ".date('d/m/Y',strtotime($item['payment_date'])) : "da pagare";
   echo "<tr><td>".$item['subject_name']."</td>";
   /*echo "<td><a href='#' onclick='showDocumentOptions(".$item['subject_id'].",this)'><img src='".$_ABSOLUTE_URL.$app->Config['basepath']."img/next-orange.png' style='border:0px'/></a></td>";*/
   echo "<td><a href='".$_ABSOLUTE_URL.$app->Config['basepath']."vendorcontracts/info.php?id=".$item['id']."'>".$item['name']."</a></td>";
   echo "<td style='color:".$color."' title='".$alt."'>".date('d/m/Y',$expire)."</td>";
   echo "<td align='right'>".number_format($item['amount'],2,',','.')." &euro;</td></tr>";
  }
  else
  {
   for($c=0; $c < count($res); $c++)
   {
	$item = $res[$c];
	$expire = strtotime($item['expiry_date']);
    $color = $item['paid'] ? "green" : ($expire < time() ? "#b50000" : "#222222");
    $alt = $item['paid'] ? "pagata il ".date('d/m/Y',strtotime($item['payment_date'])) : "da pagare";
	if($c == 0)
     echo "<tr><td rowspan='".count($res)."'>".$res[0]['subject_name']."</td>"; /*<td rowspan='".count($res)."'><a href='#' onclick='showDocumentOptions(".$res[0]['subject_id'].",this)'><img src='".$_ABSOLUTE_URL.$app->Config['basepath']."img/next-orange.png' style='border:0px'/></a></td>";*/
	else
	 echo "<tr>";
    echo "<td><a href='".$_ABSOLUTE_URL.$app->Config['basepath']."vendorcontracts/info.php?id=".$item['id']."'>".$item['name']."</a></td>";
    echo "<td style='color:".$color."' title='".$alt."'>".date('d/m/Y',$expire)."</td>";
    echo "<td align='right'>".number_format($item['amount'],2,',','.')." &euro;</td></tr>";
   }

  }
 }
}
else // DEFAULT VIEW
{
 for($c=0; $c < count($list); $c++)
 {
  $item = $list[$c];
  if(!$itemsBySubject[$item['subject_id']])
  {
   $itemsBySubject[$item['subject_id']] = array();
   $totCustomers++;
  }
  $itemsBySubject[$item['subject_id']][] = $item;

  $expire = strtotime($item['expiry_date']);
  $color = $item['paid'] ? "green" : ($expire < time() ? "#b50000" : "#222222");
  $alt = $item['paid'] ? "pagata il ".date('d/m/Y',strtotime($item['payment_date'])) : "da pagare";
  echo "<tr><td>".$item['subject_name']."</td>";
  /*echo "<td><a href='#' onclick='showDocumentOptions(".$item['subject_id'].",this)'><img src='".$_ABSOLUTE_URL.$app->Config['basepath']."img/next-orange.png' style='border:0px'/></a></td>";*/
  echo "<td><a href='".$_ABSOLUTE_URL.$app->Config['basepath']."vendorcontracts/info.php?id=".$item['id']."'>".$item['name']."</a></td>";
  echo "<td style='color:".$color."' title='".$alt."'>".date('d/m/Y',$expire)."</td>";
  echo "<td align='right'>".number_format($item['amount'],2,',','.')." &euro;</td></tr>";
  if($item['amount'])
   $totAmount+= $item['amount'];
  if($item['paid'])
   $totPaid+= $item['amount'];
  else
   $totUnpaid+= $item['amount'];
  if($item['expired'] && !$item['paid'])
   $totExpired+= $item['amount'];
 }
}
?>
</table>
<div class="totals-footer">
 <table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr><td rowspan='2' valign='middle'><input type='button' class='button-blue' value='Stampa' onclick='print()'/></td>
	  <td align='center'><span class='smalltext'>scadute</span></td>
	  <td align='center'><span class='smalltext'>pagate</span></td>
	  <td align='center'><span class='smalltext'>da pagare</span></td>
	  <td align='right'><span class='smalltext'>Totale importi</span></td></tr>
  <tr><td align='center'><span class='smalltext'><?php echo number_format($totExpired,2,',','.'); ?> &euro;</span></td>
	  <td align='center'><span class='smalltext'><?php echo number_format($totPaid,2,',','.'); ?> &euro;</span></td>
	  <td align='center' title="Restante da pagare, comprese quelle scadute"><span class='smalltext'><?php echo number_format($totUnpaid,2,',','.'); ?> &euro;</span></td>
	  <td align='right'><span class='bigtext'><b><?php echo number_format($totAmount,2,',','.'); ?> &euro;</b></span></td></tr>
 </table>
</div>

<div id='nuvcontainer' style="position:absolute;left:0px;top:0px;width:200px;display:block;visibility:hidden;">
 <div class='docopt-header'>&nbsp;</div>
  <div class='docopt-body'>
   <div class="docopt-item" style='border:0px'>
		<a href='#' id='nuv-print-btn'><img src="<?php echo $_ABSOLUTE_URL.$app->Config['basepath']; ?>img/print.png"/> Stampa</a></div>
   <div class="docopt-item">
		<a href='#' id='nuv-email-btn'><img src="<?php echo $_ABSOLUTE_URL.$app->Config['basepath']; ?>img/email.png"/> Invia per email</a></div>
  </div>
 <div class='docopt-footer'>&nbsp;</div>
</div>
<?php
$app->EndContent();
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var CHT = "<?php echo $_REQUEST['cht']; ?>";
var RVF = "<?php echo $_REQUEST['rvf']; ?>";
var RANGE = "<?php echo $_REQUEST['range']; ?>";
var RPP = <?php echo $_REQUEST['rpp']; ?>;
var VIEW = "<?php echo $_REQUEST['view']; ?>";
var SHOW = "<?php echo $_REQUEST['show']; ?>";
var SEARCH = "<?php echo $_REQUEST['search']; ?>";
var SUBJID = "<?php echo $_REQUEST['subjid']; ?>";
var SORTBY = "<?php echo $_ORDER_BY; ?>";
var SORTMETHOD = "<?php echo $_ORDER_METHOD; ?>";

var cal = null;
var ViewMenu = null;

function desktopOnLoad()
{
 cal = new GCal();
 ViewMenu = new GPopupMenu(document.getElementById('view-button'), document.getElementById('view-menu'));
 ViewMenu._options.correctX = 110;

 EditSearch.init(document.getElementById('search'),
	"dynarc item-find -ap `rubrica` -field name `","` -limit 10 --order-by 'name ASC'",
	"id","name","items",true);
 document.getElementById('search').onchange = function(){
	 if(this.value)
	 {
	  if(this.data)
	  {
	   SEARCH = this.value;
	   SUBJID = this.data.id;
	  }
	  else
	  {
	   SEARCH = this.value;
	   SUBJID = 0;
	  }
	 }
	 else
	 {
	  SEARCH = "";
	  SUBJID = 0;
	 }
	 reload();
	}
  document.addEventListener ? document.addEventListener("mouseup",hideDocumentOptions,false) : document.attachEvent("onmouseup",hideDocumentOptions);

 StandardApp.makeSortableTable(document.getElementById("contractlist"), SORTBY, SORTMETHOD).OnSort = function(field, method){
		SORTBY = field;
	    SORTMETHOD = method;
		reload();
	}

}

function setView(view)
{
 VIEW = view;
 reload();
}

function setShow(show)
{
 SHOW = show;
 switch(show)
 {
  case "expired" : {
	  var today = new Date();
	  document.getElementById("datefrom").setAttribute("date","0000-00-00");
	  document.getElementById("dateto").setAttribute("date",today.printf('Y-m-d'));
	} break;
  case "all" : case "expiring" : case "finish" : {
	  document.getElementById("datefrom").setAttribute("date","");
	  document.getElementById("dateto").setAttribute("date","");
	} break;
 }
 SORTBY = "";
 SORTMETHOD = "";
 SEARCH = "";
 SUBJID = 0;
 reload();
}

function showCal(inp, _reload)
{
 var date = new Date();

 if(inp.getAttribute('date') != "0000-00-00")
  date.setFromISO(inp.getAttribute('date'));

 cal.Show(inp, date);
 cal.OnChange = function(newdate){
	 inp.value = newdate.printf("d/M/Y").toLowerCase();
	 inp.setAttribute("date",newdate.printf("Y-m-d"));
	 if(_reload)
	  reload();
	}
}

function reload()
{
 var href = "vendorcontracts.php?show="+SHOW+"&rpp="+RPP+"&from="+document.getElementById("datefrom").getAttribute("date")+"&to="+document.getElementById("dateto").getAttribute("date")+"&view="+VIEW+"&search="+SEARCH+"&subjid="+SUBJID+"&sortby="+SORTBY+"&sortmethod="+SORTMETHOD;

 document.location.href = href;
}

function showDocumentOptions(id, obj)
{
 var pos = _getObjectPosition(obj);
 //pos['y']-= document.getElementById('itemlist-container').scrollTop;
 var nuv = document.getElementById('nuvcontainer');

 document.getElementById('nuv-print-btn').onclick = function(){print(id);}
 document.getElementById('nuv-email-btn').onclick = function(){sendmail(id);}

 nuv.style.left = pos['x'] + obj.offsetWidth;
 nuv.style.top = (pos['y'] + Math.floor(obj.offsetHeight/2)) - Math.floor(nuv.offsetHeight/2);
 nuv.style.visibility = "visible";
}

function hideDocumentOptions()
{
 if(document.getElementById('nuvcontainer'))
  document.getElementById('nuvcontainer').style.visibility = "hidden";
}

function print(subjId)
{
 var sh = new GShell();
 if(subjId)
  sh.sendCommand("dynarc item-info -ap rubrica -id '"+subjId+"' || gframe -f print.preview -params `modelap=printmodels&modelct=STATEMENTS&parser=statement&cmd=<?php echo $cmd; ?> -subject-id "+subjId+"` -title 'Estratto conto '+*.name");
 else
  sh.sendCommand("gframe -f print.preview -params `modelap=printmodels&modelct=VENDORCONTRACTS&parser=vendorcontracts&view="+VIEW+"&cmd=<?php echo $cmd; ?>` -title 'Scadenziario contratti vs fornitori'");
}

function sendmail(subjId)
{
 alert("Funzione da implementare");
}

function NewContract()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){document.location.href = "vendorcontracts/info.php?id="+a['id'];}
 sh.sendCommand("dynarc new-item -ap `<?php echo $_AP; ?>`");
}

</script>
<?php

