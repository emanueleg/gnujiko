<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$ret = GShell("dynarc item-info -ap printmodels -alias vendorcontracts_list",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 GShell("dynarc import -f tmp/mod-demo-lista-contratti-vs-fornitori.xml -ap `printmodels` -ct VENDORCONTRACTS",$_SESSION_ID,$_SHELL_ID);
