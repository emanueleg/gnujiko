<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new archive */
$_SHELL_OUT.= "Create new archive Contratti vs. fornitori...";
$ret = GShell("dynarc new-archive -name `Contratti vs. fornitori` -prefix vendorcontracts -group `backoffice` --default-cat-perms 664 --default-item-perms 664",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];

GShell("dynarc install-extension vendorcontractinfo -ap vendorcontracts",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc install-extension schedule -ap vendorcontracts",$_SESSION_ID,$_SHELL_ID);

GShell("dynarc new-cat -ap printmodels -name `Contratti vs fornit.` -tag VENDORCONTRACTS -pt BACKOFFICE -group `backoffice` -perms 664",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/mod-demo-scadenziario-contratti-vs-fornitori.xml -ap `printmodels` -ct VENDORCONTRACTS",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/mod-demo-lista-contratti-vs-fornitori.xml -ap `printmodels` -ct VENDORCONTRACTS",$_SESSION_ID,$_SHELL_ID);
