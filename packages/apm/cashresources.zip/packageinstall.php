<?php

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `cashresources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `res_type` varchar(32) NOT NULL,
  `current_balance` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `res_type` (`res_type`)
)");
$db->RunQuery("INSERT INTO `cashresources` (`id`, `name`, `res_type`, `current_balance`) VALUES (1, 'Cassa Principale', 'cash', 0),(2, 'Conto corrente','bank', 0)");
$db->Close();