<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$ret = GShell("dynarc new-archive -name 'Customer Hardware' -prefix tktcusthw -group tickets -perms 664 --def-cat-perms 664 --def-item-perms 664 -launcher `gframe -f tickets/edit.custhw -params 'id=%d'`",$_SESSION_ID, $_SHELL_ID);
$ret = GShell("dynarc install-extension hwbasicinfo -ap tktcusthw", $_SESSION_ID, $_SHELL_ID);
$ret = GShell("dynarc install-extension oslist -ap tktcusthw",$_SESSION_ID, $_SHELL_ID);
$ret = GShell("dynarc new-archive -name 'OS List' -prefix tktoslist -group tickets -perms 664 --def-cat-perms 664 --def-item-perms 664",$_SESSION_ID, $_SHELL_ID);
$ret = GShell("dynarc new-archive -name 'HDD List' -prefix tkthddlist -group tickets -perms 664 --def-cat-perms 664 --def-item-perms 664",$_SESSION_ID, $_SHELL_ID);
$ret = GShell("dynarc new-archive -name 'Customer Hardware Brands' -prefix tktcusthwbrands -group tickets -perms 664 --def-cat-perms 664 --def-item-perms 664",$_SESSION_ID, $_SHELL_ID);