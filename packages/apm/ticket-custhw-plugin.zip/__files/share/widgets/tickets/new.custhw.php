<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 28-11-2014
 #PACKAGE: ticket-custhw-plugin
 #DESCRIPTION: Registrazione nuovo hardware
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES;
$_BASE_PATH = "../../../";
$_AP = "tktcusthw";
$_BRANDS_AP = "tktcusthwbrands";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate("widget");
$template->includeObject("editsearch");
$template->includeObject("gcal");

$template->Begin("Registra nuovo hardware");
//-------------------------------------------------------------------------------------------------------------------//
?>
<div class='glight-widget-header'><h3>Registra nuovo hardware</h3></div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",600);

if($_REQUEST['subjid'])
{
 /* get customer info */
 $ret = GShell("dynarc item-info -ap rubrica -id '".$_REQUEST['subjid']."'",$_REQUEST['sessid'], $_REQUEST['shellid']);
 if(!$ret['error'])
  $subjectInfo = $ret['outarr'];
}

//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-body" style="width:584px;height:400px">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td><label>Proprietario/Cliente</label><br/>
	 <input type="text" class="contact" id="subject" style="width:260px" fields="code_str,name" contactfields="phone,phone2,cell,email" ct="customers" value="<?php echo htmlspecialchars_decode($subjectInfo['name'],ENT_QUOTES); ?>" refid="<?php echo $subjectInfo['id']; ?>"/>
	</td>
	<td colspan='2'><label>Categoria</label><br/>
	 <input type='text' class='dropdown' style='width:210px;float:left' placeholder="Seleziona una categoria" id="cat" ap="<?php echo $_AP; ?>" catid="" value=""/>
		<input type='button' class='button-folder' ap="<?php echo $_AP; ?>" connect="cat" id="btnselcat"/>
	</td></tr>

<tr class='separator'><td colspan="3"><hr style="width:570px"/></td></tr>

<tr><td><label>Marca</label><br/>
	 <input type='text' class='dropdown' style='width:260px' placeholder="Digita o seleziona una marca" id="brand" ap="<?php echo $_BRANDS_AP; ?>" limit="10"/></td>
	<td colspan='2'><label>Modello</label><br/>
	 <input type='text' class='edit' style='width:270px' placeholder="Digita il modello" id="name"/></td></tr>

<tr class='separator'><td colspan='3'>&nbsp;</td></tr>

<tr><td><label>Product number</label><br/>
	 <input type='text' class='edit-fixed' style='width:260px' id="product-number"/></td>
	<td colspan='2'><label>Numero di serie</label><br/>
	 <input type='text' class='edit-fixed' style='width:270px' id="serial-number"/></td></tr>

<tr class='separator'><td colspan='3'>&nbsp;</td></tr>

<tr><td>&nbsp;</td>
	<td><label>Data acquisto</label><br/>
	 <input type='text' class='calendar' id="purchase-date"/></td>
	<td><label>Anni di garanzia</label><br/>
	 <input type='text' class='edit' style='width:30px' id="years-guarantee" maxlength='2'/></td></tr>

<tr><td colspan="3"><hr style="width:570px"/></td></tr>

<tr><td colspan='3'><label>Annotazioni</label><br/>
	 <textarea class="textarea" id="description" style="width:560px;height:70px;resize:none;"></textarea>
    </td></tr>
</table>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$footer = "<input type='button' class='button-blue' value='Salva' style='float:left' onclick='SubmitAction()'/>";
$footer.= "<input type='button' class='button-gray' value='Annulla' style='float:right' onclick='Template.Exit()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";
var BRANDS_AP = "<?php echo $_BRANDS_AP; ?>";

Template.OnInit = function(){
	 this.initEd(document.getElementById("subject"), "contact");
	 this.initEd(document.getElementById("cat"), "catfind");
	 this.initBtn(document.getElementById("btnselcat"), "catselect");
	 this.initEd(document.getElementById("brand"), "itemfind");
	 this.initEd(document.getElementById("purchase-date"), "date");
}

function SubmitAction()
{
 var subjectId = document.getElementById("subject").getId();
 var subjectName = document.getElementById("subject").value;
 var catId = document.getElementById('cat').getId();
 var brandId = document.getElementById('brand').getId();
 var brandName = document.getElementById('brand').value;
 var model = document.getElementById('name').value;
 var productNumber = document.getElementById('product-number').value;
 var serialNumber = document.getElementById('serial-number').value;
 var notes = document.getElementById("description").value;
 var purchaseDate = document.getElementById('purchase-date').isodate;
 var yearsGuarantee = document.getElementById('years-guarantee').value;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){gframe_close(o,a);}

 var cmd = "dynarc new-item -ap `"+AP+"` -group tickets -name `"+(brandName+" - "+model)+"`"+(catId ? " -cat '"+catId+"'" : "")+" -desc `"+notes+"` -extset `hwbasicinfo.subjid='"+subjectId+"',subjname=\""+subjectName.E_QUOT()+"\",brandap='"+BRANDS_AP+"',brandid='"+brandId+"',brandname=\""+brandName+"\",productnumber='"+productNumber+"',serialnumber='"+serialNumber+"',purchasedate='"+purchaseDate+"',yearsguarantee='"+yearsGuarantee+"'`";

 sh.sendCommand(cmd);
}

</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

