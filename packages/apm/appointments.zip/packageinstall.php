<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$_SHELL_OUT.= "Create new archive Appuntamenti...";

// Verifica se esiste già l'archivio degli appuntamenti, altrimenti lo crea.
$ret = GShell("dynarc archive-info -ap appointments",$_SESSION_ID,$_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-archive -name `Appuntamenti` -type appointments -prefix appointments -perms 666 -launcher `gframe -f appointment/edit -params 'id=%d'` --functions-file `etc/dynarc/archive_funcs/__appointments/index.php` --def-cat-perms 664 --def-item-perms 664",$_SESSION_ID,$_SHELL_ID);
 if($ret['error']) { $_SHELL_ERR = $ret['error']; $_SHELL_OUT = $ret['message']; } else $_SHELL_OUT.= $ret['message'];

 $_SHELL_OUT.= "Install extension cronevents...";
 GShell("dynarc install-extension cronevents -ap appointments",$_SESSION_ID,$_SHELL_ID);

 $_SHELL_OUT.= "Install extension cronrecurrence...";
 GShell("dynarc install-extension cronrecurrence -ap appointments",$_SESSION_ID,$_SHELL_ID);
}

$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_appointments_items` ADD `status` TINYINT(1) NOT NULL,
 ADD `subject_id` INT(11) NOT NULL, 
 ADD `subject_name` VARCHAR(32) NOT NULL, 
 ADD INDEX (`status`,`subject_id`)");
$db->Close();