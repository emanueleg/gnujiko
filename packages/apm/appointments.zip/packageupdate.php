<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_appointments_items` ADD `status` TINYINT(1) NOT NULL,
 ADD `subject_id` INT(11) NOT NULL, 
 ADD `subject_name` VARCHAR(32) NOT NULL, 
 ADD INDEX (`status`,`subject_id`)");
$db->Close();

// 24-04-2014 //
$db = new AlpaDatabase();
$db->RunQuery("UPDATE dynarc_archives SET archive_type='appointments',fun_file='etc/dynarc/archive_funcs/__appointments/index.php' WHERE tb_prefix='appointments'");
$db->Close();