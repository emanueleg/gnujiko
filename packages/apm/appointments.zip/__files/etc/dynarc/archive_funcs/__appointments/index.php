<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 15-05-2014
 #PACKAGE: appointments
 #DESCRIPTION: Archive functions for appointments archives.
 #VERSION: 2.1beta
 #CHANGELOG: 15-05-2014 : aggiornata funzione _ontrashitem e _ondeleteitem
 #TODO: 
 
*/

function dynarcfunction_appointments_oninheritarchive($args, $sessid, $shellid, $archiveInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` ADD `status` TINYINT(1) NOT NULL,
	ADD `subject_id` INT(11) NOT NULL, 
	ADD `subject_name` VARCHAR(32) NOT NULL ,
	ADD INDEX (`status`,`subject_id`)");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_cronevents WHERE item_id='".$itemInfo['id']."'");
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_cronrecurrence WHERE item_id='".$itemInfo['id']."'");
 $db->RunQuery("UPDATE dynarc_rubrica_items SET lastapp_id='0',lastapp_opid='0',lastapp_opname='',lastapp_status='0',lastapp_datetime='',lastapp_agentid='0',lastapp_agentname='' WHERE lastapp_id='"
	.$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_cronevents WHERE item_id='".$itemInfo['id']."'");
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_cronrecurrence WHERE item_id='".$itemInfo['id']."'");
 $db->RunQuery("UPDATE dynarc_rubrica_items SET lastapp_id='0',lastapp_opid='0',lastapp_opname='',lastapp_status='0',lastapp_datetime='',lastapp_agentid='0',lastapp_agentname='' WHERE lastapp_id='"
	.$itemInfo['id']."'");
 $db->Close();
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_onmoveitem($sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_onmovecategory($sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_oncopyitem($sessid, $shellid, $archiveInfo, $cloneInfo, $srcInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_oncopycategory($sessid, $shellid, $archiveInfo, $cloneInfo, $srcInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_appointments_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

