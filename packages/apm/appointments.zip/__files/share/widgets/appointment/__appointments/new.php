<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 15-04-2014
 #PACKAGE: appointments
 #DESCRIPTION: Gnujiko unified system for managing appointments
 #VERSION: 2.0beta
 #CHANGELOG: 
 #DEPENDS:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_SHELL_CMD_PATH, $_USERS_HOMES;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate("widget");
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeObject("fckeditor");
$template->includeInternalObject("contactsearch");

$template->Begin("Nuovo appuntamento");
//-------------------------------------------------------------------------------------------------------------------//
$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : "appointments";
$datefrom = $_REQUEST['datetime'] ? strtotime($_REQUEST['datetime']) : time();
$dateto = strtotime("+1 hour",$datefrom);

//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-header bg-blue"><h3>Nuovo appuntamento</h3></div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("widget",700);

$_STATUS = array("da confermare", "confermato");

if($_REQUEST['subjid'])
{
 // get subject
 $ret = GShell("dynarc item-info -ap 'rubrica' -id '".$_REQUEST['subjid']."'",$_REQUEST['sessid'],$_REQUEST['shellid']);
 if(!$ret['error'])
  $subjectInfo = $ret['outarr'];
}

//-------------------------------------------------------------------------------------------------------------------//
?>
<div class="glight-widget-body" style="width:684px;height:400px">
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="standardform">
<tr><td><label>Titolo</label><br/>
	 <input type="text" class="edit" id="title" style="width:360px" value=""/>
	</td>
	<td width='100'><label>Data</label><br/>
	 <input type='text' class='calendar' id='date' placeholder='gg/mm/aaaa' value="<?php echo date('d/m/Y',$datefrom); ?>"/>
	</td>
	<td width='160'><label>&nbsp;&nbsp;dalle &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; alle</label><br/>
	 <input type='text' class='edit' style='width:60px' id='timefrom' placeholder='hh:mm' value="<?php echo date('H:i',$datefrom); ?>"/>
	 <input type='text' class='edit' style='width:60px' id='timeto' placeholder='hh:mm' value="<?php echo date('H:i',$dateto); ?>"/>
	</td></tr>

<tr class='separator'><td colspan='3'>&nbsp;</td></tr>

<tr><td><label>Cliente</label><br/>
	 <input type='text' class='contact' id='subject' placeholder="Digita il nome del cliente" modal='default' fields='code_str,name' contactfields='phone,phone2,cell,email' ct='customers' style='width:360px' value="<?php echo htmlspecialchars($subjectInfo['name'],ENT_QUOTES); ?>" refid="<?php echo $subjectInfo['id']; ?>" limit="5" nooptions="true"/>
	</td>
	<td colspan='2'><label>Status</label><br/>
	 <input type='text' class='dropdown' style='width:120px' id='status' connect='status-list' value="da confermare" retval="0" readonly="true"/>
	 <ul class='popupmenu' id='status-list'>
	  <?php
	   for($c=0; $c < count($_STATUS); $c++)
		echo "<li value='".$c."'>".$_STATUS[$c]."</li>";
	  ?>
	 </ul>
	</td></tr>

<tr class='separator'><td colspan="3"><hr style="width:670px"/></td></tr>

<tr><td colspan='3'><label>Dettagli</label><br/>
	 <textarea class="textarea" id="description" style="width:660px;height:260px"></textarea>
    </td></tr>
</table>
</div>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$footer = "<input type='button' class='button-blue' value='Salva' style='float:left' onclick='SubmitAction()'/>";
$footer.= "<input type='button' class='button-gray' value='Annulla' style='float:right' onclick='Template.Exit()'/>";
$template->Footer($footer,true);
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_AP; ?>";
Template.OnInit = function(){
	 this.initEd(document.getElementById("status"), "dropdown").onselect = function(){};
	 this.initEd(document.getElementById("description"), "fckeditor", "Basic");
	 this.initEd(document.getElementById("date"), "date");
	 this.initEd(document.getElementById("subject"), "contactextended").OnSearch = function(){};
}

function SubmitAction()
{
 var title = document.getElementById("title").value;
 var subjectId = document.getElementById("subject").getId();
 var subjectName = document.getElementById("subject").value;
 var date = document.getElementById('date').isodate;
 var timeFrom = document.getElementById('timefrom').value;
 var timeTo = document.getElementById('timeto').value;
 var status = document.getElementById("status").getValue();
 var description = document.getElementById("description").getValue();

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){gframe_close(o,a);}

 var cmd = "dynarc new-item -ap '"+AP+"' -name `"+title+"` -desc `"+description+"` -ctime `"+date+" "+timeFrom+"`";
 // set
 cmd+= " -set `subject_id='"+subjectId+"',subject_name='''"+subjectName.E_QUOT()+"''',status='"+status+"'`";
 // event
 cmd+= " -extset `cronevents.from='"+date+" "+timeFrom+"',"+(timeTo ? "to='"+date+" "+timeTo+"'" : "tl=60")+",name='''"+title.E_QUOT()+"'''`";

 sh.sendCommand(cmd);
}

</script>
<?php
//-------------------------------------------------------------------------------------------------------------------//
$template->End();
//-------------------------------------------------------------------------------------------------------------------//

