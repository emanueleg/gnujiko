<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 15-04-2014
 #PACKAGE: appointments
 #DESCRIPTION: Gnujiko unified system for managing appointments
 #VERSION: 2.0beta
 #CHANGELOG: 
 #DEPENDS:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;
$_BASE_PATH = "../../../";

define("VALID-GNUJIKO",1);
$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : "appointments";

if(file_exists($_BASE_PATH."share/widgets/appointment/__".$_AP."/new.php"))
 include($_BASE_PATH."share/widgets/appointment/__".$_AP."/new.php");
else
 include($_BASE_PATH."share/widgets/appointment/__appointments/new.php");


