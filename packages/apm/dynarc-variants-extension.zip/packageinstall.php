<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;


/* Creating variants external tables. */
$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `variant_dim` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `xml_params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
)");
$db->Close();

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `variant_sizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `xml_params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) AUTO_INCREMENT=13");

/* Import demo variant sizes. */
$db->RunQuery("INSERT INTO `variant_sizes` (`id`, `name`, `xml_params`) VALUES
(1, 'Vestiti da donna', '<xml><size name=\"33\"/><size name=\"40\"/><size name=\"42\"/><size name=\"44\"/><size name=\"46\"/><size name=\"48\"/><size name=\"50\"/><size name=\"52\"/><size name=\"54\"/></xml>'),
(2, 'Vestiti da uomo', '<xml><size name=\"44\"/><size name=\"46\"/><size name=\"48\"/><size name=\"50\"/><size name=\"52\"/><size name=\"54\"/><size name=\"56\"/><size name=\"58\"/></xml>'),
(3, 'Scarpe da donna', '<xml><size name=\"35\"/><size name=\"36\"/><size name=\"38\"/><size name=\"39\"/><size name=\"40\"/><size name=\"41\"/><size name=\"42\"/><size name=\"43\"/></xml>'),
(4, 'Scarpe da uomo', '<xml><size name=\"38\"/><size name=\"39\"/><size name=\"40\"/><size name=\"41\"/><size name=\"42\"/><size name=\"43\"/><size name=\"44\"/><size name=\"45\"/></xml>'),
(5, 'Taglie unisex', '<xml><size name=\"XXS\"/><size name=\"XS\"/><size name=\"S\"/><size name=\"M\"/><size name=\"L\"/><size name=\"XL\"/><size name=\"XXL\"/></xml>'),
(6, 'Intimo', '<xml><size name=\"I\"/><size name=\"II\"/><size name=\"III\"/><size name=\"IV\"/><size name=\"V\"/><size name=\"VI\"/><size name=\"VII\"/><size name=\"VIII\"/><size name=\"IX\"/><size name=\"X\"/><size name=\"XI\"/><size name=\"XII\"/></xml>'),
(7, 'Bambini e neonati', '<xml><size name=\"6 mesi\"/><size name=\"9 mesi\"/><size name=\"1 anno\"/><size name=\"18 mesi\"/><size name=\"2 anni\"/><size name=\"3 anni\"/><size name=\"4 anni\"/><size name=\"5 anni\"/><size name=\"6 anni\"/><size name=\"8 anni\"/><size name=\"10 anni\"/><size name=\"12 anni\"/></xml>'),
(8, 'Cinture', '<xml><size name=\"65 cm.\"/><size name=\"75 cm.\"/><size name=\"80 cm.\"/><size name=\"85 cm.\"/><size name=\"90 cm.\"/><size name=\"95 cm.\"/><size name=\"100 cm.\"/><size name=\"105 cm.\"/><size name=\"110 cm.\"/><size name=\"115 cm.\"/><size name=\"120 cm.\"/><size name=\"125 cm.\"/><size name=\"130 cm.\"/></xml>'),
(9, 'Reggiseni', '<xml><size name=\"I\"/><size name=\"II\"/><size name=\"III\"/><size name=\"IV\"/><size name=\"V\"/><size name=\"VI\"/><size name=\"VII\"/><size name=\"VIII\"/><size name=\"IX\"/></xml>'),
(10, 'Calze e collants', '<xml><size name=\"8\"/><size name=\"8½\"/><size name=\"9\"/><size name=\"9½\"/><size name=\"10\"/><size name=\"10½\"/></xml>'),
(11, 'Camicie uomo', '<xml><size name=\"36\"/><size name=\"37\"/><size name=\"38\"/><size name=\"39\"/><size name=\"40\"/><size name=\"41\"/></xml>'),
(12, 'Cappotti e Giacche', '<xml><size name=\"38\"/><size name=\"40\"/><size name=\"42\"/><size name=\"44\"/><size name=\"46\"/><size name=\"48\"/><size name=\"50\"/><size name=\"52\"/><size name=\"54\"/><size name=\"56\"/><size name=\"58\"/><size name=\"60\"/><size name=\"62\"/><size name=\"64\"/></xml>')");
$db->Close();