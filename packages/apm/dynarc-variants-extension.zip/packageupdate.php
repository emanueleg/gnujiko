<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;


if(version_compare($_INSTALLED_VER, "2.2beta","<"))
{
 $ret = GShell("dynarc extension-info variants",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'] && count($ret['outarr']['archives']))
 {
  for($c=0; $c < count($ret['outarr']['archives']); $c++)
   GShell("dynarc install-extension variantstock -ap '".$ret['outarr']['archives'][$c]['ap']."'",$_SESSION_ID, $_SHELL_ID);
 }
}