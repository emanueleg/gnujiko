<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* DROP VARIANTS TABLE */
$db = new AlpaDatabase();
$db->RunQuery("DROP TABLE IF EXISTS `variant_dim`");
$db->RunQuery("DROP TABLE IF EXISTS `variant_sizes`");
$db->Close();