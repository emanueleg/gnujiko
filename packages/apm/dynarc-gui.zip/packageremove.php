<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2012 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 05-11-2012
 #PACKAGE: dynarc-gui
 #DESCRIPTION: Remove package file.
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/

global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Remove archive gnujikoalerts */
GShell("dynarc delete-archive -r -prefix gnujikoalerts",$_SESSION_ID,$_SHELL_ID);
/* Remove archive documents */
GShell("dynarc delete-archive -r -prefix documents",$_SESSION_ID,$_SHELL_ID);
/* Remove archive documentmodels */
GShell("dynarc delete-archive -r -prefix documentmodels",$_SESSION_ID,$_SHELL_ID);
/* Un-register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Dynarc/'");
if($db->Read())
GShell("system unregister-app -id ".$db->record['id'],$_SESSION_ID,$_SHELL_ID);
$db->Close();