<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$ret = GShell("dynarc cat-info -ap printmodels -tag RECURSIVEORDERS", $_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 GShell("dynarc new-cat -ap printmodels -name 'Ordini ricorsivi' -tag RECURSIVEORDERS -pt BACKOFFICE -group backoffice -perms 664",$_SESSION_ID,$_SHELL_ID);
 
 GShell("dynarc import -f tmp/mod-demo-scadenziario-ordini-ricorsivi.xml -ap `printmodels` -ct RECURSIVEORDERS",$_SESSION_ID,$_SHELL_ID);
 GShell("dynarc import -f tmp/mod-demo-lista-ordini-ricorsivi.xml -ap `printmodels` -ct RECURSIVEORDERS",$_SESSION_ID,$_SHELL_ID);
 GShell("dynarc import -f tmp/mod-demo-lista-ordini-terminati.xml -ap `printmodels` -ct RECURSIVEORDERS",$_SESSION_ID,$_SHELL_ID);

 GShell("dynarc import -f tmp/mod-demo-sollecito-pagamento.xml -ap `printmodels` -ct STATEMENTS",$_SESSION_ID,$_SHELL_ID);
}

GShell("dynarc install-extension schedule -ap commercialdocs",$_SESSION_ID,$_SHELL_ID);

$ret = GShell("dynarc item-info -ap printmodels -alias recursiveorders_finish_list", $_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 GShell("dynarc import -f tmp/mod-demo-lista-ordini-terminati.xml -ap `printmodels` -ct RECURSIVEORDERS",$_SESSION_ID,$_SHELL_ID);

// Aggiorna il modello lista ordini ricorsivi perchè modificato. //
/* TODO: rimuovere questo codice la prossima volta che si compila */
$ret = GShell("dynarc item-info -ap printmodels -alias recursiveorders_list", $_SESSION_ID, $_SHELL_ID);
if(!$ret['error'])
 GShell("dynarc delete-item -ap printmodels -id '".$ret['outarr']['id']."' -r",$_SESSION_ID,$_SHELL_ID);

GShell("dynarc import -f tmp/mod-demo-lista-ordini-ricorsivi.xml -ap `printmodels` -ct RECURSIVEORDERS",$_SESSION_ID,$_SHELL_ID);


