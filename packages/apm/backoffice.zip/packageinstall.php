<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Register application */

	$db = new AlpaDatabase();
	$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='BackOffice/'");
	if($db->Read())
	$db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
	else
	{
	 $_SHELL_OUT.= "Register application BackOffice...";
	 $ret = GShell("system register-app -name `BackOffice` -desc `` -url 'BackOffice/' -icon 'BackOffice/icon.png'",$_SESSION_ID, $_SHELL_ID);
	 if($ret['error'])
	 {
	  $_SHELL_ERR = $ret['error'];
	  $_SHELL_OUT = $ret['message'];
	 }
	 else
	  $_SHELL_OUT.= $ret['message'];
	}
	$db->Close();

/* Create new group */
GShell("groupadd `backoffice` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new category */
GShell("dynarc new-cat -ap printmodels -name `BackOffice` -tag BACKOFFICE -group `backoffice` -perms 664",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-cat -ap printmodels -name `Scadenziario` -tag SCHEDULE -pt BACKOFFICE -group `backoffice` -perms 664",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-cat -ap printmodels -name `Estratti conto` -tag STATEMENTS -pt BACKOFFICE -group `backoffice` -perms 664",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc new-cat -ap printmodels -name 'Ordini ricorsivi' -tag RECURSIVEORDERS -pt BACKOFFICE -group backoffice -perms 664",$_SESSION_ID,$_SHELL_ID);

/* Installo l'estensione schedule per i documenti commerciali (in modo da poter abilitare gli ordini ricorsivi) */
GShell("dynarc install-extension schedule -ap commercialdocs",$_SESSION_ID,$_SHELL_ID);

/* Importo i modelli di stampa */
GShell("dynarc import -f tmp/mod-demo-scadenziario-clienti.xml -ap `printmodels` -ct SCHEDULE",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/mod-demo-scadenziario-fornitori.xml -ap `printmodels` -ct SCHEDULE",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/mod-demo-estratto-conto-cliente.xml -ap `printmodels` -ct STATEMENTS",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/mod-demo-estratto-conto-fornitore.xml -ap `printmodels` -ct STATEMENTS",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/mod-demo-sollecito-pagamento.xml -ap `printmodels` -ct STATEMENTS",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/mod-demo-scadenziario-ordini-ricorsivi.xml -ap `printmodels` -ct RECURSIVEORDERS",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/mod-demo-lista-ordini-ricorsivi.xml -ap `printmodels` -ct RECURSIVEORDERS",$_SESSION_ID,$_SHELL_ID);
GShell("dynarc import -f tmp/mod-demo-lista-ordini-terminati.xml -ap `printmodels` -ct RECURSIVEORDERS",$_SESSION_ID,$_SHELL_ID);


