<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 08-11-2013
 #PACKAGE: backoffice
 #DESCRIPTION: BackOffice home-page
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_APS;
$_BASE_PATH = "../";
include_once($_BASE_PATH."var/templates/standardapp/index.php");
//-------------------------------------------------------------------------------------------------------------------//
$app = new StandardApp();
//-------------------------------------------------------------------------------------------------------------------//
include_once($_BASE_PATH."var/objects/htmlgutility/menu.php");
include_once($_BASE_PATH."var/objects/gorganizer/index.php");
include_once($_BASE_PATH."var/objects/gcal/index.php");
include_once($_BASE_PATH."var/objects/editsearch/index.php");
include_once($_BASE_PATH."include/i18n.php");
LoadLanguage("calendar");
?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL.$app->Config['basepath']; ?>common.css" type="text/css" />
<?php
//-------------------------------------------------------------------------------------------------------------------//
$app->StartPage();
//-------------------------------------------------------------------------------------------------------------------//
if(!$_REQUEST['view'])
 $_REQUEST['view'] = "calendar";
if(!$_REQUEST['ap'])
 $_REQUEST['ap'] = $_FIRST_AP;

if(!$_REQUEST['from'] || ($_REQUEST['from'] == "0000-00-00"))
{
 // this month
 $_REQUEST['from'] = date("Y-m")."-01";
 $_REQUEST['to'] = date("Y-m-d",strtotime("+1 month",strtotime($_REQUEST['from'])));
}
if(!$_REQUEST['rpp']) $_REQUEST['rpp'] = 10;
if(!$_REQUEST['pg']) $_REQUEST['pg'] = 1;

$dateFrom = strtotime($_REQUEST['from']);
$dateTo = strtotime($_REQUEST['to']);

if(!$dateFrom)
 $dateFromStr = "da sempre";
else
 $dateFromStr = date('d',$dateFrom).'/'.strtolower(i18n('MONTHABB-'.date('n',$dateFrom))).'/'.date('Y',$dateFrom);
$dateToStr = date('d',$dateTo).'/'.strtolower(i18n('MONTHABB-'.date('n',$dateTo))).'/'.date('Y',$dateTo);

$app->Config['submenu'][] = array("title"=>"Tutti i calendari", "url"=>"index.php", "active"=>(!$_REQUEST['ap'] ? true : false));

$lastAid=0;
$archives = array();
$selectedArchiveName = "";
$db = new AlpaDatabase();
$db->RunQuery("SELECT archive_id FROM dynarc_archive_extensions WHERE (extension_name='cronevents' OR extension_name='cronrecurrence') ORDER BY archive_id ASC");
while($db->Read())
{
 if($lastAid == $db->record['archive_id'])
  continue;
 $lastAid = $db->record['archive_id'];
 $ret = GShell("dynarc archive-info -id `".$lastAid."`");
 if($ret['error'])
  continue;
 $archives[$ret['outarr']['prefix']] = $ret['outarr']['name'];
}
$db->Close();
asort($archives);
foreach($archives as $k => $v) 
{
 if($_REQUEST['ap'] == $k)
  $selectedArchiveName = $v;
 $_APS.= ",".$k;
 $app->Config['submenu'][] = array("title"=>$v, "url"=>"index.php?ap=".$k, "active"=>($_REQUEST['ap'] == $k ? true : false));
}
//-------------------------------------------------------------------------------------------------------------------//
$app->StartHeader();
if($_APS)
 $_APS = ltrim($_APS, ",");
?>
<span class='gray24'><?php echo $selectedArchiveName ? "Calendario ".$selectedArchiveName : "Organizer"; ?></span></td>
<td><span class="smalltext">Cerca:</span> <input type='text' class='edit' id='search' style='width:200px' value="<?php echo $_REQUEST['search']; ?>"/></td>
<?php
if($_REQUEST['view'] == "list")
{
 ?>
<td align='right'>&nbsp;
	<input type="button" id="datefrom" class="dropdown-gray" value="<?php echo $dateFromStr; ?>" date="<?php echo $dateFrom ? date('Y-m-d',$dateFrom) : '0000-00-00'; ?>" onclick="showCal(this)"/> 
	<span class='at12'>al</span> 
	<input type="button" id="dateto" class="dropdown-gray" value="<?php echo $dateToStr; ?>" date="<?php echo date('Y-m-d',$dateTo); ?>" onclick="showCal(this,true)"/></td>
 <?php
}
?>
<td align="right"><span class="smalltext">Vista:</span>
		<input type="button" id="view-button" class="dropdown-gray" value="<?php echo ($_REQUEST['view'] == 'list') ? 'Lista' : 'Calendario'; ?>"/>
		<ul class="submenu" id="view-menu">
		 <li onclick="setView('calendar')">Calendario</li>
		 <li onclick="setView('list')">Lista</li>
		</ul>

<?php
$app->EndHeader();
//-------------------------------------------------------------------------------------------------------------------//
$app->StartContent();
switch($_REQUEST['view'])
{
 case 'calendar' : include("calendar-view.php"); break;
 case 'list' : include("list-view.php"); break;
}
//-------------------------------------------------------------------------------------------------------------------//
$app->Finish();
//-------------------------------------------------------------------------------------------------------------------//

