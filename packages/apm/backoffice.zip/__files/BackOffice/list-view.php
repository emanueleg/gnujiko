<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 04-12-2013
 #PACKAGE: backoffice
 #DESCRIPTION: BackOffice - Calendar list view
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

?>
<table width="100%" cellspacing="0" cellpadding="0" border="0" class="flat-table" style="margin-top:20px" id="invoicelist">
<tr><th style='width:50px' sortable='true' field='date'>Data</th>
	<th style='width:80px'>orario</th>
	<th sortable='true' field='name'>Titolo</th>
	<th>Dettagli</th></tr>
<?php
$ret = GShell("cron list -from '".date('Y-m-d',$dateFrom)."' -to '".date('Y-m-d',$dateTo)."'");
$list = $ret['outarr'];

for($c=0; $c < count($list); $c++)
{
 $rec = $list[$c];
 if(($rec['tag'] == "WORKING_AREA") || ($rec['tag'] == "NONWORKING_AREA"))
  continue;
 echo "<tr><td>".date('d/m/Y',$rec['from'])."</td>";
 if($rec['all_day'])
  echo "<td>tutto il giorno</td>";
 else
  echo "<td>".date('H:i',$rec['from'])." - ".date('H:i',$rec['to'])."</td>";
 echo "<td><a href='#' onclick='editEvent(".$rec['id'].",\"".$rec['archive']."\",\"".$rec['item_id']."\")'>".$rec['name']."</a></td>";
 echo "<td>".($rec['notes'] ? $rec['notes'] : '&nbsp;')."</td></tr>";
}

?>
</table>

<?php
$app->EndContent();
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_REQUEST['ap']; ?>";
var GOrg = null;
var ViewMenu = null;
var VIEW = "<?php echo $_REQUEST['view']; ?>";

function desktopOnLoad()
{
 cal = new GCal();
 ViewMenu = new GPopupMenu(document.getElementById('view-button'), document.getElementById('view-menu'));
 ViewMenu._options.absX = 940;
 ViewMenu._options.correctY = -15;

 EditSearch.init(document.getElementById('search'),
	"dynarc item-find -ap '"+AP+"' -field name `","` -limit 10 --order-by 'name ASC'",
	"id","name","items",true);
 document.getElementById('search').onchange = function(){
	 if(this.value && this.data)
	 {
	  showEvent(AP,this.data['id']);
	 }
	}

}

function editEvent(id,ap,refid)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){document.location.reload();}
 sh.sendCommand("dynlaunch -ap '"+ap+"' -id '"+refid+"'");
}

function showEvent(ap,refid)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){document.location.reload();}
 sh.sendCommand("dynlaunch -ap '"+ap+"' -id '"+refid+"'");
}

function setView(view)
{
 VIEW = view;
 reload();
}

function reload()
{
 var href = "index.php?ap="+AP+"&view="+VIEW+"&from="+document.getElementById("datefrom").getAttribute("date")+"&to="+document.getElementById("dateto").getAttribute("date");

 document.location.href = href;
}

function showCal(inp, _reload)
{
 var date = new Date();

 if(inp.getAttribute('date') != "0000-00-00")
  date.setFromISO(inp.getAttribute('date'));

 cal.Show(inp, date);
 cal.OnChange = function(newdate){
	 inp.value = newdate.printf("d/M/Y").toLowerCase();
	 inp.setAttribute("date",newdate.printf("Y-m-d"));
	 if(_reload)
	  reload();
	}
}

</script>
<?php

