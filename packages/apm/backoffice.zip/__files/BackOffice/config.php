<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 08-11-2013
 #PACKAGE: backoffice
 #DESCRIPTION: Gnujiko Back-Office configuration file
 #VERSION: 
 #CHANGELOG: 
 #TODO:
 
*/

$_APPLICATION_CONFIG = array(
	"appname"=>"BackOffice",
	"basepath"=>"BackOffice/",
	"mainmenu"=>array(
	 	 0 => array("title"=>"Organizer", "url"=>"index.php"),
		 1 => array("title"=>"Scadenziario attivi", "url"=>"credits.php"),
		 2 => array("title"=>"Scadenziario passivi", "url"=>"debits.php"),
		 3 => array("title"=>"Ordini ricorsivi", "url"=>"recursiveorders.php"),
		),
);

if(file_exists("vendorcontracts.php"))
 $_APPLICATION_CONFIG['mainmenu'][] = array("title"=>"Contratti vs fornitori", "url"=>"vendorcontracts.php");
