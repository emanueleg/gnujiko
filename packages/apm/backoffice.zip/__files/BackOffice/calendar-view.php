<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 04-12-2013
 #PACKAGE: backoffice
 #DESCRIPTION: BackOffice - Calendar view
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_APS;

?>
<div id='gorganizer' style="width:790px;height:480px;-moz-user-select:none;-khtml-user-select:none;"></div>
<?php
$app->EndContent();
//-------------------------------------------------------------------------------------------------------------------//
?>
<script>
var AP = "<?php echo $_REQUEST['ap']; ?>";
var APS = "<?php echo $_APS; ?>";
var GOrg = null;
var ViewMenu = null;
var VIEW = "<?php echo $_REQUEST['view']; ?>";

function desktopOnLoad()
{
 cal = new GCal();
 ViewMenu = new GPopupMenu(document.getElementById('view-button'), document.getElementById('view-menu'));
 ViewMenu._options.absX = 920;
 ViewMenu._options.correctY = -15;

 EditSearch.init(document.getElementById('search'),
	"dynarc search "+(AP ? "-ap '"+AP+"'" : "-aps '"+APS+"'")+" -field name `","` -limit 10 --order-by 'name ASC'",
	"id","name","items",true);
 document.getElementById('search').onchange = function(){
	 if(this.value && this.data)
	 {
	  showEvent(this.data['tb_prefix'],this.data['id']);
	 }
	}


 /* INITIALIZE CALENDAR */
 GOrg = new GOrganizer(document.getElementById('gorganizer'), null, 14);
 
 GOrg.OnBlockMove = function(block){
		 var sh = new GShell();
	 	 sh.OnOutput = function(o,a){
		 	 if(!a) return;
			}
		 if(block.data)
		 {
		  if(block.data['archive'] == "simpletask")
		   sh.sendCommand("dynarc edit-item -ap `"+block.data['archive']+"` -id `"+block.data['item_id']+"` -extset `taskinfo.exec-datetime='"+block.dateFrom.printf('Y-m-d H:i')+"',estimated-timelength='"+timelength_to_str(block.timeLength*60)+"'`");
		  else if(block.data['is_recurrence'])
		   sh.sendCommand("cron recurrence2event -ap `"+block.data['archive']+"` -id `"+block.data['id']+"` -from `"+block.dateFrom.printf('Y-m-d H:i')+"` -to `"+block.dateTo.printf('Y-m-d H:i')+"` -exception `"+block.oldDateFrom.printf('Y-m-d H:i')+"`");
		  else
		   sh.sendCommand("cron edit-event -ap `"+block.data['archive']+"` -id `"+block.data['id']+"` -from `"+block.dateFrom.printf('Y-m-d H:i')+"` -to `"+block.dateTo.printf('Y-m-d H:i')+"`");
		 }
	 	 else if(block.id && block.archive)
		 {
		  switch(block.archive)
		  {
		   case 'simpletask' : sh.sendCommand("dynarc edit-item -ap `"+block.archive+"` -id `"+block.id+"` -extset `cronevents.from='"+block.dateFrom.printf('Y-m-d H:i')+"',to='"+block.dateTo.printf('Y-m-d H:i')+"',taskinfo.exec-datetime='"+block.dateFrom.printf('Y-m-d H:i')+"',estimated-timelength='"+timelength_to_str(block.timeLength*60)+"'`"); break;
		   default : sh.sendCommand("dynarc edit-item -ap `"+block.archive+"` -id `"+block.id+"` -extset `cronevents.from='"+block.dateFrom.printf('Y-m-d H:i')+"',to='"+block.dateTo.printf('Y-m-d H:i')+"'`"); break;
		  }
		 }
		}

GOrg.OnBlockResize = function(block){
	 	 if(!block.data) return;
	 	 var sh = new GShell();
		 if(block.data['archive'] == "simpletask")
		  sh.sendCommand("dynarc edit-item -ap `"+block.data['archive']+"` -id `"+block.data['item_id']+"` -extset `taskinfo.exec-datetime='"+block.dateFrom.printf('Y-m-d H:i')+"',estimated-timelength='"+timelength_to_str(block.timeLength*60)+"'`");
		 else
		  sh.sendCommand("cron edit-event -ap `"+block.data['archive']+"` -id `"+block.data['id']+"` -from `"+block.dateFrom.printf('Y-m-d H:i')+"` -to `"+block.dateTo.printf('Y-m-d H:i')+"`");
		}

GOrg.OnBlockClick = function(block){
	 	 if(!block.data) return;
		 switch(block.data['archive'])
		 {
		  case 'simpletask' : {
			 var sh = new GShell();
			 sh.sendCommand("gframe -f simpletask -params `ap="+block.data['archive']+"&id="+block.data['item_id']+"`"); 
			} break;

		  default : {
			 var sh = new GShell();
			 sh.OnOutput = function(o,a){GOrg.reload();}
			 sh.sendCommand("dynlaunch -ap `"+block.data['archive']+"` -id `"+block.data['item_id']+"`");
			} break;
		 }
		}


GOrg.OnUpdateRequest = function(dateFrom, dateTo){
	  	 var from = new Date(dateFrom);
	 	 var to = new Date(dateTo);

		 var sh = new GShell();
		 sh.OnError = function(e,s){}
		 sh.OnOutput = function(o,a){
			 if(!a)
			  return;
			 for(var c=0; c < a.length; c++)
			 {
			  var data = a[c];
			  var opt = {};
			  if(AP != "working_time")
			  {
			   if(data['tag'] == "WORKING_AREA")
			    opt.type = "workingarea";
			   else if(data['tag'] == "NONWORKING_AREA")
			    opt.type = "nonworkingarea";
			  }
			  switch(data['archive'])
			  {
			   case 'appointments' : opt.color = "orange"; break;
			   case 'todo' : opt.color = "sky"; break;
			  }
			  var block = GOrg.addBlock(parseFloat(data['from'])*1000, parseFloat(data['to'])*1000, data['name'], opt);
			  block.data = data;
			 }
			}
		 var cmd = "cron list -from "+from.printf('Y-m-d H:i')+" -to "+to.printf('Y-m-d H:i')+" --include-working-time";
		 if(AP)
		  cmd+= " -archive '"+AP+"'";
		 sh.sendCommand(cmd);
		 return true;
		}

 GOrg.update();
}

function setView(view)
{
 VIEW = view;
 reload();
}

function reload()
{
 var href = "index.php?ap="+AP+"&view="+VIEW;
 document.location.href = href;
}

function showEvent(ap,refid)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){document.location.reload();}
 sh.sendCommand("dynlaunch -ap '"+ap+"' -id '"+refid+"'");
}

</script>
<?php

