/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 18-10-2013
 #PACKAGE: storesearch-module
 #DESCRIPTION: Search products into stores - Module for Gnujiko Desktop.
 #VERSION: 2.1beta
 #CHANGELOG: 18-10-2013 : Bug fix.
 #TODO:
 
*/

function storesearchmodule_load(modId)
{
 var params = storesearchmodule_getparams(modId);
 var begcmd = "";
 if((params['storeloc'] == "remote") && params['rsurl'])
  begcmd = "rsh -url `"+params['rsurl']+"` -l `"+params['rslogin']+"` -p `"+params['rspasswd']+"` -> ";


 var es = EditSearch.init(document.getElementById(modId+"-search"), begcmd+"dynarc search -at 'gmart' -fields barcode,code_str,name `","` --order-by `name ASC` -limit 10","id","name","items",true,"name",storesearchmodule_queryresults);
 es.onchange = function(){
	 if(!this.value) return;
	 var oThis = this;
	 var sh = new GShell();
	 sh.OnError = function(msg,errcode){alert(msg);}
	 sh.OnOutput = function(o,a){storesearchmodule_refresh(modId,a);}
	 if(this.data && this.data['id'])
	  sh.sendCommand(begcmd+"store find -ap `"+this.data['tb_prefix']+"` -id `"+this.data['id']+"`");
	 else
	  sh.sendCommand(begcmd+"store find -at gmart -fields barcode,code_str,name `"+this.value+"`");
	 this.value = "";
	 this.focus();
	}

 var list = document.getElementsByName(modId+"-storeloc");
 for(var c=0; c < list.length; c++)
  list[c].onclick = function(){
	 if(this.getAttribute('storeserver') == "local")
	  document.getElementById(modId+"-remote-params-table").style.display = "none";
	 else if(this.getAttribute('storeserver') == "remote")
	  document.getElementById(modId+"-remote-params-table").style.display = "";
	}

}

function storesearchmodule_refresh(modId, data)
{
 var container = document.getElementById(modId+"-container");
 container.innerHTML = "&nbsp;";
 if(!data || !data['items']) return;

 var modparams = storesearchmodule_getparams(modId);
 var imgAbsURL = ABSOLUTE_URL;
 if((modparams['storeloc'] == "remote") && modparams['rsurl'])
  imgAbsURL = modparams['rsurl'];
 if(imgAbsURL.substr(imgAbsURL.length-1) != "/")
  imgAbsURL+= "/";

 for(var c=0; c < data['items'].length; c++)
 {
  var item = data['items'][c];

  var div = document.createElement('DIV');
  div.className = "storesearchmodule-productinfo";
  var html = "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
  html+= "<tr><td valign='top' width='70'><div class='product-thumb' onclick='storesearchmodule_showitem(\""+item['tb_prefix']+"\","+item['id']+",\""+modId+"\")'><img src='"+imgAbsURL+(item['thumb_img'] ? item['thumb_img'] : "var/desktop/modules/storesearch/img/photo.png")+"' height='64'/></div></td><td valign='top'>";
  html+= "<div class='product-code' onclick='storesearchmodule_showitem(\""+item['tb_prefix']+"\","+item['id']+",\""+modId+"\")'>cod. "+item['code_str']+"</div>";
  html+= "<div class='product-name' onclick='storesearchmodule_showitem(\""+item['tb_prefix']+"\","+item['id']+",\""+modId+"\")'>"+item['name']+"</div></td></tr>";
  html+= "<tr><td colspan='2'><div class='product-avail-head'>DISPONIBILITA&lsquo;</div></td></tr>";

  for(var i=0; i < data['stores'].length; i++)
  {
   html+= "<tr><td colspan='2'><div class='storename'>"+data['stores'][i]['name']+"<span class='store-avail'>"+item["store_"+data['stores'][i]['id']+"_qty"]+"</span></div></td></tr>";
  }

  html+= "</table><hr/>";

  div.innerHTML = html;

  container.appendChild(div);
 }

}

function storesearchmodule_showitem(ap,id,modId)
{
 var sh = new GShell();
 sh.OnError = function(msg,errcode){alert(msg);}
 sh.OnOutput = function(o,a){
	}

 var params = storesearchmodule_getparams(modId);
 if((params['storeloc'] == "remote") && params['rsurl'])
  sh.sendCommand("rsh test -url `"+params['rsurl']+"` -l `"+params['rslogin']+"` -p `"+params['rspasswd']+"` || gframe -f gmart/edit.item -params `ap="+ap+"&id="+id+"` -rsurl `"+params['rsurl']+"` -rslogin `"+params['rslogin']+"` -rspasswd `"+params['rspasswd']+"` -rssessid *.sessid -rsshellid *.shellid");
 else
  sh.sendCommand("gframe -f gmart/edit.item -params `ap="+ap+"&id="+id+"`");
}

function storesearchmodule_queryresults(items, resArr, retVal)
{
 for(var c=0; c < items.length; c++)
 {
  resArr.push(items[c]['code_str']+" - "+items[c]['name']);
  retVal.push(items[c]['code_str']);
 }
}



function storesearchmodule_save(modId)
{
 var arr = storesearchmodule_getparams(modId);
 if(arr['storeloc'] == "remote")
 {
  var params = "<config storeloc='remote' rsurl='"+arr['rsurl']+"' rslogin='"+arr['rslogin']+"' rspasswd='"+arr['rspasswd']+"'/>";

  /* RSH TEST */
  var sh = new GShell();
  sh.OnError = function(msg,errcode){alert(msg);}
  sh.OnOutput = function(){storesearchmodule_saveconfig(modId, params);}
  sh.sendCommand("rsh test -url `"+arr['rsurl']+"` -l `"+arr['rslogin']+"` -p `"+arr['rspasswd']+"`");
  return;
 }
 else
  var params = "<config storeloc='local'/>";
 storesearchmodule_saveconfig(modId, params);
}

function storesearchmodule_saveconfig(modId,params)
{
 var moduleId = modId.replace("gjkdskmod-","");
 var sh = new GShell();
 sh.OnError = function(msg,errcode){alert(msg);}
 sh.OnOutput = function(o,a){
	 alert("Il modulo è stato salvato correttamente!");
	 storesearchmodule_load(modId);
	}
 sh.sendCommand("desktop edit-module -id `"+moduleId+"` -params `"+params+"`");
}

function storesearchmodule_getparams(modId)
{
 var params = new Array();
 var list = document.getElementsByName(modId+"-storeloc");
 for(var c=0; c < list.length; c++)
 {
  if(!list[c].checked)
   continue;
  params['storeloc'] = list[c].getAttribute('storeserver');
  break;
 }

 if(params['storeloc'] == "remote")
 {
  params['rsurl'] = document.getElementById(modId+"-serverurl").value;
  params['rslogin'] = document.getElementById(modId+"-serverlogin").value;
  params['rspasswd'] = document.getElementById(modId+"-serverpasswd").value;
 }

 return params;
}

function storesearchmodule_rename(modId)
{
 var moduleId = modId.replace("gjkdskmod-","");
 var modTit = document.getElementById(modId+"-handle");
 var title = prompt("Rinomina questo modulo",modTit.innerHTML);
 if(!title)
  return;
 
 var sh = new GShell();
 sh.OnError = function(msg,errcode){alert(msg);}
 sh.OnOutput = function(){modTit.innerHTML = title;}
 sh.sendCommand("desktop edit-module -id `"+moduleId+"` -title `"+title+"`");
}

