<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-07-2013
 #PACKAGE: storesearch-module
 #DESCRIPTION: Search products into stores - Module for Gnujiko Desktop.
 #VERSION: 2.0beta
 #CHANGELOG:
 #DEPENDS: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_INTERNAL_LOAD, $_MODULE_INFO;

//-- PRELIMINARY ----------------------------------------------------------------------------------------------------//
if(!$_INTERNAL_LOAD) // this script is loaded into a layer
{
 define("VALID-GNUJIKO",1);
 $_BASE_PATH = "../../../../";
 include_once($_BASE_PATH."include/gshell.php");
 include_once($_BASE_PATH."include/js/gshell.php");
}
//-------------------------------------------------------------------------------------------------------------------//
$_MODULE_INFO['handle'] = $_MODULE_INFO['id']."-handle";
$_MODULE_INFO['front'] = $_MODULE_INFO['id']."-front";
$_MODULE_INFO['back'] = $_MODULE_INFO['id']."-back";

$_MODULE_INFO['plugs'][] = $_MODULE_INFO['id']."-plug1";

$from = time();

include_once($_BASE_PATH."include/i18n.php");
LoadLanguage("storesearch");

include_once($_BASE_PATH."var/objects/editsearch/index.php");

?>
<link rel="stylesheet" href="<?php echo $_ABSOLUTE_URL; ?>var/desktop/modules/storesearch/storesearch.css" type="text/css" />
<script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>var/desktop/modules/storesearch/storesearch.js" type="text/javascript"></script>

<!-- FRONT PANEL -->
<div id="<?php echo $_MODULE_INFO['front']; ?>" class="gnujiko-desktop-module-front-panel storesearchmod-frontpanel" onload="storesearchmodule_load('<?php echo $_MODULE_INFO['id']; ?>')" onrename="storesearchmodule_rename('<?php echo $_MODULE_INFO['id']; ?>')">
<div class="storesearchmod-header">
<table width="100%" height='28' cellspacing="0" cellpadding="0" border="0">
<tr><td align='right' valign='middle' width='34'>&nbsp;</td>
	<td align='center' valign='middle' class='storesearchmod-handle' id="<?php echo $_MODULE_INFO['handle']; ?>"><?php echo ($_MODULE_INFO['title'] != "storesearch") ? $_MODULE_INFO['title'] : "CERCA IN MAGAZZINO"; ?></td>
	<td align='left' valign='middle' width='34'>&nbsp;</td></tr>
</table>
<table width="100%" height='6' cellspacing='0' cellpadding='0' border='0' class="storesearchmod-refdate">
<tr><td>Cerca un articolo in magazzino</td></tr>
</table>
</div>

<div class="storesearchmod-container" id="<?php echo $_MODULE_INFO['id'].'-container'; ?>">
<div class='graytext'>Digita il codice o le iniziali del nome di un prodotto da cercare.</div>
</div>

<div class="storesearchmod-footer">
 Cerca: <input type='text' class='storesearchlist-text' style='width:80%' id="<?php echo $_MODULE_INFO['id']; ?>-search"/>
</div>

</div>
<!-- EOF - FRONT PANEL -->

<!-- BACK PANEL -->
<div id="<?php echo $_MODULE_INFO['back']; ?>" class="gnujiko-desktop-module-back-panel storesearchmod-backpanel" style="display:none">
<table width='100%' cellspacing='0' cellpadding='0' border='0' height='100%'>
<tr><td class='header'><?php echo $_MODULE_INFO['title']; ?></td></tr>
<tr><td valign='top'>
 <div class='storesearchmod-backpanel-params'>
  <span class='bluetitle'>Su quali magazzini desideri effettuare le ricerche?</span><br/>
  <table width='100%' cellspacing='5' cellpadding='0' border='0'>
  <tr><td width='100'><input type='radio' name="<?php echo $_MODULE_INFO['id']; ?>-storeloc" <?php if($_MODULE_INFO['params']['config']['storeloc'] != "remote") echo "checked='true'"; ?> storeserver='local'/><b>in locale</b></td>
	  <td><span class='smallitalic'>(su questo PC/Server)</span></td></tr>
  <tr><td><input type='radio' name="<?php echo $_MODULE_INFO['id']; ?>-storeloc" <?php if($_MODULE_INFO['params']['config']['storeloc'] == "remote") echo "checked='true'"; ?> storeserver='remote'/><b>in remoto</b></td>
	  <td><span class='smallitalic'>(su di un altro Gnujiko installato in un server remoto)</span></td></tr>
  </table>
  <table width='100%' cellspacing='5' cellpadding='0' border='0' id="<?php echo $_MODULE_INFO['id']; ?>-remote-params-table" <?php if($_MODULE_INFO['params']['config']['storeloc'] != "remote") echo "style='display:none'"; ?>>
  <tr><td align='right' width='100'><b>Server URL:</b></td>
	  <td><input type='text' class='edit' style='width:150px' id="<?php echo $_MODULE_INFO['id']; ?>-serverurl" value="<?php echo $_MODULE_INFO['params']['config']['rsurl']; ?>"/></td></tr>
  <tr><td align='right'><b>Login:</b></td>
	  <td><input type='text' class='edit' style='width:150px' id="<?php echo $_MODULE_INFO['id']; ?>-serverlogin" value="<?php echo $_MODULE_INFO['params']['config']['rslogin']; ?>"/></td></tr>
  <tr><td align='right'><b>Password:</b></td>
	  <td><input type='text' class='edit' style='width:150px' id="<?php echo $_MODULE_INFO['id']; ?>-serverpasswd" value="<?php echo $_MODULE_INFO['params']['config']['rspasswd']; ?>"/></td></tr>
  </table>
  <hr/>
  <input type='button' value='Applica' onclick="storesearchmodule_save('<?php echo $_MODULE_INFO['id']; ?>')"/>
 </div>
</td></tr>
<tr><td height='32'>
	 &nbsp;
	</td></tr>
</table>
</div>

<!-- EOF - BACK PANEL -->

