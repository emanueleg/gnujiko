<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

GShell("system unregister-app -name `Appuntamenti`",$_SESSION_ID, $_SHELL_ID);