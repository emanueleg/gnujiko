<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Register application */

	$db = new AlpaDatabase();
	$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Appointments'");
	if($db->Read())
	$db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
	else
	{
	 $_SHELL_OUT.= "Register application Appuntamenti...";
	 $ret = GShell("system register-app -name `Appuntamenti` -desc `Calendario appuntamenti` -url 'Appointments' -icon 'Appointments/icon.png'",$_SESSION_ID, $_SHELL_ID);
	 if($ret['error'])
	 {
	  $_SHELL_ERR = $ret['error'];
	  $_SHELL_OUT = $ret['message'];
	 }
	 else
	  $_SHELL_OUT.= $ret['message'];
	}
	$db->Close();

