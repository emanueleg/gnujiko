<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 23-09-2014
 #PACKAGE: appointments-gui
 #DESCRIPTION: Gnujiko unified system for managing appointments
 #VERSION: 2.2beta
 #CHANGELOG: 23-09-2014 : Integrato con i tickets.
			 29-04-2014 : Bug fix.
 #TODO:
 
*/

$_APPLICATION_CONFIG = array(
	"appname"=>"Appuntamenti",
	"basepath"=>"Appointments/",
	"archives"=>array(),
	"mainmenu"=>array(
	 0 => array("title"=>"Appuntamenti", "url"=>"index.php"),
	),
	"restrictions"=>array(
	 "import"=>array("group"=>"admin"),
	 "export"=>array("group"=>"admin"),
	 "newcontact"=>array("group"=>"admin"),
	 "allmenu"=>array("group"=>"admin")
	)
);

// get archives
$ret = GShell("dynarc archive-list -type appointments");
if(!$ret['error'])
 $_APPLICATION_CONFIG['archives'] = $ret['outarr'];

// get extra archives
$ret = GShell("dynarc archive-info -ap tickets");
if(!$ret['error'])
 $_APPLICATION_CONFIG['archives'][] = $ret['outarr'];

