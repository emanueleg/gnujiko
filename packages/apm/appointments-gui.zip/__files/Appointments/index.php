<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 04-05-2014
 #PACKAGE: appointments-gui
 #DESCRIPTION: Gnujiko unified system for managing appointments
 #VERSION: 2.1beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD;

$_BASE_PATH = "../";

if(!$_REQUEST['view'])
 $_REQUEST['view'] = "calendar";

$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : "appointments";

if(file_exists("view/__".$_AP."/".$_REQUEST['view']."-view.php"))
 include("view/__".$_AP."/".$_REQUEST['view']."-view.php");
else
 include("view/__appointments/calendar-view.php");

?>
