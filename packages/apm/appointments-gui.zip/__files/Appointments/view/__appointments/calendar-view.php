<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 18-04-2014
 #PACKAGE: appointments-gui
 #DESCRIPTION: Gnujiko unified system for managing appointments
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : "appointments";

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate();
$template->includeCSS("calendar-view.css");
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeObject("gorganizer");
$template->includeObject("gcalendar");
$template->includeInternalObject("contactsearch");
//-------------------------------------------------------------------------------------------------------------------//
$_ARCHIVES = $template->config['archives'];
$archiveInfo = array();

// get archive info //
$ret = GShell("dynarc archive-info -ap '".$_AP."'");
if(!$ret['error'])
 $archiveInfo = $ret['outarr'];

$template->Begin("Calendario appuntamenti");

$centerContents = "<input type='text' class='search' style='width:390px;float:left' placeholder='Cerca negli appuntamenti...' id='search' value=\"".$_REQUEST['search']."\"/><input type='button' class='button-search' id='searchbtn' connect='search'/>";

$template->Header("search", $centerContents, "BTN_EXIT", 700);
//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(10);
$imgPath = $_ABSOLUTE_URL.$template->config['basepath']."img/";

if(count($_ARCHIVES) > 1)
{
 echo "<span class='smalltext'>Archivio:</span> <input type='text' class='dropdown' style='width:200px' placeholder='Seleziona un archivio' value=\""
	.htmlspecialchars($archiveInfo['name'], ENT_QUOTES)."\" retval='".$archiveInfo['prefix']."' connect='archive-list' id='archive'/>";
 echo "<ul class='popupmenu' id='archive-list'>";
 for($c=0; $c < count($_ARCHIVES); $c++)
  echo "<li value='".$_ARCHIVES[$c]['prefix']."'>".$_ARCHIVES[$c]['name']."</li>";
 echo "</ul>";
}
else
 echo "&nbsp;";
?>
 </td>
 <td><ul class='toggles'><?php
	  $view = array(
		 "calendar"=>array("title"=>"Mostra calendario", "icon"=>"calendar-view.png"),
		 "list"=>array("title"=>"Mostra lista", "icon"=>"list-view.png")
		);
	  $idx = 0;
	  while(list($k,$v)=each($view))
	  {
	   $class = "";
	   if($idx == 0)
		$class = "first";
	   else if($idx == (count($view)-1))
		$class = "last";
	   if($k == $_REQUEST['view'])
		$class.= " selected";
	   echo "<li".($class ? " class='".$class."'" : "")." onclick=\"setView('".$k."')\" title=\"".$v['title']."\"><img src='".$imgPath.$v['icon']."' class='largebutton'/></li>";
	   $idx++;
	  }
 	 ?></ul>
 </td><td>
<?php
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//
$template->Body("fullspace");
?>
<table width="100%" height="80%" cellspacing="10" cellpadding="0" border="0">
<tr><td width="280" valign="top"><?php
	/* PAINT CALENDAR */
	$Calendar = new GCalendar();
	$Calendar->Paint();
	/* GET UNCONFIRMED APPOINTMENTS */
	$ret = GShell("dynarc item-list -ap '".$_AP."' --all-cat -where `status='0'` -get `subject_name` -extget cronevents");
	$list = $ret['outarr']['items'];
	if(count($list))
	{
	 echo "<div class='appointments-unconfirmed-header' style='margin-top:20px'>CI SONO ".count($list)." APPUNTAMENTI DA CONFERMARE</div>";
	 echo "<div class='appointments-unconfirmed-container' id='unconfirmed-appointments'>";
	 $db = new AlpaDatabase();
	 for($c=0; $c < count($list); $c++)
	 {
	  $item = $list[$c];
	  $rec = count($item['cronevents']) ? $item['cronevents'][0] : array();
	  $datetime = $rec['from'] ? strtotime($rec['from']) : $item['ctime'];
	  $title = $item['subject_name'] ? $item['subject_name'] : $item['name'];
	  // get username //
	  $db->RunQuery("SELECT username,fullname FROM gnujiko_users WHERE id='".$item['modinfo']['uid']."'");
	  $db->Read();
	  $username = $db->record['fullname'] ? $db->record['fullname'] : $db->record['username'];
	  echo "<div class='skypanel'>";
	  echo "<table width='100%' cellspacing='0' cellpadding='0' border='0' class='skypanel-table'>";
	  echo "<tr><td width='28' align='center' valign='middle'><img src='".$_ABSOLUTE_URL."Appointments/img/focus-on.png'/></td>";
	  echo "<td colspan='2' valign='middle'><span class='title-link' onclick='editAppointment(".$item['id'].")'>".($title ? $title : 'senza titolo')."</span></td></tr>";
	  echo "<tr><td colspan='2' style='padding-left:5px'><span class='smalltext'><i>";
	  if($rec['from'])
	   echo i18n('DAYFULL-'.date('N',$datetime)).", ".date('d',$datetime)." ".i18n('MONTH-'.date('n',$datetime))." ".date('Y H:i',$datetime);
	  else
	   echo "data da definire";
	  echo "</i></span></td>";
	  echo "<td rowspan='3' align='center' valign='top' width='60'><img src='".$_ABSOLUTE_URL."Appointments/img/confirmed-off.png' style='cursor:pointer' title='Segna come confermato' onclick='setConfirmed(this,".$item['id'].")' status='0'/></td></tr>";
	  echo "<tr><td colspan='2'>&nbsp;</td></tr>";
	  echo "<tr><td colspan='2' style='padding-left:5px'><span class='tinytext'><i>inserito da ".$username."<br/>in data "
		.date('d/m/Y H:i',$item['ctime'])."</i></span></td></tr>";
	  echo "</table>";
	  echo "</div>";
	 }
	 $db->Close();
	 echo "</div>";
	}
	?>
	</td><td valign="top">
			<div id='gorganizer' style='width:700px;height:480px;'></div>
	</td></tr>
</table>
<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
?>
<script>
var GOrg = null;
var Calendar = null;
var dateFrom = "<?php echo $_REQUEST['date'] ? $_REQUEST['date'] : date('Y-m-d'); ?>";
var AP = "<?php echo $_AP; ?>";

Template.OnExit = function(){document.location.href = ABSOLUTE_URL; return false;}

Template.OnInit = function(){
 var div = document.getElementById("unconfirmed-appointments");
 if(div)
  div.style.height = (div.parentNode.offsetHeight-230)+"px";

 var gorgDiv = document.getElementById('gorganizer');
 gorgDiv.style.height = gorgDiv.parentNode.offsetHeight+"px";
 gorgDiv.style.width = (gorgDiv.parentNode.offsetWidth-20)+"px";
 GOrg = new GOrganizer(gorgDiv, null, 14, dateFrom);
 
 GOrg.OnDblClick = function(date){
	 newAppointment(date.printf('Y-m-d H:i'));
	}

 GOrg.OnBlockMove = function(block){
		 var sh = new GShell();
		 sh.OnError = function(err){alert(err);}
	 	 sh.OnOutput = function(o,a){if(!a) return;}
		 if(block.data)
		 {
		  if(block.data['is_recurrence'])
		   sh.sendCommand("cron recurrence2event -ap `"+block.data['archive']+"` -id `"+block.data['id']+"` -from `"+block.dateFrom.printf('Y-m-d H:i')+"` -to `"+block.dateTo.printf('Y-m-d H:i')+"` -exception `"+block.oldDateFrom.printf('Y-m-d H:i')+"`");
		  else
		   sh.sendCommand("cron edit-event -ap `"+block.data['archive']+"` -id `"+block.data['id']+"` -from `"+block.dateFrom.printf('Y-m-d H:i')+"` -to `"+block.dateTo.printf('Y-m-d H:i')+"` --update-doc-date");
		 }
	 	 else if(block.id && block.archive)
		 {
		  switch(block.archive)
		  {
		   default : sh.sendCommand("dynarc edit-item -ap `"+block.archive+"` -id `"+block.id+"` -ctime `"+block.dateFrom.printf('Y-m-d H:i')+"`-extset `cronevents.from='"+block.dateFrom.printf('Y-m-d H:i')+"',to='"+block.dateTo.printf('Y-m-d H:i')+"'`"); break;
		  }
		 }
		}

 GOrg.OnBlockResize = function(block){
	 	 if(!block.data) return;
	 	 var sh = new GShell();
		 sh.OnError = function(err){alert(err);}
		 sh.OnOutput = function(o,a){}
		 sh.sendCommand("cron edit-event -ap `"+block.data['archive']+"` -id `"+block.data['id']+"` -from `"+block.dateFrom.printf('Y-m-d H:i')+"` -to `"+block.dateTo.printf('Y-m-d H:i')+"` --update-doc-date");
		}

 GOrg.OnBlockClick = function(block){
	 	 if(!block.data) return;
		 switch(block.data['archive'])
		 {
		  default : {
			 var sh = new GShell();
			 sh.OnError = function(err){alert(err);}
			 sh.OnOutput = function(o,a){GOrg.reload();}
			 sh.sendCommand("dynlaunch -ap `"+block.data['archive']+"` -id `"+block.data['item_id']+"`");
			} break;
		 }
		}


 GOrg.OnUpdateRequest = function(dateFrom, dateTo){
	  	 var from = new Date(dateFrom);
	 	 var to = new Date(dateTo);

		 var sh = new GShell();
		 sh.OnError = function(e,s){}
		 sh.OnOutput = function(o,a){
			 if(!a)
			  return;
			 for(var c=0; c < a.length; c++)
			 {
			  var data = a[c];
			  var opt = {};
			  if(data['tag'] == "WORKING_AREA")
			   opt.type = "workingarea";
			  else if(data['tag'] == "NONWORKING_AREA")
			   opt.type = "nonworkingarea";
			  switch(data['archive'])
			  {
			   case 'appointments' : opt.color = "orange"; break;
			   case 'todo' : opt.color = "sky"; break;
			  }
			  var block = GOrg.addBlock(data['dtfrom'], data['dtto'], data['name'], opt);
			  block.data = data;
			  if((data['archive'] == "todo") || (data['archive'] == "appointments"))
		   	  {
			   var sh2 = new GShell();
			   sh2.block = block;
			   sh2.OnError = function(err){alert(err);}
			   sh2.OnOutput = function(o,a){
					 switch(a['status'])
					 {
					  case '2' : this.block.setColor("blue"); break;
					  case '3' : this.block.setColor("orange"); break;
					  case '4' : this.block.setColor("red"); break;
					  case '5' : this.block.setColor("green"); break;
					  default : this.block.setColor("sky"); break;
					 }
					}

			   sh2.sendCommand("dynarc item-info -ap `"+data['archive']+"` -id "+data['item_id']+" -get status");
		      }
			 }
			}
		 sh.sendCommand("cron list -from "+from.printf('Y-m-d H:i')+" -to "+to.printf('Y-m-d H:i')+" -ap '"+AP+"'");
		 return true;
		}

 GOrg.reload();

 /* CALENDAR */
 Calendar = new GCalendar();
 Calendar.OnChange = function(datestr){
	 Template.setVar("date",datestr);
	 Template.reload();
	}

 /* SEARCH */
 this.initEd(document.getElementById("search"), "contactextended").OnSearch = function(){
	 if(this.value && this.data)
	 {
	  Template.setVar("view","list");
	  Template.setVar("subjid",this.data['id']);
	  Template.setVar("search",this.value);
	  Template.reload();
	 }
	}

 if(document.getElementById("archive"))
 {
  this.initEd(document.getElementById("archive"), "dropdown").onselect = function(){
	 Template.setVar("ap",this.getValue());
	 Template.reload(0);
	}
 }
}

function setView(value)
{
 Template.unsetVar("date");
 Template.setVar("view",value);
 Template.reload(0);
}

function newAppointment(datetime)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 GOrg.reload();
	}
 sh.sendCommand("gframe -f appointment/new -params `ap="+AP+"&datetime="+datetime+"`");
}

function editAppointment(id)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 Template.reload();
	}
 sh.sendCommand("gframe -f appointment/edit -params `ap="+AP+"&id="+id+"`");
}

function setConfirmed(img,id)
{
 var status = (img.getAttribute('status') == "1") ? 0 : 1;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 img.src = ABSOLUTE_URL+"Appointments/img/confirmed-"+(status ? "on" : "off")+".png";
	 img.setAttribute('status',status);
	 img.title = status ? "segna come da confermare" : "segna come confermato";
	}
 sh.sendCommand("dynarc edit-item -ap '"+AP+"' -id '"+id+"' -set `status="+status+"`");
}

</script>
<?php

$template->End();

?>

