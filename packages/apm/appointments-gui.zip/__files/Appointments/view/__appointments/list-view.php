<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-04-2014
 #PACKAGE: appointments-gui
 #DESCRIPTION: Gnujiko unified system for managing appointments
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

include($_BASE_PATH."var/templates/glight/index.php");

$template = new GLightTemplate();
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeInternalObject("serp");
$template->includeObject("printmanager");
$template->includeInternalObject("contactsearch");

$template->Begin("Appuntamenti");

$_AP = $_REQUEST['ap'] ? $_REQUEST['ap'] : "appointments";
$_STATUS = array("da confermare", "confermato");

if(!$_REQUEST['from'] && !$_REQUEST['to'])
{
 $dateFrom = date("Y-m")."-01";
 $dateTo = date("Y-m-d",strtotime("+1 month",strtotime($dateFrom)));
}
else
{
 $dateFrom = $_REQUEST['from'] ? $_REQUEST['from'] : "";
 $dateTo = $_REQUEST['to'] ? $_REQUEST['to'] : "";
}

$centerContents = "<input type='text' class='search' style='width:390px;float:left' placeholder='Cerca per cliente...' id='search' value=\"".htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\" ct='customers'/><input type='button' class='button-search' id='searchbtn'/>";
$centerContents.= "<input type='text' class='calendar' value='".($dateFrom ? date('d/m/Y',strtotime($dateFrom)) : '')."' id='datefrom' style='margin-left:30px'/>";
$centerContents.= "<span class='smalltext'> al </span> <input type='text' class='calendar' value='".($dateTo ? date('d/m/Y',strtotime($dateTo)) : '')."' id='dateto'/>";

$template->Header("search", $centerContents, "BTN_EXIT");

if(!$_REQUEST['show'])
 $_REQUEST['show'] = "all";

$template->SubHeaderBegin(10);
$imgPath = $_ABSOLUTE_URL.$template->config['basepath']."img/";
?>
	<input type='button' class='button-blue' value="Nuovo appuntamento" onclick="newAppointment()"/>
	</td>
 <td width='100'>
	<input type='button' class="button-blue menuwhite" value='Menu' connect='mainmenu' id='mainmenubutton'/>
		<ul class='popupmenu' id='mainmenu'>
		 <li onclick='newAppointment()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/time.png"/> Nuovo appuntamento</li>
		 <li class='separator'>&nbsp;</li>
		 <li onclick='deleteSelected()'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/delete.gif"/> Elimina selezionate</li>
		 <li class='separator'>&nbsp;</li>
		 <li onclick='Print(this)'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/printer.gif"/> Stampa lista</li>
		</ul>
 </td>
 <td width='200'><ul class='toggles'><?php
	  $view = array(
		 "calendar"=>array("title"=>"Mostra calendario", "icon"=>"calendar-view.png"),
		 "list"=>array("title"=>"Mostra lista", "icon"=>"list-view.png")
		);
	  $idx = 0;
	  while(list($k,$v)=each($view))
	  {
	   $class = "";
	   if($idx == 0)
		$class = "first";
	   else if($idx == (count($view)-1))
		$class = "last";
	   if($k == $_REQUEST['view'])
		$class.= " selected";
	   echo "<li".($class ? " class='".$class."'" : "")." onclick=\"setView('".$k."')\" title=\"".$v['title']."\"><img src='".$imgPath.$v['icon']."' class='largebutton'/></li>";
	   $idx++;
	  }
 	 ?></ul></td>

 <td width='400'><ul class='toggles'><?php
	  echo "<li class='first".(!isset($_REQUEST['status']) ? ' selected' : '')."' onclick=\"setStatus('')\">Tutti</li>";
	  for($c=0; $c < count($_STATUS); $c++)
	  {
	   $class = "";
	   if($c == (count($_STATUS)-1))
		$class = "last";
	   if(isset($_REQUEST['status']) && ($c == $_REQUEST['status']))
		$class.= " selected";
	   echo "<li".($class ? " class='".$class."'" : "")." onclick=\"setStatus('".$c."')\">".$_STATUS[$c]."</li>";
	   $idx++;
	  }
 	 ?></ul></td>
 <td>&nbsp;<?php 
 
//---------------------------------------------//
$template->SubHeaderEnd();

$template->Body("monosection",700);

/*-------------------------------------------------------------------------------------------------------------------*/
?>
<table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='cronlist'>
<tr><th width='16' printable='false'><input type='checkbox'/></th>
	<th width='60' colwidth='20'>Data</th>
    <th width='80' colwidth='20'>Orario</th>
	<th width='160' colwidth='65'>Titolo</th>
	<th colwidth='60'>Cliente</th>
	<th colwidth='20'>Status</th>
</tr>
<?php

$cmd = "dynarc item-list -ap '".$_AP."' --all-cat --order-by `ctime ASC` -get `subject_id,subject_name,status` -extget cronevents";
$where = "";
if($dateFrom)					$where.= " AND ctime>='".$dateFrom."'";
if($dateTo)						$where.= " AND ctime<='".$dateTo."'";
if(isset($_REQUEST['status']))	$where.= " AND status='".$_REQUEST['status']."'";
if($_REQUEST['subjid'])			$where.= " AND subject_id='".$_REQUEST['subjid']."'";

if($where)
 $cmd.= " -where `".ltrim($where,' AND ')."`";

$ret = GShell($cmd);
$list = $ret['outarr']['items'];

for($c=0; $c < count($list); $c++)
{
 $item = $list[$c];
 $rec = count($item['cronevents']) ? $item['cronevents'][0] : array();

 echo "<tr refap='".$_AP."' refid='".$item['id']."'><td><input type='checkbox'/></td>";
 echo "<td>".($rec['from'] ? date('d/m/Y',strtotime($rec['from'])) : 'da definire')."</td>";
 if($rec['all_day'])
  echo "<td>tutto il giorno</td>";
 else
  echo "<td>".(($rec['from'] && $rec['to']) ? date('H:i',strtotime($rec['from']))." - ".date('H:i',strtotime($rec['to'])) : '--:-- - --:--')."</td>";
 echo "<td><a href='#' onclick='editEvent(".$rec['id'].",\"".$_AP."\",\"".$item['id']."\")'>".($item['name'] ? $item['name'] : 'senza titolo')."</a></td>";
 echo "<td>".($item['subject_name'] ? $item['subject_name'] : '&nbsp;')."</td>";
 echo "<td>".$_STATUS[$item['status']]."</td></tr>";
}

?>
</table>
<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
/*-------------------------------------------------------------------------------------------------------------------*/
?>
<script>
var ON_PRINTING = false;
var ON_EXPORT = false;
var AP = "<?php echo $_AP; ?>";

Template.OnExit = function(){document.location.href = ABSOLUTE_URL; return false;}

Template.OnInit = function(){
	this.initBtn(document.getElementById('mainmenubutton'), "popupmenu");
	this.initEd(document.getElementById("datefrom"), "date").OnDateChange = function(date){Template.setVar("from",date);}
	this.initEd(document.getElementById("dateto"), "date").OnDateChange = function(date){Template.setVar("to",date);Template.reload(0);};

	this.initSortableTable(document.getElementById("cronlist"), "ctime", "ASC");

	this.initEd(document.getElementById("search"), "contactextended").OnSearch = function(){
		 if(this.value && this.data)
		 {
		  Template.setVar("subjid",this.data['id']);
		  Template.setVar("search",this.value);
		 }
		 else
		 {
		  Template.unsetVar("subjid");
		  Template.unsetVar("search");
		 }
		 Template.reload(0);
		}

	document.getElementById("searchbtn").onclick = function(){document.getElementById("search").OnSearch();}
}

function setView(value)
{
 Template.setVar("view",value);
 Template.reload(0);
}

function setShow(value)
{
 Template.setVar("show",value);
 Template.reload(0);
}

function setStatus(status)
{
 if(status == "")
  Template.unsetVar("status");
 else
  Template.setVar("status",status);
 Template.reload(0);
}


function editEvent(id,ap,refid)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){if(!a) return; document.location.reload();}
 sh.sendCommand("dynlaunch -ap '"+ap+"' -id '"+refid+"'");
}

function newAppointment()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){if(!a) return; document.location.reload();}
 sh.sendCommand("gframe -f appointment/new -params `ap="+AP+"`");
}

function Print(printBtn)
{
 if(ON_PRINTING)
  return alert("Attendi che il processo per l'esportazione in PDF abbia terminato.");

 printBtn.disabled = true;
 ON_PRINTING = true;

 var dateFrom = new Date();
 var dateTo = new Date();

 var title = "Appuntamenti";

 if(document.getElementById("datefrom").value)
 {
  dateFrom.setFromISO(document.getElementById("datefrom").isodate);
  title+= " - dal "+dateFrom.printf('d/m/Y');
 }
 if(document.getElementById("dateto").value)
 {
  dateTo.setFromISO(document.getElementById("dateto").isodate);
  title+= " al "+dateTo.printf('d/m/Y');
 }


 var doc = new GnujikoPrintableDocument("Appuntamenti", "A4");
 var header = "<div style='width:190mm' class='defaultheader'><h3>"+title+"</h3></div>";
 doc.setDefaultPageHeader(header);

 var footer = "<div style='width:190mm;margin-top:10mm' class='defaultfooter'>";
 footer+= "<table width='100%' cellspacing='0' cellpadding='0' border='0' class='footertable'>";
 footer+= "<tr><td style='width:160mm'>Pag.</td>";
 footer+= "<td style='width:20mm;text-align:center'>Tot. appuntamenti</td></tr>";

 footer+= "<tr><td>{PGC}</td>";
 footer+= "<td style='text-align:center'>"+(document.getElementById('cronlist').rows.length-1)+"</td></tr>";

 footer+= "</table></div>";

 doc.setDefaultPageFooter(footer);
 doc.includeCSS("var/objects/printmanager/printabletable.css");
 var gpt = new GnujikoPrintableTable(document.getElementById('cronlist'),true,true);
 var ppc = gpt.generatePrintPreview(190);
 for(var c=0; c < ppc.length; c++)
 {
  var page = doc.addPage();
  page.footer = page.footer.replace("{PGC}", (c+1)+"/"+ppc.length);
  page.setContents(ppc[c]);
 }

 doc.printAsPDF();
 document.location.href = "#search";

}

function deleteSelected()
{
 var tb = document.getElementById("cronlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun appuntamento è stato selezionato.");
 if(!confirm("Sei sicuro di voler eliminare gli appuntamenti selezionati?"))
  return;
 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= " -id "+sel[c].getAttribute('refid');

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){document.location.reload();}

 sh.sendCommand("dynarc delete-item -ap '"+AP+"' -r"+q);
}

</script>
<?php

$template->End();
?>

