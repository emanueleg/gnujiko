<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

GShell("system unregister-app -name 'Contratti'",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc delete-archive -ap contracts -r",$_SESSION_ID, $_SHELL_ID);
GShell("dynarc delete-cat -ap 'printmodels' -tag contracts -r",$_SESSION_ID, $_SHELL_ID);