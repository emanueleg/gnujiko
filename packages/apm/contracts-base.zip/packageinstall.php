<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `contracts` --first-user",$_SESSION_ID,$_SHELL_ID);
/* Create new archive */
$_SHELL_OUT.= "Create new archive Contratti...";
$ret = GShell("dynarc new-archive -name `Contratti` -prefix 'contracts' -group 'contracts' -perms '660' --def-cat-perms '660' --def-item-perms '660' --functions-file etc/dynarc/archive_funcs/__contracts/index.php",$_SESSION_ID,$_SHELL_ID);

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension 'coding' -ap 'contracts'",$_SESSION_ID,$_SHELL_ID);

$_SHELL_OUT.= "Install extension cdelements...";
$ret = GShell("dynarc install-extension 'cdelements' -ap 'contracts'",$_SESSION_ID,$_SHELL_ID);


$_SHELL_OUT.= "Install extension contractinfo...";
$ret = GShell("dynarc install-extension 'contractinfo' -ap 'contracts'",$_SESSION_ID,$_SHELL_ID);

$_SHELL_OUT.= "Install extension contractschedule...";
$ret = GShell("dynarc install-extension 'contractschedule' -ap 'contracts'",$_SESSION_ID,$_SHELL_ID);


/* Create new category */
$_SHELL_OUT.= "Create category Generico...";
$ret = GShell("dynarc new-cat -ap 'contracts' -name `Generico` -tag `GENERIC` -group 'contracts'",$_SESSION_ID,$_SHELL_ID);

$_SHELL_OUT.= "Create category Assistenza...";
$ret = GShell("dynarc new-cat -ap 'contracts' -name `Assistenza` -tag `SERVICE` -group 'contracts'",$_SESSION_ID,$_SHELL_ID);

$_SHELL_OUT.= "Create category Manutenzione...";
$ret = GShell("dynarc new-cat -ap 'contracts' -name `Manutenzione` -tag `MAINTENANCE` -group 'contracts'",$_SESSION_ID,$_SHELL_ID);

$ret = GShell("dynarc new-cat -ap 'printmodels' -name 'Contratti' -tag 'contracts' -group 'contracts' -perms 664 --if-not-exists",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap 'printmodels' -name 'Generici' -tag 'generic-contract' -pt contracts -group 'contracts' -perms 664 --if-not-exists",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap 'printmodels' -name 'Assistenza' -tag 'service-contract' -pt contracts -group 'contracts' -perms 664 --if-not-exists",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc new-cat -ap 'printmodels' -name 'Manutenzione' -tag 'maintenance-contract' -pt contracts -group 'contracts' -perms 664 --if-not-exists",$_SESSION_ID,$_SHELL_ID);

$ret = GShell("dynarc import -f tmp/demo-generic-contract.xml -ap printmodels -ct generic-contract",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc import -f tmp/demo-service-contract.xml -ap printmodels -ct service-contract",$_SESSION_ID,$_SHELL_ID);
$ret = GShell("dynarc import -f tmp/demo-maintenance-contract.xml -ap printmodels -ct maintenance-contract",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Contracts/'");
if($db->Read())
 $db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Contratti...";
 $ret = GShell("system register-app -name `Contratti` -desc `Gestione contratti` -url 'Contracts/' -icon 'Contracts/icon.png' -group contracts -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();