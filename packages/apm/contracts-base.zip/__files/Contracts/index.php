<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 19-03-2015
 #PACKAGE: contracts-base
 #DESCRIPTION: Contracts
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS, $_COMPANY_PROFILE;

$_BASE_PATH = "../";
$_RESTRICTED_ACCESS = "contracts";
$_AP = "contracts";
$_CT = "SERVICE";

include($_BASE_PATH."var/templates/glight/index.php");
include_once($_BASE_PATH."include/company-profile.php");


$template = new GLightTemplate();
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeInternalObject("serp");
$template->includeInternalObject("contactsearch");
$template->includeObject("printmanager");
$template->includeCSS('contractlist.css');

$template->Begin("Contratti");
//-------------------------------------------------------------------------------------------------------------------//
$dateFrom = $_REQUEST['from'] ? $_REQUEST['from'] : "";
$dateTo = $_REQUEST['to'] ? $_REQUEST['to'] : "";

$_DEF_RPP = 25;
$_DEF_TERM = 12;
$_DEF_AUTOREN = true;
$_DEF_PERIOD = 1;

$_DECIMALS = $_COMPANY_PROFILE['accounting']['decimals_pricing'];

/* GET LIST OF VAT RATES */
$ret = GShell("dynarc item-list -ap vatrates -get `percentage,vat_type`");
$_VAT_LIST = $ret['outarr']['items'];
$_VAT_BY_ID = array();
for($c=0; $c < count($_VAT_LIST); $c++)
 $_VAT_BY_ID[$_VAT_LIST[$c]['id']] = $_VAT_LIST[$c];

$_DEF_VATID = $_COMPANY_PROFILE['accounting']['freq_vat_used'];
$_DEF_VATRATE = $_VAT_BY_ID[$_DEF_VATID]['percentage'];

$_COLUMNS = array(
 0 => array('title'=>'N. contratto', 	'field'=>'code_num', 		'width'=>70, 	'sortable'=>true, 	'visibled'=>true),
 1 => array('title'=>'Data reg.',		'field'=>'ctime',			'width'=>100,	'sortable'=>true,	'visibled'=>false,	'format'=>'date'),
 2 => array('title'=>'Data inizio',		'field'=>'start_date',		'width'=>100,	'sortable'=>true,	'visibled'=>true,	'format'=>'date'),
 3 => array('title'=>'Data fine',		'field'=>'end_date',		'width'=>100,	'sortable'=>true,	'visibled'=>false,	'format'=>'date'),
 4 => array('title'=>'Cliente',			'field'=>'subject_name',	'sortable'=>true,	'visibled'=>true),
 5 => array('title'=>'Durata',			'field'=>'term',			'sortable'=>true,	'visibled'=>false),
 6 => array('title'=>'Monte ore',		'field'=>'total_hours',		'sortable'=>true,	'visibled'=>true),
 7 => array('title'=>'Ore disp.',		'field'=>'avail_hours',		'sortable'=>true,	'visibled'=>false),
 8 => array('title'=>'Agente',			'field'=>'agent_name',		'sortable'=>true,	'visibled'=>false),
 9 => array('title'=>'% commiss. agente', 'field'=>'agent_commiss',	 'sortable'=>true,	'visibled'=>false),
 10 => array('title'=>'Periodicita',		'field'=>'periodicity',		'sortable'=>true,	'visibled'=>true),
 11 => array('title'=>'Canone',			'field'=>'fee',				'sortable'=>true,	'visibled'=>true,	'format'=>'currency'),
 12 => array('title'=>'Imponibile',		'field'=>'amount',			'sortable'=>true,	'visibled'=>false,	'format'=>'currency'),
 13 => array('title'=>'IVA',			'field'=>'vat',				'sortable'=>true,	'visibled'=>false,	'format'=>'currency'),
 14 => array('title'=>'Totale',			'field'=>'total',			'sortable'=>true,	'visibled'=>false,	'format'=>'currency'),
);

/* GET COLUMN SETTINGS */
$ret = GShell("aboutconfig get -app contracts -sec contractlist");
if(!$ret['error'])
{
 $settings = $ret['outarr']['defaultsettings'];
 if(is_array($settings['contractlist']))
 {
  $visibledColumns = explode(",",$settings['contractlist']['visibledcolumns']);
  for($c=0; $c < count($_COLUMNS); $c++)
  {
   $col = $_COLUMNS[$c];
   if(in_array($col['field'], $visibledColumns))
	$_COLUMNS[$c]['visibled'] = true;
   else
	$_COLUMNS[$c]['visibled'] = false;
  }
  if($settings['contractlist']['rpp'])
   $_DEF_RPP = $settings['contractlist']['rpp'];
 }
}

/* GET CONFIG */
$config = array();
$ret = GShell("aboutconfig get-config -app contracts");
if(!$ret['error'])
 $config = $ret['outarr']['config'];

$centerContents = "<input type='text' class='edit' style='width:290px;float:left' placeholder='Ricerca per cliente' id='search' value=\""
	.htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\" modal='extended' fields='code_str,name' contactfields='phone,phone2,cell,email' ct='customers'/>";
$centerContents.= "<input type='button' class='button-search' id='searchbtn'/>";

$_DATE_FILTERS = array('ctime'=>'Filtra x data reg.', 'start'=>'Filtra x data inizio', 'end'=>'Filtra x data scadenza');
if(!$_REQUEST['datefilter'])
 $_REQUEST['datefilter'] = 'ctime';

$centerContents.= "<input type='edit' class='dropdown' id='datefilter' connect='datefilterlist' readonly='true' style='width:150px;margin-left:30px' value='".$_DATE_FILTERS[$_REQUEST['datefilter']]."' retval='".$_REQUEST['datefilter']."'/>";
$centerContents.= "<ul class='popupmenu' id='datefilterlist'>";
reset($_DATE_FILTERS);
while(list($k,$v)=each($_DATE_FILTERS)){ $centerContents.= "<li value='".$k."'>".$v."</li>"; }
$centerContents.= "</ul>";

$centerContents.= "<input type='text' class='calendar' value='".($dateFrom ? date('d/m/Y',strtotime($dateFrom)) : '')."' id='datefrom'/><span class='smalltext'> al </span><input type='text' class='calendar' value='".($dateTo ? date('d/m/Y',strtotime($dateTo)) : '')."' id='dateto'/>";


if(!$_REQUEST['show'])
 $_REQUEST['show'] = "open";

$_PERIODICITY = array(
	1 => "Mensile",
	2 => "Bimestrale",
	3 => "Trimestrale",
	4 => "Quadrimestrale",
	6 => "Semestrale",
	12 => "Annuale"
);

$template->Header("search", $centerContents, "BTN_EXIT", 800);
//-------------------------------------------------------------------------------------------------------------------//
$_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "ctime,code_num";
$_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "DESC";
$_RPP = $_REQUEST['rpp'] ? $_REQUEST['rpp'] : $_DEF_RPP;
$_PG = $_REQUEST['pg'] ? $_REQUEST['pg'] : 1;

$_SERP = new SERP();
$_SERP->setOrderBy($_ORDER_BY);
$_SERP->setOrderMethod($_ORDER_METHOD);
$_SERP->setResultsPerPage($_RPP);
$_SERP->setCurrentPage($_PG);

$today = date('Y-m-d');

 /* RICERCA NORMALE */
 $cmd = "dynarc item-list -ap `".$_AP."` --all-cat -extget `contractinfo`";
 $where = "";

 if($_REQUEST['show'] == "open")
  $where.= " AND active='1' AND end_date>'".$today."'";
 else if($_REQUEST['show'] == "expired")
  $where.= " AND active='1' AND end_date<='".$today."'";
 else if($_REQUEST['show'] == "closed")
  $where.= " AND active='0'";

 if($_REQUEST['from'] || $_REQUEST['to'])
 {
  switch($_REQUEST['datefilter'])
  {
   case 'ctime' : {	
	 if($_REQUEST['from'])	$where.= " AND ctime>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND ctime<'".$_REQUEST['to']." 23:59:59'";
	} break;

   case 'start' : {
	 if($_REQUEST['from'])	$where.= " AND start_date>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND start_date<'".$_REQUEST['to']." 23:59:59'";
	} break;

   case 'end' : {
	 if($_REQUEST['from'])	$where.= " AND end_date>='".$_REQUEST['from']."'";
	 if($_REQUEST['to'])	$where.= " AND end_date<'".$_REQUEST['to']." 23:59:59'";
	} break;

  }
 }

 if($_REQUEST['subjectid'])				$where.= " AND subject_id='".$_REQUEST['subjectid']."'";
 else if($_REQUEST['search'])			$where.= " AND subject_name='".$_REQUEST['search']."'";

 if($where)	$cmd.= " -where `".ltrim($where,' AND ')."`";


$_CMD = $cmd;
$ret = $_SERP->SendCommand($cmd);
$contractlist = $ret['items'];
//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0);
?>
 <input type='button' class='button-blue' value="Crea nuovo contratto" onclick="NewContract()"/>
 </td>
 <td width='200'>
	<input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='mainmenubutton'/>
	<ul class='popupmenu' id='mainmenu'>
  	 <li onclick="NewContract()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/new_file.png" height="16"/>Nuovo contratto</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="ExportToExcel(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Esporta in Excel</li>
	 <!--<li onclick="ImportFromExcel(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/page_white_excel.gif"/>Importa da Excel</li>
	 <li class='separator'>&nbsp;</li>
	 <li class='subitem'><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Salva su Excel
	  <ul class='popupmenu'>
		<li onclick="ExportToExcel(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Esporta come lista</li>
		<li onclick="ExportRenderedServices(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Esporta resi servizi</li>
	  </ul>
	 </li> -->
	 <li onclick="Print(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/printer.gif"/>Stampa</li>
	 <!-- 
	 <li class='separator'>&nbsp;</li>
	 <li onclick="CloneContract()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/copy.png"/>Duplica ticket selezionati</li>
	 <li class='separator'>&nbsp;</li> -->
	 <li onclick="DeleteSelected()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/trash.gif"/>Elimina contratti selezionati</li>
	 <li class='separator'>&nbsp;</li>
	 <!-- <li onclick="gotoAboutConfig()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/cog.gif"/>Configurazione avanzata</li> -->
	</ul>

	<input type='button' class="button-gray menu" value="Visualizza" connect="viewmenu" id="viewmenubutton"/>
	<ul class='popupmenu' id='viewmenu'>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $checked = $col['visibled'] ? true : false;
	 echo "<li><input type='checkbox'".($checked ? " checked='true'" : "")." onchange=\"showColumn('".$col['field']."',this)\"/>".$col['title']."</li>";
	}
	?>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="saveGlobalSettings()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save.gif"/>Salva configurazione</li>
	</ul>
 </td>
 <td>
  <ul class='toggles'><?php
	$show = array("open"=>"Aperti", "expired"=>"Scaduti", "closed"=>"Chiusi", "all"=>"Tutti");
	$idx = 0;
	while(list($k,$v)=each($show))
	{
	 if(($k == 'canceled') && $config['options']['hidecanceledbtn'])
	  continue;
	 $class = "";
	 if($idx == 0)
	  $class = "first";
	 else if($idx == (count($show)-1))
	  $class = "last";
	 if($k == $_REQUEST['show'])
	  $class.= " selected";
	 echo "<li".($class ? " class='".$class."'" : "")." onclick=\"setShow('".$k."')\">".$v."</li>";
	 $idx++;
	}
	?></ul>
 </td>
 <td width='130'>
	<span class='smalltext'>Mostra</span>
	<input type='text' class='dropdown' id='rpp' value="<?php echo $_RPP; ?> righe" retval="<?php echo $_RPP; ?>" readonly='true' connect='rpplist' style='width:80px'/>
	<ul class='popupmenu' id='rpplist'>
	 <li value='10'>10 righe</li>
	 <li value='25'>25 righe</li>
	 <li value='50'>50 righe</li>
	 <li value='100'>100 righe</li>
	 <li value='250'>250 righe</li>
	 <li value='500'>500 righe</li>
	</ul>
 </td>
 <td width='223' align='right'>
	<?php $_SERP->DrawSerpButtons(true);
 
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//

//-------------------------------------------------------------------------------------------------------------------//
$template->Body("fullspace");
//-------------------------------------------------------------------------------------------------------------------//
?>
<table width="100%" height="80%" cellspacing="0" cellpadding="0" border="0" id="template-outer-mask">
 <tr><td class="bg-lightgray" style="width:270px;<?php if($_REQUEST['hideleftsection']) echo 'display:none'; ?>" valign="top" id="template-left-section">
	<div class='advanced-search-title'>CONTRATTI
	 <img src="<?php echo $_ABSOLUTE_URL; ?>Contracts/img/hidearrow.png" style="float:right;margin-top:12px;cursor:pointer" title="Nascondi barra laterale" onclick="HideLeftSection()"/>
	</div>
	<?php
	//echo $leftContents;
	showMainMenu($template);
	?>
	</td>
	<td style="width:8px" valign="top"><div class="vertical-gray-separator" id="template-left-bar" <?php if($_REQUEST['hideleftsection']) echo "style='cursor:pointer' onclick='ShowLeftSection()' title='Mostra barra laterale'"; ?>></div></td>
	<td class="page-contents" valign="top">
	 <div class="page-contents-body">
	  <!-- START OF PAGE ------------------------------------------------------------------------->
	  <div class="titlebar blue-bar"><span class="titlebar blue-bar">ELENCO CONTRATTI</span></div>


<table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='contractlist' noprinthidden='true'>
<tr><th width='16'><input type='checkbox'/></th>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $visibled = $col['visibled'] ? true : false;
	 echo "<th".(!$visibled ? " style='display:none'" : "");
	 if($col['width'])			echo " width='".$col['width']."'";
	 if($col['field'])			echo " field='".$col['field']."'";
	 if($col['format'])			echo " format='".$col['format']."'";
	 if($col['sortable'])		echo " sortable='true'";
	 echo ">".$col['title']."</th>";
	}
	?>
	<th width='44'>&nbsp;</th>
	<!-- <th width='22'>&nbsp;</th> -->  <!-- spazio x tasto invia x email -->
</tr>
<?php
$row = 0;
$db = new AlpaDatabase();
for($c=0; $c < count($contractlist); $c++)
{
 $item = $contractlist[$c];
 $hint = $item['name']." - ".$item['subject_name'];

 $_PDF_FILENAME = "Contratto_n_".$item['code_num']."_del_".date('d-m-Y',$item['ctime']);

 /* get cat tag */
 $db->RunQuery("SELECT tag FROM dynarc_".$_AP."_categories WHERE id='".$item['cat_id']."'");
 $db->Read();
 $catTag = $db->record['tag'];

 echo "<tr class='row".$row."' id='".$item['id']."' title=\"".$hint."\"><td><input type='checkbox'/></td>";
 for($i=0; $i < count($_COLUMNS); $i++)
 {
  $col = $_COLUMNS[$i];
  $visibled = $col['visibled'] ? true : false;
  echo "<td".(!$visibled ? " style='display:none'>" : ">");
  switch($col['field'])
  {
   case 'code_num' : echo "<a class='link blue' href='".$_ABSOLUTE_URL."Contracts/contractinfo.php?id=".$item['id']."' target='CONTRACT-".$item['id']."'>".$item['code_num']."</a>"; break;
   case 'ctime' : echo "<a class='link blue' href='".$_ABSOLUTE_URL."Contracts/contractinfo.php?id=".$item['id']."' target='CONTRACT-".$item['id']."'>"
	.date('d/m/Y',$_SEARCH_BY_ADDRESS ? strtotime($item['ctime']) : $item['ctime'])."</a>"; break;

   case 'start_date' : echo $item['start_date'] ? date('d/m/Y',strtotime($item['start_date'])) : "&nbsp;"; break;
   case 'end_date' : echo $item['end_date'] ? date('d/m/Y',strtotime($item['end_date'])) : "&nbsp;"; break;
   case 'subject_name' : echo $item['subject_name'] ? "<a class='link blue' href='".$_ABSOLUTE_URL."Contracts/contractinfo.php?id=".$item['id']."' target='CONTRACT-".$item['id']."'>".$item['subject_name']."</a>" : "&nbsp;"; break;

   case 'term' : echo $item['term'] ? $item['term'] : "&nbsp;"; break;
   case 'total_hours' : echo $item['total_hours'] ? $item['total_hours'] : "&nbsp;"; break;
   case 'avail_hours' : echo $item['avail_hours'] ? $item['avail_hours'] : "&nbsp;"; break;
   case 'agent_name' : echo $item['agent_name'] ? $item['agent_name'] : "&nbsp;"; break;
   case 'agent_commiss' : echo $item['agent_commiss'] ? sprintf('%.2f',$item['agent_commiss'])."%" : "&nbsp;"; break;
   case 'periodicity' : echo $item['periodicity'] ? $_PERIODICITY[$item['periodicity']] : "&nbsp;"; break;

   case 'fee' : echo number_format($item['fee'],2,',','.'); break;

   case 'amount' : echo number_format($item['amount'],2,',','.'); break;
   case 'vat' : echo number_format($item['vat'],2,',','.'); break;
   case 'total' : echo number_format($item['total'],2,',','.'); break;
  }
  echo "</td>";
 }
 echo "<td><img src='".$_ABSOLUTE_URL."share/icons/16x16/printer.gif' onclick='PrintContract(".$item['id'].",\"".$catTag."\",\""
	.$_PDF_FILENAME."\")' style='cursor:pointer' title='Stampa'/>";
 echo "</td>";
 echo "</tr>";
 $row = $row ? 0 : 1;
}
$db->Close();

?>
</table>

	  <!-- END OF PAGE --------------------------------------------------------------------------->
	 </div>
	</td>
 </tr>
</table>

<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
/*-------------------------------------------------------------------------------------------------------------------*/
$excelExportPeriodArgStr = "";
reset($_PERIODICITY);
while(list($k,$v) = each($_PERIODICITY))
 $excelExportPeriodArgStr.= ";".$k."=".$v;
$excelExportPeriodArgStr = ltrim($excelExportPeriodArgStr, ";");

?>
<script>
var AP = "<?php echo $_AP; ?>";
var CT = "<?php echo $_CT; ?>";

var DEF_TERM = "<?php echo $_DEF_TERM; ?>";
var DEF_AUTOREN = <?php echo $_DEF_AUTOREN ? '1' : '0'; ?>;
var DEF_PERIOD = <?php echo $_DEF_PERIOD; ?>;
var DEF_VATID = <?php echo $_DEF_VATID; ?>;
var DEF_VATRATE = <?php echo $_DEF_VATRATE; ?>;

var ON_PRINTING = false;
var ON_EXPORT = false;


Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL;
	return false;
}

Template.OnInit = function(){
 /* AUTORESIZE */
 var sH = this.getScreenHeight();
 var tb = document.getElementById("template-outer-mask");
 if(tb.offsetHeight < (sH-115))
  tb.style.height = (sH-115)+"px";
 /* EOF - AUTORESIZE */

	this.initEd(document.getElementById('rpp'), "dropdown").onchange = function(){
		 Template.SERP.RPP = this.getValue();
		 Template.SERP.reload(0);
		}


	this.initEd(document.getElementById("search"), "contactextended").OnSearch = function(){
			 Template.SERP.setVar("refap","");
			 Template.SERP.setVar("refid",0);
			 if(this.value && this.data)
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",this.data['id']);
			 }
			 else
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",0);
			 }
			 Template.SERP.reload(0);
			};
	this.initBtn(document.getElementById("searchbtn")).onclick = function(){document.getElementById("search").OnSearch();}

	this.initBtn(document.getElementById('mainmenubutton'), 'popupmenu');
	this.initBtn(document.getElementById('viewmenubutton'), 'popupmenu');


	this.initEd(document.getElementById("datefrom"), "date");
	this.initEd(document.getElementById("dateto"), "date").OnDateChange = function(date){
		 Template.SERP.setVar("from",document.getElementById("datefrom").isodate);
		 Template.SERP.setVar("to",date);
		 Template.SERP.reload();
		};

	this.initEd(document.getElementById('datefilter'), 'dropdown').onchange = function(){
		 Template.SERP.setVar('datefilter',this.getValue());
		};

	this.SERP = new SERP("<?php echo $_SERP->OrderBy; ?>", "<?php echo $_SERP->OrderMethod; ?>", "<?php echo $_SERP->RPP; ?>", "<?php echo $_SERP->PG; ?>");
	this.initSortableTable(document.getElementById("contractlist"), this.SERP.OrderBy, this.SERP.OrderMethod).OnSort = function(field, method){
		Template.SERP.OrderBy = field;
	    Template.SERP.OrderMethod = method;
		Template.SERP.reload(0);
	}
}

function NewContract()
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 window.open(ABSOLUTE_URL+"Contracts/contractinfo.php?id="+a['id'],"_blank");
	}
 sh.sendCommand("dynarc new-item -ap '"+AP+"' -ct '"+CT+"' -group contracts -perms 664 -extset `contractinfo.startdate='today',term='"+DEF_TERM+"',autorenewal='"+DEF_AUTOREN+"',periodicity='"+DEF_PERIOD+"',feevatid='"+DEF_VATID+"',feevatrate='"+DEF_VATRATE+"',active='1'`");
}

function PrintContract(docId, catTag, pdfFileName)
{
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){}
 sh.sendCommand("dynarc item-info -ap `"+AP+"` -id `"+docId+"` || gframe -f print.preview -params `modelap=printmodels&modelct="+catTag.toLowerCase()+"-contract&parser=contract&id="+docId+"` -title `"+pdfFileName+"`");
}

function setFilter(filter)
{
 Template.SERP.setVar("filter",filter);
 Template.SERP.reload();
}

function setShow(show)
{
 Template.SERP.unsetVar("status");
 Template.SERP.setVar("show",show);
 Template.SERP.reload();
}

function showColumn(field,cb)
{
 var tb = document.getElementById("contractlist");
 if(cb.checked == true)
  tb.showColumn(field);
 else
  tb.hideColumn(field);
}

function ImportFromExcel(btn)
{
 alert('Funzione da implementare');

 /*var sh = new GShell();
 sh.OnOutput = function(o,a){
	 if(!a) return;
	 var fileName = a['files'][0]['fullname'];

	 var sh2 = new GShell();
	 sh2.OnFinish = function(){document.location.reload();}
	 sh2.sendCommand("gframe -f excel/import -params `ap="+AP+"&parser=tickets&file="+fileName+"`");
	}
 sh.sendCommand("gframe -f fileupload");*/
}

function ExportToExcel(btn)
{
 document.getElementById('mainmenubutton').popupmenu.hide();
 var cmd = "<?php echo $_CMD; ?> --order-by `<?php echo $_SERP->OrderBy.' '.$_SERP->OrderMethod; ?>`";
 cmd+= " || tableize *.items";
 cmd+= " -k `code_num,ctime,start_date,end_date,subject_name,term,total_hours,avail_hours,agent_name,agent_commiss,periodicity,fee,amount,vat,total`";

 cmd+= " -n `NR|DATA REG.|DATA INIZIO|DATA FINE|CLIENTE|DURATA|MONTE ORE|ORE DISP.|AGENTE|% COMMISS. AGENTE|PERIODICITA|CANONE|IMPONIBILE|IVA|TOTALE`";

 cmd+= " -f `string|date|date|date|string|string|string|string|string|string|option{<?php echo $excelExportPeriodArgStr; ?>}|currency|currency|currency|currency`";

 cmd+= " | gframe -f excel/export -params `file=lista_contratti` --use-cache-contents -c";

 var sh = new GShell();
 sh.showProcessMessage("Esportazione dei contratti in Excel", "Attendere prego, è in corso l'esportazione dei contratti su file Excel.");
 sh.OnError = function(err){this.processMessage.error(err);}
 sh.OnOutput = function(o,a){
	 this.hideProcessMessage();
	 if(!a) return;
	 var fileName = a['filename'];
	 document.location.href = ABSOLUTE_URL+"getfile.php?file="+fileName;
	}
 sh.sendCommand(cmd);
}

function Print(btn)
{
 var doc = new GnujikoPrintableDocument("ELENCO CONTRATTI", "A4");

 var dateFrom = new Date();
 var dateTo = new Date();
 dateFrom.setFromISO(document.getElementById("datefrom").isodate);
 dateTo.setFromISO(document.getElementById("dateto").isodate);

 var header = "<div style='width:190mm' class='defaultheader'><h3>ELENCO CONTRATTI - dal "+dateFrom.printf('d/m/Y')+" al "+dateTo.printf('d/m/Y')+"</h3></div>";
 doc.setDefaultPageHeader(header);

 var footer = "";

 doc.setDefaultPageFooter(footer);
 doc.includeCSS("var/objects/printmanager/printabletable.css");

 var gpt = new GnujikoPrintableTable(document.getElementById('contractlist'),true,true);
 var ppc = gpt.generatePrintPreview(190);
 for(var c=0; c < ppc.length; c++)
 {
  var page = doc.addPage();
  page.footer = page.footer.replace("{PGC}", (c+1)+"/"+ppc.length);
  page.setContents(ppc[c]);
 }

 doc.printAsPDF();
 document.location.href = "#search";
}

function DeleteSelected()
{
 var tb = document.getElementById("contractlist");
 var sel = tb.getSelectedRows();
 if(!sel.length)
  return alert("Nessun contratto selezionato");
 if(!confirm("Sei sicuro di voler eliminare i contratti selezionati?"))
  return;

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){Template.SERP.reload(0);}
 var q = "";
 for(var c=0; c < sel.length; c++)
  q+= " -id '"+sel[c].id+"'";
 sh.sendCommand("dynarc delete-item -ap '"+AP+"' -r"+q);
}

function saveGlobalSettings()
{
 var xml = "<contractlist";
 var visibledColumns = "";
 var rpp = document.getElementById('rpp').getValue();

 var tb = document.getElementById("contractlist");
 for(var c=0; c < tb.fields.length; c++)
 {
  var th = tb.fields[c];
  if(th.style.display != "none")
   visibledColumns+= ","+th.getAttribute('field');
 }
 if(visibledColumns)
  xml+= " visibledcolumns='"+visibledColumns.substr(1)+"'";

 xml+= " rpp='"+rpp+"'";
 xml+= "/"+">";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){alert("Configurazione salvata");}
 sh.sendSudoCommand("aboutconfig set-config -app contracts -sec contractlist -xml-settings `"+xml+"`");
}

function HideLeftSection()
{
 document.getElementById("template-left-section").style.display = "none";
 var tlb = document.getElementById('template-left-bar');
 tlb.style.cursor = "pointer";
 tlb.title = "Mostra barra laterale";
 tlb.onclick = function(){ShowLeftSection();}
 Template.SERP.setVar("hideleftsection",'true');
}

function ShowLeftSection()
{
 document.getElementById("template-left-section").style.display = "";
 var tlb = document.getElementById('template-left-bar');
 tlb.style.cursor = "default";
 tlb.title = "";
 tlb.onclick = null;
 Template.SERP.unsetVar("hideleftsection");
}

function gotoAboutConfig()
{
 window.open(ABSOLUTE_URL+"aboutconfig/contracts/");
}
</script>
<?php
$template->End();

