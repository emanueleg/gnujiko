<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 12-04-2015
 #PACKAGE: contracts-base
 #DESCRIPTION: Contracts
 #VERSION: 2.1beta
 #CHANGELOG: 12-04-2015 : Integrato con lo scadenziario.
 #TODO:
 
*/

global $_BASE_PATH, $_SHELL_CMD_PATH;
include_once($_BASE_PATH."include/userfunc.php");

$_AP = "contracts";

/* GET CONFIG */
$ret = GShell("aboutconfig get-config -app contracts");
if(!$ret['error'])
 $config = $ret['outarr']['config'];

$_APPLICATION_CONFIG = array(
	"appname"=>"Contratti",
	"basepath"=>"Contracts/",
	"mainmenu"=>array(
	 0 => array('title'=>'Contratti', 'url'=>'index.php', 'icon'=>'icons/open-contracts.png'),
	 1 => array('title'=>'Scadenziario', 'url'=>'schedule.php', 'icon'=>'icons/schedule.png')
	)
);

function showMainMenu($template)
{
 global $_ABSOLUTE_URL;
 echo "<ul class='glight-main-menu'>";
 for($c=0; $c < count($template->config['mainmenu']); $c++)
 {
  $itm = $template->config['mainmenu'][$c];
  if(!$itm['url'] || !$itm['title'])
  {
   // is separator
   echo "<li class='separator'>&nbsp;</li>";
   continue;
  }

  $url = $template->config['basepath'].$itm['url'];
  $active = ($template->cache['mainmenuselidx'] == $c) ? true : false;
  echo "<a href='".$_ABSOLUTE_URL.$url."'><li class='item".($active ? " selected" : "")."'>";
  echo "<img src='".$_ABSOLUTE_URL.$template->config['basepath'].$itm['icon']."'/>";
  echo "<span class='item-title-singleline'>".$itm['title']."</span>";
  if($itm['counter'])
   echo "<em>".$itm['counter']."</em>";
  echo "</li></a>";
 }
 echo "</ul>";
}

