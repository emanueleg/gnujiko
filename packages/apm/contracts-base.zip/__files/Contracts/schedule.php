<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 12-04-2015
 #PACKAGE: contracts-base
 #DESCRIPTION: Contracts - schedule list.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_RESTRICTED_ACCESS, $_COMPANY_PROFILE;

$_BASE_PATH = "../";
$_RESTRICTED_ACCESS = "contracts";
$_AP = "contracts";

include($_BASE_PATH."var/templates/glight/index.php");
include_once($_BASE_PATH."include/company-profile.php");


$template = new GLightTemplate();
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeInternalObject("serp");
$template->includeInternalObject("contactsearch");
$template->includeObject("printmanager");
$template->includeCSS('contractlist.css');

$template->Begin("Contratti - scadenziario");
//-------------------------------------------------------------------------------------------------------------------//
$dateFrom = $_REQUEST['from'] ? $_REQUEST['from'] : "";
if(!$_REQUEST['to'])
 $_REQUEST['to'] = date('Y-m-t');
$dateTo = $_REQUEST['to'] ? $_REQUEST['to'] : "";

$_DEF_RPP = 25;

$_DECIMALS = $_COMPANY_PROFILE['accounting']['decimals_pricing'];

/* GET LIST OF VAT RATES */
$ret = GShell("dynarc item-list -ap vatrates -get `percentage,vat_type`");
$_VAT_LIST = $ret['outarr']['items'];
$_VAT_BY_ID = array();
for($c=0; $c < count($_VAT_LIST); $c++)
 $_VAT_BY_ID[$_VAT_LIST[$c]['id']] = $_VAT_LIST[$c];

$_DEF_VATID = $_COMPANY_PROFILE['accounting']['freq_vat_used'];
$_DEF_VATRATE = $_VAT_BY_ID[$_DEF_VATID]['percentage'];

$_COLUMNS = array(
 0 => array('title'=>'N. contratto', 	'field'=>'code_num', 		'width'=>70, 		'sortable'=>true, 	'visibled'=>true),
 1 => array('title'=>'Cliente',			'field'=>'subject_name',	'sortable'=>true,	'visibled'=>true),
 2 => array('title'=>'Scadenza',		'field'=>'expiry',			'sortable'=>true,	'visibled'=>true),
 3 => array('title'=>'Importo',			'field'=>'total',			'width'=>70,		'sortable'=>true,	'visibled'=>true,	'format'=>'currency', 'align'=>'center'),
 4 => array('title'=>'Fattura',			'field'=>'invoice_name',	'sortable'=>true,	'visibled'=>true),
 5 => array('title'=>'Pagato',			'field'=>'paid',			'width'=>50,		'sortable'=>true,	'visibled'=>true,	'align'=>'center')
);

/* GET COLUMN SETTINGS */
$ret = GShell("aboutconfig get -app contracts -sec schedulelist");
if(!$ret['error'])
{
 $settings = $ret['outarr']['defaultsettings'];
 if(is_array($settings['schedulelist']))
 {
  $visibledColumns = explode(",",$settings['schedulelist']['visibledcolumns']);
  for($c=0; $c < count($_COLUMNS); $c++)
  {
   $col = $_COLUMNS[$c];
   if(in_array($col['field'], $visibledColumns))
	$_COLUMNS[$c]['visibled'] = true;
   else
	$_COLUMNS[$c]['visibled'] = false;
  }
  if($settings['schedulelist']['rpp'])
   $_DEF_RPP = $settings['schedulelist']['rpp'];
 }
}

/* GET CONFIG */
$config = array();
$ret = GShell("aboutconfig get-config -app contracts");
if(!$ret['error'])
 $config = $ret['outarr']['config'];

$centerContents = "<input type='text' class='edit' style='width:290px;float:left' placeholder='Ricerca per cliente' id='search' value=\""
	.htmlspecialchars($_REQUEST['search'],ENT_QUOTES)."\" modal='extended' fields='code_str,name' contactfields='phone,phone2,cell,email' ct='customers'/>";
$centerContents.= "<input type='button' class='button-search' id='searchbtn'/>";
$centerContents.= "<input type='text' class='calendar' value='".($dateFrom ? date('d/m/Y',strtotime($dateFrom)) : '')."' id='datefrom' style='margin-left:20px'/><span class='smalltext'> al </span><input type='text' class='calendar' value='".($dateTo ? date('d/m/Y',strtotime($dateTo)) : '')."' id='dateto'/>";
$centerContents.= " <img src='".$_ABSOLUTE_URL."share/icons/16x16/view-refresh.png' style='cursor:pointer' onclick='doSearchByDate()' title='Effettua la ricerca per data'/>";


if(!$_REQUEST['show'])
 $_REQUEST['show'] = "all";

$template->Header("search", $centerContents, "BTN_EXIT", 800);
//-------------------------------------------------------------------------------------------------------------------//
$_ORDER_BY = $_REQUEST['sortby'] ? $_REQUEST['sortby'] : "expiry";
$_ORDER_METHOD = $_REQUEST['sortmethod'] ? strtoupper($_REQUEST['sortmethod']) : "ASC";
$_RPP = $_REQUEST['rpp'] ? $_REQUEST['rpp'] : $_DEF_RPP;
$_PG = $_REQUEST['pg'] ? $_REQUEST['pg'] : 1;

$_SERP = new SERP();
$_SERP->setOrderBy($_ORDER_BY);
$_SERP->setOrderMethod($_ORDER_METHOD);
$_SERP->setResultsPerPage($_RPP);
$_SERP->setCurrentPage($_PG);

$today = date('Y-m-d');

/* RICERCA NORMALE */
$cmd = "dynarc cross-search -ap '".$_AP."' -ext schedule -onlyget 'name,code_num,subject_id,subject_name' --get-all-ext-fields";

$where = "";

if($_REQUEST['to'] && !$_REQUEST['from'])
 $where.= " AND ext.expiry<='".$_REQUEST['to']."'";
else if($_REQUEST['from'] && !$_REQUEST['to'])
 $where.= " AND ext.expiry>='".$_REQUEST['from']."' AND ext.expiry<'".$today."'";
else if($_REQUEST['from'] && $_REQUEST['to'])
 $where.= " AND ext.expiry>='".$_REQUEST['from']."' AND ext.expiry<'".$_REQUEST['to']." 23:59:59'";
else
 $where.= " AND ext.expiry<='".$today."'";

switch($_REQUEST['show'])
{
 case 'tobepaid' : 		$where.= " AND ext.paid='0'"; break;
 case 'paid' : 			$where.= " AND ext.paid='1'"; break;
}

if($_REQUEST['subjectid'])
 $where.= " AND subject_id='".$_REQUEST['subjectid']."'";
else if($_REQUEST['search'])
 $where.= " AND subject_name LIKE '%".$_REQUEST['search']."%'";

$cmd.= " -where `".ltrim($where,' AND ')."`"; 

$_CMD = $cmd;

$ret = $_SERP->SendCommand($cmd);
$schedulelist = $ret['items'];
//-------------------------------------------------------------------------------------------------------------------//
$template->SubHeaderBegin(0);
?>
 &nbsp;
 </td>
 <td width='200'>
	<input type='button' class="button-blue menuwhite" value="Menu" connect='mainmenu' id='mainmenubutton'/>
	<ul class='popupmenu' id='mainmenu'>
	 <li onclick="ExportToExcel(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/excel.png"/>Esporta in Excel</li>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="Print(this)"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/printer.gif"/>Stampa</li>
	</ul>

	<input type='button' class="button-gray menu" value="Visualizza" connect="viewmenu" id="viewmenubutton"/>
	<ul class='popupmenu' id='viewmenu'>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $checked = $col['visibled'] ? true : false;
	 echo "<li><input type='checkbox'".($checked ? " checked='true'" : "")." onchange=\"showColumn('".$col['field']."',this)\"/>".$col['title']."</li>";
	}
	?>
	 <li class='separator'>&nbsp;</li>
	 <li onclick="saveGlobalSettings()"><img src="<?php echo $_ABSOLUTE_URL; ?>share/icons/16x16/save.gif"/>Salva configurazione</li>
	</ul>
 </td>
 <td>
  <ul class='toggles'><?php
	$show = array("all"=>"Tutti", "tobepaid"=>"Da saldare", "paid"=>"Saldati");
	$idx = 0;
	while(list($k,$v)=each($show))
	{
	 if(($k == 'canceled') && $config['options']['hidecanceledbtn'])
	  continue;
	 $class = "";
	 if($idx == 0)
	  $class = "first";
	 else if($idx == (count($show)-1))
	  $class = "last";
	 if($k == $_REQUEST['show'])
	  $class.= " selected";
	 echo "<li".($class ? " class='".$class."'" : "")." onclick=\"setShow('".$k."')\">".$v."</li>";
	 $idx++;
	}
	?></ul>
 </td>
 <td width='130'>
	<span class='smalltext'>Mostra</span>
	<input type='text' class='dropdown' id='rpp' value="<?php echo $_RPP; ?> righe" retval="<?php echo $_RPP; ?>" readonly='true' connect='rpplist' style='width:80px'/>
	<ul class='popupmenu' id='rpplist'>
	 <li value='10'>10 righe</li>
	 <li value='25'>25 righe</li>
	 <li value='50'>50 righe</li>
	 <li value='100'>100 righe</li>
	 <li value='250'>250 righe</li>
	 <li value='500'>500 righe</li>
	</ul>
 </td>
 <td width='223' align='right'>
	<?php $_SERP->DrawSerpButtons(true);
 
$template->SubHeaderEnd();
//-------------------------------------------------------------------------------------------------------------------//

//-------------------------------------------------------------------------------------------------------------------//
$template->Body("fullspace");
//-------------------------------------------------------------------------------------------------------------------//
?>
<table width="100%" height="80%" cellspacing="0" cellpadding="0" border="0" id="template-outer-mask">
 <tr><td class="bg-lightgray" style="width:270px;<?php if($_REQUEST['hideleftsection']) echo 'display:none'; ?>" valign="top" id="template-left-section">
	<div class='advanced-search-title'>SCADENZIARIO
	 <img src="<?php echo $_ABSOLUTE_URL; ?>Contracts/img/hidearrow.png" style="float:right;margin-top:12px;cursor:pointer" title="Nascondi barra laterale" onclick="HideLeftSection()"/>
	</div>
	<?php
	//echo $leftContents;
	showMainMenu($template);
	?>
	</td>
	<td style="width:8px" valign="top"><div class="vertical-gray-separator" id="template-left-bar" <?php if($_REQUEST['hideleftsection']) echo "style='cursor:pointer' onclick='ShowLeftSection()' title='Mostra barra laterale'"; ?>></div></td>
	<td class="page-contents" valign="top">
	 <div class="page-contents-body">
	  <!-- START OF PAGE ------------------------------------------------------------------------->
	  <div class="titlebar blue-bar"><span class="titlebar blue-bar">ELENCO SCADENZE</span></div>


<table width='100%' cellspacing='0' cellpadding='0' border='0' class='sortable-table' id='schedulelist' noprinthidden='true'>
<tr><th width='16'><input type='checkbox'/></th>
	<?php
	for($c=0; $c < count($_COLUMNS); $c++)
	{
	 $col = $_COLUMNS[$c];
	 $visibled = $col['visibled'] ? true : false;
	 echo "<th".(!$visibled ? " style='display:none'" : "");
	 if($col['width'])			echo " width='".$col['width']."'";
	 if($col['field'])			echo " field='".$col['field']."'";
	 if($col['format'])			echo " format='".$col['format']."'";
	 if($col['sortable'])		echo " sortable='true'";
	 echo ">".$col['title']."</th>";
	}
	?>
	<th width='44'>&nbsp;</th>
	<!-- <th width='22'>&nbsp;</th> -->  <!-- spazio x tasto invia x email -->
</tr>
<?php
$row = 0;
$db = new AlpaDatabase();
for($c=0; $c < count($schedulelist); $c++)
{
 $item = $schedulelist[$c];
 $hint = $item['name']." - ".$item['subject_name'];

 $_PDF_FILENAME = "Contratto_n_".$item['code_num']."_del_".date('d-m-Y',$item['ctime']);

 /* get cat tag */
 $db->RunQuery("SELECT tag FROM dynarc_".$_AP."_categories WHERE id='".$item['cat_id']."'");
 $db->Read();
 $catTag = $db->record['tag'];

 echo "<tr class='row".$row."' id='".$item['id']."' contractid='".$item['item_id']."' title=\"".$hint."\"><td><input type='checkbox'/></td>";
 for($i=0; $i < count($_COLUMNS); $i++)
 {
  $col = $_COLUMNS[$i];
  $visibled = $col['visibled'] ? true : false;
  $style = "";
  if($col['align'])	$style.= "text-align:".$col['align'].";";
  if(!$visibled) $style.= "display:none";
  echo "<td".($style ? " style='".$style."'>" : ">");
  switch($col['field'])
  {
   case 'code_num' : echo "<a class='link blue' href='".$_ABSOLUTE_URL."Contracts/contractinfo.php?id=".$item['item_id']."' target='CONTRACT-".$item['item_id']."'>".$item['code_num']."</a>"; break;

   case 'subject_name' : echo $item['subject_name'] ? "<a class='link blue' href='".$_ABSOLUTE_URL."Contracts/contractinfo.php?id=".$item['item_id']."' target='CONTRACT-".$item['item_id']."'>".$item['subject_name']."</a>" : "&nbsp;"; break;

   case 'expiry' : echo date('d/m/Y',strtotime($item['expiry'])); break;

   case 'total' : echo number_format($item['total'],2,',','.'); break;

   case 'invoice_name' : {
	 if($item['invoice_id'])
	  echo "<a href='".$_ABSOLUTE_URL."GCommercialDocs/docinfo.php?id=".$item['invoice_id']."' target='GCD-"
	.$item['invoice_id']."'>".$item['invoice_name']."</a>";
	 else
	  echo "<img src='img/next-blue.png' style='cursor:pointer' title='Genera fattura' onclick='generateScheduleInvoice(this)'/>";
	} break;

   case 'paid' : echo $item['paid'] ? "<img src='".$_ABSOLUTE_URL."share/icons/16x16/ok.gif' alt='SI'/>" : "<img src='".$_ABSOLUTE_URL."share/icons/16x16/money_euro.gif' title='Segna come pagata' style='cursor:pointer' onclick='setAsPaid(this)'/>"; break;
  }
  echo "</td>";
 }

 echo "<td>";
 echo "&nbsp;"; // tasto stampa o altro...
 echo "</td>";
 echo "</tr>";
 $row = $row ? 0 : 1;
}
$db->Close();

?>
</table>

	  <!-- END OF PAGE --------------------------------------------------------------------------->
	 </div>
	</td>
 </tr>
</table>

<?php
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
/*-------------------------------------------------------------------------------------------------------------------*/

?>
<script>
var AP = "<?php echo $_AP; ?>";
var ON_PRINTING = false;
var ON_EXPORT = false;

Template.OnExit = function(){
	document.location.href = ABSOLUTE_URL;
	return false;
}

Template.OnInit = function(){
 /* AUTORESIZE */
 var sH = this.getScreenHeight();
 var tb = document.getElementById("template-outer-mask");
 if(tb.offsetHeight < (sH-115))
  tb.style.height = (sH-115)+"px";
 /* EOF - AUTORESIZE */

	this.initEd(document.getElementById('rpp'), "dropdown").onchange = function(){
		 Template.SERP.RPP = this.getValue();
		 Template.SERP.reload(0);
		}


	this.initEd(document.getElementById("search"), "contactextended").OnSearch = function(){
			 Template.SERP.setVar("refap","");
			 Template.SERP.setVar("refid",0);
			 if(this.value && this.data)
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",this.data['id']);
			 }
			 else
			 {
			  Template.SERP.setVar("search",this.value);
			  Template.SERP.setVar("subjectid",0);
			 }
			 Template.SERP.reload(0);
			};
	this.initBtn(document.getElementById("searchbtn")).onclick = function(){document.getElementById("search").OnSearch();}

	this.initBtn(document.getElementById('mainmenubutton'), 'popupmenu');
	this.initBtn(document.getElementById('viewmenubutton'), 'popupmenu');


	this.initEd(document.getElementById("datefrom"), "date");
	this.initEd(document.getElementById("dateto"), "date").OnDateChange = function(date){
		 Template.SERP.setVar("from",document.getElementById("datefrom").isodate);
		 Template.SERP.setVar("to",date);
		 Template.SERP.reload();
		};

	this.SERP = new SERP("<?php echo $_SERP->OrderBy; ?>", "<?php echo $_SERP->OrderMethod; ?>", "<?php echo $_SERP->RPP; ?>", "<?php echo $_SERP->PG; ?>");
	this.initSortableTable(document.getElementById("schedulelist"), this.SERP.OrderBy, this.SERP.OrderMethod).OnSort = function(field, method){
		Template.SERP.OrderBy = field;
	    Template.SERP.OrderMethod = method;
		Template.SERP.reload(0);
	}
}

function setFilter(filter)
{
 Template.SERP.setVar("filter",filter);
 Template.SERP.reload();
}

function setShow(show)
{
 Template.SERP.unsetVar("status");
 Template.SERP.setVar("show",show);
 Template.SERP.reload();
}

function showColumn(field,cb)
{
 var tb = document.getElementById("schedulelist");
 if(cb.checked == true)
  tb.showColumn(field);
 else
  tb.hideColumn(field);
}

function saveGlobalSettings()
{
 var xml = "<schedulelist";
 var visibledColumns = "";
 var rpp = document.getElementById('rpp').getValue();

 var tb = document.getElementById("schedulelist");
 for(var c=0; c < tb.fields.length; c++)
 {
  var th = tb.fields[c];
  if(th.style.display != "none")
   visibledColumns+= ","+th.getAttribute('field');
 }
 if(visibledColumns)
  xml+= " visibledcolumns='"+visibledColumns.substr(1)+"'";

 xml+= " rpp='"+rpp+"'";
 xml+= "/"+">";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(){alert("Configurazione salvata");}
 sh.sendSudoCommand("aboutconfig set-config -app contracts -sec schedulelist -xml-settings `"+xml+"`");
}

function HideLeftSection()
{
 document.getElementById("template-left-section").style.display = "none";
 var tlb = document.getElementById('template-left-bar');
 tlb.style.cursor = "pointer";
 tlb.title = "Mostra barra laterale";
 tlb.onclick = function(){ShowLeftSection();}
 Template.SERP.setVar("hideleftsection",'true');
}

function ShowLeftSection()
{
 document.getElementById("template-left-section").style.display = "";
 var tlb = document.getElementById('template-left-bar');
 tlb.style.cursor = "default";
 tlb.title = "";
 tlb.onclick = null;
 Template.SERP.unsetVar("hideleftsection");
}

function gotoAboutConfig()
{
 window.open(ABSOLUTE_URL+"aboutconfig/contracts/");
}

function generateScheduleInvoice(img)
{
 var r = img.parentNode.parentNode;
 var contractId = r.getAttribute('contractid');
 var scheduleId = r.id;


 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 img.parentNode.innerHTML = "<a href='"+ABSOLUTE_URL+"GCommercialDocs/docinfo.php?id="+a['id']+"' target='GCD-"+a['id']+"'>"+a['name']+"</a>";
	}
 sh.sendCommand("commercialdocs generate-from-contract -id '"+contractId+"' -scheduleid '"+scheduleId+"'");
}

function setAsPaid(img)
{
 var r = img.parentNode.parentNode;
 var contractId = r.getAttribute('contractid');
 var scheduleId = r.id;

 var date = new Date();
 var tmp = prompt("Digita la data di pagamento",date.printf('d/m/Y'));
 if(!tmp) return;
 date.setFromISO(strdatetime_to_iso(tmp));

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 img.parentNode.innerHTML = "<img src='"+ABSOLUTE_URL+"share/icons/16x16/ok.gif'/"+">";
	}
 sh.sendCommand("dynarc edit-item -ap `"+AP+"` -id `"+contractId+"` -extset `contractschedule.id='"+scheduleId+"',paid='1',paiddate='"+date.printf('Y-m-d')+"'`");
}

function doSearchByDate()
{
 document.getElementById("dateto").OnDateChange(document.getElementById("dateto").isodate);
}

function Print(btn)
{
 var doc = new GnujikoPrintableDocument("ELENCO SCADENZE", "A4");

 var dateFrom = new Date();
 var dateTo = new Date();
 dateFrom.setFromISO(document.getElementById("datefrom").isodate);
 dateTo.setFromISO(document.getElementById("dateto").isodate);

 var header = "<div style='width:190mm' class='defaultheader'><h3>ELENCO SCADENZE - dal "+dateFrom.printf('d/m/Y')+" al "+dateTo.printf('d/m/Y')+"</h3></div>";
 doc.setDefaultPageHeader(header);

 var footer = "";

 doc.setDefaultPageFooter(footer);
 doc.includeCSS("var/objects/printmanager/printabletable.css");

 var gpt = new GnujikoPrintableTable(document.getElementById('schedulelist'),true,true);
 var ppc = gpt.generatePrintPreview(190);
 for(var c=0; c < ppc.length; c++)
 {
  var page = doc.addPage();
  page.footer = page.footer.replace("{PGC}", (c+1)+"/"+ppc.length);
  page.setContents(ppc[c]);
 }

 doc.printAsPDF();
 document.location.href = "#search";
}

function ExportToExcel(btn)
{
 document.getElementById('mainmenubutton').popupmenu.hide();
 var cmd = "<?php echo $_CMD; ?> --order-by `<?php echo $_SERP->OrderBy.' '.$_SERP->OrderMethod; ?>`";
 cmd+= " || tableize *.items";
 cmd+= " -k `code_num,subject_name,expiry,total,invoice_name,paid`";

 cmd+= " -n `NR|CLIENTE|SCADENZA|TOTALE|FATTURA|PAGATO`";

 cmd+= " -f `string|string|date|currency|string|bool`";

 cmd+= " | gframe -f excel/export -params `file=scadenze_contratti` --use-cache-contents -c";

 var sh = new GShell();
 sh.showProcessMessage("Esportazione scadenze contratti in Excel", "Attendere prego, è in corso l'esportazione su file Excel.");
 sh.OnError = function(err){this.processMessage.error(err);}
 sh.OnOutput = function(o,a){
	 this.hideProcessMessage();
	 if(!a) return;
	 var fileName = a['filename'];
	 document.location.href = ABSOLUTE_URL+"getfile.php?file="+fileName;

	 /*alert(o);
	 var sh2 = new GShell();
	 sh2.sendCommand("gframe -f excel/export -params `file=scadenze_contratti` --use-cache-contents -c `"+o+"`");*/
	}

 sh.sendCommand(cmd);
}

</script>
<?php
$template->End();

