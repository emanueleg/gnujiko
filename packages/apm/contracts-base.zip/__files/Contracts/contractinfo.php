<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 19-03-2015
 #PACKAGE: contracts-base
 #DESCRIPTION: Contract info
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO: 
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL, $_CMD, $_COMPANY_PROFILE;

$_BASE_PATH = "../";
$_AP = "contracts";

include($_BASE_PATH."var/templates/glight/index.php");
include_once($_BASE_PATH."include/userfunc.php");

$template = new GLightTemplate();
$template->includeCSS("contractinfo.css");
$template->includeObject("gcal");
$template->includeObject("editsearch");
$template->includeObject("gmutable");
$template->includeObject("fckeditor");
$template->includeInternalObject("serp");
$template->includeInternalObject("contactsearch");
$template->includeInternalObject("productsearch");
$template->includeInternalObject("servicesearch");
//$template->includeInternalObject("attachments");

include_once($_BASE_PATH."include/company-profile.php");
include_once($_BASE_PATH."include/countries.php");
include_once($_BASE_PATH."etc/commercialdocs/config.php");

$_DECIMALS = $_COMPANY_PROFILE['accounting']['decimals_pricing'];
$ret = GShell("pricelists list");
$_PRICELISTS = $ret['outarr'];
$_PRICELIST_BY_ID = array();
for($c=0; $c < count($_PRICELISTS); $c++)
 $_PRICELIST_BY_ID[$_PRICELISTS[$c]['id']] = $_PRICELISTS[$c];

/* GET LIST OF VAT RATES */
$ret = GShell("dynarc item-list -ap vatrates -get `percentage,vat_type`");
$_VAT_LIST = $ret['outarr']['items'];
$_VAT_BY_ID = array();
for($c=0; $c < count($_VAT_LIST); $c++)
 $_VAT_BY_ID[$_VAT_LIST[$c]['id']] = $_VAT_LIST[$c];

$_DEF_VATID = $_COMPANY_PROFILE['accounting']['freq_vat_used'];
$_DEF_VATRATE = $_VAT_BY_ID[$_DEF_VATID]['percentage'];
$_DEF_VATTYPE = $_VAT_BY_ID[$_DEF_VATID]['vat_type'];

/* CONTRACT INFO */
$docInfo = array();
$ret = GShell("dynarc item-info -ap ".$_AP." -id '".$_REQUEST['id']."' -extget `contractinfo,cdelements,contractschedule`");
if(!$ret['error'])
{
 $docInfo = $ret['outarr'];
 if($docInfo['subject_id'])
 {
  // get customer pricelist id
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT pricelist_id FROM dynarc_rubrica_items WHERE id='".$docInfo['subject_id']."'");
  $db->Read();
  $_CUST_PLID = $db->record['pricelist_id'];
  $db->Close();
 }
}

$_VATID = $docInfo['fee_vatid'] ? $docInfo['fee_vatid'] : $_DEF_VATID;
$_VATRATE = $docInfo['fee_vatrate'] ? $docInfo['fee_vatrate'] : $_DEF_VATRATE;
if(!$docInfo['commiss_vatid'])
 $docInfo['commiss_vatid'] = $_DEF_VATID;

/* GET CONFIG */
$config = array();
$ret = GShell("aboutconfig get-config -app contracts");
if(!$ret['error'])
 $config = $ret['outarr']['config'];

/* GET LIST OF CATEGORIES */
$_CT = "";

$ret = GShell("dynarc cat-list -ap '".$_AP."'");
$list = $ret['outarr'];
$_CAT_BY_ID = array();
for($c=0; $c < count($list); $c++)
{
 if($docInfo['cat_id'] == $list[$c]['id'])
  $_CT = $list[$c]['tag'];
 $_CAT_BY_ID[$list[$c]['id']] = $list[$c]['name'];
}


$_PERIODICITY = array(
	1 => "Mensile",
	2 => "Bimestrale",
	3 => "Trimestrale",
	4 => "Quadrimestrale",
	6 => "Semestrale",
	12 => "Annuale"
);

$template->Begin($docInfo['name']);

/* HEADER ---------------------------------------------------------------------------------------------------------- */
?>
<div class='docstyle-header'>
<table width='100%' cellspacing='0' cellpadding='0' border='0' class='docstyle'>
<tr><td class='docstyle-icon' rowspan='2'><img src='img/doc-icon.png'/></td>
	<td class='docstyle-title'><i><?php echo $docInfo['name']; ?></i></td>
	<td rowspan='2' align='right'>&nbsp;</td>
	<td rowspan='2' align='right' width='300' style='padding-right:20px'>
		<input type='button' class='button-blue' value='Stampa' onclick="Print()"/>
		<input type='button' class='button-blue' value="Salva e chiudi" onclick="Submit()" id='save-btn'/>
		<input type='button' class='button-exit' value="Esci" onclick='Template.Exit()'/></td></tr>
<tr><td class='docstyle-menu'><?php
 /*if($docInfo['ext_ticket_ref'])
  echo "Rif: <b>".$docInfo['ext_ticket_ref']."</b><br/>";*/
 echo "Data apertura: <b>".date('d/m/Y',$docInfo['ctime'])."</b>";
?></td></tr>
</table>
</div>
<?php


$template->Body("monosection", 1000);
/* CONTENUTI */
?>
<div class="gnujiko-template-content-outer" style="width:900px">
 <div class="gnujiko-template-content-inner">

  <!-- PAGE -->
  <div class="gnujiko-template-page" style="padding:0px;margin-top:50px">

   <div class="form-section">
    <table width='100%' cellspacing='0' cellpadding='0' border='0' class='form-table'>
	 <tr><td width='150'><label>Cliente</label></td>
		 <td style='padding-right:20px'><input type='text' class="contact" id='subject' style="width:100%" value="<?php echo $docInfo['subject_name']; ?>" modal='extended' fields='code_str,name' contactfields='phone,phone2,cell,email' ct='customers' refid="<?php echo $docInfo['subject_id']; ?>"/></td>
		 <td class='vsep' width='100'><label>Data reg.</label></td>
		 <td width='100'><input type='text' class="calendar" id='ctime' value="<?php echo date('d/m/Y',$docInfo['ctime']); ?>"/></td>
	 </tr>
    </table>
   </div>

   <div class="form-section">
    <table width='100%' cellspacing='0' cellpadding='0' border='0' class='form-table'>
	 <tr><td width='150'><label>Tipo di contratto</label></td>
		 <td style='padding-right:20px'><input type='text' class="dropdown" id='cat' style="width:100%" value="<?php echo $_CAT_BY_ID[$docInfo['cat_id']]; ?>" connect="catlist" retval="<?php echo $docInfo['cat_id']; ?>"/>
		  <?php
		   reset($_CAT_BY_ID);
		   echo "<ul class='popupmenu' id='catlist'>";
		   while(list($k,$v) = each($_CAT_BY_ID))
			echo "<li value='".$k."'>".$v."</li>";
		   echo "</ul>";
		  ?>
		 </td>
		 <td class='vsep' width='100'><label>Data inizio</label></td>
		 <td width='120' class='padding-right:20px'><input type='text' class="calendar" id='startdate' value="<?php echo date('d/m/Y',strtotime($docInfo['start_date'])); ?>"/></td>
		 <td class='vsep' width='100'><label>Durata</label></td>
		 <td width='100'><input type='text' class="edit" id='term' value="<?php echo $docInfo['term']; ?>" style="width:40px" onchange="updateSchedule()"/> <span class='gray'>mesi</span></td>
	 </tr>
    </table>
   </div>

   <div class="form-section">
    <table width='100%' cellspacing='0' cellpadding='0' border='0' class='form-table'>
	 <tr><td width='150'><label>Periodicit&agrave;</label></td>
		 <td style='padding-right:20px'><input type='text' class="dropdown" id='periodicity' style="width:100%" value="<?php echo $_PERIODICITY[$docInfo['periodicity']]; ?>" connect="periodicitylist" retval="<?php echo $docInfo['periodicity']; ?>"/>
		  <?php
		   reset($_PERIODICITY);
		   echo "<ul class='popupmenu' id='periodicitylist'>";
		   while(list($k,$v) = each($_PERIODICITY))
			echo "<li value='".$k."'>".$v."</li>";
		   echo "</ul>";
		  ?>
		 </td>
		 <td class='vsep' width='100'><label style='font-size:14px'>Tacito rinnovo</label></td>
		 <td width='120' class='padding-right:20px'><input type='text' class="dropdown" id='autorenewal' value="<?php echo $docInfo['autorenewal'] ? 'Si' : 'No'; ?>" style="width:50px" connect='autorenewlist'/>
		  <ul class='popupmenu' id='autorenewlist'>
		   <li value='0'>No</li>
		   <li value='1'>Si</li>
		  </ul>
		  </td>
		 <td class='vsep' width='100'><label>Monte ore</label></td>
		 <td width='100'><input type='text' class="edit" id='tothours' value="<?php echo $docInfo['total_hours']; ?>" style="width:50px"/> <span class='gray'>ore</span></td>
	 </tr>
    </table>
   </div>

   <div class="form-section">
    <table width='100%' cellspacing='0' cellpadding='0' border='0' class='form-table'>
	 <tr><td width='150'><label>Pagamento</label></td>
		 <td style='padding-right:20px' align='right'><span class='smalltext'>pagamento il giorno</span> <input type='text' class='dropdown' id='payday' connect='paydaylist' style='width:80px' retval="<?php echo $docInfo['payday']; ?>" value="<?php echo ($docInfo['payday'] == 'FM') ? 'fine mese' : $docInfo['payday']; ?>" />
		  <ul class='popupmenu' id='paydaylist'>
		   <?php
			for($c=1; $c < 32; $c++)
			 echo "<li value='".$c."'>".$c."</li>";
			echo "<li class='separator'>&nbsp;</li>";
			echo "<li value='FM'>fine mese</li>";
		   ?>
		  </ul>
		 </td>
		 <td class='vsep' width='100'><label>Canone<br/><small>(annuale)</small></label></td>
		 <td width='120' class='padding-right:20px'><input type='text' class="currency" id='fee' value="<?php echo number_format($docInfo['fee'],2,',','.'); ?>" style="width:80px"/> <span class='gray'>&euro;</span></td>
		 <td class='vsep' width='100'><label style='font-size:14px'>IVA su canone</label></td>
		 <td width='100'><input type='text' class="dropdown" id='vatrate' value="<?php echo $_VAT_BY_ID[$docInfo['fee_vatid']]['name']; ?>" style="width:100px" connect='feevatlist' retval="<?php echo $docInfo['fee_vatid']; ?>"/>
		  <ul class='popupmenu' id='feevatlist'>
		   <?php
			for($c=0; $c < count($_VAT_LIST); $c++)
			 echo "<li value='".$_VAT_LIST[$c]['id']."' vatrate='".$_VAT_LIST[$c]['percentage']."'>".$_VAT_LIST[$c]['name']."</li>";
		   ?>
		  </ul>
		 </td>
	 </tr>
    </table>
   </div>

   <div class="form-section">
    <table width='100%' cellspacing='0' cellpadding='0' border='0' class='form-table'>
	 <tr><td width='150'><label style='font-size:12px'>Titolo<br/>commissione</label></td>
		 <td style='padding-right:20px'><input type='text' class="edit" id='commisstitle' style="width:100%" value="<?php echo $docInfo['commiss_title']; ?>" placeholder="Es: commissione bancaria"/></td>
		 <td class='vsep' width='100'><label style='font-size:12px'>Importo<br/>commissione</label></td>
		 <td width='120' class='padding-right:20px'><input type='text' class="currency" id='commissamount' value="<?php echo number_format($docInfo['commiss_amount'],2,',','.'); ?>" style="width:80px;text-align:right"/> <span class='gray'>&euro;</span></td>
		 <td class='vsep' width='100'><label style='font-size:12px'>IVA su<br/>commissione</label></td>
		 <td width='100'><input type='text' class="dropdown" id='commissvat' value="<?php echo $_VAT_BY_ID[$docInfo['commiss_vatid']]['name']; ?>" style="width:100px" connect='commissvatlist' retval="<?php echo $docInfo['commiss_vatid']; ?>"/>
		  <ul class='popupmenu' id='commissvatlist'>
		   <?php
			for($c=0; $c < count($_VAT_LIST); $c++)
			 echo "<li value='".$_VAT_LIST[$c]['id']."' vatrate='".$_VAT_LIST[$c]['percentage']."'>".$_VAT_LIST[$c]['name']."</li>";
		   ?>
		  </ul>
		 </td>
	 </tr>
    </table>
   </div>

   <div class="form-section">
    <table width='100%' cellspacing='0' cellpadding='0' border='0' class='form-table'>
	 <tr><td width='150'><label>Agente</label></td>
		 <td style='padding-right:20px'><input type='text' class="contact" id='agent' style="width:100%" value="<?php echo $docInfo['agent_name']; ?>" ct="agents"/></td>
		 <td class='vsep' width='100'><label>Provvigione</label></td>
		 <td width='120' class='padding-right:20px'><input type='text' class="edit" id='agentcommiss' value="<?php echo sprintf('%.2f',$docInfo['agent_commiss']); ?>" style="width:80px;text-align:right"/> <span class='gray'>%</span></td>
		 <td class='vsep' width='100'>&nbsp;</td>
		 <td width='100'>&nbsp;</td>
	 </tr>
    </table>
   </div>

   <div class="form-section">
    <table width='100%' cellspacing='0' cellpadding='0' border='0' class='form-table'>
	 <tr><td width='150' valign='top'><label>Descrizione</label></td>
		<td><textarea class='textarea' id='description' style="width:100%;height:250px"><?php echo $docInfo['desc']; ?></textarea></td>
	 </tr>
    </table>
   </div>

   <div class="form-footer">
    <ul class='horizontal-menu' id='tab-menu'>
	 <!-- <li class="selected blue-selected" connect="element-list-page">Eventuali altri addebiti</li> -->
	 <li class="selected orange-selected" connect="schedule-list-page">Scadenziario</li>
    </ul>
   </div>

  </div> <!-- EOF - gnujiko-template-page -->

  <!-- ELEMENT LIST PAGE -->
  <div id='element-list-page' style='display:none'>
   <div class='gnujiko-template-page'>
	 <input type='button' class='button-blue' value="Aggiungi riga" onclick="InsertCustomRow()"/> 
	 <input type='button' class='button-blue' value="Aggiungi nota" onclick="InsertCustomRow('note')"/>
	 &nbsp;&nbsp;&nbsp;&nbsp;<span class='mediumtext'> oppure: </span>
	 <input type='text' class='search' style='width:240px' placeholder="Inserisci un articolo" id='prod-search' value="" emptyonclick='true'/>
	 <input type='text' class='search' style='width:240px' placeholder="Inserisci un servizio" id='serv-search' value="" emptyonclick='true'/>
	 <br/>
	 <?php
	 $_ITEMS_COLUMNS = array(
		"code"=>array("title"=>"Codice", "default"=>true, "width"=>60, "sortable"=>true, "editable"=>true),
		"description"=>array("title"=>"Articolo / Descrizione", "default"=>true, "minwidth"=>250, "sortable"=>true, "editable"=>true),
		"qty"=>array("title"=>"Qta", "default"=>true, "width"=>40, "editable"=>true, "style"=>"text-align:center"),
		"units"=>array("title"=>"U.M.", "default"=>true, "width"=>40, "editable"=>true, "style"=>"text-align:center"),
		"unitprice"=>array("title"=>"Pr. Unit", "default"=>true, "width"=>60, "editable"=>true, "format"=>"currency", "decimals"=>$_DECIMALS),
		"discount"=>array("title"=>"Sconto", "default"=>true, "width"=>60, "editable"=>true, "format"=>"currency percentage", "decimals"=>$_DECIMALS),
		"vat"=>array("title"=>"I.V.A.", "default"=>true, "width"=>40, "editable"=>true, "format"=>"percentage", "style"=>"text-align:left"),
		"price"=>array("title"=>"Totale", "default"=>true, "width"=>120, "minwidth"=>100, "style"=>"text-align:center", "editable"=>true, "format"=>"currency", "decimals"=>$_DECIMALS),
		"vatprice"=>array("title"=>"Tot. + IVA", "width"=>120, "minwidth"=>100, "style"=>"text-align:center", "editable"=>true, "format"=>"currency", "decimals"=>$_DECIMALS),
		);

	 $_COLUMNS = array();
	 if(is_array($config['itemscolumns']) && count($config['itemscolumns']))
	 {
	  for($c=0; $c < count($config['itemscolumns']); $c++)
	  {
	   $col = $config['itemscolumns'][$c];
	   $_COLUMNS[$col['tag']] = $_ITEMS_COLUMNS[$col['tag']];
	   $_COLUMNS[$col['tag']]['title'] = $col['title'];
	   $_COLUMNS[$col['tag']]['width'] = $col['width'];
	   $_COLUMNS[$col['tag']]['hidden'] = false;
	  }
	  reset($_ITEMS_COLUMNS);
	  while(list($k,$v) = each($_ITEMS_COLUMNS))
	  {
	   if($_COLUMNS[$k]) continue;
	   $_COLUMNS[$k] = $v;
	   $_COLUMNS[$k]['hidden'] = true;
	  }
	  $_ITEMS_COLUMNS = $_COLUMNS;
	 }
	 else
	  $_COLUMNS = $_ITEMS_COLUMNS;
	 ?>
	 <div class="gmutable" style="height:370px;margin-top:16px">
	 <table id='doctable' class="gmutable" width="100%" cellspacing="0" cellpadding="0" border="0">
	 <tr>
	 <?php
	 reset($_COLUMNS);
	 while(list($k,$v) = each($_COLUMNS))
	 {
	  echo "<th id='".$k."'";
	  if($v['width']) echo " width='".$v['width']."'";
	  if($v['sortable']) echo " sortable='true'";
	  if($v['editable']) echo " editable='true'";
	  if($v['minwidth']) echo " minwidth='".$v['minwidth']."'";
	  if($v['format']) echo " format='".$v['format']."'";
	  if($v['decimals']) echo " decimals='".$v['decimals']."'";
	  if($v['hidden'])
	   echo " style='display:none;".$v['style']."'";
	  else if($v['style'])
	   echo " style='".$v['style']."'";
	  echo ">".strtoupper($v['title'])."</th>";
	 }

	 ?>
	 <th style='width:22px' id='btndel'>&nbsp;</th>
	 </tr>
	 <?php
	 $_TOTALS = 0;
 	 for($c=0; $c < count($docInfo['elements']); $c++)
	 {
	  $itm = $docInfo['elements'][$c];
	  echo "<tr id='".$itm['id']."' type='".$itm['type']."' refap='".$itm['ref_ap']."' refid='".$itm['ref_id']."' vatid='".$itm['vatid']."' vattype='"
		.$itm['vattype']."'>";
	  if(strtolower($itm['type']) == "note")
	   echo "<td colspan='9'><span class='graybold'>".$itm['desc']."</span></td><td><img src='".$_ABSOLUTE_URL."Contracts/img/delete-black.png' width='22' onclick='DeleteRow(this.parentNode.parentNode)' style='cursor:pointer' title='Elimina'/></td>";
	  else
	  {
	   $qty = $itm['qty'];

	   $discount = $itm['discount_inc'] ? $itm['discount_inc'] : 0;
	   $discount2 = 0;
	   $discount3 = 0;

	   if($itm['discount_perc'])
	    $discount = $itm['price'] ? ($itm['price']/100)*$itm['discount_perc'] : 0;

	   $amount = round(((($itm['price']-$discount)-$discount2)-$discount3) * $qty, $_DECIMALS);
	   $total = $amount;

	   reset($_COLUMNS);
	   while(list($k,$v) = each($_COLUMNS))
	   {
		switch($k)
		{
		 case 'code' : echo "<td><span class='graybold'>".$itm['code']."</span></td>"; break;
		 case 'sn' : case 'serialnumber' : echo "<td><span class='graybold'>".$itm['serialnumber']."</span></td>"; break;
		 case 'lot' : echo "<td><span class='graybold'>".$itm['lot']."</span></td>"; break;
		 case 'description' : echo "<td><span class='graybold doubleline'>".$itm['name']."</span></td>"; break;
		 case 'qty' : echo "<td><span class='graybold 13 center'>".$itm['qty']."</span></td>"; break;
		 case 'units' : echo "<td><span class='graybold 13 center'>".$itm['units']."</span></td>"; break;
		 case 'unitprice' : echo "<td realvalue='".$itm['price']."'><span class='graybold' title='Valore reale: "
			.number_format($itm['price'],4,',','.')."'>".number_format($itm['price'],$_DECIMALS,',','.')."</span></td>"; break;
		 case 'plbaseprice' : echo "<td realvalue='".$itm['listbaseprice']."'><span class='graybold' title='Valore reale: "
			.number_format($itm['listbaseprice'],4,',','.')."'>".number_format($itm['listbaseprice'],$_DECIMALS,',','.')."</span></td>"; break;
		 case 'plmrate' : echo "<td><span class='graybold'>".$itm['listmrate']."%</span></td>"; break;
		 case 'pldiscperc' : echo "<td><span class='graybold'>".$itm['listdiscperc']."%</span></td>"; break;

		 case 'discount' : {
		     if($itm['discount_perc'])
		      echo "<td realvalue='".$itm['discount_perc']."%'><span class='graybold'>".$itm['discount_perc']."%</span></td>";
		     else if($itm['discount_inc'])
		      echo "<td realvalue='".$itm['discount_inc']."'><span class='graybold'>&euro;. ".number_format($itm['discount_inc'],$_DECIMALS,',','.')."</span></td>";
		     else
		      echo "<td><span class='graybold'>&nbsp;</span></td>";
			} break;
		 case 'discount2' : echo "<td><span class='graybold'>".($itm['discount2'] ? $itm['discount2'] : "0")."%</span></td>"; break;
		 case 'discount3' : echo "<td><span class='graybold'>".($itm['discount3'] ? $itm['discount3'] : "0")."%</span></td>"; break;
		 case 'vat' : echo "<td><span class='graybold center'>".$itm['vatrate']."%</span></td>"; break;
		 case 'price' : echo "<td realvalue='".$amount."'><span class='eurogreen' title='Valore reale: "
			.number_format($amount,4,',','.')."'><em>&euro;</em>".number_format($amount,$_DECIMALS,',','.')."</span></td>"; break;
		 case 'vatprice' : echo "<td realvalue='".($amount+$itm['vat'])."'><span class='eurogreen' title='Valore reale: ".number_format($amount+$itm['vat'],4,',','.')."'><em>&euro;</em>".number_format($amount+$itm['vat'],$_DECIMALS,',','.')."</span></td>"; break;
		 case 'pricelist' : echo "<td pricelistid='".$itm['pricelist_id']."'><span class='graybold'>".($itm['pricelist_id'] ? $_PRICELIST_BY_ID[$itm['pricelist_id']]['name'] : $_PLINFO['name'])."</span></td>"; break;
		 default : echo "<td><span class='graybold'>".$itm[$k]."</span></td>"; break;
		} // eof- switch
	   } // eof - while
	   echo "<td><img src='".$_ABSOLUTE_URL."Contracts/img/delete-black.png' width='22' onclick='DeleteRow(this.parentNode.parentNode)' style='cursor:pointer' title='Elimina'/></td>";
	  } // eof - else
	  $_TOTALS+= ($amount+$itm['vat']);
	  echo "</tr>";
	 } // eof - for
	 ?>
	 </table>
	 </div>
	 <table width='100%' class="glight-standard-table" width="100%" cellspacing="0" cellpadding="0" border="0">
	 <tr><th style="text-align:left">&nbsp;Totale + IVA (incluso canone)</th>
		 <th id="footer-total" style="text-align:right;width:120px"><?php echo number_format($docInfo['total'],2,",","."); ?></th>
		 <th width='32'>&nbsp;</th></tr>
	 </table>
   </div>
  </div> <!-- EOF - ELEMENT LIST PAGE -->

  <!-- SCHEDULE LIST PAGE -->
  <div id='schedule-list-page'>
   <div class='gnujiko-template-page'>
	<div class="gmutable" style="height:440px;border:0px">
    <table id='scheduletable' width='100%' cellspacing='0' cellpadding='0' border='0' class='gmutable'>
	 <tr><th id='sc_idx' width='22' style='text-align:center'>N</th>
		 <th id='sc_expiry' editable='true' format='date' width='80' style='text-align:center'>Scadenza</th>
		 <th id='sc_canon' format='currency' width='80' style='text-align:right'>Canone</th>
		 <th id='sc_commiss' format='currency' width='80' style='text-align:right'>Commiss.</th>
		 <th id='sc_amount' format='currency' width='60' style='text-align:right;display:none'>Imponibile</th>
		 <th id='sc_vat' format='currency' width='60' style='text-align:right'>I.V.A.</th>
		 <th id='sc_total' format='currency' width='80' style='text-align:right'>Totale</th>
		 <th id='sc_geninvoice' width='60'>&nbsp;</th>
		 <th id='sc_invoice' width='300' style='text-align:center'>Fattura</th>
		 <th id='sc_paid' format='checkbox' width='60' style='text-align:center'>Pagato</th>
	 </tr>
	 <?php
	 for($c=0; $c < count($docInfo['schedules']); $c++)
	 {
	  $item = $docInfo['schedules'][$c];
	  echo "<tr id='".$item['id']."'><td align='center'><span class='graybold'>".($c+1)."</span></td>";
	  echo "<td align='center'><span class='graybold'>".date('d/m/Y',strtotime($item['expiry']))."</span></td>";
	  echo "<td align='right'><span class='graybold'>".number_format($item['canon'],2,',','.')."</span></td>";
	  echo "<td align='right'><span class='graybold'>".number_format($item['commiss'],2,',','.')."</span></td>";
	  echo "<td align='right'><span class='graybold'>".number_format($item['amount'],2,',','.')."</span></td>";
	  echo "<td align='right'><span class='graybold'>".number_format($item['vat'],2,',','.')."</span></td>";
	  echo "<td align='right'><span class='graybold'>".number_format($item['total'],2,',','.')."</span></td>";
	  echo "<td align='center'>".(!$item['invoice_id'] ? "<img src='img/next-blue.png' style='cursor:pointer' title='Genera fattura' onclick='generateScheduleInvoice(this)'/>" : "&nbsp;")."</td>";
	  echo "<td align='center' style='font-size:12px'>".($item['invoice_id'] ? "<a href='".$_ABSOLUTE_URL."GCommercialDocs/docinfo.php?id=".$item['invoice_id']."' target='GCD-"
		.$item['invoice_id']."'>".$item['invoice_name']."</a>" : "&nbsp;")."</td>";
	  echo "<td align='center'><input type='checkbox'".($item['paid'] ? " checked='true'" : "")."/></td></tr>";
	 }
	 ?>
    </table>
	</div>
   </div>
  </div> <!-- EOF - ELEMENT LIST PAGE -->

 </div> <!-- EOF - gnujiko-template-content-inner -->
</div> <!-- EOF - gnujiko-template-content-outer -->
<?php
/* EOF - CONTENUTI */
/*-------------------------------------------------------------------------------------------------------------------*/
$template->Footer();
/*-------------------------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------------------------*/
?>
<script>
var AP = "<?php echo $_AP; ?>";
var ID = "<?php echo $docInfo['id']; ?>";
var CT = "<?php echo $_CT; ?>";
var ON_PRINTING = false;
var ON_EXPORT = false;
var DECIMALS = <?php echo $_DECIMALS ? $_DECIMALS : "2"; ?>;
var DEF_VATID = <?php echo $_DEF_VATID; ?>;
var DEF_VATRATE = <?php echo $_DEF_VATRATE; ?>;
var DEF_VATTYPE = "<?php echo $_DEF_VATTYPE; ?>";
var VAT_ID = <?php echo $_VATID; ?>;
var VAT_RATE = <?php echo $_VATRATE; ?>;

var FEE_VATID = VAT_ID;
var FEE_VATRATE = VAT_RATE;

var TB = null;
var NEW_ROWS = new Array();
var UPDATED_ROWS = new Array();
var DELETED_ROWS = new Array();

var SCTB = null;
var SCNEW_ROWS = new Array();
var SCUPDATED_ROWS = new Array();
var SCDELETED_ROWS = new Array();
var SC_UNSET_ALL = false;

var TOT_AMOUNT = "<?php echo $docInfo['amount']; ?>";
var TOT_VAT = "<?php echo $docInfo['vat']; ?>";
var TOT_TOTAL = "<?php echo $docInfo['total']; ?>";

var SAVE_SH = null;

Template.OnExit = function(){
	if(window.opener)
	{
	 window.opener.document.location.reload();
	 window.close();
	}
	else
	 document.location.href = ABSOLUTE_URL+"Contracts/index.php";
	return false;
}

Template.OnInit = function(){
 this.initEd(document.getElementById("subject"), "contactextended").OnSearch = function(){};
 this.initEd(document.getElementById('cat'), 'dropdown');
 this.initEd(document.getElementById('ctime'), 'date');
 this.initEd(document.getElementById('startdate'), 'date').OnDateChange = function(){updateSchedule();};
 this.initEd(document.getElementById('periodicity'), 'dropdown').onchange = function(){updateSchedule();};
 this.initEd(document.getElementById('autorenewal'), 'dropdown');
 this.initEd(document.getElementById("agent"), "contact").OnSearch = function(){};
 this.initEd(document.getElementById("description"), "fckeditor", "Basic");
 this.initEd(document.getElementById('fee'), 'currency').OnChange = function(){updateTotals();}
 this.initEd(document.getElementById('vatrate'), 'dropdown').onchange = function(){
	 FEE_VATID = this.getValue();
	 FEE_VATRATE = this.selectedItem.getAttribute('vatrate');
	 updateTotals();
	}
 this.initEd(document.getElementById('commissamount'),'currency').OnChange = function(){updateSchedule();}
 this.initEd(document.getElementById('commissvat'),'dropdown').onchange = function(){updateSchedule();};
 this.initEd(document.getElementById('payday'),'dropdown').onchange = function(){updateSchedule();};

 this.initTabMenu(document.getElementById('tab-menu'));

 this.initEd(document.getElementById("prod-search"), "gmart").OnSearch = function(){
	 if(this.value && this.data)
	  InsertRow(this.data['ap'], this.data['id'], "article");
	};

 this.initEd(document.getElementById("serv-search"), "gserv").OnSearch = function(){
	 if(this.value && this.data)
	  InsertRow(this.data['ap'], this.data['id'], "service");
	};

 /* TABLE **/
  TB = new GMUTable(document.getElementById('doctable'));
  TB.OnBeforeAddRow = function(r){
		r.setAttribute('vatid',DEF_VATID);
		r.setAttribute('vattype',DEF_VATTYPE);

	   <?php
	    reset($_ITEMS_COLUMNS);
	    $idx = 0;
	    while(list($k,$v) = each($_ITEMS_COLUMNS))
	    {
		 switch($k)
		 {
		  case 'code' : case 'sn' : case 'serialnumber' : case 'lot' : case 'account' : case 'unitprice' : case 'discount' : case 'discount2' : case 'discount3' : case 'pricelist' : case 'plbaseprice' : case 'plmrate' : case 'pldiscperc' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold'></span>\";\n"; break;
		  case 'description' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold doubleline'></span>\";\n"; break;
		  case 'qty' : case 'units' : case 'weight' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold 13 center'></span>\";\n"; break;
		  case 'vat' : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold center'>\"+DEF_VATRATE+\"%</span>\";\n"; break;
		  case 'price' : case 'vatprice' : echo "r.cells[".$idx."].innerHTML = \"<span class='eurogreen'></span>\";\n"; break;
		  default : echo "r.cells[".$idx."].innerHTML = \"<span class='graybold'></span>\";\n"; break;
		 }
	     $idx++;
	    }
	   ?>
	   r.cells["<?php echo $idx; ?>"].innerHTML = "<img src='"+ABSOLUTE_URL+"Contracts/img/delete-black.png' width='22' onclick='DeleteRow(this.parentNode.parentNode)' style='cursor:pointer' title='Elimina'/"+">";

	   NEW_ROWS.push(r);
	};

  TB.OnSelectRow = function(r){};
  TB.OnUnselectRow = function(r){};
  TB.OnDeleteRow = function(r){
	 if(r.id)
	  DELETED_ROWS.push(r);
	};
  TB.OnBeforeCellEdit = function(r,cell,value){};

  TB.OnCellEdit = function(r,cell,value,data){
	 switch(cell.tag)
	 {
	  case 'qty' : updateTotals(r); break;
	  case 'unitprice' : {
		 r.unitpriceChanged=true;
		 cell.getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(parseCurrency(value),4);
		 updateTotals(r); 
		} break;

	  case 'discount' : {
		 if(value.indexOf("%") < 0)
		 {
		  value = value.replace(/\u20ac/g, "");
		  value = value.replace(". ","");
		  cell.getElementsByTagName('SPAN')[0].innerHTML = "&euro;. "+formatCurrency(parseCurrency(value),DECIMALS);
		 }
		 r.discountChanged=true;
		 updateTotals(r);
		} break;

	  case 'discount2' : {
		 r.discountChanged=true;
		 updateTotals(r);
		} break;

	  case 'discount3' : {
		 r.discountChanged=true;
		 updateTotals(r);
		} break;

	  case 'vat' : {
		 if(data)
		 {
		  r.setAttribute('vatid',data['id']);
		  r.setAttribute('vattype',data['vat_type']);
		  updateTotals(r);
		 }
		 else
		 {
		  var sh = new GShell();
		  sh.OnOutput = function(o,a){
			 if(!a)
			 {
		  	  r.setAttribute('vatid',0);
		  	  r.setAttribute('vattype',"");
			  updateTotals(r);
			  return;
			 }
			 r.setAttribute('vatid',a['items'][0]['id']);
			 r.setAttribute('vattype',a['items'][0]['vat_type']);
			 r.cell['vat'].setValue(a['items'][0]['percentage']);
			 updateTotals(r);
			}
		  sh.sendCommand("dynarc search -ap `vatrates` -fields code_str,name `"+value+"` -limit 1 --order-by `code_str ASC` -get percentage,vat_type");
		 }
		} break;

	  case 'price' : {
		 var unitPrice = 0;
		 var qty = parseFloat(r.cell['qty'].getValue());
		 if(!qty)
		  alert("Impossibile effettuare il calcolo con quantità a zero"); 
		 var disc1 = r.cell['discount'].getValue();
		 var disc2 = 0; //var disc2 = r.cell['discount2'].getValue();
		 var disc3 = 0; //var disc3 = r.cell['discount3'].getValue();
		 //if(disc2) disc2 = parseFloat(disc2);
		 //if(disc3) disc3 = parseFloat(disc3);

		 var amount = parseCurrency(value);
		 if(amount && qty)
		 {
		  if(disc3)
		   amount = (amount/(100-disc3))*100;
		  if(disc2)
		   amount = (amount/(100-disc2))*100;
		  if(disc1)
		  {
		   if(disc1.indexOf("%") < 0)
		   {
			disc1 = disc1.replace(/\u20ac/g, "");
			disc1 = disc1.replace(". ","");
			disc1 = parseCurrency(disc1);
			amount = amount+disc1;			
		   }
		   else
		   {
			disc1 = parseFloat(disc1);
			amount = (amount/(100-disc1))*100;
		   }
		  }
		  if(amount)
		   unitPrice = amount/qty;
		 }
		 r.cell['unitprice'].setValue(formatCurrency(unitPrice,DECIMALS),unitPrice);
		 if(r.getAttribute('refid'))
		  r.unitpriceChanged=true;
		 r.cell['unitprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(unitPrice,4);
		 cell.getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(unitPrice,4);
		 updateTotals(r); 
		} break;

	  case 'vatprice' : {
		 var unitPrice = 0;
		 var qty = parseFloat(r.cell['qty'].getValue());
		 if(!qty)
		  alert("Impossibile effettuare il calcolo con quantità a zero"); 
		 var vat = parseFloat(r.cell['vat'].getValue());

		 var disc1 = r.cell['discount'].getValue();
		 var disc2 = 0; //var disc2 = r.cell['discount2'].getValue();
		 var disc3 = 0; //var disc3 = r.cell['discount3'].getValue();
		 //if(disc2) disc2 = parseFloat(disc2);
		 //if(disc3) disc3 = parseFloat(disc3);

		 var amount = parseCurrency(value);
		 if(vat)
		  amount = (amount/(100+vat))*100;
		 if(amount && qty)
		 {
		  if(disc3)
		   amount = (amount/(100-disc3))*100;
		  if(disc2)
		   amount = (amount/(100-disc2))*100;
		  if(disc1)
		  {
		   if(disc1.indexOf("%") < 0)
		   {
			disc1 = disc1.replace(/\u20ac/g, "");
			disc1 = disc1.replace(". ","");
			disc1 = parseCurrency(disc1);
			amount = amount+disc1;			
		   }
		   else
		   {
			disc1 = parseFloat(disc1);
			amount = (amount/(100-disc1))*100;
		   }
		  }
		  if(amount)
		   unitPrice = amount/qty;
		 }
		 r.cell['unitprice'].setValue(formatCurrency(unitPrice,DECIMALS),unitPrice);
		 if(r.getAttribute('refid'))
		  r.unitpriceChanged=true;
		 r.cell['unitprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(unitPrice,4);
		 cell.getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(unitPrice,4);
		 updateTotals(r); 
		} break;
	 } // EOF - SWITCH
	 if(r.id && (UPDATED_ROWS.indexOf(r) < 0))
	  UPDATED_ROWS.push(r);
	};

  TB.OnRowMove = function(r){
	 if(r.id && (UPDATED_ROWS.indexOf(r) < 0)) UPDATED_ROWS.push(r);
	 else if(!r.id && (NEW_ROWS.indexOf(r) < 0)) NEW_ROWS.push(r);
	}

 /* SCHEDULE TABLE */
 SCTB = new GMUTable(document.getElementById('scheduletable'), {autoresize:false, autoaddrows:false, orderable:false});
 SCTB.OnBeforeAddRow = function(r){
	 for(var c=0; c < this.Fields.length; c++)
	 {
	  switch(this.Fields[c].name)
	  {
	   case 'sc_paid' : {
		 r.cells[c].innerHTML = "<input type='checkbox'/"+">";
		 r.cells[c].style.textAlign='center';
		} break;

	   case 'sc_idx' : case 'sc_expiry' : {
		 r.cells[c].innerHTML = "<span class='graybold'></span>";
		 r.cells[c].style.textAlign='center';
		} break;

	   case 'sc_canon' : case 'sc_commiss' : case 'sc_amount' : case 'sc_vat' : case 'sc_total' : {
		 r.cells[c].innerHTML = "<span class='graybold'></span>";
		 r.cells[c].style.textAlign='right';
		} break;


	   /*case 'sc_geninvoice' : {
		 r.cells[c].innerHTML = "<img src='img/next-blue.png' style='cursor:pointer' title='Genera fattura' onclick='generateScheduleInvoice(this)'/"+">";
		 r.cells[c].style.textAlign='center';
		} break; */

	   default : r.cells[c].innerHTML = "<span class='graybold'></span>"; break;
	  }
	 }
	 SCNEW_ROWS.push(r);
	};

 SCTB.OnDeleteRow = function(r){
	 if(r.id)
	  SCDELETED_ROWS.push(r);
	}
 SCTB.OnCellEdit = function(r,cell,value,data){
	 /*switch(cell.tag)
	 {
	  
	 }*/
	 if(r.id && (SCUPDATED_ROWS.indexOf(r) < 0))
	  SCUPDATED_ROWS.push(r);
	}
}

function Submit()
{
 var catId = document.getElementById("cat").getValue();
 var subjectId = document.getElementById("subject").getId();
 var subjectName = document.getElementById("subject").value;
 var ctime = document.getElementById("ctime").isodate;
 var desc = document.getElementById("description").getValue();
 var startDate = document.getElementById('startdate').isodate;
 var term = document.getElementById('term').value;
 var periodicity = document.getElementById('periodicity').getValue();
 var fee = parseCurrency(document.getElementById('fee').value);
 var feeVatId = document.getElementById('vatrate').getValue();
 var feeVatRate = document.getElementById('vatrate').selectedItem.getAttribute('vatrate');
 var tothours = document.getElementById('tothours').value;
 var agentId = document.getElementById("agent").getId();
 var agentName = document.getElementById("agent").value;
 var agentCommiss = parseFloat(document.getElementById('agentcommiss').value);
 var autorenew = document.getElementById('autorenewal').getValue();
 var commissTitle = document.getElementById('commisstitle').value;
 var commissAmount = parseCurrency(document.getElementById('commissamount').value);
 var commissVatId = document.getElementById('commissvat').getValue();
 var commissVatRate = document.getElementById('commissvat').selectedItem.getAttribute('vatrate');
 var payDay = document.getElementById('payday').getValue();

 var eD = new Date();
 eD.setFromISO(startDate);
 eD.NextMonth(term);
 var endDate = eD.printf('Y-m-d');

 // GET TOTALS //
 var amount = TOT_AMOUNT;
 var vat = TOT_VAT;
 var total = TOT_TOTAL;
 

 SAVE_SH = new GShell();
 SAVE_SH.showProcessMessage("Salvataggio in corso", "Attendere prego, è in corso il salvataggio del documento");
 SAVE_SH.OnError = function(err){SAVE_SH.processMessage.error(err);}
 SAVE_SH.OnOutput = function(o,a){
	 saveElements(a);
	}

 var cmd = "dynarc edit-item -ap '"+AP+"' -id '"+ID+"' -cat '"+catId+"' -ctime '"+ctime+"' -desc `"+desc+"` -extset `contractinfo.subjid='"+subjectId+"',subjname='''"+subjectName+"''',startdate='"+startDate+"',enddate='"+endDate+"',term='"+term+"',periodicity='"+periodicity+"',fee='"+fee+"',feevatid='"+feeVatId+"',feevatrate='"+feeVatRate+"',tothours='"+tothours+"',agentid='"+agentId+"',agentname='''"+agentName+"''',agentcommiss='"+agentCommiss+"',autorenewal='"+autorenew+"',amount='"+amount+"',vat='"+vat+"',total='"+total+"',commtitle='''"+commissTitle+"''',commamount='"+commissAmount+"',commvatid='"+commissVatId+"',commvatrate='"+commissVatRate+"',payday='"+payDay+"'`";

 SAVE_SH.sendCommand(cmd);
}

function saveElements(a)
{
 var sh = new GShell();
 sh.OnError = function(err){SAVE_SH.processMessage.error(err);}
 sh.OnFinish = function(){saveSchedule();}

 for(var c=0; c < NEW_ROWS.length; c++)
 {
  var r = NEW_ROWS[c];
  saveElement(r,sh);
 }

 for(var c=0; c < UPDATED_ROWS.length; c++)
 {
  var r = UPDATED_ROWS[c];
  saveElement(r,sh,r.id);
 }

 for(var c=0; c < DELETED_ROWS.length; c++)
  sh.sendCommand("dynarc edit-item -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>` -extunset `cdelements.id="+DELETED_ROWS[c].id+"`");

 if(!NEW_ROWS.length && !UPDATED_ROWS.length && !DELETED_ROWS.length)
  return saveSchedule();
}

function saveElement(r,sh,id)
{
 var vatId = r.getAttribute('vatid') ? r.getAttribute('vatid') : 0;
 var vatType = r.getAttribute('vattype') ? r.getAttribute('vattype') : "";
 var cdelementsQry = id ? "id="+id : "type='"+r.getAttribute('type')+"'";

 switch(r.getAttribute('type'))
 {
  case 'note' : cdelementsQry+= ",desc='''"+r.cells[0].getElementsByTagName('SPAN')[0].innerHTML+"''',ordering="+r.rowIndex; break;
  default : {
	 var discount = ((r.cell['discount'].getValue().indexOf("%") > 0) ? r.cell['discount'].getValue() : parseCurrency(r.cell['discount'].getValue()));
	 //var discount2 = r.cell['discount2'].getValue() ? parseFloat(r.cell['discount2'].getValue()) : 0;
	 //var discount3 = r.cell['discount3'].getValue() ? parseFloat(r.cell['discount3'].getValue()) : 0;

	 cdelementsQry+= ",refap='"+r.getAttribute('refap')+"',refid='"+r.getAttribute('refid')+"',code='"+r.cell['code'].getValue()+"',name='''"+r.cell['description'].getValue()+"''',qty='"+r.cell['qty'].getValue()+"',units='"+r.cell['units'].getValue()+"',price='"+parseCurrency(r.cell['unitprice'].getValue())+"',discount='"+discount+"',vatrate='"+parseFloat(r.cell['vat'].getValue())+"',vatid='"+vatId+"',vattype='"+vatType+"'"+(!id ? ",ordering="+r.rowIndex : "");
	} break;
 }

 if(sh)
  sh.sendCommand("dynarc edit-item -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>` -extset `cdelements."+cdelementsQry+"`");
 else
  return cdelementsQry;
}

function saveSchedule()
{
 var sh = new GShell();
 sh.OnError = function(err){SAVE_SH.processMessage.error(err);}
 sh.OnFinish = function(){saveFinish();}

 if(SC_UNSET_ALL)
  sh.sendCommand("dynarc edit-item -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>` -extunset `contractschedule.all=true`"); 

 for(var c=0; c < SCNEW_ROWS.length; c++)
 {
  var r = SCNEW_ROWS[c];
  saveScheduleItem(r,sh);
 }

 for(var c=0; c < SCUPDATED_ROWS.length; c++)
 {
  var r = SCUPDATED_ROWS[c];
  saveScheduleItem(r,sh,r.id);
 }

 for(var c=0; c < SCDELETED_ROWS.length; c++)
  sh.sendCommand("dynarc edit-item -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>` -extunset `contractschedule.id="+SCDELETED_ROWS[c].id+"`");

 if(!SCNEW_ROWS.length && !SCUPDATED_ROWS.length && !SCDELETED_ROWS.length)
  return saveFinish();
}

function saveScheduleItem(r, sh, id)
{
 var feeVatId = document.getElementById('vatrate').getValue();
 var feeVatRate = document.getElementById('vatrate').selectedItem.getAttribute('vatrate');
 var commissVatId = document.getElementById('commissvat').getValue();
 var commissVatRate = document.getElementById('commissvat').selectedItem.getAttribute('vatrate');

 var qry = "";
 qry+= "canon='"+r.cell['sc_canon'].getValue()+"',canonvatid='"+feeVatId+"',canonvatrate='"+feeVatRate+"'";
 qry+= ",commiss='"+r.cell['sc_commiss'].getValue()+"',commissvatid='"+commissVatId+"',commissvatrate='"+commissVatRate+"'";
 qry+= ",amount='"+r.cell['sc_amount'].getValue()+"',vat='"+r.cell['sc_vat'].getValue()+"',total='"+r.cell['sc_total'].getValue()+"'";
 qry+= ",expiry='"+strdatetime_to_iso(r.cell['sc_expiry'].getValue()).substr(0,10)+"',paid='"+(r.cell['sc_paid'].getValue() ? "1" : "0")+"'";

 if(id)
  qry = "id='"+id+"',"+qry;

 sh.sendCommand("dynarc edit-item -ap `<?php echo $_AP; ?>` -id `<?php echo $docInfo['id']; ?>` -extset `contractschedule."+qry+"`");
}

function saveFinish()
{
 SAVE_SH.hideProcessMessage();
 Template.Exit();
}

function Print(callback)
{
 var PDF_FILENAME = "Contratto_n_<?php echo $docInfo['code_num']; ?>_del_<?php echo date('d-m-Y',$docInfo['ctime']); ?>";

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 if(callback) callback();
	}
 sh.sendCommand("dynarc item-info -ap `"+AP+"` -id `"+ID+"` || gframe -f print.preview -params `modelap=printmodels&modelct="+CT.toLowerCase()+"-contract&parser=contract&id="+ID+"` -title `"+PDF_FILENAME+"`");
}

function InsertRow(ap, id, type)
{
 var subjectId = document.getElementById("subject").getId();

 var sh = new GShell();
 sh.OnOutput = function(o,a){  
	  if(!a)
	   return;

	  r = TB.AddRow();

	  r.setAttribute('type',type);
	  r.setAttribute('vatid',a['vatid']);
	  r.setAttribute('vattype',a['vattype']);
	  r.cell['code'].setValue(a['code_str']);
	  r.setAttribute('refid',a['id']);
	  r.setAttribute('refap',a['tb_prefix']);
	  r.cell['description'].setValue(a['name']);
	  r.cell['qty'].setValue(1);

	  if(a['custompricing'])
	  {
	   if(a['custompricing']['discount_perc'])
		r.cell['discount'].setValue(a['custompricing']['discount_perc']+"%");
	   /*if(a['custompricing']['discount2'])
	    r.cell['discount2'].setValue(a['custompricing']['discount2']+"%");
	   if(a['custompricing']['discount3'])
	    r.cell['discount3'].setValue(a['custompricing']['discount3']+"%");*/
	  }
		  
	  r.cell['units'].setValue(a['units'] ? a['units'] : "PZ");
	  r.cell['unitprice'].setValue(a['finalprice']);
	  r.cell['unitprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(a['finalprice'],4);
	  /*r.cell['plbaseprice'].setValue(a['baseprice']);
	  r.cell['plbaseprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(a['baseprice'],4);
	  r.cell['plmrate'].setValue(a['pricelist_'+CUSTPLID+'_mrate'] ? a['pricelist_'+CUSTPLID+'_mrate'] : 0);
	  r.cell['pldiscperc'].setValue(a['pricelist_'+CUSTPLID+'_discount'] ? a['pricelist_'+CUSTPLID+'_discount'] : 0);*/
	  r.cell['vat'].setValue(a['vat']);
	  r.cell['price'].setValue(a['finalprice']);
	  r.cell['price'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(a['finalprice'],4);
	  /*r.cell['pricelist'].setValue(a['pricelist_name']);
	  r.cell['pricelist'].setAttribute("pricelistid",a['pricelist_id']);*/
	  updateTotals(r);
	 }
 sh.sendCommand("commercialdocs getfullinfo -ap `"+ap+"` -id `"+id+"` -subjectid `"+subjectId+"`");
}

function InsertCustomRow(type)
{
 if(!type) type = "custom";
 var r = TB.AddRow();
 r.setAttribute('type',type);
 switch(type)
 {
  case 'note' : {
	 var colSpan = 9;
	 while(r.cells.length > 2)
	  r.deleteCell(1);
	 r.cells[0].colSpan=colSpan;
	} break;

 }

 r.edit();
}


function DeleteRow(r)
{
 r.remove();
 updateTotals();
}

function updateTotals(r)
{
 if(r)
 {
  var qty = parseFloat(r.cell['qty'].getValue());
  var unitprice = parseCurrency(r.cell['unitprice'].getValue());
  var discStr = r.cell['discount'].getValue();
  var discount = 0;
  var discount2 = 0;
  var discount3 = 0;

  if(discStr.indexOf("%") > 0)
  {
   var disc = parseFloat(discStr);
   discount = unitprice ? (unitprice/100)*disc : 0;
  }
  else
   discount = parseCurrency(discStr);

  if(!discount) 
   discount=0;

  /*var disc2Str = r.cell['discount2'].getValue();
  if(disc2Str && unitprice)
  {
   var disc = parseFloat(disc2Str);
   if(disc)
    discount2 = ((unitprice-discount)/100) * disc;
  }
  
  var disc3Str = r.cell['discount3'].getValue();
  if(disc2Str && disc3Str && unitprice)
  {
   var disc = parseFloat(disc3Str);
   if(disc)
    discount3 = (((unitprice-discount)-discount2)/100) * disc;
  }*/

  var vat = parseFloat(r.cell['vat'].getValue());

  if(discStr == "100%")
   var total = 0;
  else
   var total = (unitprice-discount-discount2-discount3) * qty;
  var totalPlusVat = total ? total + ((total/100)*vat) : 0;

  r.cell['price'].setValue("<em>&euro;</em>"+formatCurrency(total,DECIMALS),total);
  r.cell['price'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(total,4);
  r.cell['vatprice'].setValue("<em>&euro;</em>"+formatCurrency(totalPlusVat,DECIMALS),totalPlusVat);
  r.cell['vatprice'].getElementsByTagName('SPAN')[0].title = "Valore reale: "+formatCurrency(totalPlusVat,4);
 }

 var fee = parseCurrency(document.getElementById('fee').value);
 var VAT_RATES = new Array();
 var VATS = new Object();
 TOT_AMOUNT = fee;
 TOT_VAT = (fee/100)*FEE_VATRATE;
 TOT_TOTAL = 0;

 for(var c=1; c < TB.O.rows.length; c++)
 {
  var r = TB.O.rows[c];
  if(r.getAttribute('type') == "note")
   continue;
  var qty = parseFloat(r.cell['qty'].getValue());

  var discount = 0;
  var discount2 = 0;
  var discount3 = 0;
  var unitprice = parseCurrency(r.cell['unitprice'].getValue());

  var discStr = r.cell['discount'].getValue();
  if(discStr.indexOf("%") > 0)
  {
   var disc = parseFloat(discStr);
   discount = unitprice ? (unitprice/100)*disc : 0;
  }
  else
   discount = parseCurrency(discStr);

  if(!discount) 
   discount=0;

  /*var disc2Str = r.cell['discount2'].getValue();
  if(disc2Str && unitprice)
  {
   var disc = parseFloat(disc2Str);
   if(disc)
    discount2 = ((unitprice-discount)/100) * disc;
  }
  
  var disc3Str = r.cell['discount3'].getValue();
  if(disc2Str && disc3Str && unitprice)
  {
   var disc = parseFloat(disc3Str);
   if(disc)
    discount3 = (((unitprice-discount)-discount2)/100) * disc;
  }*/

  discount = (discount+discount2+discount3) * qty;

  if(discStr == "100%")
   var amount = 0;
  else
   var amount = parseCurrency(r.cell['price'].getValue());

  var total = amount;
  var vatRate = parseFloat(r.cell['vat'].getValue());
  var vat = total ? (total/100)*vatRate : 0;

  TOT_AMOUNT+= total;
  TOT_VAT+= vat;
 }

 TOT_TOTAL = TOT_AMOUNT + TOT_VAT;

 document.getElementById("footer-total").innerHTML = "&euro; "+formatCurrency(TOT_AMOUNT + TOT_VAT);

 updateSchedule();
}

function updateSchedule()
{
 SC_UNSET_ALL = true;
 SCNEW_ROWS = new Array();
 SCUPDATED_ROWS = new Array();
 SCDELETED_ROWS = new Array();

 var startDate = document.getElementById('startdate').isodate;
 var term = document.getElementById('term').value;
 var periodicity = document.getElementById('periodicity').getValue();
 var fee = parseCurrency(document.getElementById('fee').value);
 var commissAmount = parseCurrency(document.getElementById('commissamount').value);
 var commissVatRate = document.getElementById('commissvat').selectedItem.getAttribute('vatrate');
 var payDay = document.getElementById('payday').getValue();

 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 SCTB.EmptyTable();
	 if(!a || !a['deadlines'])
	  return;
	 var tmpDate = new Date();
	 for(var c=0; c < a['deadlines'].length; c++)
	 {
	  var itm = a['deadlines'][c];
	  var r = SCTB.AddRow();
	  tmpDate.setFromISO(itm['expiry']);
	  r.cell['sc_idx'].setValue(c+1);
	  r.cell['sc_canon'].setValue(itm['amount']);
	  r.cell['sc_commiss'].setValue(itm['commiss']);
	  r.cell['sc_amount'].setValue(itm['tot_amount']);
	  r.cell['sc_vat'].setValue(itm['tot_vat']);
	  r.cell['sc_total'].setValue(itm['tot_total']);
	  r.cell['sc_expiry'].setValue(tmpDate.printf('d/m/Y'));
	 }

	}

 sh.sendCommand("calcrate -amount '"+TOT_AMOUNT+"' -vatrate '"+FEE_VATRATE+"' -commiss '"+commissAmount+"' -commissvatrate '"+commissVatRate+"' -periodicity '"+periodicity+"' -months '"+term+"' -datefrom '"+startDate+"' -payday '"+payDay+"'");
}

function generateScheduleInvoice(img)
{
 var r = img.parentNode.parentNode;
 
 var sh = new GShell();
 sh.OnError = function(err){alert(err);}
 sh.OnOutput = function(o,a){
	 r.cell['sc_geninvoice'].setValue("");
	 r.cell['sc_invoice'].innerHTML = "<a href='"+ABSOLUTE_URL+"GCommercialDocs/docinfo.php?id="+a['id']+"' target='GCD-"+a['id']+"'>"+a['name']+"</a>";
	 r.cell['sc_invoice'].style.textAlign = 'center';
	 r.cell['sc_invoice'].style.fontSize = '12px';
	}
 sh.sendCommand("commercialdocs generate-from-contract -id '"+ID+"' -scheduleid '"+r.id+"'");
}
</script>
<?php

$template->End();

?>


