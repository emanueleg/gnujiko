<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
HackTVT Project
copyright(C) 2015 Alpatech mediaware - www.alpatech.it
license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
Gnujiko 10.1 is free software released under GNU/GPL license
developed by D. L. Alessandro (alessandro@alpatech.it)

#DATE: 07-04-2015
#PACKAGE: contracts-base
#DESCRIPTION: Contract info
#VERSION: 2.1beta
#CHANGELOG: 07-04-2015 : Aggiunto campi.
#TODO: 
*/

global $_BASE_PATH;

function dynarcextension_contractinfo_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` ADD `start_date` DATE NOT NULL, 
	ADD `end_date` DATE NOT NULL, 
	ADD `subject_id` INT(11) NOT NULL, 
	ADD `subject_name` VARCHAR(32) NOT NULL, 
	ADD `term` INT(1) NOT NULL, 
	ADD `autorenewal` TINYINT(1) NOT NULL, 
	ADD `periodicity` INT(1) NOT NULL, 
	ADD `total_hours` FLOAT NOT NULL, 
	ADD `agent_id` INT(11) NOT NULL, 
	ADD `agent_name` VARCHAR(32) NOT NULL, 
	ADD `agent_commiss` FLOAT NOT NULL, 
	ADD `fee` DECIMAL(10,5) NOT NULL, 
	ADD `fee_vatid` INT(11) NOT NULL, 
	ADD `fee_vatrate` FLOAT NOT NULL, 
	ADD `amount` DECIMAL(10,5) NOT NULL, 
	ADD `vat` DECIMAL(10,5) NOT NULL, 
	ADD `total` DECIMAL(10,5) NOT NULL, 
	ADD `active` TINYINT(1) NOT NULL,
	ADD `commiss_title` VARCHAR(64) NOT NULL,
	ADD `commiss_amount` DECIMAL(10,5) NOT NULL,
	ADD `commiss_vatid` INT(11) NOT NULL,
	ADD `commiss_vatrate` FLOAT NOT NULL,
	ADD `payday` VARCHAR(2) NOT NULL,
	ADD INDEX (`subject_id`,`agent_id`,`active`)");
 $db->Close();

 return array("message"=>"ContractInfo extension has been installed into archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` DROP `start_date`, DROP `end_date`, DROP `subject_id`, DROP `subject_name`, DROP `term`, DROP `autorenewal`, DROP `periodicity`, DROP `total_hours`, DROP `agent_id`, DROP `agent_name`, DROP `agent_commiss`, DROP `fee`, DROP `fee_vatid`, DROP `fee_vatrate`, DROP `amount`, DROP `vat`, DROP `total`, DROP `active`, DROP `commiss_title`, DROP `commiss_amount`, DROP `commiss_vatid`, DROP `commiss_vatrate`, DROP `payday`");
 $db->Close();
 return array("message"=>"ContractInfo extension has been removed from archive ".$archiveInfo['name']);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_catset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_catunset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_catget($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_contractinfo_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'startdate' : { $startdate = $args[$c+1]; $c++;} break;
   case 'enddate' : { $enddate = $args[$c+1]; $c++;} break;
   case 'subjid' : { $subjid = $args[$c+1]; $c++;} break;
   case 'subjname' : { $subjname = $args[$c+1]; $c++;} break;
   case 'term' : { $term = $args[$c+1]; $c++;} break;
   case 'autorenewal' : case 'autorenew' : { $autorenewal = $args[$c+1]; $c++;} break;
   case 'periodicity' : case 'freq' : { $periodicity = $args[$c+1]; $c++;} break;
   case 'tothours' : { $tothours = $args[$c+1]; $c++;} break;
   case 'agentid' : { $agentid = $args[$c+1]; $c++;} break;
   case 'agentname' : { $agentname = $args[$c+1]; $c++;} break;
   case 'agentcommiss' : { $agentcommiss = $args[$c+1]; $c++;} break;
   case 'fee' : { $fee = $args[$c+1]; $c++;} break;
   case 'feevatid' : { $feevatid = $args[$c+1]; $c++;} break;
   case 'feevatrate' : { $feevatrate = $args[$c+1]; $c++;} break;
   case 'amount' : { $amount = $args[$c+1]; $c++;} break;
   case 'vat' : { $vat = $args[$c+1]; $c++;} break;
   case 'total' : { $total = $args[$c+1]; $c++;} break;
   case 'active' : { $active = $args[$c+1]; $c++;} break;
   case 'commtitle' : case 'commisstitle' : { $commissTitle=$args[$c+1]; $c++;} break;
   case 'commamount' : case 'commissamount' : { $commissAmount=$args[$c+1]; $c++;} break;
   case 'commvatid' : case 'commissvatid' : { $commissVatId=$args[$c+1]; $c++;} break;
   case 'commvatrate' : case 'commissvatrate' : { $commissVatRate=$args[$c+1]; $c++;} break;
   case 'payday' : { $payDay=$args[$c+1]; $c++;} break;
  }


 if($tothours)
 {
  // verifica se è stato modificato dall'ultima volta
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT subject_id,total_hours FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
  $db->Read();
  $oldTotHours = $db->record['total_hours'];
  if(!$subjid) $subjid = $db->record['subject_id'];
  if($subjid)
  {
   if($tothours != $oldTotHours)
   {
	// Aggiorna il tot. ore disponibili nell'anagrafica cliente.
    if($tothours > $oldTotHours)
	 $db->RunQuery("UPDATE dynarc_rubrica_items SET assist_avail_hours = assist_avail_hours+".($tothours-$oldTotHours)." WHERE id='"
	 .($subjid ? $subjid : $db->record['subject_id'])."'");
	else
	 $db->RunQuery("UPDATE dynarc_rubrica_items SET assist_avail_hours = assist_avail_hours-".($oldTotHours-$tothours)." WHERE id='"
	 .($subjid ? $subjid : $db->record['subject_id'])."'");
   }
  }
  $db->Close();
 }

 $db = new AlpaDatabase();
 $q = "";

 if($startdate == "today")		$startdate = date('Y-m-d');

 if(isset($startdate))			$q.= ",start_date='".$startdate."'";
 if(isset($enddate))			$q.= ",end_date='".$enddate."'";
 if(isset($subjid))				$q.= ",subject_id='".$subjid."'";
 if(isset($subjname))			$q.= ",subject_name='".$db->Purify($subjname)."'";
 if(isset($term))				$q.= ",term='".$term."'";
 if(isset($autorenewal))		$q.= ",autorenewal='".$autorenewal."'";
 if(isset($periodicity))		$q.= ",periodicity='".$periodicity."'";
 if(isset($tothours))			$q.= ",total_hours='".$tothours."'";
 if(isset($agentid))			$q.= ",agent_id='".$agentid."'";
 if(isset($agentname))			$q.= ",agent_name='".$db->Purify($agentname)."'";
 if(isset($agentcommiss))		$q.= ",agent_commiss='".$agentcommiss."'";
 if(isset($fee))				$q.= ",fee='".$fee."'";
 if(isset($feevatid))			$q.= ",fee_vatid='".$feevatid."'";
 if(isset($feevatrate))			$q.= ",fee_vatrate='".$feevatrate."'";
 if(isset($amount))				$q.= ",amount='".$amount."'";
 if(isset($vat))				$q.= ",vat='".$vat."'";
 if(isset($total))				$q.= ",total='".$total."'";
 if(isset($active))				$q.= ",active='".$active."'";
 if(isset($commissTitle))		$q.= ",commiss_title='".$db->Purify($commissTitle)."'";
 if(isset($commissAmount))		$q.= ",commiss_amount='".$commissAmount."'";
 if(isset($commissVatId))		$q.= ",commiss_vatid='".$commissVatId."'";
 if(isset($commissVatRate))		$q.= ",commiss_vatrate='".$commissVatRate."'";
 if(isset($payDay))				$q.= ",payday='".$payDay."'";

 if($q)
 {
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET ".ltrim($q,",")." WHERE id='".$itemInfo['id']."'");
  if($db->Error) return array('message'=>"MySQL Error: ".$db->Error, 'error'=>'MYSQL_ERROR');
 }
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_contractinfo_catunset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return dynarcextension_contractinfo_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {

  }

 $_FIELDS = "*";
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT ".$_FIELDS." FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();

 $itemInfo['start_date'] = (($db->record['start_date'] != '0000-00-00') && ($db->record['start_date'] != '1970-01-01')) ? $db->record['start_date'] : '';
 $itemInfo['end_date'] = (($db->record['end_date'] != '0000-00-00') && ($db->record['end_date'] != '1970-01-01')) ? $db->record['end_date'] : '';
 $itemInfo['subject_id'] = $db->record['subject_id'];
 $itemInfo['subject_name'] = $db->record['subject_name'];
 $itemInfo['term'] = $db->record['term'];
 $itemInfo['autorenewal'] = $db->record['autorenewal'];
 $itemInfo['periodicity'] = $db->record['periodicity'];
 $itemInfo['total_hours'] = $db->record['total_hours'];
 $itemInfo['agent_id'] = $db->record['agent_id'];
 $itemInfo['agent_name'] = $db->record['agent_name'];
 $itemInfo['agent_commiss'] = $db->record['agent_commiss'];
 $itemInfo['fee'] = $db->record['fee'];
 $itemInfo['fee_vatid'] = $db->record['fee_vatid'];
 $itemInfo['fee_vatrate'] = $db->record['fee_vatrate'];
 $itemInfo['amount'] = $db->record['amount'];
 $itemInfo['vat'] = $db->record['vat'];
 $itemInfo['total'] = $db->record['total'];
 $itemInfo['active'] = $db->record['active'];
 $itemInfo['commiss_title'] = $db->record['commiss_title'];
 $itemInfo['commiss_amount'] = $db->record['commiss_amount'];
 $itemInfo['commiss_vatid'] = $db->record['commiss_vatid'];
 $itemInfo['commiss_vatrate'] = $db->record['commiss_vatrate'];
 $itemInfo['payday'] = $db->record['payday'];

 /* get available hours from subject */
 if($itemInfo['subject_id'])
 {
  $db->RunQuery("SELECT assist_avail_hours FROM dynarc_rubrica_items WHERE id='".$itemInfo['subject_id']."'");
  $db->Read();
  $itemInfo['avail_hours'] = $db->record['assist_avail_hours'];
 }
 else
  $itemInfo['avail_hours'] = 0;

 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 $xml = "<contractinfo />";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 global $_BASE_PATH;

 if($isCategory)
  return ;

 if(!$node)
  return ;

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* Decremento le ore disponibili sull'anagrafica cliente */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT subject_id,total_hours FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 if($db->record['subject_id'] && $db->record['total_hours'])
  $db->RunQuery("UPDATE dynarc_rubrica_items SET assist_avail_hours=assist_avail_hours-".$db->record['total_hours']
	." WHERE id='".$db->record['subject_id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* Incremento le ore disponibili sull'anagrafica cliente */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT subject_id,total_hours FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 if($db->record['subject_id'] && $db->record['total_hours'])
  $db->RunQuery("UPDATE dynarc_rubrica_items SET assist_avail_hours=assist_avail_hours+".$db->record['total_hours']
	." WHERE id='".$db->record['subject_id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* Decremento le ore disponibili sull'anagrafica cliente */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT subject_id,total_hours FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 if($db->record['subject_id'] && $db->record['total_hours'])
  $db->RunQuery("UPDATE dynarc_rubrica_items SET assist_avail_hours=assist_avail_hours-".$db->record['total_hours']
	." WHERE id='".$db->record['subject_id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 $_FIELDS = "start_date,end_date,subject_id,subject_name,term,autorenewal,periodicity,total_hours,
agent_id,agent_name,agent_commiss,fee,fee_vatid,fee_vatrate,amount,vat,total,active";

 /* TODO: da vedere x la data per le proroghe dei contratti */

 /*$db = new AlpaDatabase();
 $db2 = new AlpaDatabase();
 $db->RunQuery("SELECT ".$_FIELDS." FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$srcInfo['id']."'");
 $db->Read();

 $db2->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET start_date='".$db->record['start_date']."',end_date='".$db->record['end_date']."',subject_id='".$db->record['subject_id']."',subject_name='".$db2->Purify($db->record['subject_name'])."',term='".$db->record['term']."',autorenewal='".$db->record['autorenewal']."',periodicity='".$db->record['periodicity']."',total_hours='".$db->record['total_hours']."',agent_id='".$db->record['agent_id']."',agent_name='".$db2->Purify($db->record['agent_name'])."',agent_commiss='".$db->record['agent_commiss']."',fee='".$db->record['fee']."',fee_vatid='".$db->record['fee_vatid']."',fee_vatrate='".$db->record['fee_vatrate']."',amount='".$db->record['amount']."',vat='".$db->record['vat']."',total='".$db->record['total']."',active='".$db->record['active']."' WHERE id='".$cloneInfo['id']."'");
 $db2->Close();
 $db->Close();*/

 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractinfo_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
