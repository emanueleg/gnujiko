<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: contracts-base
 #DESCRIPTION: Contract schedule extension.
 #VERSION: 2.1beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.

 
*/

global $_BASE_PATH;

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `dynarc_".$archiveInfo['prefix']."_schedule` (
	`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
	`item_id` INT(11) NOT NULL ,
	`canon` DECIMAL(10,5) NOT NULL ,
	`canon_vatid` INT(11) NOT NULL ,
	`canon_vatrate` FLOAT NOT NULL ,
	`commiss` DECIMAL(10,5) NOT NULL ,
	`commiss_vatid` INT(11) NOT NULL ,
	`commiss_vatrate` FLOAT NOT NULL ,
	`amount` DECIMAL(10,5) NOT NULL ,
	`vat` DECIMAL(10,5) NOT NULL ,
	`total` DECIMAL(10,5) NOT NULL ,
	`expiry` DATE NOT NULL ,
	`invoice_id` INT(11) NOT NULL ,
	`invoice_name` VARCHAR(64) NOT NULL ,
	`paid` TINYINT(1) NOT NULL ,
	`paid_date` DATE NOT NULL ,
	INDEX (`item_id`,`invoice_id`,`paid`) 
)");
 $db->Close();

 return array("message"=>"Contract Schedule extension has been installed into archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("DROP TABLE IF EXISTS `dynarc_".$archiveInfo['prefix']."_schedule`");
 $db->Close();

 return array("message"=>"Contract Schedule extension has been removed from archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 /* REMOVE ALL SCHEDULE */
 $db = new AlpaDatabase();
 $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_schedule WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_set($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 global $_BASE_PATH, $_ABSOLUTE_URL;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'canon' : {$canon=$args[$c+1]; $c++;} break;
   case 'canonvatid' : {$canonVatId=$args[$c+1]; $c++;} break;
   case 'canonvatrate' : {$canonVatRate=$args[$c+1]; $c++;} break;
   case 'commiss' : {$commiss=$args[$c+1]; $c++;} break;
   case 'commissvatid' : {$commissVatId=$args[$c+1]; $c++;} break;
   case 'commissvatrate' : {$commissVatRate=$args[$c+1]; $c++;} break;
   case 'amount' : {$amount=$args[$c+1]; $c++;} break;
   case 'vat' : {$vat=$args[$c+1]; $c++;} break;
   case 'total' : {$total=$args[$c+1]; $c++;} break;
   case 'expiry' : {$expiry=$args[$c+1]; $c++;} break;
   case 'invoiceid' : {$invoiceId=$args[$c+1]; $c++;} break;
   case 'invoicename' : {$invoiceName=$args[$c+1]; $c++;} break;
   case 'paid' : {$paid=$args[$c+1]; $c++;} break;
   case 'paiddate' : {$paidDate=$args[$c+1]; $c++;} break;
  }

 $sessInfo = sessionInfo($sessid);

 if($id)
 {
  $db = new AlpaDatabase();
  $q = "";
  
  if(isset($canon))					$q.= ",canon='".$canon."'";
  if(isset($canonVatId))			$q.= ",canon_vatid='".$canonVatId."'";
  if(isset($canonVatRate))			$q.= ",canon_vatrate='".$canonVatRate."'";
  if(isset($commiss))				$q.= ",commiss='".$commiss."'";
  if(isset($commissVatId))			$q.= ",commiss_vatid='".$commissVatId."'";
  if(isset($commissVatRate))		$q.= ",commiss_vatrate='".$commissVatRate."'";
  if(isset($amount))				$q.= ",amount='".$amount."'";
  if(isset($vat))					$q.= ",vat='".$vat."'";
  if(isset($total))					$q.= ",total='".$total."'";
  if(isset($expiry))				$q.= ",expiry='".$expiry."'";
  if(isset($invoiceId))				$q.= ",invoice_id='".$invoiceId."'";
  if(isset($invoiceName))			$q.= ",invoice_name='".$db->Purify($invoiceName)."'";
  if(isset($paid))					$q.= ",paid='".$paid."'";
  if(isset($paidDate))				$q.= ",paid_date='".$paidDate."'";

  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_schedule SET ".ltrim($q,',')." WHERE id='".$id."'");
  $db->Close();
 }
 else
 {
  $db = new AlpaDatabase();

  $qry = "INSERT INTO dynarc_".$archiveInfo['prefix']."_schedule(item_id,canon,canon_vatid,canon_vatrate,commiss,commiss_vatid,commiss_vatrate,amount,vat,total,expiry,invoice_id,invoice_name,paid,paid_date) VALUES('"
	.$itemInfo['id']."','".$canon."','".$canonVatId."','".$canonVatRate."','".$commiss."','".$commissVatId."','".$commissVatRate."','"
	.$amount."','".$vat."','".$total."','".$expiry."','".$invoiceId."','".$db->Purify($invoiceName)."','".$paid."','".$paidDate."')";

  $db->RunQuery($qry);
  if($db->Error)
   return array('message'=>'MySQL Error: '.$db->Error.'\nQRY: '.$qry, 'error'=>'MYSQL_ERROR');

  $id = $db->GetInsertId();
  $db->Close();
 }

 $itemInfo['last_schedule'] = array('id'=>$id, 'canon'=>$canon, 'canon_vatid'=>$canonVatId, 'canon_vatrate'=>$canonVatRate, 'commiss'=>$commiss,
	'commiss_vatid'=>$commissVatId, 'commiss_vatrate'=>$commissVatRate, 'amount'=>$amount, 'vat'=>$vat, 'total'=>$total, 'expiry'=>$expiry,
	'invoice_id'=>$invoiceId, 'invoice_name'=>$invoiceName, 'paid'=>$paid, 'paid_date'=>$paidDate);


 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'id' : {$id=$args[$c+1]; $c++;} break;
   case 'all' : $all=true; break;
  }
 
 $db = new AlpaDatabase();
 if($id)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_schedule WHERE id='".$id."'");
 else if($all)
  $db->RunQuery("DELETE FROM dynarc_".$archiveInfo['prefix']."_schedule WHERE item_id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_get($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 global $_BASE_PATH, $_ABSOLUTE_URL;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$archiveInfo['prefix']."_schedule WHERE item_id='".$itemInfo['id']."' ORDER BY expiry ASC");
 while($db->Read())
 {
  $a = array('id'=>$db->record['id'], 'canon'=>$db->record['canon'], 'canon_vatid'=>$db->record['canon_vatid'], 
	'canon_vatrate'=>$db->record['canon_vatrate'], 'commiss'=>$db->record['commiss'], 'commiss_vatid'=>$db->record['commiss_vatid'],
	'commiss_vatrate'=>$db->record['commiss_vatrate'], 'amount'=>$db->record['amount'], 'vat'=>$db->record['vat'], 
	'total'=>$db->record['total'], 'expiry'=>$db->record['expiry'], 'invoice_id'=>$db->record['invoice_id'], 
	'invoice_name'=>$db->record['invoice_name'], 'paid'=>$db->record['paid'], 'paid_date'=>$db->record['paid_date']);


  $itemInfo['schedules'][] = $a;
 }
 $db->Close();
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_export($sessid, $shellid, $archiveInfo, $itemInfo)
{
 $xml = "";
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_import($sessid, $shellid, $archiveInfo, $itemInfo, $node)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_syncexport($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_USERS_HOMES;
 $xml = "";
 $attachments = array();

 return array('xml'=>$xml,'attachments'=>$attachments);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_contractschedule_syncimport($sessid, $shellid, $archiveInfo, $itemInfo, $xmlNode, $isCategory=false)
{
 global $_USER_PATH;
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

