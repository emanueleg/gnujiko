<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 19-03-2015
 #PACKAGE: contracts-base
 #DESCRIPTION: Archive functions for Contracts.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO: Modificare le scritte in italiano utilizzando i18n.
 
*/

function dynarcfunction_contracts_oninheritarchive($args, $sessid, $shellid, $archiveInfo)
{

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT tag FROM dynarc_".$archiveInfo['prefix']."_categories WHERE id='".$itemInfo['cat_id']."'");
 if($db->Read())
  $catTag = $db->record['tag'];
 $db->Close();

 /* Get last document and adjust document number */
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT code_num FROM dynarc_".$archiveInfo['prefix']."_items WHERE cat_id='".$itemInfo['cat_id']."' AND id!='"
	.$itemInfo['id']."' AND trash=0 AND ctime>='".date('Y',$itemInfo['ctime'])."-01-01' AND ctime<'".date('Y',strtotime("+1 Year",$itemInfo['ctime']))."-01-01' ORDER BY code_num DESC LIMIT 1");
 if($db->Read())
  $itemInfo['code_num'] = $db->record['code_num']+1;
 else
  $itemInfo['code_num'] = 1; 
 $db->Close();

 $title = "";
 switch($catTag)
 {
  case 'MAINTENANCE' : $title = "Contratto di manutenzione"; break;
  case 'SERVICE' : $title = "Contratto di assistenza"; break;
  default : $title = "Contratto"; break;
 }

 $title.= " n&deg;".$itemInfo['code_num'].($itemInfo['code_ext'] ? "/".$itemInfo['code_ext'] : "")." del ".date('d/m/Y',$itemInfo['ctime']);

 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET code_num='".$itemInfo['code_num']."',name='".$db->Purify($title)."',ctime='".date('Y-m-d',$itemInfo['ctime'])."' WHERE id='".$itemInfo['id']."'");
 $db->Close();

 $itemInfo['name'] = $title;
 
 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT tag FROM dynarc_".$archiveInfo['prefix']."_categories WHERE id='".$itemInfo['cat_id']."'");
 if($db->Read())
  $catTag = $db->record['tag'];
 $db->Close();

 $title = "";
 switch($catTag)
 {
  case 'MAINTENANCE' : $title = "Contratto di manutenzione"; break;
  case 'SERVICE' : $title = "Contratto di assistenza"; break;
  default : $title = "Contratto"; break;
 }

 $title.= " n&deg;".$itemInfo['code_num'].($itemInfo['code_ext'] ? "/".$itemInfo['code_ext'] : "")." del ".date('d/m/Y',$itemInfo['ctime']);

 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET name='".$db->Purify($title)."',ctime='".date('Y-m-d',$itemInfo['ctime'])."' WHERE id='".$itemInfo['id']."'");
 $db->Close();

 $itemInfo['name'] = $title;

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_onmoveitem($sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_onmovecategory($sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_oncopyitem($sessid, $shellid, $archiveInfo, $cloneInfo, $srcInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_oncopycategory($sessid, $shellid, $archiveInfo, $cloneInfo, $srcInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcfunction_contracts_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//


