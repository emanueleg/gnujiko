<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 20-03-2015
 #PACKAGE: contract-base
 #DESCRIPTION: Contract parser
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

function gnujikocontentparser_contract_info($sessid, $shellid)
{
 $info = array('name' => "Contratti");
 $keys = array(
	 "SUBJECT_NAME" => "Cliente - nome e cognome",
	 "SUBJECT_CODE" => "Codice cliente",
	 "DOC_NUM" => "Nr. contratto",
	 "REG_DATE" => "Data registrazione",
	 "START_DATE" => "Data inizio contratto",
	 "END_DATE" => "Data scadenza contratto",
	 "TERM" => "Durata contratto (in mesi)",
	 "AUTORENEW" => "Tacito rinnovo (Si - No)",
	 "PERIOD" => "Periodicit&agrave;",
	 "TOT_HOURS" => "Monte ore",
	 "AGENT_NAME" => "Agente",
	 "AGENT_COMMISS" => "Commissioni agente",
	 "FEE" => "Canone",
	 "FEE_VR" => "Aliq. IVA su canone",
	 "AMOUNT" => "Imponibile",
	 "VAT" => "IVA",
	 "TOTAL" => "Totale",
	 "DESCRIPTION" => "Dettagli contratto",

	 "COMPANY-NAME" => "Denominazione azienda (la vostra)",
	 "CO_ADDR" => "Indirizzo (della vs azienda)",
	 "CO_ZIP" => "C.A.P. (della vs azienda)",
	 "CO_CITY" => "Città (della vs azienda)",
	 "CO_PROV" => "Provincia (della vs azienda)",
	 "CO_CC" => "Paese (della vs azienda)",
	 "CO_VATNUMBER" => "Numero della Partita IVA (della vs azienda)",
	 "CO_TAXCODE" => "Codice Fiscale (della vs azienda)",
	 "CO_PHONE" => "Telefono principale (della vs azienda)",
	 "CO_PHONE2" => "Telefono secondario (della vs azienda)",
	 "CO_FAX" => "Fax principale (della vs azienda)",
	 "CO_FAX2" => "Fax secondario (della vs azienda)",
	 "CO_CELL" => "Cellulare principale (della vs azienda)",
	 "CO_CELL2" => "Cellulare secondario (della vs azienda)",
	 "CO_EMAIL" => "Email principale (della vs azienda)",
	 "CO_EMAIL2" => "Email secondaria (della vs azienda)",
	 "CO_WEBSITE" => "Sito web (della vs azienda)",

	 "COBNK_NAME" => "Ns. Banca: Nome della banca ",
	 "COBNK_IBAN" => "Ns. Banca: IBAN",
	 "CB_ABI" => "Ns. Banca: ABI",
	 "CB_CAB" => "Ns. Banca: CAB",
	 "CB_CIN" => "Ns. Banca: CIN",
	 "CB_CC" => "Ns. Banca: Conto Corrente",


	);
 return array('info'=>$info, 'keys'=>$keys);
}

function gnujikocontentparser_contract_parse($_CONTENTS, $_PARAMS, $sessid, $shellid)
{
 global $_BASE_PATH, $_ABSOLUTE_URL, $_COMPANY_PROFILE;
 include_once($_BASE_PATH."include/company-profile.php");
 $_BANKS = $_COMPANY_PROFILE['banks'];
 $_DECIMALS = $_COMPANY_PROFILE['accounting']['decimals_pricing'];

 $_PERIODICITY = array(
	1 => "Mensile",
	2 => "Bimestrale",
	3 => "Trimestrale",
	4 => "Quadrimestrale",
	6 => "Semestrale",
	12 => "Annuale"
 );

 $contents = $_CONTENTS;

 // DOC INFO //
 $ret = GShell("dynarc item-info -ap contracts -id '".$_PARAMS['id']."' -extget `contractinfo`",$sessid,$shellid);
 if(!$ret['error'])
 {
  $docInfo = $ret['outarr'];
  // get subject info //
  if($docInfo['subject_id'])
  {
   $ret = GShell("dynarc item-info -ap rubrica -id '".$docInfo['subject_id']."' -extget `rubricainfo`",$sessid,$shellid);
   if(!$ret['error'])
	$subjectInfo = $ret['outarr'];
  }
 }

 $keys = array(
	 "{SUBJECT_NAME}",
	 "{SUBJECT_CODE}",
	 "{DOC_NUM}",
	 "{REG_DATE}",
	 "{START_DATE}",
	 "{END_DATE}",
	 "{TERM}",
	 "{AUTORENEW}",
	 "{PERIOD}",
	 "{TOT_HOURS}",
	 "{AGENT_NAME}",
	 "{AGENT_COMMISS}",
	 "{FEE}",
	 "{FEE_VR}",
	 "{AMOUNT}",
	 "{VAT}",
	 "{TOTAL}",
	 "{DESCRIPTION}",

	 "{COMPANY-NAME}", "{CO_ADDR}", "{CO_ZIP}", "{CO_CITY}", "{CO_PROV}", "{CO_CC}", "{CO_VATNUMBER}", "{CO_TAXCODE}", "{CO_PHONE}", "{CO_PHONE2}", 
	 "{CO_FAX}", "{CO_FAX2}", "{CO_CELL}", "{CO_CELL2}", "{CO_EMAIL}", "{CO_EMAIL2}", "{CO_WEBSITE}",

	 "{COBNK_NAME}", "{COBNK_IBAN}", "{CB_ABI}", "{CB_CAB}", "{CB_CIN}", "{CB_CC}",

	);

 $tcaovn = "";
 if($subjectInfo['vatnumber'] && $subjectInfo['taxcode'])
  $tcaovn = "P.IVA: ".$subjectInfo['vatnumber']."<br/>C.F.: ".$subjectInfo['taxcode'];
 else if($subjectInfo['vatnumber'])
  $tcaovn = "P.IVA: ".$subjectInfo['vatnumber'];
 else if($subjectInfo['taxcode'])
  $tcaovn = "C.F.: ".$subjectInfo['taxcode'];

 /* Get company bank info */
 $CObankName = $_BANKS[0] ? $_BANKS[0]['name'] : "&nbsp;";
 $CObankIBAN = $_BANKS[0] ? $_BANKS[0]['iban'] : "&nbsp;";
 $CObankABI = $_BANKS[0] ? $_BANKS[0]['abi'] : "&nbsp;";
 $CObankCAB = $_BANKS[0] ? $_BANKS[0]['cab'] : "&nbsp;";
 $CObankCIN = $_BANKS[0] ? $_BANKS[0]['cin'] : "&nbsp;";
 $CObankCC = $_BANKS[0] ? $_BANKS[0]['cc'] : "&nbsp;";

 if($CObankIBAN && (strlen($CObankIBAN) >= 27))
  $CObankIBAN = substr($CObankIBAN,0,4)." ".substr($CObankIBAN,4,4)." ".substr($CObankIBAN,8,4)." ".substr($CObankIBAN,12,4)." ".substr($CObankIBAN,16,4)." ".substr($CObankIBAN,20,4)." ".substr($CObankIBAN,24);


 $vals = array(
	 $subjectInfo['name'],
	 $subjectInfo['code_str'],
	 $docInfo['code_num'],
	 date('d/m/Y',$docInfo['ctime']),
	 $docInfo['start_date'] ? date('d/m/Y',strtotime($docInfo['start_date'])) : "",
	 $docInfo['end_date'] ? date('d/m/Y',strtotime($docInfo['end_date'])) : "",
	 $docInfo['term'] ? $docInfo['term'] : "",
	 $docInfo['autorenewal'] ? "Si" : "No",
	 $_PERIODICITY[$docInfo['periodicity']],
	 $docInfo['total_hours'],
	 $docInfo['agent_name'] ? $docInfo['agent_name'] : "",
	 $docInfo['agent_commiss'] ? sprintf('%.2f',$docInfo['agent_commiss']) : "",
	 number_format($docInfo['fee'],2,',','.'),
	 $docInfo['fee_vatrate']."%",

	 number_format($docInfo['amount'],2,",","."),
	 number_format($docInfo['vat'],2,",","."),
	 number_format($docInfo['total'],2,",","."),

	 $docInfo['desc'],

	 /* COMPANY INFO */
	 $_COMPANY_PROFILE['name'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['address'] ? $_COMPANY_PROFILE['addresses']['headquarters']['address'] : $_COMPANY_PROFILE['addresses']['registered_office']['address'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['zip'] ? $_COMPANY_PROFILE['addresses']['headquarters']['zip'] : $_COMPANY_PROFILE['addresses']['registered_office']['zip'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['city'] ? $_COMPANY_PROFILE['addresses']['headquarters']['city'] : $_COMPANY_PROFILE['addresses']['registered_office']['city'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['prov'] ? $_COMPANY_PROFILE['addresses']['headquarters']['prov'] : $_COMPANY_PROFILE['addresses']['registered_office']['prov'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['country'] ? $_COMPANY_PROFILE['addresses']['headquarters']['country'] : $_COMPANY_PROFILE['addresses']['registered_office']['country'],

	 $_COMPANY_PROFILE['vatnumber'], $_COMPANY_PROFILE['taxcode'], 

	 $_COMPANY_PROFILE['addresses']['headquarters']['phones'][0]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['phones'][0]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['phones'][0]['number'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['phones'][1]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['phones'][1]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['phones'][1]['number'],

	 $_COMPANY_PROFILE['addresses']['headquarters']['fax'][0]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['fax'][0]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['fax'][0]['number'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['fax'][1]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['fax'][1]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['fax'][1]['number'],

	 $_COMPANY_PROFILE['addresses']['headquarters']['cells'][0]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['cells'][0]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['cells'][0]['number'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['cells'][1]['number'] ? $_COMPANY_PROFILE['addresses']['headquarters']['cells'][1]['number'] : $_COMPANY_PROFILE['addresses']['registered_office']['cells'][1]['number'],

	 $_COMPANY_PROFILE['addresses']['headquarters']['emails'][0]['email'] ? $_COMPANY_PROFILE['addresses']['headquarters']['emails'][0]['email'] : $_COMPANY_PROFILE['addresses']['registered_office']['emails'][0]['email'],
	 $_COMPANY_PROFILE['addresses']['headquarters']['emails'][1]['email'] ? $_COMPANY_PROFILE['addresses']['headquarters']['emails'][1]['email'] : $_COMPANY_PROFILE['addresses']['registered_office']['emails'][1]['email'],

	 $_COMPANY_PROFILE['website'],

 	 $CObankName, $CObankIBAN, $CObankABI, $CObankCAB, $CObankCIN, $CObankCC
	);

 for($c=0; $c < count($keys); $c++)
 {
  $key = $keys[$c];
  $val = $vals[$c];

  while($p = stripos($contents,$key,$p))
  {
   $chunk = strtoupper(substr($contents,$p-4,4));
   if(($chunk == "ID='") || ($chunk == 'ID="'))
   {// is inside on html tag //
    $endTag = stripos($contents,">",$p+strlen($key));
    $contents = substr($contents,0,$endTag+1).$val.substr($contents,$endTag+1);
    $p = $endTag+strlen($val);
   }
   else
   {
    $contents = substr($contents,0,$p).$val.substr($contents,$p+strlen($key));
    $p+= strlen($val);
   }
  }
 }

 $_CONTENTS = $contents;
 return $contents;
}


