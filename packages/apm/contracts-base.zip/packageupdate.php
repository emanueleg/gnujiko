<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* 07-04-2015 - Aggiunto campi */
$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `dynarc_contracts_items` ADD `commiss_title` VARCHAR(64) NOT NULL ,
ADD `commiss_amount` DECIMAL(10,5) NOT NULL ,
ADD `commiss_vatid` INT(11) NOT NULL ,
ADD `commiss_vatrate` FLOAT NOT NULL ,
ADD `payday` VARCHAR(2) NOT NULL");
$db->Close();

$ret = GShell("dynarc install-extension 'contractschedule' -ap 'contracts'",$_SESSION_ID,$_SHELL_ID);