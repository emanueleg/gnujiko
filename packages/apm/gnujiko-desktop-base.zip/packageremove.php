<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$_SHELL_OUT.= "Drop desktop tables...";
$db = new AlpaDatabase();
$db->RunQuery("DROP TABLE IF EXISTS `gnujiko_desktop_pages`");
$db->RunQuery("DROP TABLE IF EXISTS `gnujiko_desktop_modules`");
$db->RunQuery("DROP TABLE IF EXISTS `gnujiko_desktop_connections`");
$db->Close();
$_SHELL_OUT.= "done!\n";