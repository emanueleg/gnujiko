<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

if(version_compare($_INSTALLED_VER, "2.18beta", "<"))
{
$_SHELL_OUT.= "Creating table gnujiko_desktop_pages...";
$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `gnujiko_desktop_pages` (
`id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`uid` INT( 11 ) NOT NULL ,
`gid` INT( 11 ) NOT NULL ,
`_mod` VARCHAR( 3 ) NOT NULL ,
`name` VARCHAR( 32 ) NOT NULL ,
`section_type` VARCHAR( 64 ) NOT NULL ,
`section_xml_params` TEXT NOT NULL ,
`ordering` INT( 11 ) NOT NULL ,
INDEX ( `uid` , `gid` , `_mod` , `ordering` )
)");
$db->Close();
$_SHELL_OUT.= "done!\n";

$_SHELL_OUT.= "Creating table gnujiko_desktop_modules...";
$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `gnujiko_desktop_modules` (
`id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`uid` INT( 11 ) NOT NULL ,
`gid` INT( 11 ) NOT NULL ,
`_mod` VARCHAR( 3 ) NOT NULL ,
`page_id` INT( 11 ) NOT NULL ,
`module_name` VARCHAR( 64 ) NOT NULL ,
`module_title` VARCHAR( 64 ) NOT NULL ,
`section_id` VARCHAR( 64 ) NOT NULL ,
`ordering` INT( 11 ) NOT NULL ,
`xml_params` TEXT NOT NULL ,
INDEX ( `uid` , `gid` , `_mod` , `page_id` , `section_id` , `ordering` )
)");
$db->Close();
$_SHELL_OUT.= "done!\n";

$_SHELL_OUT.= "Creating table gnujiko_desktop_connections...";
$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `gnujiko_desktop_connections` (
`id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`mod_src` INT( 11 ) NOT NULL ,
`port_src` VARCHAR( 64 ) NOT NULL ,
`mod_dest` INT( 11 ) NOT NULL ,
`port_dest` VARCHAR( 64 ) NOT NULL ,
`page_id` INT( 11 ) NOT NULL ,
INDEX ( `mod_src` , `mod_dest` , `page_id` )
)");
$db->Close();
$_SHELL_OUT.= "done!\n";


$db = new AlpaDatabase();
$db->RunQuery("ALTER TABLE `gnujiko_desktop_modules` ADD `html_contents` LONGTEXT NOT NULL , ADD `css` TEXT NOT NULL , ADD `javascript` TEXT NOT NULL");
$db->Close();
}