<?php global $_BASE_PATH, $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

/* 14-09-2013 */
if(version_compare($_INSTALLED_VER, "2.34beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `stores` ADD `doc_ext` VARCHAR(8) NOT NULL");
 $db->Close();
}

/* 17-09-2013 */
if(version_compare($_INSTALLED_VER, "2.35beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `stores` ADD `ext_refcat` INT(11) NOT NULL, ADD `gid` INT(11) NOT NULL");
 $db->Close();
}

/* 24-02-2014 - GStore ver.2 */
if(version_compare($_INSTALLED_VER, "2.36beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE gnujiko_applications SET icon='Store2/icon.png',url='Store2/' WHERE (url='Store' OR url='Store/' OR url='Store/index.php')");
 $db->Close();
 GShell("store fix-qty",$_SESSION_ID,$_SHELL_ID);
}

/* 25-08-2014 - Aggiornata tabella store_movements */
if(version_compare($_INSTALLED_VER, "2.37beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `store_movements` ADD `barcode` VARCHAR(32) NOT NULL, ADD `location` VARCHAR(64) NOT NULL, ADD INDEX(`barcode`)");
 $db->Close();

 /* Archivio causali movimenti magazzino */
 $ret = GShell("dynarc new-archive -prefix storemovcausals -name `Causali movimenti magazzino` -perms 644 --def-cat-perms 644 --def-item-perms 644", $_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
 {
  $ret = GShell("dynarc install-extension coding -ap storemovcausals", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-cat -ap storemovcausals -name CARICO -tag UPLOAD", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-cat -ap storemovcausals -name SCARICO -tag DOWNLOAD", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-cat -ap storemovcausals -name MOVIMENTAZIONE -tag TRANSFER", $_SESSION_ID, $_SHELL_ID);
  
  $ret = GShell("dynarc new-item -ap storemovcausals -ct UPLOAD -name `Carico da DDT` -code-str CARCDDT", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-item -ap storemovcausals -ct UPLOAD -name `Carico conto riparazione` -code-str CARCRIP", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-item -ap storemovcausals -ct UPLOAD -name `Carico conto lavoro` -code-str CARCLAV", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-item -ap storemovcausals -ct DOWNLOAD -name `Scarico per conto visione` -code-str SCARCVIS", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-item -ap storemovcausals -ct DOWNLOAD -name `Scarico per conto riparazione` -code-str SCARCRIP", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-item -ap storemovcausals -ct DOWNLOAD -name `Scarico per conto lavorazione` -code-str SCARCLAV", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-item -ap storemovcausals -ct TRANSFER -name `Movim. per lavorazione` -code-str MOVCLAV", $_SESSION_ID, $_SHELL_ID);
  $ret = GShell("dynarc new-item -ap storemovcausals -ct TRANSFER -name `Movim. per stoccaggio` -code-str MOVSTOCK", $_SESSION_ID, $_SHELL_ID);
 }

 include_once($_BASE_PATH."include/userfunc.php");

 /* Create new group */
 GShell("groupadd `gstore` --first-user",$_SESSION_ID,$_SHELL_ID);

 $gid = _getGID("gstore");

 /* Sistema il gruppo ed i permessi */
 $db = new AlpaDatabase();
 $db->RunQuery("UPDATE gnujiko_applications SET gid='".$gid."',_mod='640' WHERE url='Store2/'");
 $db->Close();
}

/* 01-11-2014 : Aggiunto campi su tabella */
if(version_compare($_INSTALLED_VER, "2.38beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `store_movements` ADD `stock_qty` FLOAT NOT NULL,  
 ADD `stock_amount` DECIMAL(10,4) NOT NULL,  
 ADD `stock_vat` DECIMAL(10,4) NOT NULL,  
 ADD `stock_total` DECIMAL(10,4) NOT NULL");
 $db->Close();
}

/* 01-11-2014 : Creo tabella stock_enhancement */
if(version_compare($_INSTALLED_VER, "2.39beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `stock_enhancement` (
 `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
 `store_id` INT(11) NOT NULL, 
 `ap` VARCHAR(32) NOT NULL, 
 `amount` DECIMAL(10,4) NOT NULL, 
 `vat` DECIMAL(10,4) NOT NULL, 
 `total` DECIMAL(10,4) NOT NULL, 
 INDEX (`store_id`, `ap`)
 )");
 $db->Close();

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT ext.archive_id,archive.tb_prefix FROM dynarc_archive_extensions AS ext
	INNER JOIN dynarc_archives AS archive
	ON ext.archive_id = archive.id
	WHERE ext.extension_name='storeinfo'");
 while($db->Read())
 {
  GShell("dynarc install-extension storeinfo -ap '".$db->record['tb_prefix']."' --force",$_SESSION_ID,$_SHELL_ID);
 }
 $db->Close();
}

/* 19-11-2014  - Aggiunto campi delle varianti */
if(version_compare($_INSTALLED_VER, "2.40beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `store_movements` ADD `variant_coltint` VARCHAR(64) NOT NULL, ADD `variant_sizmis` VARCHAR(64) NOT NULL");
 $db->Close();
}

/* 24-03-2016  - Aggiunto campo store_2_id su store_movements */
if(version_compare($_INSTALLED_VER, "2.42beta", "<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `store_movements` ADD `store_2_id` INT(11) NOT NULL");
 $db->Close();
}