<?php 
global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Remove tables */
$db = new AlpaDatabase();
$db->RunQuery("DROP TABLE IF EXISTS `stores`");
$db->RunQuery("DROP TABLE IF EXISTS `store_movements`");
$db->RunQuery("DROP TABLE IF EXISTS `stock_enhancement`");
$db->Close();