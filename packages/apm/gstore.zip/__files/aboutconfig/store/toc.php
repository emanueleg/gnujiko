<?php

global $_APPLICATION_CONFIG;

$_APPLICATION_CONFIG['mainmenu'][] = array("title"=>"Magazzino", "url"=>"store/index.php");
