<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 08-04-2014
 #PACKAGE: gstore
 #DESCRIPTION: Italian translation for GStore2.
 #VERSION: 2.0beta
 #CHANGELOG: 
 #TODO:
 
*/

global $_DICTIONARY;

/* MOVEMENTS */
$_DICTIONARY['catalog'] = "catalogo";
$_DICTIONARY['product'] = "prodotto";
$_DICTIONARY['customer'] = "cliente";
$_DICTIONARY['serial number'] = "numero seriale";
$_DICTIONARY['lot'] = "lotto";
$_DICTIONARY['vendor'] = "fornitore";
$_DICTIONARY['notes'] = "note";
$_DICTIONARY['Find a product'] = "Cerca un prodotto";
$_DICTIONARY['Find a vendor'] = "Cerca un fornitore";
$_DICTIONARY['Filter by:'] = "Filtra per:";






