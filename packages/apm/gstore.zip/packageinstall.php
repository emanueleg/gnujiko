<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `gstore` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Store2/'");
if($db->Read())
$db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Magazzino...";
 $ret = GShell("system register-app -name `Magazzino` -desc `Gestione magazzino prodotti.` -url 'Store2/' -icon 'Store2/icon.png' -group gstore -perms 640",$_SESSION_ID, $_SHELL_ID);
 $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create tables */
$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `stores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `doc_ext` varchar(8) NOT NULL,
  `ext_refcat` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
)");

$db->RunQuery("CREATE TABLE IF NOT EXISTS `store_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `store_2_id` int(11) NOT NULL,
  `op_time` datetime NOT NULL,
  `uid` int(11) NOT NULL,
  `mov_act` tinyint(1) NOT NULL,
  `mov_causal` varchar(8) NOT NULL,
  `qty` float NOT NULL,
  `units` varchar(16) NOT NULL,
  `serial_number` varchar(64) NOT NULL,
  `lot` varchar(64) NOT NULL,
  `ref_at` varchar(32) NOT NULL,
  `ref_ap` varchar(64) NOT NULL,
  `ref_id` int(11) NOT NULL,
  `ref_code` varchar(64) NOT NULL,
  `ref_name` varchar(128) NOT NULL,
  `ref_vendor_id` int(11) NOT NULL,
  `ref_vendor_code` varchar(64) NOT NULL,
  `vendor_unitprice` float NOT NULL,
  `vendor_vatrate` float NOT NULL,
  `price` float NOT NULL,
  `vatrate` float NOT NULL,
  `discount_perc` float NOT NULL,
  `discount_inc` float NOT NULL,
  `account_id` int(11) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `doc_ap` varchar(64) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `doc_ref` varchar(64) NOT NULL,
  `barcode` varchar(32) NOT NULL,
  `location` varchar(64) NOT NULL,
  `stock_qty` FLOAT NOT NULL,  
  `stock_amount` DECIMAL(10,4) NOT NULL,  
  `stock_vat` DECIMAL(10,4) NOT NULL,  
  `stock_total` DECIMAL(10,4) NOT NULL,
  `variant_coltint` VARCHAR(64) NOT NULL ,
  `variant_sizmis` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`,`uid`,`mov_act`,`mov_causal`,`serial_number`,`lot`,`ref_ap`,`ref_id`,`ref_code`,`ref_vendor_id`,`account_id`,`barcode`),
  KEY `doc_ap` (`doc_ap`,`doc_id`)
)");

$db->RunQuery("CREATE TABLE IF NOT EXISTS `stock_enhancement` (
 `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
 `store_id` INT(11) NOT NULL, 
 `ap` VARCHAR(32) NOT NULL, 
 `amount` DECIMAL(10,4) NOT NULL, 
 `vat` DECIMAL(10,4) NOT NULL, 
 `total` DECIMAL(10,4) NOT NULL, 
 INDEX (`store_id`, `ap`)
)");

$db->Close();

/* Create print models categories */
$ret = GShell("dynarc cat-info -ap `printmodels` -tag store",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Magazzino` -tag `store` -group printmodels",$_SESSION_ID, $_SHELL_ID);

$ret = GShell("dynarc cat-info -ap `printmodels` -tag storeinfo",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Giacenze` -tag `storeinfo` -pt store -group printmodels",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-store-info.xml -ap `printmodels` -ct storeinfo",$_SESSION_ID,$_SHELL_ID);
}

$ret = GShell("dynarc cat-info -ap `printmodels` -tag storemovements",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Movimenti` -tag `storemovements` -pt store -group printmodels",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-store-movements.xml -ap `printmodels` -ct storemovements",$_SESSION_ID,$_SHELL_ID);
}

/* Archivio causali movimenti magazzino */
$ret = GShell("dynarc new-archive -prefix storemovcausals -name `Causali movimenti magazzino` -perms 644 --def-cat-perms 644 --def-item-perms 644", $_SESSION_ID, $_SHELL_ID);
if(!$ret['error'])
{
 $ret = GShell("dynarc install-extension coding -ap storemovcausals", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-cat -ap storemovcausals -name CARICO -tag UPLOAD", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-cat -ap storemovcausals -name SCARICO -tag DOWNLOAD", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-cat -ap storemovcausals -name MOVIMENTAZIONE -tag TRANSFER", $_SESSION_ID, $_SHELL_ID);
  
 $ret = GShell("dynarc new-item -ap storemovcausals -ct UPLOAD -name `Carico da DDT` -code-str CARCDDT", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-item -ap storemovcausals -ct UPLOAD -name `Carico conto riparazione` -code-str CARCRIP", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-item -ap storemovcausals -ct UPLOAD -name `Carico conto lavoro` -code-str CARCLAV", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-item -ap storemovcausals -ct DOWNLOAD -name `Scarico per conto visione` -code-str SCARCVIS", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-item -ap storemovcausals -ct DOWNLOAD -name `Scarico per conto riparazione` -code-str SCARCRIP", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-item -ap storemovcausals -ct DOWNLOAD -name `Scarico per conto lavorazione` -code-str SCARCLAV", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-item -ap storemovcausals -ct TRANSFER -name `Movim. per lavorazione` -code-str MOVCLAV", $_SESSION_ID, $_SHELL_ID);
 $ret = GShell("dynarc new-item -ap storemovcausals -ct TRANSFER -name `Movim. per stoccaggio` -code-str MOVSTOCK", $_SESSION_ID, $_SHELL_ID);
}