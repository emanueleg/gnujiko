<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `gpart` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Register application */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_applications WHERE url='Parts/'");
if($db->Read())
 $db->RunQuery("UPDATE gnujiko_applications SET published='1' WHERE id='".$db->record['id']."'");
else
{
 $_SHELL_OUT.= "Register application Componenti...";
 $ret = GShell("system register-app -name `Componenti` -desc `Catalogo componenti / semilavorati.` -url 'Parts/' -icon 'Parts/icon.png' -group gpart -perms 640",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_ERR = $ret['error'];
  $_SHELL_OUT = $ret['message'];
 }
 else
  $_SHELL_OUT.= $ret['message'];
}
$db->Close();

/* Create new archive */
$_SHELL_OUT.= "Create new archive Componenti / Semilavorati...";
$ret = GShell("dynarc new-archive -name `Componenti / Semilavorati` -prefix 'gpart' -group 'gpart' -type gpart -perms '660' --def-cat-perms '660' --def-item-perms '660' --functions-file `etc/dynarc/archive_funcs/__gpart/index.php` -launcher `gframe -f gpart/edit.item -params id=%d`",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Installing extension */
$_SHELL_OUT.= "Install extension coding...";
$ret = GShell("dynarc install-extension 'coding' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension custompricing...";
$ret = GShell("dynarc install-extension 'custompricing' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension gpart...";
$ret = GShell("dynarc install-extension 'gpart' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension idoc...";
$ret = GShell("dynarc install-extension 'idoc' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension pricing...";
$ret = GShell("dynarc install-extension 'pricing' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension storeinfo...";
$ret = GShell("dynarc install-extension 'storeinfo' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension thumbnails...";
$ret = GShell("dynarc install-extension 'thumbnails' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension variants...";
$ret = GShell("dynarc install-extension 'variants' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension variantstock...";
$ret = GShell("dynarc install-extension 'variantstock' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension vendorprices...";
$ret = GShell("dynarc install-extension 'vendorprices' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension components...";
$ret = GShell("dynarc install-extension 'components' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension materials...";
$ret = GShell("dynarc install-extension 'materials' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

$_SHELL_OUT.= "Install extension labors...";
$ret = GShell("dynarc install-extension 'labors' -ap 'gpart'",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];

/* Create new category */
$_SHELL_OUT.= "Create category MARCHE COMPONENTI...";
$ret = GShell("dynarc new-cat -ap 'brands' -name `MARCHE COMPONENTI` -tag `gpart` -group 'gpart' -perms '664' --def-item-perms 664",$_SESSION_ID,$_SHELL_ID);
//if($ret['error']) {$_SHELL_ERR=$ret['error']; $_SHELL_OUT.="failed!".$ret['message'];} else $_SHELL_OUT.=$ret['message'];