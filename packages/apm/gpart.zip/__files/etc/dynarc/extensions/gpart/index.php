<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 26-09-2015
 #PACKAGE: gpart
 #DESCRIPTION: GPart basic info extension for Dynarc.
 #VERSION: 2.1beta
 #CHANGELOG: 26-09-2015 : Aggiunto campo nascondi dal magazzino.
 #TODO:
 
*/

global $_BASE_PATH;

//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_install($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` ADD `brand` VARCHAR( 32 ) NOT NULL ,
ADD `brand_id` INT( 11 ) NOT NULL ,
ADD `model` VARCHAR( 64 ) NOT NULL ,
ADD `barcode` VARCHAR( 32 ) NOT NULL ,
ADD `manufacturer_code` VARCHAR( 64 ) NOT NULL ,
ADD `item_location` VARCHAR( 64 ) NOT NULL ,
ADD `qty_sold` FLOAT NOT NULL ,
ADD `units` VARCHAR( 16 ) NOT NULL ,
ADD `weight` FLOAT NOT NULL ,
ADD `weightunits` VARCHAR ( 5 ) NOT NULL ,
ADD `hide_in_store` TINYINT(1) NOT NULL,
ADD INDEX (`barcode`,`brand_id`,`hide_in_store`)");

 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_categories` ADD `subcat_count` INT( 4 ) NOT NULL ,
ADD `items_count` INT( 4 ) NOT NULL ,
ADD `totitems_count` INT( 4 ) NOT NULL");

 $db->Close();
 return array("message"=>"GPart extension has been installed into archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_uninstall($params, $sessid, $shellid=0, $archiveInfo=null)
{
 $db = new AlpaDatabase();
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_items` DROP `brand`, DROP `model`, DROP `barcode`, DROP `manufacturer_code`,
  DROP `item_location`, DROP `qty_sold`, DROP `units`, DROP `weight`, DROP `weightunits`, DROP `brand_id`");
 $db->RunQuery("ALTER TABLE `dynarc_".$archiveInfo['prefix']."_categories` DROP `subcat_count`,  DROP `items_count`, DROP `totitems_count`, DROP `hide_in_store`");
 $db->Close();

 return array("message"=>"GPart extension has been removed from archive ".$archiveInfo['name']."\n");
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_catset($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'subcatcount' : {$subcatCount=$args[$c+1]; $c++;} break;
   case 'itemscount' : {$itemsCount=$args[$c+1]; $c++;} break;
   case 'totitemscount' : {$totItemsCount=$args[$c+1]; $c++;} break;
  }

 $db = new AlpaDatabase();
 $q = "";
 if(isset($subcatCount))
  $q.= ",subcat_count='$subcatCount'";
 if(isset($itemsCount))
  $q.= ",items_count='$itemsCount'";
 if(isset($totItemsCount))
  $q.= ",totitems_count='$totItemsCount'";
 
 if($q)
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_categories SET ".ltrim($q,",")." WHERE id='".$catInfo['id']."'");
 $db->Close();

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_set($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 if($isCategory)
  return dynarcextension_gpart_catset($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'brand' : {$brandName=$args[$c+1]; $c++;} break;
   case 'brandid' : {$brandId=$args[$c+1]; $c++;} break;
   case 'model' : {$model=$args[$c+1]; $c++;} break;
   case 'barcode' : {$barcode=$args[$c+1]; $c++;} break;
   case 'manufacturer-code' : case 'manufacturer_code' : case 'manufacturercode' : case 'mancode' : {$manufacturerCode=$args[$c+1]; $c++;} break;
   case 'location' : {$itemLocation=$args[$c+1]; $c++;} break;
   case 'sold' : case 'qty-sold' : case 'qtysold' : {$qtySold=$args[$c+1]; $c++;} break;
   case 'units' : case 'umis' : {$units=$args[$c+1]; $c++;} break;
   case 'weight' : {$weight=$args[$c+1]; $c++;} break;
   case 'weightunits' : {$weightUnits=$args[$c+1]; $c++;} break;
   case 'hideinstore' : {$hideInStore=$args[$c+1]; $c++;} break;	/* nascondi dal magazzino */
  }

 if($brandName && !$brandId)
 {
  // check if exists
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT id FROM dynarc_brands_items WHERE name='".$db->Purify($brandName)."' AND trash='0' LIMIT 1");
  if($db->Read())
   $brandId = $db->record['id'];
  else
  {
   $ret = GShell("dynarc new-item -ap brands -ct gpart -name `".$brandName."`",$sessid,$shellid);
   if(!$ret['error'])
	$brandId = $ret['outarr']['id'];
  }
  $db->Close();
 }

 $db = new AlpaDatabase();
 $q="";
 if(isset($brandName))					$q.=",brand='".$db->Purify($brandName)."'";
 if(isset($brandId))					$q.=",brand_id='".$brandId."'";
 if(isset($model))						$q.= ",model='".$db->Purify($model)."'";
 if(isset($barcode))					$q.= ",barcode='".$barcode."'";
 if(isset($manufacturerCode))			$q.= ",manufacturer_code='".$manufacturerCode."'";
 if(isset($itemLocation))				$q.= ",item_location='".$db->Purify($itemLocation)."'";
 if(isset($qtySold))					$q.= ",qty_sold='".$qtySold."'";
 if(isset($units))						$q.= ",units='".$units."'";
 if(isset($weight))						$q.= ",weight='".$weight."'";
 if(isset($weightUnits))				$q.= ",weightunits='".$weightUnits."'";
 if(isset($hideInStore))				$q.= ",hide_in_store='".$hideInStore."'";

 if($q)
  $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET ".ltrim($q,",")." WHERE id='".$itemInfo['id']."'");
 $db->Close();


 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_unset($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_catget($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'subcatcount' : $subcatCount=true; break;
   case 'itemscount' : $itemsCount=true; break;
   case 'totitemscount' : $totItemsCount=true; break;
  }

 if(!count($args))
  $all=true;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT subcat_count,items_count,totitems_count FROM dynarc_".$archiveInfo['prefix']."_categories WHERE id='".$catInfo['id']."'");
 $db->Read();
 if($subcatCount || $all)
  $catInfo['subcatcount'] = $db->record['subcat_count'];
 if($itemsCount || $all)
  $catInfo['itemscount'] = $db->record['items_count'];
 if($totItemsCount || $all)
  $catInfo['totitemscount'] = $db->record['totitems_count'];
 $db->Close();

 return $catInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_get($args, $sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 if($isCategory)
  return dynarcextension_gpart_catget($args, $sessid, $shellid, $archiveInfo, $itemInfo);

 global $_BASE_PATH;

 for($c=0; $c < count($args); $c++)
  switch($args[$c])
  {
   case 'brand' : $brand=true; break;
   case 'model' : $model=true; break;
   case 'barcode' : $barcode=true; break;
   case 'manufacturer-code' : case 'manufacturer_code' : case 'manufacturercode' : case 'mancode' : $manufacturerCode=true; break;
   case 'location' : $itemLocation=true; break;
   case 'sold' : case 'qty-sold' : case 'qtysold' : $qtySold=true; break;
   case 'units' : case 'umis' : $units=true; break;
   case 'weight' : $weight=true; break;
   case 'hideinstore' : $hideInStore=true; break;
  }

 if(!count($args))
  $all=true;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT brand,brand_id,model,barcode,manufacturer_code,item_location,qty_sold,units,weight,weightunits,hide_in_store FROM dynarc_".$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 if($brand || $all)
 {
  $itemInfo['brand'] = $db->record['brand'];
  $itemInfo['brand_id'] = $db->record['brand_id'];
 }
 if($model || $all)						$itemInfo['model'] = $db->record['model'];
 if($barcode || $all)					$itemInfo['barcode'] = $db->record['barcode'];
 if($manufacturerCode || $all)			$itemInfo['manufacturer_code'] = $db->record['manufacturer_code'];
 if($itemLocation || $all)				$itemInfo['item_location'] = $db->record['item_location'];
 if($qtySold || $all)					$itemInfo['sold'] = $db->record['qty_sold'];
 if($units || $all)						$itemInfo['units'] = $db->record['units'];
 if($weight || $all)
 {
  $itemInfo['weight'] = $db->record['weight'];
  $itemInfo['weightunits'] = $db->record['weightunits'];
 }
 if($hideInStore || $all)				$itemInfo['hide_in_store'] = $db->record['hide_in_store'];
 $db->Close();

 return $itemInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_oncopyitem($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 $db = new AlpaDatabase();
 $db2 = new AlpaDatabase();
 $db->RunQuery("SELECT brand,brand_id,model,barcode,manufacturer_code,item_location,units,weight,weightunits,hide_in_store FROM dynarc_"
	.$archiveInfo['prefix']."_items WHERE id='".$srcInfo['id']."'");
 $db->Read();
 $db2->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET brand='".$db2->Purify($db->record['brand'])."',brand_id='"
	.$db->record['brand_id']."',model='".$db2->Purify($db->record['model'])."',barcode='".$db->record['barcode']."',manufacturer_code='"
	.$db->record['manufacturer_code']."',item_location='".$db2->Purify($db->record['item_location'])."',units='".$db->record['units']."',weight='"
	.$db->record['weight']."',weightunits='".$db->record['weightunits']."',hide_in_store='".$db->record['hide_in_store']."' WHERE id='".$cloneInfo['id']."'");
 $db2->Close();
 $db->Close();

 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_oncreateitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_oncreatecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_onedititem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_oneditcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_ondeleteitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_ondeletecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_ontrashitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_ontrashcategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_onrestoreitem($args, $sessid, $shellid, $archiveInfo, $itemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_onrestorecategory($args, $sessid, $shellid, $archiveInfo, $catInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_onmoveitem($args, $sessid, $shellid, $archiveInfo, $oldItemInfo, $newItemInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_onmovecategory($args, $sessid, $shellid, $archiveInfo, $oldCatInfo, $newCatInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_oncopycategory($sessid, $shellid, $archiveInfo, $srcInfo, $cloneInfo)
{
 return $cloneInfo;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_onarchiveempty($args, $sessid, $shellid, $archiveInfo)
{
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_export($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 if($isCategory)
  return;

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT brand,brand_id,model,barcode,manufacturer_code,item_location,units,weight,weightunits,hide_in_store FROM dynarc_"
	.$archiveInfo['prefix']."_items WHERE id='".$itemInfo['id']."'");
 $db->Read();
 $xml = "<gpart brand='".$db->record['brand']."' brand_id='".$db->record['brand_id']."' model='".$db->record['model']."' barcode='"
	.$db->record['barcode']."' manufacturer_code='".$db->record['manufacturer_code']."' item_location='".$db->record['item_location']."' units='"
	.$db->record['units']."' weight='".$db->record['weight']."' weightunits='".$db->record['weightunits']."' hideinstore='"
	.$db->record['hide_in_store']."'/>";
 $db->Close();
 return array('xml'=>$xml);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_import($sessid, $shellid, $archiveInfo, $itemInfo, $node, $isCategory=false)
{
 if($isCategory)
  return;

 if(!$node)
  return;

 $q = "";
 $db = new AlpaDatabase();
 if($brand = $node->getString('brand'))					$q.= ",brand='".$db->Purify($brand)."'";
 if($brandId = $node->getString('brand_id'))			$q.= ",brand_id='".$brandId."'";
 if($model = $node->getString('model'))					$q.= ",model='".$db->Purify($model)."'";
 if($barcode = $node->getString('barcode'))				$q.= ",barcode='".$barcode."'";
 if($mancode = $node->getString('manufacturer_code'))	$q.= ",manufacturer_code='".$mancode."'";
 if($location = $node->getString('item_location'))		$q.= ",item_location='".$location."'";
 if($units = $node->getString('units'))					$q.= ",units='".$units."'";
 if($weight = $node->getString('weight'))				$q.= ",weight='".$weight."'";
 if($weightUnits = $node->getString('weightunits'))		$q.= ",weightunits='".$weightUnits."'";
 if($hideInStore = $node->getString('hideinstore'))		$q.= ",hide_in_store='".$hideInStore."'";
 
 $db->RunQuery("UPDATE dynarc_".$archiveInfo['prefix']."_items SET ".ltrim($q,",")." WHERE id='".$itemInfo['id']."'");
 $db->Close();

 return true;
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_syncexport($sessid, $shellid, $archiveInfo, $itemInfo, $isCategory=false)
{
 global $_USERS_HOMES;
 $xml = "";
 $attachments = array();

 return array('xml'=>$xml,'attachments'=>$attachments);
}
//-------------------------------------------------------------------------------------------------------------------//
function dynarcextension_gpart_syncimport($sessid, $shellid, $archiveInfo, $itemInfo, $xmlNode, $isCategory=false)
{
 global $_USER_PATH;
 return true;
}
//-------------------------------------------------------------------------------------------------------------------//

