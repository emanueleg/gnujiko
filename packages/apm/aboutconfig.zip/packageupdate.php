<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Verifica se esiste già l'archivio 'AboutConfig - HTML Params' altrimenti lo crea */
$ret = GShell("dynarc archive-info -prefix aboutconfig_htmlparms",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-archive -name 'AboutConfig - HTML Params' -prefix aboutconfig_htmlparms -perms 644 --def-cat-perms 644 --def-item-perms 644 --hidden",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_OUT.= $ret['message'];
  $_SHELL_ERR = $ret['error'];
 }
}

/* Insert into config menu */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_config_menu WHERE cfg_file='/share/widgets/config/system/aboutconfig.php'");
if(!$db->Read())
 GShell("system cfg-add-element -name `AboutConfig` -sec system -perms 444 -icon /share/widgets/config/icons/aboutconfig.png -file /share/widgets/config/system/aboutconfig.php",$_SESSION_ID, $_SHELL_ID);
$db->Close();


