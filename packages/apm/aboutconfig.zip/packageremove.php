<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("DROP TABLE IF EXISTS `aboutconfig_appconfig`");
$db->RunQuery("DROP TABLE IF EXISTS `aboutconfig_usersettings`");
$db->Close();

/* Remove archive 'AboutConfig - HTML Params' */
GShell("dynarc delete-archive -ap aboutconfig_htmlparms -r",$_SESSION_ID, $_SHELL_ID);

/* Remove from config menu */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_config_menu WHERE cfg_file='/share/widgets/config/system/aboutconfig.php'");
if($db->Read())
 GShell("system cfg-delete-element -id `".$db->record['id']."`",$_SESSION_ID, $_SHELL_ID);
$db->Close();
