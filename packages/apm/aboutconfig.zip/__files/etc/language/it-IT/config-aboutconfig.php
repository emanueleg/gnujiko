<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2014 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 28-05-2014
 #PACKAGE: aboutconfig
 #DESCRIPTION: Italian translation file for Gnujiko Aboutconfig
 #VERSION: 
 #CHANGELOG:
 #TODO:
 
*/

global $_DICTIONARY;

$_DICTIONARY["Applications Settings"] = "Impostazioni Applicazioni";
$_DICTIONARY["Advanced configuration panel for setting the parameters for the various applications."] = "Pannello di configurazione avanzato per l&lsquo;impostazione dei parametri delle varie applicazioni.";

