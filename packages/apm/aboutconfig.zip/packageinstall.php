<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `aboutconfig_appconfig` (
`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`app_name` VARCHAR(32) NOT NULL ,
`app_section` VARCHAR(32) NOT NULL ,
`xml_config` LONGTEXT NOT NULL ,
`xml_default_settings` LONGTEXT NOT NULL ,
INDEX (`app_name`,`app_section`)
)");
$db->Close();

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `aboutconfig_usersettings` (
`id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`user_id` INT(11) NOT NULL ,
`app_name` VARCHAR(32) NOT NULL ,
`app_section` VARCHAR(32) NOT NULL ,
`xml_settings` LONGTEXT NOT NULL ,
INDEX (`user_id`,`app_name`,`app_section`)
)");
$db->Close();

/* Verifica se esiste già l'archivio 'AboutConfig - HTML Params' altrimenti lo crea */
$ret = GShell("dynarc archive-info -prefix aboutconfig_htmlparms",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-archive -name 'AboutConfig - HTML Params' -prefix aboutconfig_htmlparms -perms 644 --def-cat-perms 644 --def-item-perms 644 --hidden",$_SESSION_ID, $_SHELL_ID);
 if($ret['error'])
 {
  $_SHELL_OUT.= $ret['message'];
  $_SHELL_ERR = $ret['error'];
 }
}

/* Insert into config menu */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_config_menu WHERE cfg_file='/share/widgets/config/system/aboutconfig.php'");
if(!$db->Read())
 GShell("system cfg-add-element -name `AboutConfig` -sec system -perms 444 -icon /share/widgets/config/icons/aboutconfig.png -file /share/widgets/config/system/aboutconfig.php",$_SESSION_ID, $_SHELL_ID);
$db->Close();
