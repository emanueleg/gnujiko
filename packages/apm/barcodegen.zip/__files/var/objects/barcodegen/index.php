<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2013 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 07-12-2013
 #PACKAGE: barcodegen
 #DESCRIPTION: 
 #VERSION: 2.0beta-5.1.0
 #CHANGELOG: 
 #TODO: creare una classe che possa fare in modo di salvare su file immagine un barcode.
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;

/* Si usa così:
   
   <img src='share/gd/barcode.php?barcode=12345'/>

*/
