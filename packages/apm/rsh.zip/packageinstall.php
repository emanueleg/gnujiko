<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `gnujiko_rsh_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_url` varchar(255) NOT NULL,
  `server_name` varchar(80) NOT NULL,
  `login` varchar(40) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server_name` (`server_name`)
)");
$db->Close();