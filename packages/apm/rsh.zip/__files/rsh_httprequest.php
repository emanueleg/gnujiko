<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: rsh
 #DESCRIPTION: Remote shell HTTP Request file
 #VERSION: 2.2beta
 #CHANGELOG: 24-10-2016 : Sostituita funzione mysql escape string con funzione db->EscapeString() per integrazione con mysqli.
			 24-07-2013 : Aggiunto comando test per effettuare test su connessioni rsh.
 #TODO:
 
*/
include('init/init1.php');
include('include/session.php');
include('include/gshell.php');

define("VALID-GNUJIKO-SHELLREQUEST",1);

switch($_POST['request'])
{
 case 'command' : case 'test' : {
	 $remotesessid = isset($_POST['sessid']) ? $_POST['sessid'] : 0;
	 $login = isset($_POST['login']) ? $_POST['login'] : "";
	 $passwd = isset($_POST['password']) ? $_POST['password'] : "";

	 if($remotesessid)
	 {
	  $db = new AlpaDatabase();
	  $db->RunQuery("SELECT * FROM gnujiko_session WHERE dev='rshell' AND devid='".$remotesessid."'");
	  if(!$db->Read())
	  {
	   if($login)
	   {
		$username = $db->EscapeString(trim($login));
		$password = $db->EscapeString(trim($passwd));

		$db2 = new AlpaDatabase();
		$db2->RunQuery("SELECT * FROM gnujiko_users WHERE username='$username'");
		if(!$db2->Read())
		 return rsh_returnError("Remote login failed. User '$username' does not exists!","USER_DOES_NOT_EXISTS");
		if($db2->record['password'] == "!")
  		 $cryptpass = "!";
 		else
  		 $cryptpass = md5($password.$db2->record['regtime']);
		if($db2->record['password'] != $cryptpass)
		 return rsh_returnError("Remote login failed. Password wrong!","PASSWORD_WRONG");
		$time = time();
		$uid = $db2->record['id'];
		$gid = $db2->record['group_id'];
		$uname = $db2->record['username'];
		$sessid = md5($uid.$uname.$time);
		$_POST['sessid'] = $sessid;
		$_POST['shellid'] = $remotesessid;

		$db2->Close();
		$db->Close();

		$db = new AlpaDatabase();
		$db->RunQuery("INSERT INTO gnujiko_session(uname,login_time,time,session_id,uid,gid,dev,devid) VALUES('$uname','$time','$time','$sessid','$uid','$gid','rshell','$remotesessid')");
		$db->Close();
	   }
	  }
	  else
	  {
	   $_POST['sessid'] = $db->record['session_id'];
	   $_POST['shellid'] = $db->record['devid'];
	   $db->Close();
	  }
	 }
	 include("gshell_httprequest.php");
	} break;
}

function rsh_returnError($message, $code="")
{
 header("Content-Type: application/xml; charset:UTF-8");
 $xmloutput = "<xml encoding='utf-8'>";
 $xmloutput.= "<request type='command' result='false' message='$message' error='$code'/>";
 $xmloutput.="</xml>";
 echo $xmloutput;
}

