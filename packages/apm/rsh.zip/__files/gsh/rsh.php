<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: rsh
 #DESCRIPTION: Official Gnujiko Remote Shell
 #VERSION: 2.3beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.
			 28-06-2016 : Bug fix in function rsh_PostRequest
			 24-07-2013 : Aggiunto comando test.
 #DEPENDS:
 #TODO:
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;
include_once($_BASE_PATH."include/userfunc.php");

function shell_rsh($args, $sessid, $shellid=null)
{
 switch($args[0])
 {
  case 'register-server' : return rsh_registerServer($args, $sessid, $shellid); break;
  case 'server-list' : return rsh_serverList($args, $sessid, $shellid); break;
  case 'test' : return rsh_test($args, $sessid, $shellid); break;
  default : return rsh_sendCommand($args, $sessid, $shellid); break;
 }

}
//-------------------------------------------------------------------------------------------------------------------//
function rsh_invalidArguments()
{
 return array('message'=>"Invalid arguments",'error'=>"INVALID_ARGUMENTS");
}
//-------------------------------------------------------------------------------------------------------------------//
function rsh_sendCommand($args, $sessid, $shellid)
{
 global $_ABSOLUTE_URL;

 $rcpp = false;
 $rCmd = "";
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 for($c=0; $c < count($args); $c++)
 {
  if($rcpp)
  {
   if(strpos($args[$c]," ") !== false)
   {
	if(strpos($args[$c],"'") === false)
	 $rCmd.= " '".$args[$c]."'";
	else if(strpos($args[$c],'"') === false)
	 $rCmd.= ' "'.$args[$c].'"';
	else if(strpos($args[$c],"`") === false)
	 $rCmd.= " `".$args[$c]."`";
	else
	 return array('message'=>"Invalid command query. There are unclosed quotes.","error"=>"INVALID_COMMAND_QUERY");
   }
   else
    $rCmd.= " ".$args[$c];
  }
  else
  {
   switch($args[$c])
   {
    case '-url' : {$url=$args[$c+1]; $c++;} break;
	case '-s' : {$server=$args[$c+1]; $c++;} break;
    case '-l' : case '-login' : {$login=$args[$c+1]; $c++;} break;
    case '-p' : case '-passwd' : case '-password' : {$password=$args[$c+1]; $c++;} break;
    case '->' : $rcpp = true; break;
   }
  }
 }

 if(!$login)
  $login = $sessInfo['uname'];
 
 if($server)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT * FROM gnujiko_rsh_servers WHERE server_name='".$server."' AND login='".$login."'");
  if(!$db->Read())
  {
   $db2 = new AlpaDatabase();
   $db2->RunQuery("SELECT * FROM gnujiko_rsh_servers WHERE server_name='".$server."'");
   if(!$db2->Read())
	return array('message'=>"Server $server does not exists.",'error'=>"SERVER_DOES_NOT_EXISTS");
   return array('message'=>"User $login is not registered into server $server.",'error'=>"USER_NOT_REGISTERED");
  }

  $url = $db->record['server_url'];
  $password = $db->record['password'];
  $db->Close();
 }
 

 $params = array();
 $params['request'] = "command";
 if(isset($login))
  $params['login'] = $login;
 if(isset($password))
  $params['password'] = $password;
 $params['sessid'] = $sessid;
 $params['command'] = ltrim($rCmd);

 $request = rsh_PostRequest(rtrim($url,"/")."/rsh_httprequest.php", $_ABSOLUTE_URL, $params);

 /* Purge request 1 */
 $pos = strpos($request[1],"<");
 if($pos > 0)
  $request[1] = substr($request[1],$pos);
 $pos = strrpos($request[1],">");
 $request[1] = substr($request[1],0, $pos+1);

 //return array('message'=>$request[1]);

 $xml = new GXML();
 if(!$xml->LoadFromString($request[1]))
  return array("message"=>"Unable to connect with server $url","error"=>"CONNECTION_FAILED");
 $req = $xml->GetElementsByTagName("request");
 $req = $req[0];
 $out = $req->getAttribute("message","");
 $htmlOutput = $req->getAttribute("htmloutput","");

 $arr = $xml->GetElementsByTagName("output_array");
 //if($arr[0])
  //$outArr = $arr[0]->toArray();

 return array('message'=>$out, 'outarr'=>$outArr, 'htmloutput'=>$htmlOutput);
}
//-------------------------------------------------------------------------------------------------------------------//
function rsh_registerServer($args, $sessid, $shellid)
{
 $sessInfo = sessionInfo($sessid);
 if($sessInfo['uname'] != "root")
  return array("message"=>"You must be root", "error"=>"YOU_MUST_BE_ROOT");

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-url' : {$serverURL = $args[$c+1]; $c++;} break;
   case '-name' : {$serverName = $args[$c+1]; $c++;} break;
   case '-l' : case '-login' : {$login = $args[$c+1]; $c++;} break;
   case '-p' : case '-password' : {$passwd = $args[$c+1]; $c++;} break;
  }

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT id FROM gnujiko_rsh_servers WHERE server_url='".$serverURL."' AND server_name='".$serverName."' AND login='".$login."'");
 if($db->Read())
  return array('message'=>"User $login is already registered into server $serverName",'error'=>"USER_ALREADY_REGISTERED");

 $db->RunQuery("INSERT INTO gnujiko_rsh_servers(server_url,server_name,login,password) VALUES('".$serverURL."','"
	.$serverName."','".$login."','".$passwd."')");
 $id = $db->GetInsertId();
 $db->Close();

 $out = "Done!. ID=$id";
 $outArr = array('id'=>$id,'url'=>$serverURL,'name'=>$serverName,'login'=>$login,'password'=>$password);

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function rsh_serverList($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);
 if($sessInfo['uname'] != "root")
  return array("message"=>"You must be root", "error"=>"YOU_MUST_BE_ROOT");

 $servers = array();

 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM gnujiko_rsh_servers WHERE 1 ORDER BY server_name ASC");
 while($db->Read())
 {
  if(!$servers[$db->record['server_name']])
  {
   $servers[$db->record['server_name']] = $db->record['server_url'];
   $outArr[] = array('name'=>$db->record['server_name'],'url'=>$db->record['server_url'],'login'=>$db->record['server_login']);
  }
 }
 $db->Close();
 
 while(list($k,$v) = each($servers))
  $out.= $k." (".$v.")\n";

 return array('message'=>$out,'outarr'=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function rsh_test($args, $sessid, $shellid)
{
 global $_ABSOLUTE_URL;

 $out = "";
 $outArr = array();

 $sessInfo = sessionInfo($sessid);

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-url' : {$url=$args[$c+1]; $c++;} break;
   case '-s' : {$server=$args[$c+1]; $c++;} break;
   case '-l' : case '-login' : {$login=$args[$c+1]; $c++;} break;
   case '-p' : case '-passwd' : case '-password' : {$password=$args[$c+1]; $c++;} break;
  }

 if(!$login)
  $login = $sessInfo['uname'];
 
 if($server)
 {
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT * FROM gnujiko_rsh_servers WHERE server_name='".$server."' AND login='".$login."'");
  if(!$db->Read())
  {
   $db2 = new AlpaDatabase();
   $db2->RunQuery("SELECT * FROM gnujiko_rsh_servers WHERE server_name='".$server."'");
   if(!$db2->Read())
	return array('message'=>"Server $server does not exists.",'error'=>"SERVER_DOES_NOT_EXISTS");
   return array('message'=>"User $login is not registered into server $server.",'error'=>"USER_NOT_REGISTERED");
  }

  $url = $db->record['server_url'];
  $password = $db->record['password'];
  $db->Close();
 }
 

 $params = array();
 $params['request'] = "test";
 if(isset($login))
  $params['login'] = $login;
 if(isset($password))
  $params['password'] = $password;
 $params['sessid'] = $sessid;

 $request = rsh_PostRequest(rtrim($url,"/")."/rsh_httprequest.php", $_ABSOLUTE_URL, $params);

 /* Purge request 1 */
 $pos = strpos($request[1],"<");
 if($pos > 0)
  $request[1] = substr($request[1],$pos);
 $pos = strrpos($request[1],">");
 $request[1] = substr($request[1],0, $pos+1);

 //return array('message'=>$request[1]);

 $xml = new GXML();
 if(!$xml->LoadFromString($request[1]))
  return array("message"=>"Unable to connect with server $url","error"=>"CONNECTION_FAILED");
 $req = $xml->GetElementsByTagName("request");
 $req = $req[0];
 $out = $req->getAttribute("message","");
 $htmlOutput = $req->getAttribute("htmloutput","");

 $arr = $xml->GetElementsByTagName("output_array");
 if($arr[0])
  $outArr = $arr[0]->toArray();
 if($req->getAttribute('sessid'))
  $outArr['sessid'] = $req->getAttribute('sessid');
 if($req->getAttribute('shellid'))
  $outArr['shellid'] = $req->getAttribute('shellid');
 
 return array('message'=>$out, 'outarr'=>$outArr, 'htmloutput'=>$htmlOutput);
}
//-------------------------------------------------------------------------------------------------------------------//
function rsh_PostRequest($url, $referer, $_data) 
{
 // convert variables array to string:
 reset($_data);
 $data = "";
 while(list($k,$v) = each($_data))
 {
  $data.= "&".$k."=".urlencode($v);
 }
 if($data != "") $data = ltrim($data,"&");


 // parse the given URL
 $url = parse_url($url);
 if($url['scheme'] != 'http') 
 { 
  //die('Only HTTP request are supported !');
  return false;
 }
 
 // extract host and path:
 $host = $url['host'];
 $path = $url['path'];
 
 // open a socket connection on port 80
 $fp = fsockopen($host, 80);
 
 // send the request headers:
 fputs($fp, "POST $path HTTP/1.1\r\n");
 fputs($fp, "Host: $host\r\n");
 fputs($fp, "Referer: $referer\r\n");
 fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
 fputs($fp, "Content-length: ". strlen($data) ."\r\n");
 fputs($fp, "Connection: close\r\n\r\n");
 fputs($fp, $data);
 
 $result = ''; 
 while(!feof($fp)) {
  // receive the results of the request
  $result .= fgets($fp, 128);
 }
 
 // close the socket connection:
 fclose($fp);

 // split the result header from the content
 $result = explode("\r\n\r\n", $result, 2);

 $header = isset($result[0]) ? $result[0] : '';
 $content = isset($result[1]) ? $result[1] : '';
 
 // return as array:
 return array($header, $content);
}
//-------------------------------------------------------------------------------------------------------------------//

