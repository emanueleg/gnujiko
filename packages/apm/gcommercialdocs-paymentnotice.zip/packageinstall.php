<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Create new group */
GShell("groupadd `commdocs-paymentnotice` --first-user",$_SESSION_ID,$_SHELL_ID);

/* Create new category */
$_SHELL_OUT.= "Create new category Avvisi di pagamento...";
$ret = GShell("dynarc new-cat -ap commercialdocs -name `Avvisi di pagamento` -tag PAYMENTNOTICE -group `commdocs-paymentnotice` --publish",$_SESSION_ID,$_SHELL_ID);
if($ret['error']) 
{ 
 $_SHELL_ERR = $ret['error']; 
 $_SHELL_OUT = $ret['message']; 
} 
else 
 $_SHELL_OUT.= $ret['message'];

// CREATE PAYMENT NOTICE PRINT MODEL //
$ret = GShell("dynarc cat-info -ap `printmodels` -tag PAYMENTNOTICE",$_SESSION_ID, $_SHELL_ID);
if($ret['error'])
{
 $ret = GShell("dynarc new-cat -ap `printmodels` -name `Avvisi di pagamento` -tag `PAYMENTNOTICE` -pt commercialdocs -group commdocs-paymentnotice",$_SESSION_ID, $_SHELL_ID);
 if(!$ret['error'])
  GShell("dynarc import -f tmp/demo-avviso-pagamento.xml -ap `printmodels` -ct PAYMENTNOTICE",$_SESSION_ID,$_SHELL_ID);
}