<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

GShell("dynarc delete-cat -ap commercialdocs -tag PAYMENTNOTICE -r", $_SESSION_ID, $_SHELL_ID);
GShell("dynarc delete-cat -ap printmodels -tag PAYMENTNOTICE -r", $_SESSION_ID, $_SHELL_ID);