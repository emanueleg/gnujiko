<?php global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID, $_INSTALLED_VER;

if(version_compare($_INSTALLED_VER, "2.83beta","<"))
{
 $db = new AlpaDatabase();
 $db->RunQuery("CREATE TABLE IF NOT EXISTS `gnujiko_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `_mod` varchar(3) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` varchar(255) NOT NULL,
  `command` text NOT NULL,
  `oneshot` tinyint(1) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `last_exec` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `uid` (`uid`,`gid`,`_mod`,`name`,`enabled`)
 )");
 $db->Close();
}