<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2010 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 30-11-2009
 #PACKAGE: gnujiko-base
 #DESCRIPTION: Provide eXtraRequest
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/

if(!defined("VALID-GNUJIKO"))
 return;

global $_BASE_PATH, $_ABSOLUTE_URL;

?>
<script language="JavaScript" src="<?php echo $_ABSOLUTE_URL; ?>include/js/xrequest.js" type="text/javascript"></script>
<?php

