<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2015 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 02-10-2015
 #PACKAGE: paymentmodes-config
 #DESCRIPTION: Paymentmodes package installer.
 #VERSION: 2.4beta
 #CHANGELOG: 02-10-2015 : Aggiunto campo collection_charges.
			 02-03-2015 : Aggiunto campo pa_mode.
			 16-04-2013 : Nuova gestione delle modalità di pagamento.
			 13-01-2013 : Aggiunto 'type' (BB=Bonifico bancario, RB=RiBa, RD=Rimessa diretta)
 #TODO:
 
*/
global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

$db = new AlpaDatabase();
$db->RunQuery("CREATE TABLE IF NOT EXISTS `payment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `type` varchar(3) NOT NULL,
  `date_terms` tinyint(1) NOT NULL,
  `deadlines` text NOT NULL,
  `day_after` tinyint(1) NOT NULL,
  `pa_mode` VARCHAR(4) NOT NULL,
  `collection_charges` DECIMAL(10,5) NOT NULL,
  PRIMARY KEY (`id`)
)");
$db->Close();

/* Insert into config menu */
GShell("system cfg-add-element -name `Modalità di pagamento` -sec managerial -perms 444 -icon /share/widgets/config/icons/payment.png -file /share/widgets/config/managerial/paymentmodes.php",$_SESSION_ID, $_SHELL_ID);