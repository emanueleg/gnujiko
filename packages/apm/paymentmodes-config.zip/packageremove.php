<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2012 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 03-11-2012
 #PACKAGE: paymentmodes-config
 #DESCRIPTION: Paymentmodes un-installer.
 #VERSION: 2.0beta
 #CHANGELOG:
 #TODO:
 
*/
global $_SHELL_OUT, $_SHELL_ERR, $_SESSION_ID, $_SHELL_ID;

/* Drop table payment_modes */
$db = new AlpaDatabase();
$db->RunQuery("DROP TABLE IF EXISTS `payment_modes`");
$db->Close();

/* Remove from config menu */
$db = new AlpaDatabase();
$db->RunQuery("SELECT id FROM gnujiko_config_menu WHERE cfg_file='/share/widgets/config/managerial/paymentmodes.php'");
if($db->Read())
 GShell("system cfg-delete-element -id `".$db->record['id']."`",$_SESSION_ID, $_SHELL_ID);
$db->Close();