<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 HackTVT Project
 copyright(C) 2016 Alpatech mediaware - www.alpatech.it
 license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 Gnujiko 10.1 is free software released under GNU/GPL license
 developed by D. L. Alessandro (alessandro@alpatech.it)
 
 #DATE: 24-10-2016
 #PACKAGE: schedule
 #DESCRIPTION: Official Gnujiko unified schedule system.
 #VERSION: 2.1beta
 #CHANGELOG: 24-10-2016 : MySQLi integration.
 #DEPENDS: 
 #TODO: 
 
*/

global $_BASE_PATH, $_ABSOLUTE_URL;

function shell_schedule($args, $sessid, $shellid=null)
{
 switch($args[0])
 {
  case 'list' : return shell_scheduleList($args, $sessid, $shellid); break;
  case 'history' : return shell_scheduleHistory($args, $sessid, $shellid); break;

  case 'add' : case 'new' : return shell_scheduleAdd($args, $sessid, $shellid); break;
  case 'edit' : return shell_scheduleEdit($args, $sessid, $shellid); break;
  case 'delete' : return shell_scheduleDelete($args, $sessid, $shellid); break;

  default : return shell_scheduleInvalidArguments($args, $sessid, $shellid); break;
 }
}
//-------------------------------------------------------------------------------------------------------------------//
function shell_scheduleInvalidArguments($args, $sessid, $shellid)
{
 $out = "Invalid arguments!\n";
 $out.= "Available commands are:\n";

 $out.= "list [-from FROM] [-to TO] ...\n";
 $out.= "history -ap ARCHIVE_PREFIX -id DOC_ID [-from FROM] [-to TO] ...\n";
 $out.= "add -ap ARCHIVE_PREFIX -id DOC_ID [OPTIONS] ...\n";
 $out.= "edit -ap ARCHIVE_PREFIX -id RECORD_ID [OPTIONS] ...\n";
 $out.= "delete -ap ARCHIVE_PREFIX (-id RECORD_ID || -refid DOC_ID)\n";

 return array("message"=>$out, "error"=>"INVALID_ARGUMENTS");
}
//-------------------------------------------------------------------------------------------------------------------//
function shell_scheduleList($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array("results"=>array(), "count"=>0);
 $archives = array();
 $orderBy = "ctime ASC";

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$archives[]=$args[$c+1]; $c++;} break;
   case '-id' : {$_ID=$args[$c+1]; $c++;} break; /* ID of document */
   /*case '-cat' : {$cat=$args[$c+1]; $c++;} break;
   case '-ct' : {$catTag=$args[$c+1]; $c++;} break;*/

   case '-from' : {$dateFrom=$args[$c+1]; $c++;} break;
   case '-to' : {$dateTo=$args[$c+1]; $c++;} break;
   case '-where' : {$where=$args[$c+1]; $c++;} break;
   case '-orderby' : case '--order-by' : {$orderBy=$args[$c+1]; $c++;} break;
   case '-limit' : {$limit=$args[$c+1]; $c++;} break;

   case '-subject' : {$subjectName=$args[$c+1]; $c++;} break;
   case '-subjectid' : {$subjectId=$args[$c+1]; $c++;} break;

   /* OPTIONS */
   case '--only-expired' : $onlyExpired=true; break;
   case '--only-expiring' : $onlyExpiring=true; break;
  
   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 if($dateFrom == "always")
  $dateFrom = "0000-00-00";
 else if($dateFrom == "today")
  $dateFrom = date("Y-m-d");
 $dateFrom = strtotime($dateFrom ? $dateFrom : date('Y-m')."-01");

 if($dateTo == "today")
  $dateTo = date('Y-m-d');
 $dateTo = $dateTo ? strtotime($dateTo) : strtotime("+1 month",$dateFrom);
 $dateTo = strtotime(date('Y-m-d',$dateTo)." 23:59:59");

 $outArr['date_from'] = $dateFrom;
 $outArr['date_to'] = $dateTo;
 $outArr['tot_expired'] = 0;
 $outArr['tot_expiring'] = 0;
 $outArr['tot_paid'] = 0;
 $outArr['tot_unpaid'] = 0;
 
 if(!count($archives))
 {
  $db = new AlpaDatabase();
  $db2 = new AlpaDatabase();
  $db->RunQuery("SELECT archive_id FROM dynarc_archive_extensions WHERE extension_name='schedule'");
  while($db->Read())
  {
   $db2->RunQuery("SELECT tb_prefix FROM dynarc_archives WHERE id='".$db->record['archive_id']."'");
   $db2->Read();
   if(!in_array($db2->record['tb_prefix'],$archives))
    $archives[] = $db2->record['tb_prefix'];
  }
  $db2->Close();
  $db->Close();
 }

 if($verbose)
 {
  $out.= "List of results from ".date('d/m/Y',$dateFrom)." to ".date('d/m/Y',$dateTo);
  if(count($archives) > 1)
  {
   $out.= " from these archives:\n";
   for($c=0; $c < count($archives); $c++)
	$out.= " - ".$archives[$c]."\n";
  }
  else
   $out.= " from archive '".$archives[0]."':\n";
 }

 //----------------------------------------------------------------------------------------------//
 $db = new AlpaDatabase();
 $db2 = new AlpaDatabase();
 for($c=0; $c < count($archives); $c++)
 {
  $_AP = $archives[$c];
  if((count($archives) == 1) && $_ID)
   $qry = "SELECT * FROM dynarc_".$_AP."_items WHERE id='".$_ID."'";
  else
  {
   $qry = "SELECT * FROM dynarc_".$_AP."_items WHERE trash='0' AND freq>0 AND ctime<'"
	.date('Y-m-d',$dateTo)."' AND (finish_date='0000-00-00' OR finish_date>'".date('Y-m-d',$dateFrom)."')";
   
   if($subjectId)
	$qry.= " AND subject_id='".$subjectId."'";
   else if($subjectName)
	$qry.= " AND subject_name='".$db->Purify($subjectName)."'";

   if($where) $qry.= " AND (".$where.")";
   $qry.= " ORDER BY ".$orderBy.($limit ? " LIMIT ".$limit : "");  
  }
  $db->RunQuery($qry);
  while($db->Read())
  {
   $db->record['ctime'] = date('Y-m-d',strtotime($db->record['ctime']));
   switch($db->record['freq'])
   {
	case 12 : {
	 /* YEARLY */
	 $diff = ($dateFrom - strtotime($db->record['ctime'])) / 86400;
	 $diff = floor($diff/365);
	 if($diff > 0)
	  $p = strtotime("+".$diff." year", strtotime($db->record['ctime']));
	 else
	  $p = strtotime("-".(-$diff)." year", strtotime($db->record['ctime'])); 
	} break;
   
    default : {
	 /* MONTHLY */
	 $diff = ($dateFrom - strtotime($db->record['ctime'])) / 86400;
	 $diff = floor(($diff/30)%12);
	 if($diff > 0)
	  $p = strtotime("+".$diff." month", strtotime($db->record['ctime']));
	 else
	  $p = strtotime("-".(-$diff)." month", strtotime($db->record['ctime'])); 
	} break;

   }
   //------------------------------------------------------------------------//
   while($p < $dateTo)
   {
    if(($p >= $dateFrom) && ($p < $dateTo) && ($p >= strtotime($db->record['ctime'])) && (date('Y-m',$p) != date('Y-m',strtotime($db->record['ctime']))))
	{
	 $a = array(
		"ap"=>$_AP,
		"id"=>$db->record['id'], 
		"name"=>$db->record['name'], 
		"aliasname"=>$db->record['aliasname'],
		"expiry_date"=>date('Y-m-d',$p), 
		"amount"=>$db->record['amount'], 
		"paid"=>false, 
		"expired"=>false, 
		"subject_id"=>$db->record['subject_id'], 
		"subject_name"=>$db->record['subject_name'], 
		"vendor_id"=>$db->record['vendor_id'], 
		"vendor_name"=>$db->record['vendor_name']
		);

	 if($_AP == "commercialdocs")
	  $a['amount'] = $db->record['tot_netpay'];

	 $pFrom = date('Y-m',$p)."-01";
	 $pTo = date('Y-m-d',strtotime("+1 month",strtotime($pFrom)));

	 // verifica se è stata pagata //
	 $db2->RunQuery("SELECT id,expiry_date,payment_date,amount,payment_method,receipt_of_payment,notes,refer FROM dynarc_".$_AP."_schedule WHERE item_id='"
		.$db->record['id']."' AND expiry_date>='".$pFrom."' AND expiry_date<'".$pTo."'");
	 if($db2->Read())
	 {
	  $a['expiry_date'] = $db2->record['expiry_date'];
	  $a['payment_date'] = $db2->record['payment_date'];
	  if($a['payment_date'] && ($a['payment_date'] != "0000-00-00"))
	   $a['paid'] = true;
	  $a['amount'] = $db2->record['amount'];
	  $a['payment_method'] = $db2->record['payment_method'];
	  $a['receipt_of_payment'] = $db2->record['receipt_of_payment'];
	  $a['notes'] = $db2->record['notes'];
	  $a['refer'] = $db2->record['refer'];
	 }
	 if(strtotime($a['expiry_date']) <= time())
	  $a['expired'] = true;

	 if($onlyExpired && (!$a['expired'] || $a['paid']))
	 {
	  /* nothing to do */
	  $bypassed = true;
	 }
	 else if($onlyExpiring && ($a['expired'] || $a['paid']))
	 {
	  /* nothing to do */
	  $bypassed = true;
	 }
	 else
	 {
      $outArr['results'][] = $a;
	  if($a['expired'] && !$a['paid'])
	   $outArr['tot_expired']+= $a['amount'];
	  else if(!$a['expired'] && !$a['paid'])
	   $outArr['tot_expiring']+= $a['amount'];
	  else if($a['paid'])
	   $outArr['tot_paid']+= $a['amount'];

	  if($verbose)
	   $out.= date('d/m/Y',strtotime($a['expiry_date']))." - ".$a['name']." (".number_format($a['amount'],2,",",".").") "
		.($a['paid'] ? "[pagata il ".date('d/m/Y',strtotime($a['payment_date']))."]" : "")."\n";
	 }
	}
    if($db->record['freq'] == 12)
	 $p = strtotime("+1 year",$p);
	else
	 $p = strtotime("+".$db->record['freq']." months",$p);
   }
   //------------------------------------------------------------------------//
  }
 }
 $db2->Close();
 $db->Close();
 $outArr['tobepaid'] = $outArr['tot_expired']+$outArr['tot_expiring'];
 //----------------------------------------------------------------------------------------------//
 $out.= "\n".count($outArr['results'])." results found.\n";

 return array("message"=>$out, "outarr"=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function shell_scheduleHistory($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array("results"=>array());
 $orderBy = "expiry_date ASC";

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break; /* ARCHIVE PREFIX */
   case '-id' : {$_ID=$args[$c+1]; $c++;} break; /* DOCUMENT ID */
   case '-orderby' : case '--order-by' : {$orderBy=$args[$c+1]; $c++;} break;
   case '-verbose' : case '--verbose' : $verbose=true; break;
  }

 $out.= "History for document #".$_ID."\n";
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT * FROM dynarc_".$_AP."_schedule WHERE item_id='".$_ID."' ORDER BY ".$orderBy);
 while($db->Read())
 {
  $a = array("id"=>$db->record['id'], "expiry_date"=>$db->record['expiry_date'], "payment_date"=>$db->record['payment_date'],
	"amount"=>$db->record['amount'], "payment_method"=>$db->record['payment_method'], "receipt"=>$db->record['receipt_of_payment'],
	"notes"=>$db->record['notes'], "refer"=>$db->record['refer']);
  $outArr['results'][] = $a;
  if($verbose)
   $out.= "Expiry: ".date('d/m/Y',strtotime($a['expiry_date']))." Payment: ".date('d/m/Y',strtotime($a['payment_date']))." Amount: "
	.number_format($a['amount'],2,",",".")."\n";
 }
 $db->Close();
 $out.= "\n".count($outArr['results'])." results found.";

 return array("message"=>$out, "outarr"=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function shell_scheduleAdd($args, $sessid, $shellid)
{
 $out = "";
 $outArr = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_ID=$args[$c+1]; $c++;} break; /* ID del documento */

   case '-expiry' : case '-expiry-date' : {$expiryDate=$args[$c+1]; $c++;} break;
   case '-payment' : case '-payment-date' : {$paymentDate=$args[$c+1]; $c++;} break;
   case '-amount' : {$amount=$args[$c+1]; $c++;} break;
   case '-payment-method' : {$paymentMethod=$args[$c+1]; $c++;} break;
   case '-receipt' : {$receiptOfPayment=$args[$c+1]; $c++;} break;
   case '-notes' : {$notes=$args[$c+1]; $c++;} break;
   case '-refer' : {$refer=$args[$c+1]; $c++;} break;
  }

 if(!$_AP)
  return array("message"=>"You must specify the archive prefix. (with: -ap ARCHIVE_PREFIX)", "error"=>"INVALID_ARCHIVE");
 if(!$_ID)
  return array("message"=>"You must specify the document id. (with: -id DOCUMENT_ID)", "error"=>"INVALID_DOCUMENT");

 $db = new AlpaDatabase();
 $db->RunQuery("INSERT INTO dynarc_".$_AP."_schedule(item_id,expiry_date,payment_date,amount,payment_method,receipt_of_payment,notes,refer) VALUES('"
	.$_ID."','".$expiryDate."','".$paymentDate."','".$amount."','".$paymentMethod."','".$receiptOfPayment."','".$db->Purify($notes)."','"
	.$db->Purify($refer)."')");
 $recId = $db->GetInsertId();
 $db->Close();

 $out.= "Record has been inserted. ID=".$recId;
 $outArr = array("id"=>$recId, "expiry_date"=>$expiryDate, "payment_date"=>$paymentDate, "amount"=>$amount, "payment_method"=>$paymentMethod, "receipt"=>$receiptOfPayment, "notes"=>$notes, "refer"=>$refer);

 // aggiorna la prossima data di scadenza //
 $db = new AlpaDatabase();
 $db->RunQuery("SELECT freq FROM dynarc_".$_AP."_items WHERE id='".$_ID."'");
 $db->Read();
 if($db->record['freq'] == 12)
  $nextExpiry = strtotime("+1 year",strtotime($expiryDate));
 else if($db->record['freq'])
  $nextExpiry = strtotime("+".$db->record['freq']." months",strtotime($expiryDate));

 if($nextExpiry > time())
  $db->RunQuery("UPDATE dynarc_".$_AP."_items SET next_expiry='".date('Y-m-d',$nextExpiry)."' WHERE id='".$_ID."'");

 $db->Close();

 return array("message"=>$out, "outarr"=>$outArr);
}
//-------------------------------------------------------------------------------------------------------------------//
function shell_scheduleEdit($args, $sessid, $shellid)
{
 $out = "";

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-id' : {$_ID=$args[$c+1]; $c++;} break; /* ID del record, non del documento */

   case '-expiry' : case '-expiry-date' : {$expiryDate=$args[$c+1]; $c++;} break;
   case '-payment' : case '-payment-date' : {$paymentDate=$args[$c+1]; $c++;} break;
   case '-amount' : {$amount=$args[$c+1]; $c++;} break;
   case '-payment-method' : {$paymentMethod=$args[$c+1]; $c++;} break;
   case '-receipt' : {$receiptOfPayment=$args[$c+1]; $c++;} break;
   case '-notes' : {$notes=$args[$c+1]; $c++;} break;
   case '-refer' : {$refer=$args[$c+1]; $c++;} break;
  }

 if(!$_AP)
  return array("message"=>"You must specify the archive prefix. (with: -ap ARCHIVE_PREFIX)", "error"=>"INVALID_ARCHIVE");
 if(!$_ID)
  return array("message"=>"You must specify the record id. (with: -id RECORD_ID)", "error"=>"INVALID_RECORD");

 $db = new AlpaDatabase();
 $q = "";
 if($expiryDate)
  $q.= ",expiry_date='".$expiryDate."'";
 if($paymentDate)
  $q.= ",payment_date='".$paymentDate."'";
 if(isset($amount))
  $q.= ",amount='".$amount."'";
 if(isset($paymentMethod))
  $q.= ",payment_method='".$paymentMethod."'";
 if(isset($receiptOfPayment))
  $q.= ",receipt_of_payment='".$receiptOfPayment."'";
 if(isset($notes))
  $q.= ",notes='".$db->Purify($notes)."'";
 if(isset($refer))
  $q.= ",refer='".$db->Purify($refer)."'";

 if($q)
  $db->RunQuery("UPDATE dynarc_".$_AP."_schedule SET ".ltrim($q,",")." WHERE id='".$_ID."'");
 $db->Close();

 $out.= "Record has been updated.";

 return array("message"=>$out);
}
//-------------------------------------------------------------------------------------------------------------------//
function shell_scheduleDelete($args, $sessid, $shellid)
{
 $out = "";
 $ids = array();

 for($c=1; $c < count($args); $c++)
  switch($args[$c])
  {
   case '-ap' : {$_AP=$args[$c+1]; $c++;} break;
   case '-refid' : case '-docid' : {$refId=$args[$c+1]; $c++;} break; /* ID del documento (se specificato verranno rimossi tutti i records di quel doc.) */
   case '-id' : {$ids[]=$args[$c+1]; $c++;} break; /* ID dei singoli record da rimuovere */
  }

 if(!$_AP)
  return array("message"=>"You must specify the archive prefix. (with: -ap ARCHIVE_PREFIX)", "error"=>"INVALID_ARCHIVE");

 if($refId)
 {
  $out.= "Will'be removed all records from the document #".$refId."\n";
  $db = new AlpaDatabase();
  $db->RunQuery("SELECT COUNT(*) FROM dynarc_".$_AP."_schedule WHERE item_id='".$refId."'");
  $db->Read();
  $count = $db->record[0];
  $db->RunQuery("DELETE FROM dynarc_".$_AP."_schedule WHERE item_id='".$refId."'");
  $db->Close();
  $out.= $count." record has been removed!";
 }
 else
 {
  if(!count($ids))
   return array("message"=>"You must specify at least one record to remove.", "error"=>"INVALID_RECORD");
  $db = new AlpaDatabase();
  for($c=0; $c < count($ids); $c++)
   $db->RunQuery("DELETE FROM dynarc_".$_AP."_schedule WHERE id='".$ids[$c]."'");
  $db->Close();
  $out.= count($ids)." records has been removed.";
 }

 return array("message"=>$out);
}
//-------------------------------------------------------------------------------------------------------------------//

